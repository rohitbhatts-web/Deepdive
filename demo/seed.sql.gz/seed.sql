BEGIN TRANSACTION;
CREATE TABLE audit_events (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    event_type TEXT NOT NULL,
    stage TEXT NOT NULL,
    created_at TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}'
);
INSERT INTO "audit_events" VALUES(1,1,'run_created','api','2026-10-22T13:58:14+00:00','{"question": "When were HTTP/2 and HTTP/3 published as RFCs, and how do their transport layers differ?"}');
INSERT INTO "audit_events" VALUES(2,1,'research_started','graph','2026-10-22T13:58:14+00:00','{"limits": {"model_requests": [0, 40], "search_queries": [0, 8], "page_fetches": [0, 12], "candidate_claims": [0, 4], "output_tokens": [0, 30000], "elapsed_seconds": [0.0, 600.0]}, "search_allocation": {"total": [0, 8], "initial": [0, 6], "corrective": [0, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}, "structured_output_models": ["anthropic/claude-haiku-4.5", "qwen/qwen3-235b-a22b-instruct-2507"]}');
INSERT INTO "audit_events" VALUES(3,1,'plan_created','planner','2026-10-22T13:59:00+00:00','{"asks": [{"quote": "When were HTTP/2 and HTTP/3 published as RFCs", "label": "publication dates of HTTP/2 and HTTP/3 RFCs"}, {"quote": "how do their transport layers differ", "label": "difference in transport layers"}], "subquestions": [{"id": 1, "question": "What is the publication date of the HTTP/2 specification as an RFC?", "rationale": "To determine when HTTP/2 was officially standardized."}, {"id": 2, "question": "What is the publication date of the HTTP/3 specification as an RFC?", "rationale": "To determine when HTTP/3 was officially standardized."}, {"id": 3, "question": "Which transport layer protocol does HTTP/2 use?", "rationale": "To understand the underlying transport mechanism of HTTP/2."}, {"id": 4, "question": "Which transport layer protocol does HTTP/3 use and how does it differ from HTTP/2''s transport?", "rationale": "To identify the key difference in transport layers between HTTP/2 and HTTP/3."}], "truncated_from": null}');
INSERT INTO "audit_events" VALUES(4,1,'queries_generated','researcher','2026-10-22T13:59:08+00:00','{"subquestion_id": 1, "queries": ["HTTP/2 RFC publication date official specification"], "rationale": "These queries target the official RFC documentation to identify both the publication date and the RFC number for the HTTP/2 specification.", "purpose": "initial", "initial_share": 1, "focus": null}');
INSERT INTO "audit_events" VALUES(5,1,'search_completed','researcher','2026-10-22T13:59:10+00:00','{"subquestion_id": 1, "query": "HTTP/2 RFC publication date official specification", "search_id": 1, "hits": 5}');
INSERT INTO "audit_events" VALUES(6,1,'urls_selected','researcher','2026-10-22T13:59:20+00:00','{"subquestion_id": 1, "selected": [{"url": "https://datatracker.ietf.org/doc/html/rfc9113", "reason": "This is the official RFC 9113 document for HTTP/2, which provides the definitive publication date (June 2022) and confirms it obsoletes RFC 7540, the original HTTP/2 specification."}]}');
INSERT INTO "audit_events" VALUES(7,1,'source_ingested','ingest','2026-10-22T13:59:21+00:00','{"url": "https://datatracker.ietf.org/doc/html/rfc9113", "final_url": "https://datatracker.ietf.org/doc/html/rfc9113", "source_id": 1, "passages": 200, "snapshot_chars": 170502, "redirects": []}');
INSERT INTO "audit_events" VALUES(8,1,'subquestion_done','researcher','2026-10-22T13:59:21+00:00','{"subquestion_id": 1, "status": "evidence_collected", "reason": null}');
INSERT INTO "audit_events" VALUES(9,1,'queries_generated','researcher','2026-10-22T13:59:30+00:00','{"subquestion_id": 2, "queries": ["HTTP/3 RFC publication date official specification"], "rationale": "These queries target the official RFC publication date and the RFC number for HTTP/3 by referencing authoritative sources.", "purpose": "initial", "initial_share": 1, "focus": null}');
INSERT INTO "audit_events" VALUES(10,1,'search_completed','researcher','2026-10-22T13:59:32+00:00','{"subquestion_id": 2, "query": "HTTP/3 RFC publication date official specification", "search_id": 2, "hits": 5}');
INSERT INTO "audit_events" VALUES(11,1,'urls_selected','researcher','2026-10-22T13:59:59+00:00','{"subquestion_id": 2, "selected": [{"url": "https://en.wikipedia.org/wiki/HTTP/3", "reason": "States that HTTP/3 was published as RFC 9114 on 6 June 2022, providing both the RFC number and publication date."}, {"url": "https://datatracker.ietf.org/doc/draft-ietf-quic-http/33", "reason": "Confirms the document was ultimately published as RFC 9114, giving context to the final RFC number and its development timeline."}, {"url": "https://news.ycombinator.com/item?id=31647033", "reason": "Mentions the publication of RFC 9114 and notes the date context around June 7, 2022, supporting the publication date of the HTTP/3 specification."}]}');
INSERT INTO "audit_events" VALUES(12,1,'source_ingested','ingest','2026-10-22T14:00:00+00:00','{"url": "https://en.wikipedia.org/wiki/HTTP/3", "final_url": "https://en.wikipedia.org/wiki/HTTP/3", "source_id": 2, "passages": 19, "snapshot_chars": 16771, "redirects": []}');
INSERT INTO "audit_events" VALUES(13,1,'source_ingested','ingest','2026-10-22T14:00:01+00:00','{"url": "https://datatracker.ietf.org/doc/draft-ietf-quic-http/33", "final_url": "https://datatracker.ietf.org/doc/draft-ietf-quic-http/33/", "source_id": 3, "passages": 164, "snapshot_chars": 148508, "redirects": ["https://datatracker.ietf.org/doc/draft-ietf-quic-http/33/"]}');
INSERT INTO "audit_events" VALUES(14,1,'source_ingested','ingest','2026-10-22T14:00:03+00:00','{"url": "https://news.ycombinator.com/item?id=31647033", "final_url": "https://news.ycombinator.com/item?id=31647033", "source_id": 4, "passages": 41, "snapshot_chars": 36140, "redirects": []}');
INSERT INTO "audit_events" VALUES(15,1,'subquestion_done','researcher','2026-10-22T14:00:03+00:00','{"subquestion_id": 2, "status": "evidence_collected", "reason": null}');
INSERT INTO "audit_events" VALUES(16,1,'queries_generated','researcher','2026-10-22T14:00:11+00:00','{"subquestion_id": 3, "queries": ["HTTP/2 transport layer protocol official documentation", "how does HTTP/2 use TCP specification"], "rationale": "These queries target the official specifications and technical descriptions to identify the transport protocol used by HTTP/2 and explain how it utilizes TCP.", "purpose": "initial", "initial_share": 2, "focus": null}');
INSERT INTO "audit_events" VALUES(17,1,'search_completed','researcher','2026-10-22T14:00:13+00:00','{"subquestion_id": 3, "query": "HTTP/2 transport layer protocol official documentation", "search_id": 3, "hits": 5}');
INSERT INTO "audit_events" VALUES(18,1,'search_completed','researcher','2026-10-22T14:00:15+00:00','{"subquestion_id": 3, "query": "how does HTTP/2 use TCP specification", "search_id": 4, "hits": 5}');
INSERT INTO "audit_events" VALUES(19,1,'urls_selected','researcher','2026-10-22T14:00:42+00:00','{"subquestion_id": 3, "selected": [{"url": "https://datatracker.ietf.org/doc/html/rfc9113", "reason": "This is the official IETF specification for HTTP/2, which directly states that HTTP/2 uses TCP and describes how it operates over a single, persistent TCP connection for multiplexed communication."}, {"url": "https://http2.github.io", "reason": "This page references the core HTTP/2 specifications including RFC 9113, providing authoritative links and context on how HTTP/2 uses TCP for efficient, multiplexed transport."}, {"url": "https://www.imperva.com/learn/performance/http2", "reason": "This reputable explanatory article describes how HTTP/2 uses a single TCP connection to enable multiplexing, solving inefficiencies present in HTTP/1.1."}]}');
INSERT INTO "audit_events" VALUES(20,1,'source_duplicate','ingest','2026-10-22T14:00:42+00:00','{"url": "https://datatracker.ietf.org/doc/html/rfc9113", "outcome": "duplicate_url", "source_id": 1}');
INSERT INTO "audit_events" VALUES(21,1,'source_ingested','ingest','2026-10-22T14:00:42+00:00','{"url": "https://http2.github.io", "final_url": "https://http2.github.io", "source_id": 5, "passages": 2, "snapshot_chars": 1189, "redirects": []}');
INSERT INTO "audit_events" VALUES(22,1,'source_ingested','ingest','2026-10-22T14:00:48+00:00','{"url": "https://www.imperva.com/learn/performance/http2", "final_url": "https://www.imperva.com/learn/performance/http2/", "source_id": 6, "passages": 6, "snapshot_chars": 5514, "redirects": ["https://www.imperva.com/learn/performance/http2/"]}');
INSERT INTO "audit_events" VALUES(23,1,'subquestion_done','researcher','2026-10-22T14:00:48+00:00','{"subquestion_id": 3, "status": "evidence_collected", "reason": null}');
INSERT INTO "audit_events" VALUES(24,1,'queries_generated','researcher','2026-10-22T14:01:01+00:00','{"subquestion_id": 4, "queries": ["What transport protocol does HTTP/3 use instead of TCP", "How does HTTP/3 use QUIC compared to HTTP/2''s TCP"], "rationale": "These queries target the specific transport protocol used by HTTP/3 (QUIC) and highlight the difference from HTTP/2''s use of TCP, focusing on the shift from TCP to QUIC.", "purpose": "initial", "initial_share": 2, "focus": null}');
INSERT INTO "audit_events" VALUES(25,1,'search_completed','researcher','2026-10-22T14:01:03+00:00','{"subquestion_id": 4, "query": "What transport protocol does HTTP/3 use instead of TCP", "search_id": 5, "hits": 5}');
INSERT INTO "audit_events" VALUES(26,1,'search_completed','researcher','2026-10-22T14:01:06+00:00','{"subquestion_id": 4, "query": "How does HTTP/3 use QUIC compared to HTTP/2''s TCP", "search_id": 6, "hits": 5}');
INSERT INTO "audit_events" VALUES(27,1,'urls_selected','researcher','2026-10-22T14:01:28+00:00','{"subquestion_id": 4, "selected": [{"url": "https://en.wikipedia.org/wiki/HTTP/3", "reason": "Provides the name of the transport protocol used by HTTP/3 and explains its use of QUIC instead of TCP."}, {"url": "https://www.cloudflare.com/learning/performance/what-is-http3", "reason": "Describes HTTP/3''s use of QUIC over UDP and contrasts it with TCP used in previous versions."}, {"url": "https://www.fastly.com/learning/what-is-http-3", "reason": "Explains that HTTP/3 uses QUIC as its [withheld], and details how it changes connection management."}]}');
INSERT INTO "audit_events" VALUES(28,1,'source_duplicate','ingest','2026-10-22T14:01:28+00:00','{"url": "https://en.wikipedia.org/wiki/HTTP/3", "outcome": "duplicate_url", "source_id": 2}');
INSERT INTO "audit_events" VALUES(29,1,'source_ingested','ingest','2026-10-22T14:01:30+00:00','{"url": "https://www.cloudflare.com/learning/performance/what-is-http3", "final_url": "https://www.cloudflare.com/learning/performance/what-is-http3/", "source_id": 7, "passages": 6, "snapshot_chars": 4993, "redirects": ["https://www.cloudflare.com/learning/performance/what-is-http3/"]}');
INSERT INTO "audit_events" VALUES(30,1,'source_ingested','ingest','2026-10-22T14:01:31+00:00','{"url": "https://www.fastly.com/learning/what-is-http-3", "final_url": "https://www.fastly.com/learning/what-is-http-3", "source_id": 8, "passages": 13, "snapshot_chars": 10672, "redirects": []}');
INSERT INTO "audit_events" VALUES(31,1,'subquestion_done','researcher','2026-10-22T14:01:31+00:00','{"subquestion_id": 4, "status": "evidence_collected", "reason": null}');
INSERT INTO "audit_events" VALUES(32,1,'association_failed','relevance','2026-10-22T14:02:31+00:00','{"warning": "optional cross-subquestion association failed; direct source-subquestion links were kept", "error_type": "ModelCallError", "error": "Mesh call failed for model ''qwen/qwen3-235b-a22b-instruct-2507'': TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)"}');
INSERT INTO "audit_events" VALUES(33,1,'research_finished','graph','2026-10-22T14:02:31+00:00','{"status": "collection_finished", "stop_reason": null, "unresolved_subquestions": [], "budget_used_of_limit": {"model_requests": [10, 40], "search_queries": [6, 8], "page_fetches": [8, 12], "candidate_claims": [0, 4], "output_tokens": [2662, 30000], "elapsed_seconds": [257.2, 600.0]}, "search_allocation": {"total": [6, 8], "initial": [6, 6], "corrective": [0, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}}');
INSERT INTO "audit_events" VALUES(34,1,'draft_input','drafter','2026-10-22T14:02:31+00:00','{"passages_offered": {"1": ["S1-P2", "S1-P57", "S1-P154", "S1-P0"], "2": ["S2-P2", "S2-P9", "S2-P11", "S2-P0"], "3": ["S1-P11", "S1-P177"]}, "chars": 8985, "mode": "overlap"}');
INSERT INTO "audit_events" VALUES(35,1,'verification_finished','graph','2026-10-22T14:03:31+00:00','{"status": "failed", "stop_reason": "drafter failed: Mesh call failed for model ''qwen/qwen3-235b-a22b-instruct-2507'': TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)", "claims": {"claims": 0, "by_status": {}, "by_integrity": {}, "by_semantic": {}, "eligible_for_report": 0}, "budget_used_of_limit": {"model_requests": [11, 40], "search_queries": [6, 8], "page_fetches": [8, 12], "candidate_claims": [0, 4], "output_tokens": [4162, 30000], "elapsed_seconds": [317.3, 600.0]}}');
INSERT INTO "audit_events" VALUES(36,1,'completion_finished','graph','2026-10-22T14:03:31+00:00','{"status": "failed", "stop_reason": "drafter failed: Mesh call failed for model ''qwen/qwen3-235b-a22b-instruct-2507'': TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)", "report_id": null, "corrective_rounds": 0, "budget_used_of_limit": {"model_requests": [11, 40], "search_queries": [6, 8], "page_fetches": [8, 12], "candidate_claims": [0, 4], "output_tokens": [4162, 30000], "elapsed_seconds": [317.3, 600.0]}, "search_allocation": {"total": [6, 8], "initial": [6, 6], "corrective": [0, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}}');
INSERT INTO "audit_events" VALUES(37,2,'run_created','api','2026-10-22T14:03:31+00:00','{"question": "Has Mistral AI publicly reported a net profit or loss for fiscal year 2024, and if so, what is the figure and which primary source states it?"}');
INSERT INTO "audit_events" VALUES(38,2,'research_started','graph','2026-10-22T14:03:31+00:00','{"limits": {"model_requests": [0, 40], "search_queries": [0, 8], "page_fetches": [0, 12], "candidate_claims": [0, 4], "output_tokens": [0, 30000], "elapsed_seconds": [0.0, 600.0]}, "search_allocation": {"total": [0, 8], "initial": [0, 6], "corrective": [0, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}, "structured_output_models": ["anthropic/claude-haiku-4.5", "qwen/qwen3-235b-a22b-instruct-2507"]}');
INSERT INTO "audit_events" VALUES(39,2,'plan_created','planner','2026-10-22T14:04:28+00:00','{"asks": [{"quote": "Has Mistral AI publicly reported a net profit or loss for fiscal year 2024", "label": "profit or loss reported"}, {"quote": "what is the figure", "label": "net profit or loss figure"}, {"quote": "which primary source states it", "label": "primary source"}], "subquestions": [{"id": 5, "question": "Has Mistral AI released an official financial statement or annual report for fiscal year 2024 that includes net profit or loss?", "rationale": "Determines whether the company has made any public disclosure of its financial performance for the relevant period."}, {"id": 6, "question": "What is the net profit or net loss reported by Mistral AI for fiscal year 2024, if any?", "rationale": "Identifies the specific financial figure that answers the user''s query about performance."}, {"id": 7, "question": "Is there an official, publicly accessible document\u2014such as an annual report, press release, or regulatory filing\u2014published by Mistral AI that discloses the financial results for fiscal year 2024?", "rationale": "Establishes the existence and identity of a primary source that can be referenced."}], "truncated_from": null}');
INSERT INTO "audit_events" VALUES(40,2,'queries_generated','researcher','2026-10-22T14:04:38+00:00','{"subquestion_id": 5, "queries": ["Mistral AI official financial statement 2024 release", "Mistral AI annual report 2024 net profit or loss"], "rationale": "These queries target whether Mistral AI has published an official financial report for 2024 and whether it includes net profit or loss data, focusing on authoritative sources like official announcements.", "purpose": "initial", "initial_share": 2, "focus": null}');
INSERT INTO "audit_events" VALUES(41,2,'search_completed','researcher','2026-10-22T14:04:41+00:00','{"subquestion_id": 5, "query": "Mistral AI official financial statement 2024 release", "search_id": 7, "hits": 5}');
INSERT INTO "audit_events" VALUES(42,2,'search_completed','researcher','2026-10-22T14:04:45+00:00','{"subquestion_id": 5, "query": "Mistral AI annual report 2024 net profit or loss", "search_id": 8, "hits": 5}');
INSERT INTO "audit_events" VALUES(43,2,'result_skipped','researcher','2026-10-22T14:04:45+00:00','{"subquestion_id": 5, "search_id": 8, "url": "https://www.msci.com/downloads/web/msci-com/annuals-and-proxies/2024-annual-report/MSCI%202024%20Annual%20Report.pdf", "reason": "pdf_not_supported"}');
INSERT INTO "audit_events" VALUES(44,2,'result_skipped','researcher','2026-10-22T14:04:45+00:00','{"subquestion_id": 5, "search_id": 8, "url": "https://ir.mi.com/system/files-encrypted/nasdaq_kms/assets/2025/03/18/5-38-56/%E8%8B%B1%E6%96%87%E5%85%AC%E5%91%8A.pdf", "reason": "pdf_not_supported"}');
INSERT INTO "audit_events" VALUES(45,2,'result_skipped','researcher','2026-10-22T14:04:45+00:00','{"subquestion_id": 5, "search_id": 8, "url": "https://filecache.investorroom.com/mr5ir_genuineparts/978/2024%20Annual%20Report.pdf", "reason": "pdf_not_supported"}');
INSERT INTO "audit_events" VALUES(46,2,'urls_selected','researcher','2026-10-22T14:04:48+00:00','{"subquestion_id": 5, "selected": []}');
INSERT INTO "audit_events" VALUES(47,2,'subquestion_done','researcher','2026-10-22T14:04:48+00:00','{"subquestion_id": 5, "status": "collection_incomplete", "reason": "none of the selected pages could be collected"}');
INSERT INTO "audit_events" VALUES(48,2,'queries_generated','researcher','2026-10-22T14:05:00+00:00','{"subquestion_id": 6, "queries": ["Mistral AI net profit 2024 fiscal year reported financial results", "Mistral AI net loss 2024 official financial statement release"], "rationale": "These queries target publicly reported financial statements or official announcements from Mistral AI that would include the net profit or loss for fiscal year 2024, specifying currency and time period.", "purpose": "initial", "initial_share": 2, "focus": null}');
INSERT INTO "audit_events" VALUES(49,2,'search_completed','researcher','2026-10-22T14:05:04+00:00','{"subquestion_id": 6, "query": "Mistral AI net profit 2024 fiscal year reported financial results", "search_id": 9, "hits": 5}');
INSERT INTO "audit_events" VALUES(50,2,'search_completed','researcher','2026-10-22T14:05:06+00:00','{"subquestion_id": 6, "query": "Mistral AI net loss 2024 official financial statement release", "search_id": 10, "hits": 5}');
INSERT INTO "audit_events" VALUES(51,2,'urls_selected','researcher','2026-10-22T14:05:10+00:00','{"subquestion_id": 6, "selected": []}');
INSERT INTO "audit_events" VALUES(52,2,'subquestion_done','researcher','2026-10-22T14:05:10+00:00','{"subquestion_id": 6, "status": "collection_incomplete", "reason": "none of the selected pages could be collected"}');
INSERT INTO "audit_events" VALUES(53,2,'queries_generated','researcher','2026-10-22T14:05:39+00:00','{"subquestion_id": 7, "queries": ["Mistral AI official annual report 2024 financial results", "Mistral AI press release or regulatory filing fiscal year 2024 financial disclosure"], "rationale": "These queries target official documents published by Mistral AI or an authorized entity that would contain disclosed financial results for fiscal year 2024, such as annual reports, press releases, or regulatory filings, with the aim of identifying title, date, and source link.", "purpose": "initial", "initial_share": 2, "focus": null}');
INSERT INTO "audit_events" VALUES(54,2,'search_completed','researcher','2026-10-22T14:05:42+00:00','{"subquestion_id": 7, "query": "Mistral AI official annual report 2024 financial results", "search_id": 11, "hits": 5}');
INSERT INTO "audit_events" VALUES(55,2,'result_skipped','researcher','2026-10-22T14:05:42+00:00','{"subquestion_id": 7, "search_id": 11, "url": "https://siliconvalleyinvestclub.com/companies/mistral/tear-sheet.pdf", "reason": "pdf_not_supported"}');
INSERT INTO "audit_events" VALUES(56,2,'search_completed','researcher','2026-10-22T14:05:46+00:00','{"subquestion_id": 7, "query": "Mistral AI press release or regulatory filing fiscal year 2024 financial disclosure", "search_id": 12, "hits": 5}');
INSERT INTO "audit_events" VALUES(57,2,'urls_selected','researcher','2026-10-22T14:05:52+00:00','{"subquestion_id": 7, "selected": []}');
INSERT INTO "audit_events" VALUES(58,2,'subquestion_done','researcher','2026-10-22T14:05:52+00:00','{"subquestion_id": 7, "status": "collection_incomplete", "reason": "none of the selected pages could be collected"}');
INSERT INTO "audit_events" VALUES(59,2,'association_skipped','relevance','2026-10-22T14:05:52+00:00','{"reason": "no source has passages overlapping another subquestion''s requirements"}');
INSERT INTO "audit_events" VALUES(60,2,'research_finished','graph','2026-10-22T14:05:52+00:00','{"status": "collection_finished", "stop_reason": null, "unresolved_subquestions": [], "budget_used_of_limit": {"model_requests": [7, 40], "search_queries": [6, 8], "page_fetches": [0, 12], "candidate_claims": [0, 4], "output_tokens": [649, 30000], "elapsed_seconds": [140.3, 600.0]}, "search_allocation": {"total": [6, 8], "initial": [6, 6], "corrective": [0, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}}');
INSERT INTO "audit_events" VALUES(61,2,'draft_skipped','drafter','2026-10-22T14:05:52+00:00','{"reason": "no subquestion has linked passages"}');
INSERT INTO "audit_events" VALUES(62,2,'verification_finished','graph','2026-10-22T14:05:52+00:00','{"status": "completed", "stop_reason": null, "claims": {"claims": 0, "by_status": {}, "by_integrity": {}, "by_semantic": {}, "eligible_for_report": 0}, "budget_used_of_limit": {"model_requests": [7, 40], "search_queries": [6, 8], "page_fetches": [0, 12], "candidate_claims": [0, 4], "output_tokens": [649, 30000], "elapsed_seconds": [140.3, 600.0]}}');
INSERT INTO "audit_events" VALUES(63,2,'obligations_derived','coverage','2026-10-22T14:05:56+00:00','{"requirements": 7, "derived": 7, "fallback": 0, "model": "anthropic/claude-haiku-4.5", "unknown_requirement_keys": []}');
INSERT INTO "audit_events" VALUES(64,2,'coverage_assessed','coverage','2026-10-22T14:05:56+00:00','{"round": 0, "requirements": 7, "obligations": 7, "model": null, "eligible_claim_ids": []}');
INSERT INTO "audit_events" VALUES(65,2,'coverage_routed','coverage','2026-10-22T14:05:56+00:00','{"round": 0, "summary": {"addressed": 0, "partially_addressed": 0, "unresolved": 7, "requirements": 7, "fully_addressed": false}, "tasks": [{"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q5.R1", "skipped": null}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q5.R2", "skipped": null}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q6.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q6.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R3", "skipped": "no search budget left"}], "loop_end": null, "stop": null}');
INSERT INTO "audit_events" VALUES(66,2,'correction_round_started','correct','2026-10-22T14:05:56+00:00','{"round": 1, "tasks": [1, 2]}');
INSERT INTO "audit_events" VALUES(67,2,'queries_generated','researcher','2026-10-22T14:06:07+00:00','{"subquestion_id": 5, "queries": ["Mistral AI official financial statement 2024 release announcement"], "rationale": "Targets evidence of whether Mistral AI has publicly announced the release of its 2024 financial results, which would include confirmation of net profit or loss", "purpose": "corrective", "initial_share": null, "focus": {"missing_kind": "other", "gap": "no eligible claim exists yet"}}');
INSERT INTO "audit_events" VALUES(68,2,'search_completed','researcher','2026-10-22T14:06:09+00:00','{"subquestion_id": 5, "query": "Mistral AI official financial statement 2024 release announcement", "search_id": 13, "hits": 5}');
INSERT INTO "audit_events" VALUES(69,2,'urls_selected','researcher','2026-10-22T14:06:13+00:00','{"subquestion_id": 5, "selected": []}');
INSERT INTO "audit_events" VALUES(70,2,'queries_generated','researcher','2026-10-22T14:06:24+00:00','{"subquestion_id": 5, "queries": ["Mistral AI official financial statement 2024 net profit or loss"], "rationale": "Targets the official release of Mistral AI''s 2024 financial results with specific focus on net profit or loss.", "purpose": "corrective", "initial_share": null, "focus": {"missing_kind": "other", "gap": "no eligible claim exists yet"}}');
INSERT INTO "audit_events" VALUES(71,2,'search_completed','researcher','2026-10-22T14:06:27+00:00','{"subquestion_id": 5, "query": "Mistral AI official financial statement 2024 net profit or loss", "search_id": 14, "hits": 5}');
INSERT INTO "audit_events" VALUES(72,2,'urls_selected','researcher','2026-10-22T14:06:31+00:00','{"subquestion_id": 5, "selected": []}');
INSERT INTO "audit_events" VALUES(73,2,'correction_round_finished','correct','2026-10-22T14:06:31+00:00','{"round": 1, "new_claim_ids": [], "new_source_ids": [], "stop": null}');
INSERT INTO "audit_events" VALUES(74,2,'claims_reverified','verifier','2026-10-22T14:06:31+00:00','{"integrity_failed": 0, "verified": 0, "errors": 0}');
INSERT INTO "audit_events" VALUES(75,2,'coverage_assessed','coverage','2026-10-22T14:06:31+00:00','{"round": 1, "requirements": 7, "obligations": 7, "model": null, "eligible_claim_ids": []}');
INSERT INTO "audit_events" VALUES(76,2,'coverage_routed','coverage','2026-10-22T14:06:31+00:00','{"round": 1, "summary": {"addressed": 0, "partially_addressed": 0, "unresolved": 7, "requirements": 7, "fully_addressed": false}, "tasks": [{"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q5.R1", "skipped": "same requirement and gap were already searched in an earlier round (no new information)"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q5.R2", "skipped": "same requirement and gap were already searched in an earlier round (no new information)"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q6.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q6.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q7.R3", "skipped": "no search budget left"}], "loop_end": "no progress: the eligible claims and every requirement status are unchanged", "stop": null}');
INSERT INTO "audit_events" VALUES(77,2,'report_created','report','2026-10-22T14:06:31+00:00','{"report_id": 1, "outcome": "insufficient_evidence", "claims": 0, "ordering": "deterministic", "rejected_ids": []}');
INSERT INTO "audit_events" VALUES(78,2,'completion_finished','graph','2026-10-22T14:06:31+00:00','{"status": "completed", "stop_reason": "no progress: the eligible claims and every requirement status are unchanged", "report_id": 1, "corrective_rounds": 1, "budget_used_of_limit": {"model_requests": [12, 40], "search_queries": [8, 8], "page_fetches": [0, 12], "candidate_claims": [0, 4], "output_tokens": [1045, 30000], "elapsed_seconds": [179.7, 600.0]}, "search_allocation": {"total": [8, 8], "initial": [6, 6], "corrective": [2, 2], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}}');
INSERT INTO "audit_events" VALUES(79,1,'job_retry_started','api','2026-10-22T14:45:40+00:00','{"attempt": 1, "confirmed": true, "retry_of": {"event_id": 36, "event_type": "completion_finished", "finished_at": "2026-10-22T14:03:31+00:00", "status": "failed", "stop_reason": "drafter failed: Mesh call failed for model ''qwen/qwen3-235b-a22b-instruct-2507'': TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)", "budget_used_of_limit": {"model_requests": [11, 40], "search_queries": [6, 8], "page_fetches": [8, 12], "candidate_claims": [0, 4], "output_tokens": [4162, 30000], "elapsed_seconds": [317.3, 600.0]}}, "new_job_limits": {"model_requests": 20, "search_queries": 0, "page_fetches": 0, "candidate_claims": 4, "output_tokens": 15000, "elapsed_seconds": 300.0}, "retrieval": "disabled", "stored_evidence": {"sources": 8, "passages": 451, "claims": 0}, "drafting_profile": "compact", "budget_note": "a new job budget; the previous job''s budget_used_of_limit is copied in retry_of and its own events are unchanged"}');
INSERT INTO "audit_events" VALUES(80,1,'verification_started','graph','2026-10-22T14:45:40+00:00','{"limits": {"model_requests": [0, 20], "search_queries": [0, 0], "page_fetches": [0, 0], "candidate_claims": [0, 4], "output_tokens": [0, 15000], "elapsed_seconds": [0.0, 300.0]}, "search_allocation": {"total": [0, 0], "initial": [0, 0], "corrective": [0, 0], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}, "structured_output_models": ["anthropic/claude-haiku-4.5", "qwen/qwen3-235b-a22b-instruct-2507"]}');
INSERT INTO "audit_events" VALUES(81,1,'draft_input','drafter','2026-10-22T14:45:40+00:00','{"passages_offered": {"1": ["S1-P2", "S1-P57"], "2": ["S2-P2"], "3": ["S1-P11", "S5-P1"], "4": ["S2-P4"]}, "chars": 4556, "mode": "overlap"}');
INSERT INTO "audit_events" VALUES(82,1,'claims_drafted','drafter','2026-10-22T14:46:39+00:00','{"claim_ids": [1, 2, 3, 4, 5], "model": "qwen/qwen3-235b-a22b-instruct-2507"}');
INSERT INTO "audit_events" VALUES(83,1,'integrity_checked','integrity','2026-10-22T14:46:39+00:00','{"passed": [1, 2, 3, 4, 5], "failed": []}');
INSERT INTO "audit_events" VALUES(84,1,'claims_verified','verifier','2026-10-22T14:46:56+00:00','{"integrity_failed": 0, "verified": 5, "errors": 0}');
INSERT INTO "audit_events" VALUES(85,1,'verification_finished','graph','2026-10-22T14:46:56+00:00','{"status": "completed", "stop_reason": null, "claims": {"claims": 5, "by_status": {"partially_supported": 1, "supported": 4}, "by_integrity": {"passed": 5}, "by_semantic": {"partially_supported": 1, "supported": 4}, "eligible_for_report": 4}, "budget_used_of_limit": {"model_requests": [7, 20], "search_queries": [0, 0], "page_fetches": [0, 0], "candidate_claims": [0, 4], "output_tokens": [1623, 15000], "elapsed_seconds": [75.9, 300.0]}}');
INSERT INTO "audit_events" VALUES(86,1,'obligations_derived','coverage','2026-10-22T14:46:58+00:00','{"requirements": 8, "derived": 8, "fallback": 0, "model": "anthropic/claude-haiku-4.5", "unknown_requirement_keys": []}');
INSERT INTO "audit_events" VALUES(87,1,'coverage_assessed','coverage','2026-10-22T14:47:03+00:00','{"round": 0, "requirements": 8, "obligations": 8, "model": "anthropic/claude-haiku-4.5", "eligible_claim_ids": [2, 3, 4, 5], "unknown_obligation_keys": [], "claims_not_shown": []}');
INSERT INTO "audit_events" VALUES(88,1,'coverage_routed','coverage','2026-10-22T14:47:03+00:00','{"round": 0, "summary": {"addressed": 3, "partially_addressed": 0, "unresolved": 5, "requirements": 8, "fully_addressed": false}, "tasks": [{"kind": "claim_repair", "claim_id": 1, "requirement_key": null, "skipped": null}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q1.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q1.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q2.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q2.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q3.R1", "skipped": "no search budget left"}], "loop_end": null, "stop": null}');
INSERT INTO "audit_events" VALUES(89,1,'correction_round_started','correct','2026-10-22T14:47:03+00:00','{"round": 1, "tasks": [15]}');
INSERT INTO "audit_events" VALUES(90,1,'claim_revised','reviser','2026-10-22T14:47:19+00:00','{"from_claim_id": 1, "to_claim_id": 6, "version": 2, "reason": "Added the publication date ''June 2022'' from S1-P0 to fully support the claim, which was previously missing."}');
INSERT INTO "audit_events" VALUES(91,1,'correction_round_finished','correct','2026-10-22T14:47:19+00:00','{"round": 1, "new_claim_ids": [6], "new_source_ids": [], "stop": null}');
INSERT INTO "audit_events" VALUES(92,1,'claims_reverified','verifier','2026-10-22T14:47:21+00:00','{"integrity_failed": 0, "verified": 1, "errors": 0}');
INSERT INTO "audit_events" VALUES(93,1,'coverage_assessed','coverage','2026-10-22T14:47:25+00:00','{"round": 1, "requirements": 8, "obligations": 8, "model": "anthropic/claude-haiku-4.5", "eligible_claim_ids": [2, 3, 4, 5, 6], "unknown_obligation_keys": [], "claims_not_shown": []}');
INSERT INTO "audit_events" VALUES(94,1,'coverage_routed','coverage','2026-10-22T14:47:25+00:00','{"round": 1, "summary": {"addressed": 3, "partially_addressed": 1, "unresolved": 4, "requirements": 8, "fully_addressed": false}, "tasks": [{"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q1.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q2.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q2.R2", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q3.R1", "skipped": "no search budget left"}, {"kind": "missing_evidence", "claim_id": null, "requirement_key": "Q3.R2", "skipped": "no search budget left"}], "loop_end": null, "stop": "search budget exhausted (0 of 0 searches used); 5 unmet requirement(s) could not be researched"}');
INSERT INTO "audit_events" VALUES(95,1,'report_created','report','2026-10-22T14:47:25+00:00','{"report_id": 2, "outcome": "claims_with_gaps", "claims": 5, "ordering": "deterministic", "rejected_ids": []}');
INSERT INTO "audit_events" VALUES(96,1,'completion_finished','graph','2026-10-22T14:47:25+00:00','{"status": "stopped", "stop_reason": "search budget exhausted (0 of 0 searches used); 5 unmet requirement(s) could not be researched", "report_id": 2, "corrective_rounds": 1, "budget_used_of_limit": {"model_requests": [12, 20], "search_queries": [0, 0], "page_fetches": [0, 0], "candidate_claims": [0, 4], "output_tokens": [3019, 15000], "elapsed_seconds": [104.9, 300.0]}, "search_allocation": {"total": [0, 0], "initial": [0, 0], "corrective": [0, 0], "note": "corrective research may also use any initial allocation left unused; initial collection may not use the reserve"}}');
CREATE TABLE claim_dispositions (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    claim_id INTEGER NOT NULL UNIQUE REFERENCES claims(id),
    disposition TEXT NOT NULL CHECK (disposition IN ('excluded')),
    reason TEXT NOT NULL,
    planned_round INTEGER NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE claim_evidence (
    id INTEGER PRIMARY KEY,
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    position INTEGER NOT NULL,
    passage_ref TEXT NOT NULL,
    passage_id TEXT REFERENCES passages(id),
    resolution TEXT NOT NULL,
    quote TEXT NOT NULL,
    UNIQUE (claim_id, position)
);
INSERT INTO "claim_evidence" VALUES(1,1,0,'S5-P1','S5-P1','resolved','[quote withheld in the public demo]');
INSERT INTO "claim_evidence" VALUES(2,2,0,'S1-P11','S1-P11','resolved','The string "h2" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS); see Section 9.2.');
INSERT INTO "claim_evidence" VALUES(3,3,0,'S2-P4','S2-P4','resolved','Both HTTP/1.1 and HTTP/2 use TCP as their transport. HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP).');
INSERT INTO "claim_evidence" VALUES(4,4,0,'S2-P4','S2-P4','resolved','The switch to QUIC aims to fix a major problem of HTTP/2 called "head-of-line blocking": because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was impacted by the lost packet. Because QUIC provides native multiplexing, lost packets only impact the streams where data has been lost.');
INSERT INTO "claim_evidence" VALUES(5,5,0,'S2-P2','S2-P2','resolved','On 28 October 2018 in a mailing list discussion, Mark Nottingham, Chair of the IETF HTTP and QUIC Working Groups, proposed renaming HTTP-over-QUIC to HTTP/3, to "clearly identify it as another binding of HTTP semantics to the wire protocol [...] so people understand its separation from QUIC".');
INSERT INTO "claim_evidence" VALUES(6,6,0,'S1-P0','S1-P0','resolved','RFC 9113

HTTP/2

June 2022');
CREATE TABLE claim_relevance (
    id INTEGER PRIMARY KEY,
    obligation_assessment_id INTEGER NOT NULL REFERENCES obligation_assessments(id),
    requirement_key TEXT NOT NULL,
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    role TEXT NOT NULL CHECK (role IN ('direct_answer', 'relevant_context', 'does_not_answer')),
    reason TEXT NOT NULL DEFAULT '',
    origin TEXT NOT NULL CHECK (origin IN ('model', 'rule')),
    UNIQUE (obligation_assessment_id, claim_id)
);
CREATE TABLE claims (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    parent_claim_id INTEGER REFERENCES claims(id),
    version INTEGER NOT NULL DEFAULT 1,
    text TEXT NOT NULL,
    origin TEXT NOT NULL,
    drafter_model TEXT,
    draft_call_id INTEGER REFERENCES model_calls(id),
    provenance TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);
INSERT INTO "claims" VALUES(1,1,1,NULL,1,'The HTTP/2 specification was published as RFC 9113.','drafted','qwen/qwen3-235b-a22b-instruct-2507',24,'{}','2026-10-22T14:46:39+00:00');
INSERT INTO "claims" VALUES(2,1,3,NULL,1,'HTTP/2 uses Transport Layer Security (TLS) when identified by the "h2" string.','drafted','qwen/qwen3-235b-a22b-instruct-2507',24,'{}','2026-10-22T14:46:39+00:00');
INSERT INTO "claims" VALUES(3,1,4,NULL,1,'HTTP/3 uses QUIC as its transport layer protocol.','drafted','qwen/qwen3-235b-a22b-instruct-2507',24,'{}','2026-10-22T14:46:39+00:00');
INSERT INTO "claims" VALUES(4,1,4,NULL,1,'HTTP/3 differs from HTTP/2 by using QUIC over UDP instead of TCP, which provides native multiplexing and avoids head-of-line blocking.','drafted','qwen/qwen3-235b-a22b-instruct-2507',24,'{}','2026-10-22T14:46:39+00:00');
INSERT INTO "claims" VALUES(5,1,2,NULL,1,'The article describes that on 28 October 2018, Mark Nottingham proposed renaming HTTP-over-QUIC to HTTP/3.','drafted','qwen/qwen3-235b-a22b-instruct-2507',24,'{}','2026-10-22T14:46:39+00:00');
INSERT INTO "claims" VALUES(6,1,1,1,2,'The HTTP/2 specification was published as RFC 9113 in June 2022.','drafted','qwen/qwen3-235b-a22b-instruct-2507',33,'{"revision": {"kind": "wording_repair", "from_claim_id": 1, "round": 1, "task_id": 15, "reason": "Added the publication date ''June 2022'' from S1-P0 to fully support the claim, which was previously missing.", "failure": {"status": "partially_supported", "semantic": {"verdict": "partially_supported", "reason": "S5-P1 confirms that the HTTP/2 specification was published as RFC 9113, establishing the RFC number. However, the claim asks for the publication date, and the evidence provides only the RFC number without specifying when RFC 9113 was published.", "unsupported_details": ["the publication date of RFC 9113"], "conflicts": [], "flagged_aspects": {"date": "missing"}}}}}','2026-10-22T14:47:19+00:00');
CREATE TABLE correction_tasks (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    planned_round INTEGER NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('rejudge', 'claim_repair', 'missing_evidence', 'claim_exclusion')),
    subquestion_id INTEGER REFERENCES subquestions(id),
    claim_id INTEGER REFERENCES claims(id),
    requirement_key TEXT,
    spec TEXT NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'done', 'skipped', 'failed')),
    outcome TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    finished_at TEXT
);
INSERT INTO "correction_tasks" VALUES(1,2,0,'missing_evidence',5,NULL,'Q5.R1','{"requirement_text": "statement on release of financial results for fiscal year 2024", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','done','{"new_source_ids": [], "status": "collection_incomplete", "reason": "none of the selected pages could be collected"}','2026-10-22T14:05:56+00:00','2026-10-22T14:06:13+00:00');
INSERT INTO "correction_tasks" VALUES(2,2,0,'missing_evidence',5,NULL,'Q5.R2','{"requirement_text": "indication of net profit or net loss in the report", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','done','{"new_source_ids": [], "status": "collection_incomplete", "reason": "none of the selected pages could be collected"}','2026-10-22T14:05:56+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(3,2,0,'missing_evidence',6,NULL,'Q6.R1','{"requirement_text": "numerical value of net profit or loss", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:05:56+00:00','2026-10-22T14:05:56+00:00');
INSERT INTO "correction_tasks" VALUES(4,2,0,'missing_evidence',6,NULL,'Q6.R2','{"requirement_text": "currency and time period (fiscal year 2024)", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:05:56+00:00','2026-10-22T14:05:56+00:00');
INSERT INTO "correction_tasks" VALUES(5,2,0,'missing_evidence',7,NULL,'Q7.R1','{"requirement_text": "title and publication date of the document", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:05:56+00:00','2026-10-22T14:05:56+00:00');
INSERT INTO "correction_tasks" VALUES(6,2,0,'missing_evidence',7,NULL,'Q7.R2','{"requirement_text": "publisher (must be Mistral AI or authorized entity)", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:05:56+00:00','2026-10-22T14:05:56+00:00');
INSERT INTO "correction_tasks" VALUES(7,2,0,'missing_evidence',7,NULL,'Q7.R3','{"requirement_text": "direct link or citation to the source", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:05:56+00:00','2026-10-22T14:05:56+00:00');
INSERT INTO "correction_tasks" VALUES(8,2,1,'missing_evidence',5,NULL,'Q5.R1','{"requirement_text": "statement on release of financial results for fiscal year 2024", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "same requirement and gap were already searched in an earlier round (no new information)"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(9,2,1,'missing_evidence',5,NULL,'Q5.R2','{"requirement_text": "indication of net profit or net loss in the report", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "same requirement and gap were already searched in an earlier round (no new information)"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(10,2,1,'missing_evidence',6,NULL,'Q6.R1','{"requirement_text": "numerical value of net profit or loss", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(11,2,1,'missing_evidence',6,NULL,'Q6.R2','{"requirement_text": "currency and time period (fiscal year 2024)", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(12,2,1,'missing_evidence',7,NULL,'Q7.R1','{"requirement_text": "title and publication date of the document", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(13,2,1,'missing_evidence',7,NULL,'Q7.R2','{"requirement_text": "publisher (must be Mistral AI or authorized entity)", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(14,2,1,'missing_evidence',7,NULL,'Q7.R3','{"requirement_text": "direct link or citation to the source", "gap": "no eligible claim exists yet", "missing_kind": "other", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:06:31+00:00','2026-10-22T14:06:31+00:00');
INSERT INTO "correction_tasks" VALUES(15,1,0,'claim_repair',1,1,NULL,'{"failure": {"status": "partially_supported", "semantic": {"verdict": "partially_supported", "reason": "S5-P1 confirms that the HTTP/2 specification was published as RFC 9113, establishing the RFC number. However, the claim asks for the publication date, and the evidence provides only the RFC number without specifying when RFC 9113 was published.", "unsupported_details": ["the publication date of RFC 9113"], "conflicts": [], "flagged_aspects": {"date": "missing"}}}}','done','{"action": "revised", "claim_id": 6, "reason": "Added the publication date ''June 2022'' from S1-P0 to fully support the claim, which was previously missing."}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:19+00:00');
INSERT INTO "correction_tasks" VALUES(16,1,0,'missing_evidence',1,NULL,'Q1.R1','{"requirement_text": "RFC publication date for HTTP/2", "gap": "No claim provides the RFC publication date for HTTP/2", "missing_kind": "date", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:03+00:00');
INSERT INTO "correction_tasks" VALUES(17,1,0,'missing_evidence',1,NULL,'Q1.R2','{"requirement_text": "RFC number for HTTP/2", "gap": "No claim provides the RFC number for HTTP/2", "missing_kind": "quantity", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:03+00:00');
INSERT INTO "correction_tasks" VALUES(18,1,0,'missing_evidence',2,NULL,'Q2.R1','{"requirement_text": "RFC publication date for HTTP/3", "gap": "No claim provides the RFC publication date for HTTP/3", "missing_kind": "date", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:03+00:00');
INSERT INTO "correction_tasks" VALUES(19,1,0,'missing_evidence',2,NULL,'Q2.R2','{"requirement_text": "RFC number for HTTP/3", "gap": "No claim provides the RFC number for HTTP/3", "missing_kind": "quantity", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:03+00:00');
INSERT INTO "correction_tasks" VALUES(20,1,0,'missing_evidence',3,NULL,'Q3.R1','{"requirement_text": "name of transport protocol used by HTTP/2", "gap": "No claim directly names the transport protocol used by HTTP/2; claim 2 mentions TLS but does not specify the underlying transport layer protocol", "missing_kind": "detail", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:03+00:00','2026-10-22T14:47:03+00:00');
INSERT INTO "correction_tasks" VALUES(21,1,1,'missing_evidence',1,NULL,'Q1.R1','{"requirement_text": "RFC publication date for HTTP/2", "gap": "The claim states June 2022 but does not provide the specific day of publication", "missing_kind": "date", "status": "partially_addressed"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:25+00:00','2026-10-22T14:47:25+00:00');
INSERT INTO "correction_tasks" VALUES(22,1,1,'missing_evidence',2,NULL,'Q2.R1','{"requirement_text": "RFC publication date for HTTP/3", "gap": "No RFC publication date provided for HTTP/3", "missing_kind": "date", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:25+00:00','2026-10-22T14:47:25+00:00');
INSERT INTO "correction_tasks" VALUES(23,1,1,'missing_evidence',2,NULL,'Q2.R2','{"requirement_text": "RFC number for HTTP/3", "gap": "No RFC number provided for HTTP/3", "missing_kind": "primary_documentation", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:25+00:00','2026-10-22T14:47:25+00:00');
INSERT INTO "correction_tasks" VALUES(24,1,1,'missing_evidence',3,NULL,'Q3.R1','{"requirement_text": "name of transport protocol used by HTTP/2", "gap": "No explicit statement of the transport protocol name used by HTTP/2 is provided in the claims", "missing_kind": "detail", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:25+00:00','2026-10-22T14:47:25+00:00');
INSERT INTO "correction_tasks" VALUES(25,1,1,'missing_evidence',3,NULL,'Q3.R2','{"requirement_text": "description of how HTTP/2 uses TCP", "gap": "No description of how HTTP/2 uses TCP is provided; the claims only mention that HTTP/2 uses TLS and that it uses TCP as transport, but do not describe the manner or mechanism of that use", "missing_kind": "detail", "status": "unresolved"}','skipped','{"reason": "no search budget left"}','2026-10-22T14:47:25+00:00','2026-10-22T14:47:25+00:00');
CREATE TABLE coverage_assessments (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    round INTEGER NOT NULL,
    requirement_key TEXT NOT NULL,
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    requirement_text TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('addressed', 'partially_addressed', 'unresolved')),
    gap TEXT NOT NULL DEFAULT '',
    missing_kind TEXT NOT NULL DEFAULT 'none',
    model TEXT,
    model_call_id INTEGER REFERENCES model_calls(id),
    notes TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    UNIQUE (run_id, round, requirement_key)
);
INSERT INTO "coverage_assessments" VALUES(1,2,0,'Q5.R1',5,'statement on release of financial results for fiscal year 2024','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(2,2,0,'Q5.R2',5,'indication of net profit or net loss in the report','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(3,2,0,'Q6.R1',6,'numerical value of net profit or loss','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(4,2,0,'Q6.R2',6,'currency and time period (fiscal year 2024)','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(5,2,0,'Q7.R1',7,'title and publication date of the document','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(6,2,0,'Q7.R2',7,'publisher (must be Mistral AI or authorized entity)','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(7,2,0,'Q7.R3',7,'direct link or citation to the source','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_assessments" VALUES(8,2,1,'Q5.R1',5,'statement on release of financial results for fiscal year 2024','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(9,2,1,'Q5.R2',5,'indication of net profit or net loss in the report','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(10,2,1,'Q6.R1',6,'numerical value of net profit or loss','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(11,2,1,'Q6.R2',6,'currency and time period (fiscal year 2024)','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(12,2,1,'Q7.R1',7,'title and publication date of the document','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(13,2,1,'Q7.R2',7,'publisher (must be Mistral AI or authorized entity)','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(14,2,1,'Q7.R3',7,'direct link or citation to the source','unresolved','no eligible claim exists yet','other',NULL,NULL,'{"reason": "no eligible claim exists yet"}','2026-10-22T14:06:31+00:00');
INSERT INTO "coverage_assessments" VALUES(15,1,0,'Q1.R1',1,'RFC publication date for HTTP/2','unresolved','No claim provides the RFC publication date for HTTP/2','date','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(16,1,0,'Q1.R2',1,'RFC number for HTTP/2','unresolved','No claim provides the RFC number for HTTP/2','quantity','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(17,1,0,'Q2.R1',2,'RFC publication date for HTTP/3','unresolved','No claim provides the RFC publication date for HTTP/3','date','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(18,1,0,'Q2.R2',2,'RFC number for HTTP/3','unresolved','No claim provides the RFC number for HTTP/3','quantity','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(19,1,0,'Q3.R1',3,'name of transport protocol used by HTTP/2','unresolved','No claim directly names the transport protocol used by HTTP/2; claim 2 mentions TLS but does not specify the underlying transport layer protocol','detail','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(20,1,0,'Q3.R2',3,'description of how HTTP/2 uses TCP','addressed','','none','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(21,1,0,'Q4.R1',4,'name of transport protocol used by HTTP/3','addressed','','none','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(22,1,0,'Q4.R2',4,'description of HTTP/3''s use of QUIC instead of TCP','addressed','','none','anthropic/claude-haiku-4.5',32,'{}','2026-10-22T14:47:03+00:00');
INSERT INTO "coverage_assessments" VALUES(23,1,1,'Q1.R1',1,'RFC publication date for HTTP/2','partially_addressed','The claim states June 2022 but does not provide the specific day of publication','date','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(24,1,1,'Q1.R2',1,'RFC number for HTTP/2','addressed','','none','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(25,1,1,'Q2.R1',2,'RFC publication date for HTTP/3','unresolved','No RFC publication date provided for HTTP/3','date','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(26,1,1,'Q2.R2',2,'RFC number for HTTP/3','unresolved','No RFC number provided for HTTP/3','primary_documentation','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(27,1,1,'Q3.R1',3,'name of transport protocol used by HTTP/2','unresolved','No explicit statement of the transport protocol name used by HTTP/2 is provided in the claims','detail','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(28,1,1,'Q3.R2',3,'description of how HTTP/2 uses TCP','unresolved','No description of how HTTP/2 uses TCP is provided; the claims only mention that HTTP/2 uses TLS and that it uses TCP as transport, but do not describe the manner or mechanism of that use','detail','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(29,1,1,'Q4.R1',4,'name of transport protocol used by HTTP/3','addressed','','none','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
INSERT INTO "coverage_assessments" VALUES(30,1,1,'Q4.R2',4,'description of HTTP/3''s use of QUIC instead of TCP','addressed','','none','anthropic/claude-haiku-4.5',35,'{}','2026-10-22T14:47:25+00:00');
CREATE TABLE coverage_obligations (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    requirement_key TEXT NOT NULL,
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    obligation_key TEXT NOT NULL,
    subject TEXT NOT NULL,
    dimension TEXT NOT NULL,
    origin TEXT NOT NULL CHECK (origin IN ('derived', 'fallback')),
    model TEXT,
    model_call_id INTEGER REFERENCES model_calls(id),
    created_at TEXT NOT NULL,
    UNIQUE (run_id, obligation_key)
);
INSERT INTO "coverage_obligations" VALUES(1,2,'Q5.R1',5,'Q5.R1.O1','Mistral AI','release of official financial statement or annual report for fiscal year 2024','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(2,2,'Q5.R2',5,'Q5.R2.O1','the report','indication of net profit or net loss','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(3,2,'Q6.R1',6,'Q6.R1.O1','Mistral AI','numerical value of net profit or loss for fiscal year 2024','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(4,2,'Q6.R2',6,'Q6.R2.O1','the reported figure','currency and time period specification','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(5,2,'Q7.R1',7,'Q7.R1.O1','the official document','title and publication date','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(6,2,'Q7.R2',7,'Q7.R2.O1','the document','publisher identity','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(7,2,'Q7.R3',7,'Q7.R3.O1','the source','direct link or citation','derived','anthropic/claude-haiku-4.5',19,'2026-10-22T14:05:56+00:00');
INSERT INTO "coverage_obligations" VALUES(8,1,'Q1.R1',1,'Q1.R1.O1','HTTP/2','RFC publication date','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(9,1,'Q1.R2',1,'Q1.R2.O1','HTTP/2','RFC number','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(10,1,'Q2.R1',2,'Q2.R1.O1','HTTP/3','RFC publication date','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(11,1,'Q2.R2',2,'Q2.R2.O1','HTTP/3','RFC number','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(12,1,'Q3.R1',3,'Q3.R1.O1','HTTP/2','transport layer protocol','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(13,1,'Q3.R2',3,'Q3.R2.O1','HTTP/2','how it uses TCP','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(14,1,'Q4.R1',4,'Q4.R1.O1','HTTP/3','transport layer protocol','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
INSERT INTO "coverage_obligations" VALUES(15,1,'Q4.R2',4,'Q4.R2.O1','HTTP/3','use of QUIC instead of TCP','derived','anthropic/claude-haiku-4.5',31,'2026-10-22T14:46:58+00:00');
CREATE TABLE coverage_supporting_claims (
    assessment_id INTEGER NOT NULL REFERENCES coverage_assessments(id),
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    PRIMARY KEY (assessment_id, claim_id)
);
INSERT INTO "coverage_supporting_claims" VALUES(20,3);
INSERT INTO "coverage_supporting_claims" VALUES(21,3);
INSERT INTO "coverage_supporting_claims" VALUES(22,3);
INSERT INTO "coverage_supporting_claims" VALUES(22,4);
INSERT INTO "coverage_supporting_claims" VALUES(23,6);
INSERT INTO "coverage_supporting_claims" VALUES(24,6);
INSERT INTO "coverage_supporting_claims" VALUES(29,3);
INSERT INTO "coverage_supporting_claims" VALUES(30,3);
INSERT INTO "coverage_supporting_claims" VALUES(30,4);
CREATE TABLE fetch_attempts (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    source_id INTEGER REFERENCES sources(id),
    url TEXT NOT NULL,
    outcome TEXT NOT NULL,
    status_code INTEGER,
    reason TEXT,
    created_at TEXT NOT NULL
);
INSERT INTO "fetch_attempts" VALUES(1,1,1,'https://datatracker.ietf.org/doc/html/rfc9113','ok',200,NULL,'2026-10-22T13:59:21+00:00');
INSERT INTO "fetch_attempts" VALUES(2,1,2,'https://en.wikipedia.org/wiki/HTTP/3','ok',200,NULL,'2026-10-22T14:00:00+00:00');
INSERT INTO "fetch_attempts" VALUES(3,1,3,'https://datatracker.ietf.org/doc/draft-ietf-quic-http/33','ok',200,NULL,'2026-10-22T14:00:01+00:00');
INSERT INTO "fetch_attempts" VALUES(4,1,4,'https://news.ycombinator.com/item?id=31647033','ok',200,NULL,'2026-10-22T14:00:03+00:00');
INSERT INTO "fetch_attempts" VALUES(5,1,1,'https://datatracker.ietf.org/doc/html/rfc9113','duplicate_url',NULL,NULL,'2026-10-22T14:00:42+00:00');
INSERT INTO "fetch_attempts" VALUES(6,1,5,'https://http2.github.io','ok',200,NULL,'2026-10-22T14:00:42+00:00');
INSERT INTO "fetch_attempts" VALUES(7,1,6,'https://www.imperva.com/learn/performance/http2','ok',200,NULL,'2026-10-22T14:00:48+00:00');
INSERT INTO "fetch_attempts" VALUES(8,1,2,'https://en.wikipedia.org/wiki/HTTP/3','duplicate_url',NULL,NULL,'2026-10-22T14:01:28+00:00');
INSERT INTO "fetch_attempts" VALUES(9,1,7,'https://www.cloudflare.com/learning/performance/what-is-http3','ok',200,NULL,'2026-10-22T14:01:30+00:00');
INSERT INTO "fetch_attempts" VALUES(10,1,8,'https://www.fastly.com/learning/what-is-http-3','ok',200,NULL,'2026-10-22T14:01:31+00:00');
CREATE TABLE model_calls (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    agent TEXT NOT NULL,
    model TEXT NOT NULL,
    attempt INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    latency_ms INTEGER,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    total_tokens INTEGER,
    finish_reason TEXT,
    ok INTEGER NOT NULL,
    error TEXT,
    request_id TEXT,
    structured_output INTEGER
);
INSERT INTO "model_calls" VALUES(1,1,'planner','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T13:59:00+00:00',45485,648,335,983,'stop',1,NULL,'req_01M5HYFHQXTJ43RR12AZ1FVXMX',1);
INSERT INTO "model_calls" VALUES(2,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T13:59:08+00:00',8000,348,55,403,'stop',1,NULL,'req_01M5HYGY3TH3EP8HPZ7PDC1G1C',1);
INSERT INTO "model_calls" VALUES(3,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T13:59:20+00:00',10437,999,81,1080,'stop',1,NULL,'req_01M5HYH87KMA60MP40H5X4PQ19',1);
INSERT INTO "model_calls" VALUES(4,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T13:59:30+00:00',9296,348,54,402,'stop',1,NULL,'req_01M5HYHK7GA9NJEE7YKVXH12KV',1);
INSERT INTO "model_calls" VALUES(5,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T13:59:59+00:00',26859,1041,182,1223,'stop',1,NULL,'req_01M5HYHY8SVTZX79XSYN9ZZF78',1);
INSERT INTO "model_calls" VALUES(6,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:00:11+00:00',8109,347,52,399,'stop',1,NULL,'req_01M5HYJVYQS3J5P8ZAA5YXA03Y',1);
INSERT INTO "model_calls" VALUES(7,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:00:42+00:00',26344,1260,176,1436,'stop',1,NULL,'req_01M5HYK86G71MKSDXJDX55CW43',1);
INSERT INTO "model_calls" VALUES(8,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:01:01+00:00',13140,363,79,442,'stop',1,NULL,'req_01M5HYM7XJE1N964283BBG68F3',1);
INSERT INTO "model_calls" VALUES(9,1,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:01:28+00:00',22109,1213,148,1361,'stop',1,NULL,'req_01M5HYMSCVG9B78GMKHZN78Z8A',1);
INSERT INTO "model_calls" VALUES(10,1,'relevance','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:02:31+00:00',60014,NULL,NULL,NULL,NULL,0,'TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)',NULL,1);
INSERT INTO "model_calls" VALUES(11,1,'drafter','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:03:31+00:00',60032,NULL,NULL,NULL,NULL,0,'TimeoutError: wall-clock deadline of 60s reached; the request was cancelled and its connection closed (request timeout 60s)',NULL,1);
INSERT INTO "model_calls" VALUES(12,2,'planner','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:04:28+00:00',56328,661,367,1028,'stop',1,NULL,'req_01M5HYS7SBMN1PCMQ740RG9GYK',1);
INSERT INTO "model_calls" VALUES(13,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:04:38+00:00',10640,371,79,450,'stop',1,NULL,'req_01M5HYTYRZGY6QJN8VFBYNGTEH',1);
INSERT INTO "model_calls" VALUES(14,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:04:48+00:00',3280,1335,7,1342,'stop',1,NULL,'req_01M5HYVF7SPB6WQFP69KE4PY76',1);
INSERT INTO "model_calls" VALUES(15,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:05:00+00:00',11952,365,82,447,'stop',1,NULL,'req_01M5HYVJEP1VACCEAZ8EV6S7ZQ',1);
INSERT INTO "model_calls" VALUES(16,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:05:10+00:00',3875,1194,7,1201,'stop',1,NULL,'req_01M5HYW3NB4K4Q8Q7Q9DX5FMP4',1);
INSERT INTO "model_calls" VALUES(17,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:05:39+00:00',29922,388,100,488,'stop',1,NULL,'req_01M5HYW7EZPJ0G8A7GN598JYS2',1);
INSERT INTO "model_calls" VALUES(18,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:05:52+00:00',5703,1528,7,1535,'stop',1,NULL,'req_01M5HYXB6RJAJEQ3CD7EQE9WH1',1);
INSERT INTO "model_calls" VALUES(19,2,'coverage','anthropic/claude-haiku-4.5',1,'2026-10-22T14:05:56+00:00',3953,1321,272,1593,'stop',1,NULL,'req_01M5HYXGNW8CQ1DMPN9TZKNMMZ',1);
INSERT INTO "model_calls" VALUES(20,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:06:07+00:00',11343,428,57,485,'stop',1,NULL,'req_01M5HYXMK8X2P89XQJTZ8BDMAB',1);
INSERT INTO "model_calls" VALUES(21,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:06:13+00:00',3905,1007,7,1014,'stop',1,NULL,'req_01M5HYY1XHRNFGEZX0ECGS4JQB',1);
INSERT INTO "model_calls" VALUES(22,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:06:24+00:00',11030,424,53,477,'stop',1,NULL,'req_01M5HYY5RVBWTB1RWJMX4G7ANH',1);
INSERT INTO "model_calls" VALUES(23,2,'researcher','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:06:31+00:00',4593,1074,7,1081,'stop',1,NULL,'req_01M5HYYJMP75HBTB2SN656DVQE',1);
INSERT INTO "model_calls" VALUES(24,1,'drafter','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:46:39+00:00',58500,1981,521,2502,'stop',1,NULL,'req_01M5J16D8KNSJBFR077KJYFT3S',1);
INSERT INTO "model_calls" VALUES(25,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:43+00:00',4375,2911,169,3080,'stop',1,NULL,'req_01M5J186PMHST8PCTSKB3Y4VZT',1);
INSERT INTO "model_calls" VALUES(26,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:46+00:00',2750,3375,160,3535,'stop',1,NULL,'req_01M5J18ANN34A5PF4RB6FHCKXC',1);
INSERT INTO "model_calls" VALUES(27,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:49+00:00',2530,3347,167,3514,'stop',1,NULL,'req_01M5J18DC99VVPK14X7X3MQZG7',1);
INSERT INTO "model_calls" VALUES(28,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:52+00:00',3562,3419,273,3692,'stop',0,'invalid output: 1 validation error for VerifierVerdict
explanation
  String should have at most 500 characters [type=string_too_long, input_value="S2-P4 directly establish...tion of the difference.", input_type=str]
    For further information visit https://errors.pydantic.dev/2.14/v/string_too_long','req_01M5J18FW1RRHX6YYCX15X7Q8E',1);
INSERT INTO "model_calls" VALUES(29,1,'verifier','anthropic/claude-haiku-4.5',2,'2026-10-22T14:46:54+00:00',1406,3796,153,3949,'stop',1,NULL,'req_01M5J18KBSRQVNV2J263MXQ066',1);
INSERT INTO "model_calls" VALUES(30,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:56+00:00',2594,3392,180,3572,'stop',1,NULL,'req_01M5J18MS74SKQ0AYJDC64VATT',1);
INSERT INTO "model_calls" VALUES(31,1,'coverage','anthropic/claude-haiku-4.5',1,'2026-10-22T14:46:58+00:00',2171,1236,283,1519,'stop',1,NULL,'req_01M5J18Q9WCN1C6ZTJEXA8WE3N',1);
INSERT INTO "model_calls" VALUES(32,1,'coverage','anthropic/claude-haiku-4.5',1,'2026-10-22T14:47:03+00:00',4594,2099,438,2537,'stop',1,NULL,'req_01M5J18SFCXQSSK0J669D689CY',1);
INSERT INTO "model_calls" VALUES(33,1,'reviser','qwen/qwen3-235b-a22b-instruct-2507',1,'2026-10-22T14:47:19+00:00',15875,1800,111,1911,'stop',1,NULL,'req_01M5J18Y18ABPX69XP38EAPDED',1);
INSERT INTO "model_calls" VALUES(34,1,'verifier','anthropic/claude-haiku-4.5',1,'2026-10-22T14:47:21+00:00',2327,3061,157,3218,'stop',1,NULL,'req_01M5J19DHEYH6BS4AGV1DN6XP4',1);
INSERT INTO "model_calls" VALUES(35,1,'coverage','anthropic/claude-haiku-4.5',1,'2026-10-22T14:47:25+00:00',3891,2280,407,2687,'stop',1,NULL,'req_01M5J19FSTN41C267RBMF7JTMB',1);
CREATE TABLE obligation_assessments (
    id INTEGER PRIMARY KEY,
    assessment_id INTEGER NOT NULL REFERENCES coverage_assessments(id),
    obligation_id INTEGER NOT NULL REFERENCES coverage_obligations(id),
    status TEXT NOT NULL CHECK (status IN ('addressed', 'partially_addressed', 'unresolved')),
    gap TEXT NOT NULL DEFAULT '',
    missing_kind TEXT NOT NULL DEFAULT 'none',
    notes TEXT NOT NULL DEFAULT '{}',
    UNIQUE (assessment_id, obligation_id)
);
INSERT INTO "obligation_assessments" VALUES(1,1,1,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(2,2,2,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(3,3,3,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(4,4,4,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(5,5,5,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(6,6,6,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(7,7,7,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(8,8,1,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(9,9,2,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(10,10,3,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(11,11,4,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(12,12,5,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(13,13,6,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(14,14,7,'unresolved','no eligible claim exists yet','other','{"reason": "no eligible claim exists yet"}');
INSERT INTO "obligation_assessments" VALUES(15,15,8,'unresolved','No claim provides the RFC publication date for HTTP/2','date','{}');
INSERT INTO "obligation_assessments" VALUES(16,16,9,'unresolved','No claim provides the RFC number for HTTP/2','quantity','{}');
INSERT INTO "obligation_assessments" VALUES(17,17,10,'unresolved','No claim provides the RFC publication date for HTTP/3','date','{}');
INSERT INTO "obligation_assessments" VALUES(18,18,11,'unresolved','No claim provides the RFC number for HTTP/3','quantity','{}');
INSERT INTO "obligation_assessments" VALUES(19,19,12,'unresolved','No claim directly names the transport protocol used by HTTP/2; claim 2 mentions TLS but does not specify the underlying transport layer protocol','detail','{}');
INSERT INTO "obligation_assessments" VALUES(20,20,13,'addressed','','none','{}');
INSERT INTO "obligation_assessments" VALUES(21,21,14,'addressed','','none','{}');
INSERT INTO "obligation_assessments" VALUES(22,22,15,'addressed','','none','{}');
INSERT INTO "obligation_assessments" VALUES(23,23,8,'partially_addressed','The claim states June 2022 but does not provide the specific day of publication','date','{}');
INSERT INTO "obligation_assessments" VALUES(24,24,9,'addressed','','none','{}');
INSERT INTO "obligation_assessments" VALUES(25,25,10,'unresolved','No RFC publication date provided for HTTP/3','date','{}');
INSERT INTO "obligation_assessments" VALUES(26,26,11,'unresolved','No RFC number provided for HTTP/3','primary_documentation','{}');
INSERT INTO "obligation_assessments" VALUES(27,27,12,'unresolved','No explicit statement of the transport protocol name used by HTTP/2 is provided in the claims','detail','{}');
INSERT INTO "obligation_assessments" VALUES(28,28,13,'unresolved','No description of how HTTP/2 uses TCP is provided; the claims only mention that HTTP/2 uses TLS and that it uses TCP as transport, but do not describe the manner or mechanism of that use','detail','{}');
INSERT INTO "obligation_assessments" VALUES(29,29,14,'addressed','','none','{}');
INSERT INTO "obligation_assessments" VALUES(30,30,15,'addressed','','none','{}');
CREATE TABLE obligation_supporting_claims (
    obligation_assessment_id INTEGER NOT NULL REFERENCES obligation_assessments(id),
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    PRIMARY KEY (obligation_assessment_id, claim_id)
);
INSERT INTO "obligation_supporting_claims" VALUES(20,3);
INSERT INTO "obligation_supporting_claims" VALUES(21,3);
INSERT INTO "obligation_supporting_claims" VALUES(22,3);
INSERT INTO "obligation_supporting_claims" VALUES(22,4);
INSERT INTO "obligation_supporting_claims" VALUES(23,6);
INSERT INTO "obligation_supporting_claims" VALUES(24,6);
INSERT INTO "obligation_supporting_claims" VALUES(29,3);
INSERT INTO "obligation_supporting_claims" VALUES(30,3);
INSERT INTO "obligation_supporting_claims" VALUES(30,4);
CREATE TABLE passages (
    id TEXT PRIMARY KEY,
    source_id INTEGER NOT NULL REFERENCES sources(id),
    ordinal INTEGER NOT NULL,
    text TEXT NOT NULL,
    start_offset INTEGER NOT NULL,
    end_offset INTEGER NOT NULL,
    UNIQUE (source_id, ordinal)
);
INSERT INTO "passages" VALUES('S1-P0',1,0,'Light

Dark

Auto

RFC 9113

HTTP/2

June 2022

Thomson & Benfield

Standards Track

[Page]

Stream:

Internet Engineering Task Force (IETF)

RFC:

9113

Obsoletes:

7540, 8740

Category:

Standards Track

Published:

June 2022

ISSN:

2070-1721

Authors:

M. Thomson, Ed.

Mozilla

C. Benfield, Ed.

Apple Inc.

RFC 9113

HTTP/2

Abstract

This specification describes an optimized expression of the semantics of the Hypertext Transfer Protocol (HTTP), referred to as HTTP version 2 (HTTP/2). HTTP/2 enables a more efficient use of network resources and a reduced latency by introducing field compression and allowing multiple concurrent exchanges on the same connection.¶

This document obsoletes RFCs 7540 and 8740.¶

Status of This Memo

This is an Internet Standards Track document.¶',0,788);
INSERT INTO "passages" VALUES('S1-P1',1,1,'This document is a product of the Internet Engineering Task Force (IETF). It represents the consensus of the IETF community. It has received public review and has been approved for publication by the Internet Engineering Steering Group (IESG). Further information on Internet Standards is available in Section 2 of RFC 7841.¶

Information about the current status of this document, any errata, and how to provide feedback on it may be obtained at https://www.rfc-editor.org/info/rfc9113.¶

Copyright Notice

Copyright (c) 2022 IETF Trust and the persons identified as the document authors. All rights reserved.¶',790,1401);
INSERT INTO "passages" VALUES('S1-P2',1,2,'This document is subject to BCP 78 and the IETF Trust''s Legal Provisions Relating to IETF Documents (https://trustee.ietf.org/license-info) in effect on the date of publication of this document. Please review these documents carefully, as they describe your rights and restrictions with respect to this document. Code Components extracted from this document must include Revised BSD License text as described in Section 4.e of the Trust Legal Provisions and are provided without warranty as described in the Revised BSD License.¶

▲

Table of Contents

1. Introduction

The performance of applications using the Hypertext Transfer Protocol (HTTP, [HTTP]) is linked to how each version of HTTP uses the underlying transport, and the conditions under which the transport operates.¶',1403,2182);
INSERT INTO "passages" VALUES('S1-P3',1,3,'Making multiple concurrent requests can reduce latency and improve application performance. HTTP/1.0 allowed only one request to be outstanding at a time on a given TCP [TCP] connection. HTTP/1.1 [HTTP/1.1] added request pipelining, but this only partially addressed request concurrency and still suffers from application-layer head-of-line blocking. Therefore, HTTP/1.0 and HTTP/1.1 clients use multiple connections to a server to make concurrent requests.¶

Furthermore, HTTP fields are often repetitive and verbose, causing unnecessary network traffic as well as causing the initial TCP congestion window to quickly fill. This can result in excessive latency when multiple requests are made on a new TCP connection.¶',2184,2903);
INSERT INTO "passages" VALUES('S1-P4',1,4,'HTTP/2 addresses these issues by defining an optimized mapping of HTTP''s semantics to an underlying connection. Specifically, it allows interleaving of messages on the same connection and uses an efficient coding for HTTP fields. It also allows prioritization of requests, letting more important requests complete more quickly, further improving performance.¶

The resulting protocol is more friendly to the network because fewer TCP connections can be used in comparison to HTTP/1.x. This means less competition with other flows and longer-lived connections, which in turn lead to better utilization of available network capacity. Note, however, that TCP head-of-line blocking is not addressed by this protocol.¶

Finally, HTTP/2 also enables more efficient processing of messages through use of binary message framing.¶

This document obsoletes RFCs 7540 and 8740. Appendix B lists notable changes.¶

2. HTTP/2 Protocol Overview',2905,3835);
INSERT INTO "passages" VALUES('S1-P5',1,5,'HTTP/2 provides an optimized transport for HTTP semantics. HTTP/2 supports all of the core features of HTTP but aims to be more efficient than HTTP/1.1.¶

HTTP/2 is a connection-oriented application-layer protocol that runs over a TCP connection ([TCP]). The client is the TCP connection initiator.¶

The basic protocol unit in HTTP/2 is a frame (Section 4.1). Each frame type serves a different purpose. For example, HEADERS and DATA frames form the basis of HTTP requests and responses (Section 8.1); other frame types like SETTINGS, WINDOW_UPDATE, and PUSH_PROMISE are used in support of other HTTP/2 features.¶

Multiplexing of requests is achieved by having each HTTP request/response exchange associated with its own stream (Section 5). Streams are largely independent of each other, so a blocked or stalled request or response does not prevent progress on other streams.¶',3837,4715);
INSERT INTO "passages" VALUES('S1-P6',1,6,'Effective use of multiplexing depends on flow control and prioritization. Flow control (Section 5.2) ensures that it is possible to efficiently use multiplexed streams by restricting data that is transmitted to what the receiver is able to handle. Prioritization (Section 5.3) ensures that limited resources are used most effectively. This revision of HTTP/2 deprecates the priority signaling scheme from [RFC7540].¶

Because HTTP fields used in a connection can contain large amounts of redundant data, frames that contain them are compressed (Section 4.3). This has especially advantageous impact upon request sizes in the common case, allowing many requests to be compressed into one packet.¶',4717,5412);
INSERT INTO "passages" VALUES('S1-P7',1,7,'Finally, HTTP/2 adds a new, optional interaction mode whereby a server can push responses to a client (Section 8.4). This is intended to allow a server to speculatively send data to a client that the server anticipates the client will need, trading off some network usage against a potential latency gain. The server does this by synthesizing a request, which it sends as a PUSH_PROMISE frame. The server is then able to send a response to the synthetic request on a separate stream.¶

2.1. Document Organization

The HTTP/2 specification is split into four parts:¶

Starting HTTP/2 (Section 3) covers how an HTTP/2 connection is initiated.¶

The frame (Section 4) and stream (Section 5) layers describe the way HTTP/2 frames are structured and formed into multiplexed streams.¶

Frame (Section 6) and error (Section 7) definitions include details of the frame and error types used in HTTP/2.¶',5414,6307);
INSERT INTO "passages" VALUES('S1-P8',1,8,'HTTP mappings (Section 8) and additional requirements (Section 9) describe how HTTP semantics are expressed using frames and streams.¶

While some of the frame- and stream-layer concepts are isolated from HTTP, this specification does not define a completely generic frame layer. The frame and stream layers are tailored to the needs of HTTP.¶

2.2. Conventions and Terminology

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "NOT RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in BCP 14 [RFC2119] [RFC8174] when, and only when, they appear in all capitals, as shown here.¶

All numeric values are in network byte order. Values are unsigned unless otherwise indicated. Literal values are provided in decimal or hexadecimal as appropriate. Hexadecimal literals are prefixed with "0x" to distinguish them from decimal literals.¶',6309,7236);
INSERT INTO "passages" VALUES('S1-P9',1,9,'This specification describes binary formats using the conventions described in Section 1.3 of RFC 9000 [QUIC]. Note that this format uses network byte order and that high-valued bits are listed before low-valued bits.¶

The following terms are used:¶

client:

The endpoint that initiates an HTTP/2 connection. Clients send HTTP requests and receive HTTP responses.¶

connection:

A transport-layer connection between two endpoints.¶

connection error:

An error that affects the entire HTTP/2 connection.¶

endpoint:

Either the client or server of the connection.¶

frame:

The smallest unit of communication within an HTTP/2 connection, consisting of a header and a variable-length sequence of octets structured according to the frame type.¶

peer:

An endpoint. When discussing a particular endpoint, "peer" refers to the endpoint that is remote to the primary subject of discussion.¶

receiver:

An endpoint that is receiving frames.¶

sender:

An endpoint that is transmitting frames.¶

server:',7238,8238);
INSERT INTO "passages" VALUES('S1-P10',1,10,'The endpoint that accepts an HTTP/2 connection. Servers receive HTTP requests and send HTTP responses.¶

stream:

A bidirectional flow of frames within the HTTP/2 connection.¶

stream error:

An error on the individual HTTP/2 stream.¶

Finally, the terms "gateway", "intermediary", "proxy", and "tunnel" are defined in Section 3.7 of [HTTP]. Intermediaries act as both client and server at different times.¶

The term "content" as it applies to message bodies is defined in Section 6.4 of [HTTP].¶

3. Starting HTTP/2

Implementations that generate HTTP requests need to discover whether a server supports HTTP/2.¶

HTTP/2 uses the "http" and "https" URI schemes defined in Section 4.2 of [HTTP], with the same default port numbers as HTTP/1.1 [HTTP/1.1]. These URIs do not include any indication about what HTTP versions an upstream server (the immediate peer to which the client wishes to establish a connection) supports.¶',8240,9165);
INSERT INTO "passages" VALUES('S1-P11',1,11,'The means by which support for HTTP/2 is determined is different for "http" and "https" URIs. Discovery for "https" URIs is described in Section 3.2. HTTP/2 support for "http" URIs can only be discovered by out-of-band means and requires prior knowledge of the support as described in Section 3.3.¶

3.1. HTTP/2 Version Identification

The protocol defined in this document has two identifiers. Creating a connection based on either implies the use of the transport, framing, and message semantics described in this document.¶

The string "h2" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS); see Section 9.2. This identifier is used in the TLS Application-Layer Protocol Negotiation (ALPN) extension [TLS-ALPN] field and in any place where HTTP/2 over TLS is identified.¶

The "h2" string is serialized into an ALPN protocol identifier as the two-octet sequence: 0x68, 0x32.¶',9167,10068);
INSERT INTO "passages" VALUES('S1-P12',1,12,'The "h2c" string was previously used as a token for use in the HTTP Upgrade mechanism''s Upgrade header field (Section 7.8 of [HTTP]). This usage was never widely deployed and is deprecated by this document. The same applies to the HTTP2-Settings header field, which was used with the upgrade to "h2c".¶

3.2. Starting HTTP/2 for "https" URIs

A client that makes a request to an "https" URI uses TLS [TLS13] with the ALPN extension [TLS-ALPN].¶

HTTP/2 over TLS uses the "h2" protocol identifier. The "h2c" protocol identifier MUST NOT be sent by a client or selected by a server; the "h2c" protocol identifier describes a protocol that does not use TLS.¶

Once TLS negotiation is complete, both the client and the server MUST send a connection preface (Section 3.4).¶

3.3. Starting HTTP/2 with Prior Knowledge

A client can learn that a particular server supports HTTP/2 by other means. For example, a client could be configured with knowledge that a server supports HTTP/2.¶',10070,11047);
INSERT INTO "passages" VALUES('S1-P13',1,13,'A client that knows that a server supports HTTP/2 can establish a TCP connection and send the connection preface (Section 3.4) followed by HTTP/2 frames. Servers can identify these connections by the presence of the connection preface. This only affects the establishment of HTTP/2 connections over cleartext TCP; HTTP/2 connections over TLS MUST use protocol negotiation in TLS [TLS-ALPN].¶

Likewise, the server MUST send a connection preface (Section 3.4).¶

Without additional information, prior support for HTTP/2 is not a strong signal that a given server will support HTTP/2 for future connections. For example, it is possible for server configurations to change, for configurations to differ between instances in clustered servers, or for network conditions to change.¶

3.4. HTTP/2 Connection Preface',11049,11858);
INSERT INTO "passages" VALUES('S1-P14',1,14,'In HTTP/2, each endpoint is required to send a connection preface as a final confirmation of the protocol in use and to establish the initial settings for the HTTP/2 connection. The client and server each send a different connection preface.¶

The client connection preface starts with a sequence of 24 octets, which in hex notation is:¶

0x505249202a20485454502f322e300d0a0d0a534d0d0a0d0a

¶

That is, the connection preface starts with the string "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n". This sequence MUST be followed by a SETTINGS frame (Section 6.5), which MAY be empty. The client sends the client connection preface as the first application data octets of a connection.¶

The server connection preface consists of a potentially empty SETTINGS frame (Section 6.5) that MUST be the first frame the server sends in the HTTP/2 connection.¶

The SETTINGS frames received from a peer as part of the connection preface MUST be acknowledged (see Section 6.5.3) after sending the connection preface.¶',11860,12853);
INSERT INTO "passages" VALUES('S1-P15',1,15,'To avoid unnecessary latency, clients are permitted to send additional frames to the server immediately after sending the client connection preface, without waiting to receive the server connection preface. It is important to note, however, that the server connection preface SETTINGS frame might include settings that necessarily alter how a client is expected to communicate with the server. Upon receiving the SETTINGS frame, the client is expected to honor any settings established. In some configurations, it is possible for the server to transmit SETTINGS before the client sends additional frames, providing an opportunity to avoid this issue.¶

Clients and servers MUST treat an invalid connection preface as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. A GOAWAY frame (Section 6.8) MAY be omitted in this case, since an invalid preface indicates that the peer is not using HTTP/2.¶

4. HTTP Frames',12855,13775);
INSERT INTO "passages" VALUES('S1-P16',1,16,'Once the HTTP/2 connection is established, endpoints can begin exchanging frames.¶

4.1. Frame Format

All frames begin with a fixed 9-octet header followed by a variable-length frame payload.¶

HTTP Frame { Length (24), Type (8), Flags (8), Reserved (1), Stream Identifier (31), Frame Payload (..), }

Figure 1: Frame Layout

The fields of the frame header are defined as:¶

Length:

The length of the frame payload expressed as an unsigned 24-bit integer in units of octets. Values greater than 214 (16,384) MUST NOT be sent unless the receiver has set a larger value for SETTINGS_MAX_FRAME_SIZE.¶

The 9 octets of the frame header are not included in this value.¶

Type:

The 8-bit type of the frame. The frame type determines the format and semantics of the frame. Frames defined in this document are listed in Section 6. Implementations MUST ignore and discard frames of unknown types.¶

Flags:

An 8-bit field reserved for boolean flags specific to the frame type.¶',13777,14748);
INSERT INTO "passages" VALUES('S1-P17',1,17,'Flags are assigned semantics specific to the indicated frame type. Unused flags are those that have no defined semantics for a particular frame type. Unused flags MUST be ignored on receipt and MUST be left unset (0x00) when sending.¶

Reserved:

A reserved 1-bit field. The semantics of this bit are undefined, and the bit MUST remain unset (0x00) when sending and MUST be ignored when receiving.¶

Stream Identifier:

A stream identifier (see Section 5.1.1) expressed as an unsigned 31-bit integer. The value 0x00 is reserved for frames that are associated with the connection as a whole as opposed to an individual stream.¶

The structure and content of the frame payload are dependent entirely on the frame type.¶

4.2. Frame Size

The size of a frame payload is limited by the maximum size that a receiver advertises in the SETTINGS_MAX_FRAME_SIZE setting. This setting can have any value between 214 (16,384) and 224-1 (16,777,215) octets, inclusive.¶',14750,15707);
INSERT INTO "passages" VALUES('S1-P18',1,18,'All implementations MUST be capable of receiving and minimally processing frames up to 214 octets in length, plus the 9-octet frame header (Section 4.1). The size of the frame header is not included when describing frame sizes.¶

An endpoint MUST send an error code of FRAME_SIZE_ERROR if a frame exceeds the size defined in SETTINGS_MAX_FRAME_SIZE, exceeds any limit defined for the frame type, or is too small to contain mandatory frame data. A frame size error in a frame that could alter the state of the entire connection MUST be treated as a connection error (Section 5.4.1); this includes any frame carrying a field block (Section 4.3) (that is, HEADERS, PUSH_PROMISE, and CONTINUATION), a SETTINGS frame, and any frame with a stream identifier of 0.¶',15709,16467);
INSERT INTO "passages" VALUES('S1-P19',1,19,'Endpoints are not obligated to use all available space in a frame. Responsiveness can be improved by using frames that are smaller than the permitted maximum size. Sending large frames can result in delays in sending time-sensitive frames (such as RST_STREAM, WINDOW_UPDATE, or PRIORITY), which, if blocked by the transmission of a large frame, could affect performance.¶

4.3. Field Section Compression and Decompression

Field section compression is the process of compressing a set of field lines (Section 5.2 of [HTTP]) to form a field block. Field section decompression is the process of decoding a field block into a set of field lines. Details of HTTP/2 field section compression and decompression are defined in [COMPRESSION], which, for historical reasons, refers to these processes as header compression and decompression.¶',16469,17302);
INSERT INTO "passages" VALUES('S1-P20',1,20,'Each field block carries all of the compressed field lines of a single field section. Header sections also include control data associated with the message in the form of pseudo-header fields (Section 8.3) that use the same format as a field line.¶

Field blocks carry control data and header sections for requests, responses, promised requests, and pushed responses (see Section 8.4). All these messages, except for interim responses and requests contained in PUSH_PROMISE (Section 6.6) frames, can optionally include a field block that carries a trailer section.¶',17304,17869);
INSERT INTO "passages" VALUES('S1-P21',1,21,'A field section is a collection of field lines. Each of the field lines in a field block carries a single value. The serialized field block is then divided into one or more octet sequences, called field block fragments. The first field block fragment is transmitted within the frame payload of HEADERS (Section 6.2) or PUSH_PROMISE (Section 6.6), each of which could be followed by CONTINUATION (Section 6.10) frames to carry subsequent field block fragments.¶

The Cookie header field [COOKIE] is treated specially by the HTTP mapping (see Section 8.2.3).¶

A receiving endpoint reassembles the field block by concatenating its fragments and then decompresses the block to reconstruct the field section.¶

A complete field section consists of either:¶

a single HEADERS or PUSH_PROMISE frame, with the END_HEADERS flag set, or¶

a HEADERS or PUSH_PROMISE frame with the END_HEADERS flag unset and one or more CONTINUATION frames, where the last CONTINUATION frame has the END_HEADERS flag set.¶',17871,18866);
INSERT INTO "passages" VALUES('S1-P22',1,22,'Each field block is processed as a discrete unit. Field blocks MUST be transmitted as a contiguous sequence of frames, with no interleaved frames of any other type or from any other stream. The last frame in a sequence of HEADERS or CONTINUATION frames has the END_HEADERS flag set. The last frame in a sequence of PUSH_PROMISE or CONTINUATION frames has the END_HEADERS flag set. This allows a field block to be logically equivalent to a single frame.¶

Field block fragments can only be sent as the frame payload of HEADERS, PUSH_PROMISE, or CONTINUATION frames because these frames carry data that can modify the compression context maintained by a receiver. An endpoint receiving HEADERS, PUSH_PROMISE, or CONTINUATION frames needs to reassemble field blocks and perform decompression even if the frames are to be discarded. A receiver MUST terminate the connection with a connection error (Section 5.4.1) of type COMPRESSION_ERROR if it does not decompress a field block.¶',18868,19845);
INSERT INTO "passages" VALUES('S1-P23',1,23,'A decoding error in a field block MUST be treated as a connection error (Section 5.4.1) of type COMPRESSION_ERROR.¶

4.3.1. Compression State

Field compression is stateful. Each endpoint has an HPACK encoder context and an HPACK decoder context that are used for encoding and decoding all field blocks on a connection. Section 4 of [COMPRESSION] defines the dynamic table, which is the primary state for each context.¶

The dynamic table has a maximum size that is set by an HPACK decoder. An endpoint communicates the size chosen by its HPACK decoder context using the SETTINGS_HEADER_TABLE_SIZE setting; see Section 6.5.2. When a connection is established, the dynamic table size for the HPACK decoder and encoder at both endpoints starts at 4,096 bytes, the initial value of the SETTINGS_HEADER_TABLE_SIZE setting.¶',19847,20666);
INSERT INTO "passages" VALUES('S1-P24',1,24,'Any change to the maximum value set using SETTINGS_HEADER_TABLE_SIZE takes effect when the endpoint acknowledges settings (Section 6.5.3). The HPACK encoder at that endpoint can set the dynamic table to any size up to the maximum value set by the decoder. An HPACK encoder declares the size of the dynamic table with a Dynamic Table Size Update instruction (Section 6.3 of [COMPRESSION]).¶',20668,21057);
INSERT INTO "passages" VALUES('S1-P25',1,25,'Once an endpoint acknowledges a change to SETTINGS_HEADER_TABLE_SIZE that reduces the maximum below the current size of the dynamic table, its HPACK encoder MUST start the next field block with a Dynamic Table Size Update instruction that sets the dynamic table to a size that is less than or equal to the reduced maximum; see Section 4.2 of [COMPRESSION]. An endpoint MUST treat a field block that follows an acknowledgment of the reduction to the maximum dynamic table size as a connection error (Section 5.4.1) of type COMPRESSION_ERROR if it does not start with a conformant Dynamic Table Size Update instruction.¶

5. Streams and Multiplexing

A "stream" is an independent, bidirectional sequence of frames exchanged between the client and server within an HTTP/2 connection. Streams have several important characteristics:¶

A single HTTP/2 connection can contain multiple concurrently open streams, with either endpoint interleaving frames from multiple streams.¶',21059,22029);
INSERT INTO "passages" VALUES('S1-P26',1,26,'Streams can be established and used unilaterally or shared by either endpoint.¶

Streams can be closed by either endpoint.¶

The order in which frames are sent is significant. Recipients process frames in the order they are received. In particular, the order of HEADERS and DATA frames is semantically significant.¶

Streams are identified by an integer. Stream identifiers are assigned to streams by the endpoint initiating the stream.¶

5.1. Stream States

The lifecycle of a stream is shown in Figure 2.¶

¶

Figure 2: Stream States

send:

endpoint sends this frame¶

recv:

endpoint receives this frame¶

H:

HEADERS frame (with implied CONTINUATION frames)¶

ES:

END_STREAM flag¶

R:

RST_STREAM frame¶

PP:

PUSH_PROMISE frame (with implied CONTINUATION frames); state transitions are for the promised stream¶',22031,22848);
INSERT INTO "passages" VALUES('S1-P27',1,27,'Note that this diagram shows stream state transitions and the frames and flags that affect those transitions only. In this regard, CONTINUATION frames do not result in state transitions; they are effectively part of the HEADERS or PUSH_PROMISE that they follow. For the purpose of state transitions, the END_STREAM flag is processed as a separate event to the frame that bears it; a HEADERS frame with the END_STREAM flag set can cause two state transitions.¶

Both endpoints have a subjective view of the state of a stream that could be different when frames are in transit. Endpoints do not coordinate the creation of streams; they are created unilaterally by either endpoint. The negative consequences of a mismatch in states are limited to the "closed" state after sending RST_STREAM, where frames might be received for some time after closing.¶

Streams have the following states:¶

idle:

All streams start in the "idle" state.¶

The following transitions are valid from this state:¶',22850,23839);
INSERT INTO "passages" VALUES('S1-P28',1,28,'Sending a HEADERS frame as a client, or receiving a HEADERS frame as a server, causes the stream to become "open". The stream identifier is selected as described in Section 5.1.1. The same HEADERS frame can also cause a stream to immediately become "half-closed".¶

Sending a PUSH_PROMISE frame on another stream reserves the idle stream that is identified for later use. The stream state for the reserved stream transitions to "reserved (local)". Only a server may send PUSH_PROMISE frames.¶

Receiving a PUSH_PROMISE frame on another stream reserves an idle stream that is identified for later use. The stream state for the reserved stream transitions to "reserved (remote)". Only a client may receive PUSH_PROMISE frames.¶

Note that the PUSH_PROMISE frame is not sent on the idle stream but references the newly reserved stream in the Promised Stream ID field.¶',23841,24706);
INSERT INTO "passages" VALUES('S1-P29',1,29,'Opening a stream with a higher-valued stream identifier causes the stream to transition immediately to a "closed" state; note that this transition is not shown in the diagram.¶

Receiving any frame other than HEADERS or PRIORITY on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. If this stream is initiated by the server, as described in Section 5.1.1, then receiving a HEADERS frame MUST also be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

reserved (local):

A stream in the "reserved (local)" state is one that has been promised by sending a PUSH_PROMISE frame. A PUSH_PROMISE frame reserves an idle stream by associating the stream with an open stream that was initiated by the remote peer (see Section 8.4).¶

In this state, only the following transitions are possible:¶

The endpoint can send a HEADERS frame. This causes the stream to open in a "half-closed (remote)" state.¶',24708,25671);
INSERT INTO "passages" VALUES('S1-P30',1,30,'Either endpoint can send a RST_STREAM frame to cause the stream to become "closed". This releases the stream reservation.¶

An endpoint MUST NOT send any type of frame other than HEADERS, RST_STREAM, or PRIORITY in this state.¶

A PRIORITY or WINDOW_UPDATE frame MAY be received in this state. Receiving any type of frame other than RST_STREAM, PRIORITY, or WINDOW_UPDATE on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

reserved (remote):

A stream in the "reserved (remote)" state has been reserved by a remote peer.¶

In this state, only the following transitions are possible:¶

Receiving a HEADERS frame causes the stream to transition to "half-closed (local)".¶

Either endpoint can send a RST_STREAM frame to cause the stream to become "closed". This releases the stream reservation.¶

An endpoint MUST NOT send any type of frame other than RST_STREAM, WINDOW_UPDATE, or PRIORITY in this state.¶',25673,26632);
INSERT INTO "passages" VALUES('S1-P31',1,31,'Receiving any type of frame other than HEADERS, RST_STREAM, or PRIORITY on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

open:

A stream in the "open" state may be used by both peers to send frames of any type. In this state, sending peers observe advertised stream-level flow-control limits (Section 5.2).¶

From this state, either endpoint can send a frame with an END_STREAM flag set, which causes the stream to transition into one of the "half-closed" states. An endpoint sending an END_STREAM flag causes the stream state to become "half-closed (local)"; an endpoint receiving an END_STREAM flag causes the stream state to become "half-closed (remote)".¶

Either endpoint can send a RST_STREAM frame from this state, causing it to transition immediately to "closed".¶

half-closed (local):

A stream that is in the "half-closed (local)" state cannot be used for sending frames other than WINDOW_UPDATE, PRIORITY, and RST_STREAM.¶',26634,27625);
INSERT INTO "passages" VALUES('S1-P32',1,32,'A stream transitions from this state to "closed" when a frame is received with the END_STREAM flag set or when either peer sends a RST_STREAM frame.¶

An endpoint can receive any type of frame in this state. Providing flow-control credit using WINDOW_UPDATE frames is necessary to continue receiving flow-controlled frames. In this state, a receiver can ignore WINDOW_UPDATE frames, which might arrive for a short period after a frame with the END_STREAM flag set is sent.¶

PRIORITY frames can be received in this state.¶

half-closed (remote):

A stream that is "half-closed (remote)" is no longer being used by the peer to send frames. In this state, an endpoint is no longer obligated to maintain a receiver flow-control window.¶

If an endpoint receives additional frames, other than WINDOW_UPDATE, PRIORITY, or RST_STREAM, for a stream that is in this state, it MUST respond with a stream error (Section 5.4.2) of type STREAM_CLOSED.¶',27627,28567);
INSERT INTO "passages" VALUES('S1-P33',1,33,'A stream that is "half-closed (remote)" can be used by the endpoint to send frames of any type. In this state, the endpoint continues to observe advertised stream-level flow-control limits (Section 5.2).¶

A stream can transition from this state to "closed" by sending a frame with the END_STREAM flag set or when either peer sends a RST_STREAM frame.¶

closed:

The "closed" state is the terminal state.¶

A stream enters the "closed" state after an endpoint both sends and receives a frame with an END_STREAM flag set. A stream also enters the "closed" state after an endpoint either sends or receives a RST_STREAM frame.¶

An endpoint MUST NOT send frames other than PRIORITY on a closed stream. An endpoint MAY treat receipt of any other type of frame on a closed stream as a connection error (Section 5.4.1) of type STREAM_CLOSED, except as noted below.¶',28569,29428);
INSERT INTO "passages" VALUES('S1-P34',1,34,'An endpoint that sends a frame with the END_STREAM flag set or a RST_STREAM frame might receive a WINDOW_UPDATE or RST_STREAM frame from its peer in the time before the peer receives and processes the frame that closes the stream.¶

An endpoint that sends a RST_STREAM frame on a stream that is in the "open" or "half-closed (local)" state could receive any type of frame. The peer might have sent or enqueued for sending these frames before processing the RST_STREAM frame. An endpoint MUST minimally process and then discard any frames it receives in this state. This means updating header compression state for HEADERS and PUSH_PROMISE frames. Receiving a PUSH_PROMISE frame also causes the promised stream to become "reserved (remote)", even when the PUSH_PROMISE frame is received on a closed stream. Additionally, the content of DATA frames counts toward the connection flow-control window.¶',29430,30327);
INSERT INTO "passages" VALUES('S1-P35',1,35,'An endpoint can perform this minimal processing for all streams that are in the "closed" state. Endpoints MAY use other signals to detect that a peer has received the frames that caused the stream to enter the "closed" state and treat receipt of any frame other than PRIORITY as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Endpoints can use frames that indicate that the peer has received the closing signal to drive this. Endpoints SHOULD NOT use timers for this purpose. For example, an endpoint that sends a SETTINGS frame after closing a stream can safely treat receipt of a DATA frame on that stream as an error after receiving an acknowledgment of the settings. Other things that might be used are PING frames, receiving data on streams that were created after closing the stream, or responses to requests created after closing the stream.¶',30329,31190);
INSERT INTO "passages" VALUES('S1-P36',1,36,'In the absence of more specific rules, implementations SHOULD treat the receipt of a frame that is not expressly permitted in the description of a state as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that PRIORITY can be sent and received in any stream state.¶

The rules in this section only apply to frames defined in this document. Receipt of frames for which the semantics are unknown cannot be treated as an error, as the conditions for sending and receiving those frames are also unknown; see Section 5.5.¶

An example of the state transitions for an HTTP request/response exchange can be found in Section 8.8. An example of the state transitions for server push can be found in Sections 8.4.1 and 8.4.2.¶

5.1.1. Stream Identifiers',31192,31950);
INSERT INTO "passages" VALUES('S1-P37',1,37,'Streams are identified by an unsigned 31-bit integer. Streams initiated by a client MUST use odd-numbered stream identifiers; those initiated by the server MUST use even-numbered stream identifiers. A stream identifier of zero (0x00) is used for connection control messages; the stream identifier of zero cannot be used to establish a new stream.¶

The identifier of a newly established stream MUST be numerically greater than all streams that the initiating endpoint has opened or reserved. This governs streams that are opened using a HEADERS frame and streams that are reserved using PUSH_PROMISE. An endpoint that receives an unexpected stream identifier MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',31952,32688);
INSERT INTO "passages" VALUES('S1-P38',1,38,'A HEADERS frame will transition the client-initiated stream identified by the stream identifier in the frame header from "idle" to "open". A PUSH_PROMISE frame will transition the server-initiated stream identified by the Promised Stream ID field in the frame payload from "idle" to "reserved (local)" or "reserved (remote)". When a stream transitions out of the "idle" state, all streams in the "idle" state that might have been opened by the peer with a lower-valued stream identifier immediately transition to "closed". That is, an endpoint may skip a stream identifier, with the effect being that the skipped stream is immediately closed.¶',32690,33333);
INSERT INTO "passages" VALUES('S1-P39',1,39,'Stream identifiers cannot be reused. Long-lived connections can result in an endpoint exhausting the available range of stream identifiers. A client that is unable to establish a new stream identifier can establish a new connection for new streams. A server that is unable to establish a new stream identifier can send a GOAWAY frame so that the client is forced to open a new connection for new streams.¶

5.1.2. Stream Concurrency

A peer can limit the number of concurrently active streams using the SETTINGS_MAX_CONCURRENT_STREAMS parameter (see Section 6.5.2) within a SETTINGS frame. The maximum concurrent streams setting is specific to each endpoint and applies only to the peer that receives the setting. That is, clients specify the maximum number of concurrent streams the server can initiate, and servers specify the maximum number of concurrent streams the client can initiate.¶',33335,34226);
INSERT INTO "passages" VALUES('S1-P40',1,40,'Streams that are in the "open" state or in either of the "half-closed" states count toward the maximum number of streams that an endpoint is permitted to open. Streams in any of these three states count toward the limit advertised in the SETTINGS_MAX_CONCURRENT_STREAMS setting. Streams in either of the "reserved" states do not count toward the stream limit.¶

Endpoints MUST NOT exceed the limit set by their peer. An endpoint that receives a HEADERS frame that causes its advertised concurrent stream limit to be exceeded MUST treat this as a stream error (Section 5.4.2) of type PROTOCOL_ERROR or REFUSED_STREAM. The choice of error code determines whether the endpoint wishes to enable automatic retry (see Section 8.7 for details).¶

An endpoint that wishes to reduce the value of SETTINGS_MAX_CONCURRENT_STREAMS to a value that is below the current number of open streams can either close streams that exceed the new value or allow streams to complete.¶

5.2. Flow Control',34228,35207);
INSERT INTO "passages" VALUES('S1-P41',1,41,'Using streams for multiplexing introduces contention over use of the TCP connection, resulting in blocked streams. A flow-control scheme ensures that streams on the same connection do not destructively interfere with each other. Flow control is used for both individual streams and the connection as a whole.¶

HTTP/2 provides for flow control through use of the WINDOW_UPDATE frame (Section 6.9).¶

5.2.1. Flow-Control Principles

HTTP/2 stream flow control aims to allow a variety of flow-control algorithms to be used without requiring protocol changes. Flow control in HTTP/2 has the following characteristics:¶

Flow control is specific to a connection. HTTP/2 flow control operates between the endpoints of a single hop and not over the entire end-to-end path.¶

Flow control is based on WINDOW_UPDATE frames. Receivers advertise how many octets they are prepared to receive on a stream and for the entire connection. This is a credit-based scheme.¶',35209,36164);
INSERT INTO "passages" VALUES('S1-P42',1,42,'Flow control is directional with overall control provided by the receiver. A receiver MAY choose to set any window size that it desires for each stream and for the entire connection. A sender MUST respect flow-control limits imposed by a receiver. Clients, servers, and intermediaries all independently advertise their flow-control window as a receiver and abide by the flow-control limits set by their peer when sending.¶

The initial value for the flow-control window is 65,535 octets for both new streams and the overall connection.¶

The frame type determines whether flow control applies to a frame. Of the frames specified in this document, only DATA frames are subject to flow control; all other frame types do not consume space in the advertised flow-control window. This ensures that important control frames are not blocked by flow control.¶

An endpoint can choose to disable its own flow control, but an endpoint cannot ignore flow-control signals from its peer.¶',36166,37141);
INSERT INTO "passages" VALUES('S1-P43',1,43,'HTTP/2 defines only the format and semantics of the WINDOW_UPDATE frame (Section 6.9). This document does not stipulate how a receiver decides when to send this frame or the value that it sends, nor does it specify how a sender chooses to send packets. Implementations are able to select any algorithm that suits their needs.¶

Implementations are also responsible for prioritizing the sending of requests and responses, choosing how to avoid head-of-line blocking for requests, and managing the creation of new streams. Algorithm choices for these could interact with any flow-control algorithm.¶

5.2.2. Appropriate Use of Flow Control',37143,37780);
INSERT INTO "passages" VALUES('S1-P44',1,44,'Flow control is defined to protect endpoints that are operating under resource constraints. For example, a proxy needs to share memory between many connections and also might have a slow upstream connection and a fast downstream one. Flow control addresses cases where the receiver is unable to process data on one stream yet wants to continue to process other streams in the same connection.¶

Deployments that do not require this capability can advertise a flow-control window of the maximum size (231-1) and can maintain this window by sending a WINDOW_UPDATE frame when any data is received. This effectively disables flow control for that receiver. Conversely, a sender is always subject to the flow-control window advertised by the receiver.¶',37782,38530);
INSERT INTO "passages" VALUES('S1-P45',1,45,'Deployments with constrained resources (for example, memory) can employ flow control to limit the amount of memory a peer can consume. Note, however, that this can lead to suboptimal use of available network resources if flow control is enabled without knowledge of the bandwidth * delay product (see [RFC7323]).¶

Even with full awareness of the current bandwidth * delay product, implementation of flow control can be difficult. Endpoints MUST read and process HTTP/2 frames from the TCP receive buffer as soon as data is available. Failure to read promptly could lead to a deadlock when critical frames, such as WINDOW_UPDATE, are not read and acted upon. Reading frames promptly does not expose endpoints to resource exhaustion attacks, as HTTP/2 flow control limits resource commitments.¶

5.2.3. Flow-Control Performance',38532,39358);
INSERT INTO "passages" VALUES('S1-P46',1,46,'If an endpoint cannot ensure that its peer always has available flow-control window space that is greater than the peer''s bandwidth * delay product on this connection, its receive throughput will be limited by HTTP/2 flow control. This will result in degraded performance.¶

Sending timely WINDOW_UPDATE frames can improve performance. Endpoints will want to balance the need to improve receive throughput with the need to manage resource exhaustion risks and should take careful note of Section 10.5 in defining their strategy to manage window sizes.¶

5.3. Prioritization

In a multiplexed protocol like HTTP/2, prioritizing allocation of bandwidth and computation resources to streams can be critical to attaining good performance. A poor prioritization scheme can result in HTTP/2 providing poor performance. With no parallelism at the TCP layer, performance could be significantly worse than HTTP/1.1.¶',39360,40267);
INSERT INTO "passages" VALUES('S1-P47',1,47,'A good prioritization scheme benefits from the application of contextual knowledge such as the content of resources, how resources are interrelated, and how those resources will be used by a peer. In particular, clients can possess knowledge about the priority of requests that is relevant to server prioritization. In those cases, having clients provide priority information can improve performance.¶

5.3.1. Background on Priority in RFC 7540

RFC 7540 defined a rich system for signaling priority of requests. However, this system proved to be complex, and it was not uniformly implemented.¶

The flexible scheme meant that it was possible for clients to express priorities in very different ways, with little consistency in the approaches that were adopted. For servers, implementing generic support for the scheme was complex. Implementation of priorities was uneven in both clients and servers. Many server deployments ignored client signals when prioritizing their handling of requests.¶',40269,41263);
INSERT INTO "passages" VALUES('S1-P48',1,48,'In short, the prioritization signaling in RFC 7540 [RFC7540] was not successful.¶

5.3.2. Priority Signaling in This Document

This update to HTTP/2 deprecates the priority signaling defined in RFC 7540 [RFC7540]. The bulk of the text related to priority signals is not included in this document. The description of frame fields and some of the mandatory handling is retained to ensure that implementations of this document remain interoperable with implementations that use the priority signaling described in RFC 7540.¶

A thorough description of the RFC 7540 priority scheme remains in Section 5.3 of [RFC7540].¶

Signaling priority information is necessary to attain good performance in many cases. Where signaling priority information is important, endpoints are encouraged to use an alternative scheme, such as the scheme described in [HTTP-PRIORITY].¶',41265,42123);
INSERT INTO "passages" VALUES('S1-P49',1,49,'Though the priority signaling from RFC 7540 was not widely adopted, the information it provides can still be useful in the absence of better information. Endpoints that receive priority signals in HEADERS or PRIORITY frames can benefit from applying that information. In particular, implementations that consume these signals would not benefit from discarding these priority signals in the absence of alternatives.¶

Servers SHOULD use other contextual information in determining priority of requests in the absence of any priority signals. Servers MAY interpret the complete absence of signals as an indication that the client has not implemented the feature. The defaults described in Section 5.3.5 of [RFC7540] are known to have poor performance under most conditions, and their use is unlikely to be deliberate.¶

5.4. Error Handling

HTTP/2 framing permits two classes of errors:¶

An error condition that renders the entire connection unusable is a connection error.¶',42125,43098);
INSERT INTO "passages" VALUES('S1-P50',1,50,'An error in an individual stream is a stream error.¶

A list of error codes is included in Section 7.¶

It is possible that an endpoint will encounter frames that would cause multiple errors. Implementations MAY discover multiple errors during processing, but they SHOULD report at most one stream and one connection error as a result.¶

The first stream error reported for a given stream prevents any other errors on that stream from being reported. In comparison, the protocol permits multiple GOAWAY frames, though an endpoint SHOULD report just one type of connection error unless an error is encountered during graceful shutdown. If this occurs, an endpoint MAY send an additional GOAWAY frame with the new error code, in addition to any prior GOAWAY that contained NO_ERROR.¶',43100,43881);
INSERT INTO "passages" VALUES('S1-P51',1,51,'If an endpoint detects multiple different errors, it MAY choose to report any one of those errors. If a frame causes a connection error, that error MUST be reported. Additionally, an endpoint MAY use any applicable error code when it detects an error condition; a generic error code (such as PROTOCOL_ERROR or INTERNAL_ERROR) can always be used in place of more specific error codes.¶

5.4.1. Connection Error Handling

A connection error is any error that prevents further processing of the frame layer or corrupts any connection state.¶

An endpoint that encounters a connection error SHOULD first send a GOAWAY frame (Section 6.8) with the stream identifier of the last stream that it successfully received from its peer. The GOAWAY frame includes an error code (Section 7) that indicates why the connection is terminating. After sending the GOAWAY frame for an error condition, the endpoint MUST close the TCP connection.¶',43883,44809);
INSERT INTO "passages" VALUES('S1-P52',1,52,'It is possible that the GOAWAY will not be reliably received by the receiving endpoint. In the event of a connection error, GOAWAY only provides a best-effort attempt to communicate with the peer about why the connection is being terminated.¶

An endpoint can end a connection at any time. In particular, an endpoint MAY choose to treat a stream error as a connection error. Endpoints SHOULD send a GOAWAY frame when ending a connection, providing that circumstances permit it.¶

5.4.2. Stream Error Handling

A stream error is an error related to a specific stream that does not affect processing of other streams.¶

An endpoint that detects a stream error sends a RST_STREAM frame (Section 6.4) that contains the stream identifier of the stream where the error occurred. The RST_STREAM frame includes an error code that indicates the type of error.¶',44811,45662);
INSERT INTO "passages" VALUES('S1-P53',1,53,'A RST_STREAM is the last frame that an endpoint can send on a stream. The peer that sends the RST_STREAM frame MUST be prepared to receive any frames that were sent or enqueued for sending by the remote peer. These frames can be ignored, except where they modify connection state (such as the state maintained for field section compression (Section 4.3) or flow control).¶

Normally, an endpoint SHOULD NOT send more than one RST_STREAM frame for any stream. However, an endpoint MAY send additional RST_STREAM frames if it receives frames on a closed stream after more than a round-trip time. This behavior is permitted to deal with misbehaving implementations.¶

To avoid looping, an endpoint MUST NOT send a RST_STREAM in response to a RST_STREAM frame.¶

5.4.3. Connection Termination

If the TCP connection is closed or reset while streams remain in the "open" or "half-closed" states, then the affected streams cannot be automatically retried (see Section 8.7 for details).¶',45664,46644);
INSERT INTO "passages" VALUES('S1-P54',1,54,'5.5. Extending HTTP/2

HTTP/2 permits extension of the protocol. Within the limitations described in this section, protocol extensions can be used to provide additional services or alter any aspect of the protocol. Extensions are effective only within the scope of a single HTTP/2 connection.¶

This applies to the protocol elements defined in this document. This does not affect the existing options for extending HTTP, such as defining new methods, status codes, or fields (see Section 16 of [HTTP]).¶

Extensions are permitted to use new frame types (Section 4.1), new settings (Section 6.5), or new error codes (Section 7). Registries for managing these extension points are defined in Section 11 of [RFC7540].¶',46646,47361);
INSERT INTO "passages" VALUES('S1-P55',1,55,'Implementations MUST ignore unknown or unsupported values in all extensible protocol elements. Implementations MUST discard frames that have unknown or unsupported types. This means that any of these extension points can be safely used by extensions without prior arrangement or negotiation. However, extension frames that appear in the middle of a field block (Section 4.3) are not permitted; these MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Extensions SHOULD avoid changing protocol elements defined in this document or elements for which no extension mechanism is defined. This includes changes to the layout of frames, additions or changes to the way that frames are composed into HTTP messages (Section 8.1), the definition of pseudo-header fields, or changes to any protocol element that a compliant endpoint might treat as a connection error (Section 5.4.1).¶',47363,48266);
INSERT INTO "passages" VALUES('S1-P56',1,56,'An extension that changes existing protocol elements or state MUST be negotiated before being used. For example, an extension that changes the layout of the HEADERS frame cannot be used until the peer has given a positive signal that this is acceptable. In this case, it could also be necessary to coordinate when the revised layout comes into effect. For example, treating frames other than DATA frames as flow controlled requires a change in semantics that both endpoints need to understand, so this can only be done through negotiation.¶

This document doesn''t mandate a specific method for negotiating the use of an extension but notes that a setting (Section 6.5.2) could be used for that purpose. If both peers set a value that indicates willingness to use the extension, then the extension can be used. If a setting is used for extension negotiation, the initial value MUST be defined in such a fashion that the extension is initially disabled.¶

6. Frame Definitions',48268,49242);
INSERT INTO "passages" VALUES('S1-P57',1,57,'This specification defines a number of frame types, each identified by a unique 8-bit type code. Each frame type serves a distinct purpose in the establishment and management of either the connection as a whole or individual streams.¶

The transmission of specific frame types can alter the state of a connection. If endpoints fail to maintain a synchronized view of the connection state, successful communication within the connection will no longer be possible. Therefore, it is important that endpoints have a shared comprehension of how the state is affected by the use of any given frame.¶

6.1. DATA

DATA frames (type=0x00) convey arbitrary, variable-length sequences of octets associated with a stream. One or more DATA frames are used, for instance, to carry HTTP request or response message contents.¶

DATA frames MAY also contain padding. Padding can be added to DATA frames to obscure the size of messages. Padding is a security feature; see Section 10.7.¶',49244,50213);
INSERT INTO "passages" VALUES('S1-P58',1,58,'DATA Frame { Length (24), Type (8) = 0x00, Unused Flags (4), PADDED Flag (1), Unused Flags (2), END_STREAM Flag (1), Reserved (1), Stream Identifier (31), [Pad Length (8)], Data (..), Padding (..2040), }

Figure 3: DATA Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The DATA frame contains the following additional fields:¶

Pad Length:

An 8-bit field containing the length of the frame padding in units of octets. This field is conditional and is only present if the PADDED flag is set.¶

Data:

Application data. The amount of data is the remainder of the frame payload after subtracting the length of the other fields that are present.¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',50215,51183);
INSERT INTO "passages" VALUES('S1-P59',1,59,'The DATA frame defines the following flags:¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶

END_STREAM (0x01):

When set, the END_STREAM flag indicates that this frame is the last that the endpoint will send for the identified stream. Setting this flag causes the stream to enter one of the "half-closed" states or the "closed" state (Section 5.1).¶

DATA frames MUST be associated with a stream. If a DATA frame is received whose Stream Identifier field is 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',51185,51821);
INSERT INTO "passages" VALUES('S1-P60',1,60,'DATA frames are subject to flow control and can only be sent when a stream is in the "open" or "half-closed (remote)" state. The entire DATA frame payload is included in flow control, including the Pad Length and Padding fields if present. If a DATA frame is received whose stream is not in the "open" or "half-closed (local)" state, the recipient MUST respond with a stream error (Section 5.4.2) of type STREAM_CLOSED.¶

The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.2. HEADERS',51823,52514);
INSERT INTO "passages" VALUES('S1-P61',1,61,'The HEADERS frame (type=0x01) is used to open a stream (Section 5.1), and additionally carries a field block fragment. Despite the name, a HEADERS frame can carry a header section or a trailer section. HEADERS frames can be sent on a stream in the "idle", "reserved (local)", "open", or "half-closed (remote)" state.¶

HEADERS Frame { Length (24), Type (8) = 0x01, Unused Flags (2), PRIORITY Flag (1), Unused Flag (1), PADDED Flag (1), END_HEADERS Flag (1), Unused Flag (1), END_STREAM Flag (1), Reserved (1), Stream Identifier (31), [Pad Length (8)], [Exclusive (1)], [Stream Dependency (31)], [Weight (8)], Field Block Fragment (..), Padding (..2040), }

Figure 4: HEADERS Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The HEADERS frame payload has the following additional fields:¶

Pad Length:

An 8-bit field containing the length of the frame padding in units of octets. This field is only present if the PADDED flag is set.¶',52516,53516);
INSERT INTO "passages" VALUES('S1-P62',1,62,'Exclusive:

A single-bit flag. This field is only present if the PRIORITY flag is set. Priority signals in HEADERS frames are deprecated; see Section 5.3.2.¶

Stream Dependency:

A 31-bit stream identifier. This field is only present if the PRIORITY flag is set.¶

Weight:

An unsigned 8-bit integer. This field is only present if the PRIORITY flag is set.¶

Field Block Fragment:

A field block fragment (Section 4.3).¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The HEADERS frame defines the following flags:¶

PRIORITY (0x20):

When set, the PRIORITY flag indicates that the Exclusive, Stream Dependency, and Weight fields are present.¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶',53518,54501);
INSERT INTO "passages" VALUES('S1-P63',1,63,'END_HEADERS (0x04):

When set, the END_HEADERS flag indicates that this frame contains an entire field block (Section 4.3) and is not followed by any CONTINUATION frames.¶

A HEADERS frame without the END_HEADERS flag set MUST be followed by a CONTINUATION frame for the same stream. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

END_STREAM (0x01):

When set, the END_STREAM flag indicates that the field block (Section 4.3) is the last that the endpoint will send for the identified stream.¶

A HEADERS frame with the END_STREAM flag set signals the end of a stream. However, a HEADERS frame with the END_STREAM flag set can be followed by CONTINUATION frames on the same stream. Logically, the CONTINUATION frames are part of the HEADERS frame.¶',54503,55362);
INSERT INTO "passages" VALUES('S1-P64',1,64,'The frame payload of a HEADERS frame contains a field block fragment (Section 4.3). A field block that does not fit within a HEADERS frame is continued in a CONTINUATION frame (Section 6.10).¶

HEADERS frames MUST be associated with a stream. If a HEADERS frame is received whose Stream Identifier field is 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The HEADERS frame changes the connection state as described in Section 4.3.¶

The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.3. PRIORITY

The PRIORITY frame (type=0x02) is deprecated; see Section 5.3.2. A PRIORITY frame can be sent in any stream state, including idle or closed streams.¶',55364,56269);
INSERT INTO "passages" VALUES('S1-P65',1,65,'PRIORITY Frame { Length (24) = 0x05, Type (8) = 0x02, Unused Flags (8), Reserved (1), Stream Identifier (31), Exclusive (1), Stream Dependency (31), Weight (8), }

Figure 5: PRIORITY Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a PRIORITY frame contains the following additional fields:¶

Exclusive:

A single-bit flag.¶

Stream Dependency:

A 31-bit stream identifier.¶

Weight:

An unsigned 8-bit integer.¶

The PRIORITY frame does not define any flags.¶

The PRIORITY frame always identifies a stream. If a PRIORITY frame is received with a stream identifier of 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',56271,57024);
INSERT INTO "passages" VALUES('S1-P66',1,66,'Sending or receiving a PRIORITY frame does not affect the state of any stream (Section 5.1). The PRIORITY frame can be sent on a stream in any state, including "idle" or "closed". A PRIORITY frame cannot be sent between consecutive frames that comprise a single field block (Section 4.3).¶

A PRIORITY frame with a length other than 5 octets MUST be treated as a stream error (Section 5.4.2) of type FRAME_SIZE_ERROR.¶

6.4. RST_STREAM

The RST_STREAM frame (type=0x03) allows for immediate termination of a stream. RST_STREAM is sent to request cancellation of a stream or to indicate that an error condition has occurred.¶

RST_STREAM Frame { Length (24) = 0x04, Type (8) = 0x03, Unused Flags (8), Reserved (1), Stream Identifier (31), Error Code (32), }

Figure 6: RST_STREAM Frame Format',57026,57817);
INSERT INTO "passages" VALUES('S1-P67',1,67,'The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. Additionally, the RST_STREAM frame contains a single unsigned, 32-bit integer identifying the error code (Section 7). The error code indicates why the stream is being terminated.¶

The RST_STREAM frame does not define any flags.¶

The RST_STREAM frame fully terminates the referenced stream and causes it to enter the "closed" state. After receiving a RST_STREAM on a stream, the receiver MUST NOT send additional frames for that stream, except for PRIORITY. However, after sending the RST_STREAM, the sending endpoint MUST be prepared to receive and process additional frames sent on the stream that might have been sent by the peer prior to the arrival of the RST_STREAM.¶

RST_STREAM frames MUST be associated with a stream. If a RST_STREAM frame is received with a stream identifier of 0x00, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',57819,58808);
INSERT INTO "passages" VALUES('S1-P68',1,68,'RST_STREAM frames MUST NOT be sent for a stream in the "idle" state. If a RST_STREAM frame identifying an idle stream is received, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A RST_STREAM frame with a length other than 4 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.5. SETTINGS

The SETTINGS frame (type=0x04) conveys configuration parameters that affect how endpoints communicate, such as preferences and constraints on peer behavior. The SETTINGS frame is also used to acknowledge the receipt of those settings. Individually, a configuration parameter from a SETTINGS frame is referred to as a "setting".¶',58810,59513);
INSERT INTO "passages" VALUES('S1-P69',1,69,'Settings are not negotiated; they describe characteristics of the sending peer, which are used by the receiving peer. Different values for the same setting can be advertised by each peer. For example, a client might set a high initial flow-control window, whereas a server might set a lower value to conserve resources.¶

A SETTINGS frame MUST be sent by both endpoints at the start of a connection and MAY be sent at any other time by either endpoint over the lifetime of the connection. Implementations MUST support all of the settings defined by this specification.¶

Each parameter in a SETTINGS frame replaces any existing value for that parameter. Settings are processed in the order in which they appear, and a receiver of a SETTINGS frame does not need to maintain any state other than the current value of each setting. Therefore, the value of a SETTINGS parameter is the last value that is seen by a receiver.¶',59515,60435);
INSERT INTO "passages" VALUES('S1-P70',1,70,'SETTINGS frames are acknowledged by the receiving peer. To enable this, the SETTINGS frame defines the ACK flag:¶

ACK (0x01):

When set, the ACK flag indicates that this frame acknowledges receipt and application of the peer''s SETTINGS frame. When this bit is set, the frame payload of the SETTINGS frame MUST be empty. Receipt of a SETTINGS frame with the ACK flag set and a length field value other than 0 MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR. For more information, see Section 6.5.3 ("Settings Synchronization").¶

SETTINGS frames always apply to a connection, never a single stream. The stream identifier for a SETTINGS frame MUST be zero (0x00). If an endpoint receives a SETTINGS frame whose Stream Identifier field is anything other than 0x00, the endpoint MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',60437,61321);
INSERT INTO "passages" VALUES('S1-P71',1,71,'The SETTINGS frame affects connection state. A badly formed or incomplete SETTINGS frame MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A SETTINGS frame with a length other than a multiple of 6 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.5.1. SETTINGS Format

The frame payload of a SETTINGS frame consists of zero or more settings, each consisting of an unsigned 16-bit setting identifier and an unsigned 32-bit value.¶

SETTINGS Frame { Length (24), Type (8) = 0x04, Unused Flags (7), ACK Flag (1), Reserved (1), Stream Identifier (31) = 0, Setting (48) ..., } Setting { Identifier (16), Value (32), }

Figure 7: SETTINGS Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a SETTINGS frame contains any number of Setting fields, each of which consists of:¶

Identifier:

A 16-bit setting identifier; see Section 6.5.2.¶

Value:',61323,62317);
INSERT INTO "passages" VALUES('S1-P72',1,72,'A 32-bit value for the setting.¶

6.5.2. Defined Settings

The following settings are defined:¶

SETTINGS_HEADER_TABLE_SIZE (0x01):

This setting allows the sender to inform the remote endpoint of the maximum size of the compression table used to decode field blocks, in units of octets. The encoder can select any size equal to or less than this value by using signaling specific to the compression format inside a field block (see [COMPRESSION]). The initial value is 4,096 octets.¶

SETTINGS_ENABLE_PUSH (0x02):

This setting can be used to enable or disable server push. A server MUST NOT send a PUSH_PROMISE frame if it receives this parameter set to a value of 0; see Section 8.4. A client that has both set this parameter to 0 and had it acknowledged MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',62319,63186);
INSERT INTO "passages" VALUES('S1-P73',1,73,'The initial value of SETTINGS_ENABLE_PUSH is 1. For a client, this value indicates that it is willing to receive PUSH_PROMISE frames. For a server, this initial value has no effect, and is equivalent to the value 0. Any value other than 0 or 1 MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A server MUST NOT explicitly set this value to 1. A server MAY choose to omit this setting when it sends a SETTINGS frame, but if a server does include a value, it MUST be 0. A client MUST treat receipt of a SETTINGS frame with SETTINGS_ENABLE_PUSH set to 1 as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

SETTINGS_MAX_CONCURRENT_STREAMS (0x03):',63188,63873);
INSERT INTO "passages" VALUES('S1-P74',1,74,'This setting indicates the maximum number of concurrent streams that the sender will allow. This limit is directional: it applies to the number of streams that the sender permits the receiver to create. Initially, there is no limit to this value. It is recommended that this value be no smaller than 100, so as to not unnecessarily limit parallelism.¶

A value of 0 for SETTINGS_MAX_CONCURRENT_STREAMS SHOULD NOT be treated as special by endpoints. A zero value does prevent the creation of new streams; however, this can also happen for any limit that is exhausted with active streams. Servers SHOULD only set a zero value for short durations; if a server does not wish to accept requests, closing the connection is more appropriate.¶

SETTINGS_INITIAL_WINDOW_SIZE (0x04):

This setting indicates the sender''s initial window size (in units of octets) for stream-level flow control. The initial value is 216-1 (65,535) octets.¶',63875,64802);
INSERT INTO "passages" VALUES('S1-P75',1,75,'This setting affects the window size of all streams (see Section 6.9.2).¶

Values above the maximum flow-control window size of 231-1 MUST be treated as a connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR.¶

SETTINGS_MAX_FRAME_SIZE (0x05):

This setting indicates the size of the largest frame payload that the sender is willing to receive, in units of octets.¶

The initial value is 214 (16,384) octets. The value advertised by an endpoint MUST be between this initial value and the maximum allowed frame size (224-1 or 16,777,215 octets), inclusive. Values outside this range MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

SETTINGS_MAX_HEADER_LIST_SIZE (0x06):',64804,65509);
INSERT INTO "passages" VALUES('S1-P76',1,76,'This advisory setting informs a peer of the maximum field section size that the sender is prepared to accept, in units of octets. The value is based on the uncompressed size of field lines, including the length of the name and value in units of octets plus an overhead of 32 octets for each field line.¶

For any given request, a lower limit than what is advertised MAY be enforced. The initial value of this setting is unlimited.¶

An endpoint that receives a SETTINGS frame with any unknown or unsupported identifier MUST ignore that setting.¶

6.5.3. Settings Synchronization

Most values in SETTINGS benefit from or require an understanding of when the peer has received and applied the changed parameter values. In order to provide such synchronization timepoints, the recipient of a SETTINGS frame in which the ACK flag is not set MUST apply the updated settings as soon as possible upon receipt. SETTINGS frames are acknowledged in the order in which they are received.¶',65511,66488);
INSERT INTO "passages" VALUES('S1-P77',1,77,'The values in the SETTINGS frame MUST be processed in the order they appear, with no other frame processing between values. Unsupported settings MUST be ignored. Once all values have been processed, the recipient MUST immediately emit a SETTINGS frame with the ACK flag set. Upon receiving a SETTINGS frame with the ACK flag set, the sender of the altered settings can rely on the values from the oldest unacknowledged SETTINGS frame having been applied.¶

If the sender of a SETTINGS frame does not receive an acknowledgment within a reasonable amount of time, it MAY issue a connection error (Section 5.4.1) of type SETTINGS_TIMEOUT. In setting a timeout, some allowance needs to be made for processing delays at the peer; a timeout that is solely based on the round-trip time between endpoints might result in spurious errors.¶

6.6. PUSH_PROMISE',66490,67339);
INSERT INTO "passages" VALUES('S1-P78',1,78,'The PUSH_PROMISE frame (type=0x05) is used to notify the peer endpoint in advance of streams the sender intends to initiate. The PUSH_PROMISE frame includes the unsigned 31-bit identifier of the stream the endpoint plans to create along with a field section that provides additional context for the stream. Section 8.4 contains a thorough description of the use of PUSH_PROMISE frames.¶

PUSH_PROMISE Frame { Length (24), Type (8) = 0x05, Unused Flags (4), PADDED Flag (1), END_HEADERS Flag (1), Unused Flags (2), Reserved (1), Stream Identifier (31), [Pad Length (8)], Reserved (1), Promised Stream ID (31), Field Block Fragment (..), Padding (..2040), }

Figure 8: PUSH_PROMISE Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The PUSH_PROMISE frame payload has the following additional fields:¶

Pad Length:',67341,68217);
INSERT INTO "passages" VALUES('S1-P79',1,79,'An 8-bit field containing the length of the frame padding in units of octets. This field is only present if the PADDED flag is set.¶

Promised Stream ID:

An unsigned 31-bit integer that identifies the stream that is reserved by the PUSH_PROMISE. The promised stream identifier MUST be a valid choice for the next stream sent by the sender (see "new stream identifier" in Section 5.1.1).¶

Field Block Fragment:

A field block fragment (Section 4.3) containing the request control data and a header section.¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The PUSH_PROMISE frame defines the following flags:¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶

END_HEADERS (0x04):',68219,69188);
INSERT INTO "passages" VALUES('S1-P80',1,80,'When set, the END_HEADERS flag indicates that this frame contains an entire field block (Section 4.3) and is not followed by any CONTINUATION frames.¶

A PUSH_PROMISE frame without the END_HEADERS flag set MUST be followed by a CONTINUATION frame for the same stream. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

PUSH_PROMISE frames MUST only be sent on a peer-initiated stream that is in either the "open" or "half-closed (remote)" state. The stream identifier of a PUSH_PROMISE frame indicates the stream it is associated with. If the Stream Identifier field specifies the value 0x00, a recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Promised streams are not required to be used in the order they are promised. The PUSH_PROMISE only reserves stream identifiers for later use.¶',69190,70123);
INSERT INTO "passages" VALUES('S1-P81',1,81,'PUSH_PROMISE MUST NOT be sent if the SETTINGS_ENABLE_PUSH setting of the peer endpoint is set to 0. An endpoint that has set this setting and has received acknowledgment MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Recipients of PUSH_PROMISE frames can choose to reject promised streams by returning a RST_STREAM referencing the promised stream identifier back to the sender of the PUSH_PROMISE.¶',70125,70587);
INSERT INTO "passages" VALUES('S1-P82',1,82,'A PUSH_PROMISE frame modifies the connection state in two ways. First, the inclusion of a field block (Section 4.3) potentially modifies the state maintained for field section compression. Second, PUSH_PROMISE also reserves a stream for later use, causing the promised stream to enter the "reserved (local)" or "reserved (remote)" state. A sender MUST NOT send a PUSH_PROMISE on a stream unless that stream is either "open" or "half-closed (remote)"; the sender MUST ensure that the promised stream is a valid choice for a new stream identifier (Section 5.1.1) (that is, the promised stream MUST be in the "idle" state).¶',70589,71210);
INSERT INTO "passages" VALUES('S1-P83',1,83,'Since PUSH_PROMISE reserves a stream, ignoring a PUSH_PROMISE frame causes the stream state to become indeterminate. A receiver MUST treat the receipt of a PUSH_PROMISE on a stream that is neither "open" nor "half-closed (local)" as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. However, an endpoint that has sent RST_STREAM on the associated stream MUST handle PUSH_PROMISE frames that might have been created before the RST_STREAM frame is received and processed.¶

A receiver MUST treat the receipt of a PUSH_PROMISE that promises an illegal stream identifier (Section 5.1.1) as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that an illegal stream identifier is an identifier for a stream that is not currently in the "idle" state.¶',71212,71978);
INSERT INTO "passages" VALUES('S1-P84',1,84,'The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.7. PING

The PING frame (type=0x06) is a mechanism for measuring a minimal round-trip time from the sender, as well as determining whether an idle connection is still functional. PING frames can be sent from any endpoint.¶

PING Frame { Length (24) = 0x08, Type (8) = 0x06, Unused Flags (7), ACK Flag (1), Reserved (1), Stream Identifier (31) = 0, Opaque Data (64), }

Figure 9: PING Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4.¶

In addition to the frame header, PING frames MUST contain 8 octets of opaque data in the frame payload. A sender can include any value it chooses and use those octets in any fashion.¶',71980,72923);
INSERT INTO "passages" VALUES('S1-P85',1,85,'Receivers of a PING frame that does not include an ACK flag MUST send a PING frame with the ACK flag set in response, with an identical frame payload. PING responses SHOULD be given higher priority than any other frame.¶

The PING frame defines the following flags:¶

ACK (0x01):

When set, the ACK flag indicates that this PING frame is a PING response. An endpoint MUST set this flag in PING responses. An endpoint MUST NOT respond to PING frames containing this flag.¶

PING frames are not associated with any individual stream. If a PING frame is received with a Stream Identifier field value other than 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Receipt of a PING frame with a length field value other than 8 MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.8. GOAWAY',72925,73788);
INSERT INTO "passages" VALUES('S1-P86',1,86,'The GOAWAY frame (type=0x07) is used to initiate shutdown of a connection or to signal serious error conditions. GOAWAY allows an endpoint to gracefully stop accepting new streams while still finishing processing of previously established streams. This enables administrative actions, like server maintenance.¶

There is an inherent race condition between an endpoint starting new streams and the remote peer sending a GOAWAY frame. To deal with this case, the GOAWAY contains the stream identifier of the last peer-initiated stream that was or might be processed on the sending endpoint in this connection. For instance, if the server sends a GOAWAY frame, the identified stream is the highest-numbered stream initiated by the client.¶',73790,74526);
INSERT INTO "passages" VALUES('S1-P87',1,87,'Once the GOAWAY is sent, the sender will ignore frames sent on streams initiated by the receiver if the stream has an identifier higher than the included last stream identifier. Receivers of a GOAWAY frame MUST NOT open additional streams on the connection, although a new connection can be established for new streams.¶

If the receiver of the GOAWAY has sent data on streams with a higher stream identifier than what is indicated in the GOAWAY frame, those streams are not or will not be processed. The receiver of the GOAWAY frame can treat the streams as though they had never been created at all, thereby allowing those streams to be retried later on a new connection.¶',74528,75202);
INSERT INTO "passages" VALUES('S1-P88',1,88,'Endpoints SHOULD always send a GOAWAY frame before closing a connection so that the remote peer can know whether a stream has been partially processed or not. For example, if an HTTP client sends a POST at the same time that a server closes a connection, the client cannot know if the server started to process that POST request if the server does not send a GOAWAY frame to indicate what streams it might have acted on.¶

An endpoint might choose to close a connection without sending a GOAWAY for misbehaving peers.¶

A GOAWAY frame might not immediately precede closing of the connection; a receiver of a GOAWAY that has no more use for the connection SHOULD still send a GOAWAY frame before terminating the connection.¶

GOAWAY Frame { Length (24), Type (8) = 0x07, Unused Flags (8), Reserved (1), Stream Identifier (31) = 0, Reserved (1), Last-Stream-ID (31), Error Code (32), Additional Debug Data (..), }

Figure 10: GOAWAY Frame Format',75204,76147);
INSERT INTO "passages" VALUES('S1-P89',1,89,'The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4.¶

The GOAWAY frame does not define any flags.¶

The GOAWAY frame applies to the connection, not a specific stream. An endpoint MUST treat a GOAWAY frame with a stream identifier other than 0x00 as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The last stream identifier in the GOAWAY frame contains the highest-numbered stream identifier for which the sender of the GOAWAY frame might have taken some action on or might yet take action on. All streams up to and including the identified stream might have been processed in some way. The last stream identifier can be set to 0 if no streams were processed.¶

If a connection terminates without a GOAWAY frame, the last stream identifier is effectively the highest possible stream identifier.¶',76149,77006);
INSERT INTO "passages" VALUES('S1-P90',1,90,'On streams with lower- or equal-numbered identifiers that were not closed completely prior to the connection being closed, reattempting requests, transactions, or any protocol activity is not possible, except for idempotent actions like HTTP GET, PUT, or DELETE. Any protocol activity that uses higher-numbered streams can be safely retried using a new connection.¶

Activity on streams numbered lower than or equal to the last stream identifier might still complete successfully. The sender of a GOAWAY frame might gracefully shut down a connection by sending a GOAWAY frame, maintaining the connection in an "open" state until all in-progress streams complete.¶',77008,77671);
INSERT INTO "passages" VALUES('S1-P91',1,91,'An endpoint MAY send multiple GOAWAY frames if circumstances change. For instance, an endpoint that sends GOAWAY with NO_ERROR during graceful shutdown could subsequently encounter a condition that requires immediate termination of the connection. The last stream identifier from the last GOAWAY frame received indicates which streams could have been acted upon. Endpoints MUST NOT increase the value they send in the last stream identifier, since the peers might already have retried unprocessed requests on another connection.¶',77673,78202);
INSERT INTO "passages" VALUES('S1-P92',1,92,'A client that is unable to retry requests loses all requests that are in flight when the server closes the connection. This is especially true for intermediaries that might not be serving clients using HTTP/2. A server that is attempting to gracefully shut down a connection SHOULD send an initial GOAWAY frame with the last stream identifier set to 231-1 and a NO_ERROR code. This signals to the client that a shutdown is imminent and that initiating further requests is prohibited. After allowing time for any in-flight stream creation (at least one round-trip time), the server MAY send another GOAWAY frame with an updated last stream identifier. This ensures that a connection can be cleanly shut down without losing requests.¶',78204,78936);
INSERT INTO "passages" VALUES('S1-P93',1,93,'After sending a GOAWAY frame, the sender can discard frames for streams initiated by the receiver with identifiers higher than the identified last stream. However, any frames that alter connection state cannot be completely ignored. For instance, HEADERS, PUSH_PROMISE, and CONTINUATION frames MUST be minimally processed to ensure that the state maintained for field section compression is consistent (see Section 4.3); similarly, DATA frames MUST be counted toward the connection flow-control window. Failure to process these frames can cause flow control or field section compression state to become unsynchronized.¶

The GOAWAY frame also contains a 32-bit error code (Section 7) that contains the reason for closing the connection.¶',78938,79675);
INSERT INTO "passages" VALUES('S1-P94',1,94,'Endpoints MAY append opaque data to the frame payload of any GOAWAY frame. Additional debug data is intended for diagnostic purposes only and carries no semantic value. Debug information could contain security- or privacy-sensitive data. Logged or otherwise persistently stored debug data MUST have adequate safeguards to prevent unauthorized access.¶

6.9. WINDOW_UPDATE

The WINDOW_UPDATE frame (type=0x08) is used to implement flow control; see Section 5.2 for an overview.¶

Flow control operates at two levels: on each individual stream and on the entire connection.¶

Both types of flow control are hop by hop, that is, only between the two endpoints. Intermediaries do not forward WINDOW_UPDATE frames between dependent connections. However, throttling of data transfer by any receiver can indirectly cause the propagation of flow-control information toward the original sender.¶',79677,80563);
INSERT INTO "passages" VALUES('S1-P95',1,95,'Flow control only applies to frames that are identified as being subject to flow control. Of the frame types defined in this document, this includes only DATA frames. Frames that are exempt from flow control MUST be accepted and processed, unless the receiver is unable to assign resources to handling the frame. A receiver MAY respond with a stream error (Section 5.4.2) or connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR if it is unable to accept a frame.¶

WINDOW_UPDATE Frame { Length (24) = 0x04, Type (8) = 0x08, Unused Flags (8), Reserved (1), Stream Identifier (31), Reserved (1), Window Size Increment (31), }

Figure 11: WINDOW_UPDATE Frame Format',80565,81234);
INSERT INTO "passages" VALUES('S1-P96',1,96,'The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a WINDOW_UPDATE frame is one reserved bit plus an unsigned 31-bit integer indicating the number of octets that the sender can transmit in addition to the existing flow-control window. The legal range for the increment to the flow-control window is 1 to 231-1 (2,147,483,647) octets.¶

The WINDOW_UPDATE frame does not define any flags.¶

The WINDOW_UPDATE frame can be specific to a stream or to the entire connection. In the former case, the frame''s stream identifier indicates the affected stream; in the latter, the value "0" indicates that the entire connection is the subject of the frame.¶

A receiver MUST treat the receipt of a WINDOW_UPDATE frame with a flow-control window increment of 0 as a stream error (Section 5.4.2) of type PROTOCOL_ERROR; errors on the connection flow-control window MUST be treated as a connection error (Section 5.4.1).¶',81236,82214);
INSERT INTO "passages" VALUES('S1-P97',1,97,'WINDOW_UPDATE can be sent by a peer that has sent a frame with the END_STREAM flag set. This means that a receiver could receive a WINDOW_UPDATE frame on a stream in a "half-closed (remote)" or "closed" state. A receiver MUST NOT treat this as an error (see Section 5.1).¶

A receiver that receives a flow-controlled frame MUST always account for its contribution against the connection flow-control window, unless the receiver treats this as a connection error (Section 5.4.1). This is necessary even if the frame is in error. The sender counts the frame toward the flow-control window, but if the receiver does not, the flow-control window at the sender and receiver can become different.¶

A WINDOW_UPDATE frame with a length other than 4 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.9.1. The Flow-Control Window',82216,83077);
INSERT INTO "passages" VALUES('S1-P98',1,98,'Flow control in HTTP/2 is implemented using a window kept by each sender on every stream. The flow-control window is a simple integer value that indicates how many octets of data the sender is permitted to transmit; as such, its size is a measure of the buffering capacity of the receiver.¶

Two flow-control windows are applicable: the stream flow-control window and the connection flow-control window. The sender MUST NOT send a flow-controlled frame with a length that exceeds the space available in either of the flow-control windows advertised by the receiver. Frames with zero length with the END_STREAM flag set (that is, an empty DATA frame) MAY be sent if there is no available space in either flow-control window.¶

For flow-control calculations, the 9-octet frame header is not counted.¶

After sending a flow-controlled frame, the sender reduces the space available in both windows by the length of the transmitted frame.¶',83079,84013);
INSERT INTO "passages" VALUES('S1-P99',1,99,'The receiver of a frame sends a WINDOW_UPDATE frame as it consumes data and frees up space in flow-control windows. Separate WINDOW_UPDATE frames are sent for the stream- and connection-level flow-control windows. Receivers are advised to have mechanisms in place to avoid sending WINDOW_UPDATE frames with very small increments; see Section 4.2.3.3 of [RFC1122].¶

A sender that receives a WINDOW_UPDATE frame updates the corresponding window by the amount specified in the frame.¶

A sender MUST NOT allow a flow-control window to exceed 231-1 octets. If a sender receives a WINDOW_UPDATE that causes a flow-control window to exceed this maximum, it MUST terminate either the stream or the connection, as appropriate. For streams, the sender sends a RST_STREAM with an error code of FLOW_CONTROL_ERROR; for the connection, a GOAWAY frame with an error code of FLOW_CONTROL_ERROR is sent.¶',84015,84905);
INSERT INTO "passages" VALUES('S1-P100',1,100,'Flow-controlled frames from the sender and WINDOW_UPDATE frames from the receiver are completely asynchronous with respect to each other. This property allows a receiver to aggressively update the window size kept by the sender to prevent streams from stalling.¶

6.9.2. Initial Flow-Control Window Size

When an HTTP/2 connection is first established, new streams are created with an initial flow-control window size of 65,535 octets. The connection flow-control window is also 65,535 octets. Both endpoints can adjust the initial window size for new streams by including a value for SETTINGS_INITIAL_WINDOW_SIZE in the SETTINGS frame. The connection flow-control window can only be changed using WINDOW_UPDATE frames.¶',84907,85627);
INSERT INTO "passages" VALUES('S1-P101',1,101,'Prior to receiving a SETTINGS frame that sets a value for SETTINGS_INITIAL_WINDOW_SIZE, an endpoint can only use the default initial window size when sending flow-controlled frames. Similarly, the connection flow-control window is set based on the default initial window size until a WINDOW_UPDATE frame is received.¶

In addition to changing the flow-control window for streams that are not yet active, a SETTINGS frame can alter the initial flow-control window size for streams with active flow-control windows (that is, streams in the "open" or "half-closed (remote)" state). When the value of SETTINGS_INITIAL_WINDOW_SIZE changes, a receiver MUST adjust the size of all stream flow-control windows that it maintains by the difference between the new value and the old value.¶',85629,86408);
INSERT INTO "passages" VALUES('S1-P102',1,102,'A change to SETTINGS_INITIAL_WINDOW_SIZE can cause the available space in a flow-control window to become negative. A sender MUST track the negative flow-control window and MUST NOT send new flow-controlled frames until it receives WINDOW_UPDATE frames that cause the flow-control window to become positive.¶

For example, if the client sends 60 KB immediately on connection establishment and the server sets the initial window size to be 16 KB, the client will recalculate the available flow-control window to be -44 KB on receipt of the SETTINGS frame. The client retains a negative flow-control window until WINDOW_UPDATE frames restore the window to being positive, after which the client can resume sending.¶

A SETTINGS frame cannot alter the connection flow-control window.¶

An endpoint MUST treat a change to SETTINGS_INITIAL_WINDOW_SIZE that causes any flow-control window to exceed the maximum size as a connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR.¶',86410,87386);
INSERT INTO "passages" VALUES('S1-P103',1,103,'6.9.3. Reducing the Stream Window Size

A receiver that wishes to use a smaller flow-control window than the current size can send a new SETTINGS frame. However, the receiver MUST be prepared to receive data that exceeds this window size, since the sender might send data that exceeds the lower limit prior to processing the SETTINGS frame.¶

After sending a SETTINGS frame that reduces the initial flow-control window size, a receiver MAY continue to process streams that exceed flow-control limits. Allowing streams to continue does not allow the receiver to immediately reduce the space it reserves for flow-control windows. Progress on these streams can also stall, since WINDOW_UPDATE frames are needed to allow the sender to resume sending. The receiver MAY instead send a RST_STREAM with an error code of FLOW_CONTROL_ERROR for the affected streams.¶

6.10. CONTINUATION',87388,88265);
INSERT INTO "passages" VALUES('S1-P104',1,104,'The CONTINUATION frame (type=0x09) is used to continue a sequence of field block fragments (Section 4.3). Any number of CONTINUATION frames can be sent, as long as the preceding frame is on the same stream and is a HEADERS, PUSH_PROMISE, or CONTINUATION frame without the END_HEADERS flag set.¶

CONTINUATION Frame { Length (24), Type (8) = 0x09, Unused Flags (5), END_HEADERS Flag (1), Unused Flags (2), Reserved (1), Stream Identifier (31), Field Block Fragment (..), }

Figure 12: CONTINUATION Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The CONTINUATION frame payload contains a field block fragment (Section 4.3).¶

The CONTINUATION frame defines the following flag:¶

END_HEADERS (0x04):

When set, the END_HEADERS flag indicates that this frame ends a field block (Section 4.3).¶',88267,89124);
INSERT INTO "passages" VALUES('S1-P105',1,105,'If the END_HEADERS flag is not set, this frame MUST be followed by another CONTINUATION frame. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The CONTINUATION frame changes the connection state as defined in Section 4.3.¶

CONTINUATION frames MUST be associated with a stream. If a CONTINUATION frame is received with a Stream Identifier field of 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A CONTINUATION frame MUST be preceded by a HEADERS, PUSH_PROMISE or CONTINUATION frame without the END_HEADERS flag set. A recipient that observes violation of this rule MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

7. Error Codes

Error codes are 32-bit fields that are used in RST_STREAM and GOAWAY frames to convey the reasons for the stream or connection error.¶',89126,90082);
INSERT INTO "passages" VALUES('S1-P106',1,106,'Error codes share a common code space. Some error codes apply only to either streams or the entire connection and have no defined semantics in the other context.¶

The following error codes are defined:¶

NO_ERROR (0x00):

The associated condition is not a result of an error. For example, a GOAWAY might include this code to indicate graceful shutdown of a connection.¶

PROTOCOL_ERROR (0x01):

The endpoint detected an unspecific protocol error. This error is for use when a more specific error code is not available.¶

INTERNAL_ERROR (0x02):

The endpoint encountered an unexpected internal error.¶

FLOW_CONTROL_ERROR (0x03):

The endpoint detected that its peer violated the flow-control protocol.¶

SETTINGS_TIMEOUT (0x04):

The endpoint sent a SETTINGS frame but did not receive a response in a timely manner. See Section 6.5.3 ("Settings Synchronization").¶

STREAM_CLOSED (0x05):

The endpoint received a frame after a stream was half-closed.¶

FRAME_SIZE_ERROR (0x06):',90084,91062);
INSERT INTO "passages" VALUES('S1-P107',1,107,'The endpoint received a frame with an invalid size.¶

REFUSED_STREAM (0x07):

The endpoint refused the stream prior to performing any application processing (see Section 8.7 for details).¶

CANCEL (0x08):

The endpoint uses this error code to indicate that the stream is no longer needed.¶

COMPRESSION_ERROR (0x09):

The endpoint is unable to maintain the field section compression context for the connection.¶

CONNECT_ERROR (0x0a):

The connection established in response to a CONNECT request (Section 8.5) was reset or abnormally closed.¶

ENHANCE_YOUR_CALM (0x0b):

The endpoint detected that its peer is exhibiting a behavior that might be generating excessive load.¶

INADEQUATE_SECURITY (0x0c):

The underlying transport has properties that do not meet minimum security requirements (see Section 9.2).¶

HTTP_1_1_REQUIRED (0x0d):

The endpoint requires that HTTP/1.1 be used instead of HTTP/2.¶',91064,91966);
INSERT INTO "passages" VALUES('S1-P108',1,108,'Unknown or unsupported error codes MUST NOT trigger any special behavior. These MAY be treated by an implementation as being equivalent to INTERNAL_ERROR.¶

8. Expressing HTTP Semantics in HTTP/2

HTTP/2 is an instantiation of the HTTP message abstraction (Section 6 of [HTTP]).¶

8.1. HTTP Message Framing

A client sends an HTTP request on a new stream, using a previously unused stream identifier (Section 5.1.1). A server sends an HTTP response on the same stream as the request.¶

An HTTP message (request or response) consists of:¶

one HEADERS frame (followed by zero or more CONTINUATION frames) containing the header section (see Section 6.3 of [HTTP]),¶

zero or more DATA frames containing the message content (see Section 6.4 of [HTTP]), and¶

optionally, one HEADERS frame (followed by zero or more CONTINUATION frames) containing the trailer section, if present (see Section 6.5 of [HTTP]).¶',91968,92873);
INSERT INTO "passages" VALUES('S1-P109',1,109,'For a response only, a server MAY send any number of interim responses before the HEADERS frame containing a final response. An interim response consists of a HEADERS frame (which might be followed by zero or more CONTINUATION frames) containing the control data and header section of an interim (1xx) HTTP response (see Section 15 of [HTTP]). A HEADERS frame with the END_STREAM flag set that carries an informational status code is malformed (Section 8.1.1).¶

The last frame in the sequence bears an END_STREAM flag, noting that a HEADERS frame with the END_STREAM flag set can be followed by CONTINUATION frames that carry any remaining fragments of the field block.¶

Other frames (from any stream) MUST NOT occur between the HEADERS frame and any CONTINUATION frames that might follow.¶

HTTP/2 uses DATA frames to carry message content. The chunked transfer encoding defined in Section 7.1 of [HTTP/1.1] cannot be used in HTTP/2; see Section 8.2.2.¶',92875,93831);
INSERT INTO "passages" VALUES('S1-P110',1,110,'Trailer fields are carried in a field block that also terminates the stream. That is, trailer fields comprise a sequence starting with a HEADERS frame, followed by zero or more CONTINUATION frames, where the HEADERS frame bears an END_STREAM flag. Trailers MUST NOT include pseudo-header fields (Section 8.3). An endpoint that receives pseudo-header fields in trailers MUST treat the request or response as malformed (Section 8.1.1).¶

An endpoint that receives a HEADERS frame without the END_STREAM flag set after receiving the HEADERS frame that opens a request or after receiving a final (non-informational) status code MUST treat the corresponding request or response as malformed (Section 8.1.1).¶',93833,94536);
INSERT INTO "passages" VALUES('S1-P111',1,111,'An HTTP request/response exchange fully consumes a single stream. A request starts with the HEADERS frame that puts the stream into the "open" state. The request ends with a frame with the END_STREAM flag set, which causes the stream to become "half-closed (local)" for the client and "half-closed (remote)" for the server. A response stream starts with zero or more interim responses in HEADERS frames, followed by a HEADERS frame containing a final status code.¶',94538,95002);
INSERT INTO "passages" VALUES('S1-P112',1,112,'An HTTP response is complete after the server sends -- or the client receives -- a frame with the END_STREAM flag set (including any CONTINUATION frames needed to complete a field block). A server can send a complete response prior to the client sending an entire request if the response does not depend on any portion of the request that has not been sent and received. When this is true, a server MAY request that the client abort transmission of a request without error by sending a RST_STREAM with an error code of NO_ERROR after sending a complete response (i.e., a frame with the END_STREAM flag set). Clients MUST NOT discard responses as a result of receiving such a RST_STREAM, though clients can always discard responses at their discretion for other reasons.¶

8.1.1. Malformed Messages',95004,95801);
INSERT INTO "passages" VALUES('S1-P113',1,113,'A malformed request or response is one that is an otherwise valid sequence of HTTP/2 frames but is invalid due to the presence of extraneous frames, prohibited fields or pseudo-header fields, the absence of mandatory pseudo-header fields, the inclusion of uppercase field names, or invalid field names and/or values (in certain circumstances; see Section 8.2).¶

A request or response that includes message content can include a content-length header field. A request or response is also malformed if the value of a content-length header field does not equal the sum of the DATA frame payload lengths that form the content, unless the message is defined as having no content. For example, 204 or 304 responses contain no content, as does the response to a HEAD request. A response that is defined to have no content, as described in Section 6.4.1 of [HTTP], MAY have a non-zero content-length header field, even though no content is included in DATA frames.¶',95803,96761);
INSERT INTO "passages" VALUES('S1-P114',1,114,'Intermediaries that process HTTP requests or responses (i.e., any intermediary not acting as a tunnel) MUST NOT forward a malformed request or response. Malformed requests or responses that are detected MUST be treated as a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

For malformed requests, a server MAY send an HTTP response prior to closing or resetting the stream. Clients MUST NOT accept a malformed response.¶

Endpoints that progressively process messages might have performed some processing before identifying a request or response as malformed. For instance, it might be possible to generate an informational or 404 status code without having received a complete request. Similarly, intermediaries might forward incomplete messages before detecting errors. A server MAY generate a final response before receiving an entire request when the response does not depend on the remainder of the request being correct.¶',96763,97696);
INSERT INTO "passages" VALUES('S1-P115',1,115,'These requirements are intended to protect against several types of common attacks against HTTP; they are deliberately strict because being permissive can expose implementations to these vulnerabilities.¶

8.2. HTTP Fields

HTTP fields (Section 5 of [HTTP]) are conveyed by HTTP/2 in the HEADERS, CONTINUATION, and PUSH_PROMISE frames, compressed with HPACK [COMPRESSION].¶

Field names MUST be converted to lowercase when constructing an HTTP/2 message.¶

8.2.1. Field Validity

The definitions of field names and values in HTTP prohibit some characters that HPACK might be able to convey. HTTP/2 implementations SHOULD validate field names and values according to their definitions in Sections 5.1 and 5.5 of [HTTP], respectively, and treat messages that contain prohibited characters as malformed (Section 8.1.1).¶',97698,98515);
INSERT INTO "passages" VALUES('S1-P116',1,116,'Failure to validate fields can be exploited for request smuggling attacks. In particular, unvalidated fields might enable attacks when messages are forwarded using HTTP/1.1 [HTTP/1.1], where characters such as carriage return (CR), line feed (LF), and COLON are used as delimiters. Implementations MUST perform the following minimal validation of field names and values:¶

A field name MUST NOT contain characters in the ranges 0x00-0x20, 0x41-0x5a, or 0x7f-0xff (all ranges inclusive). This specifically excludes all non-visible ASCII characters, ASCII SP (0x20), and uppercase characters (''A'' to ''Z'', ASCII 0x41 to 0x5a).¶

With the exception of pseudo-header fields (Section 8.3), which have a name that starts with a single colon, field names MUST NOT include a colon (ASCII COLON, 0x3a).¶

A field value MUST NOT contain the zero value (ASCII NUL, 0x00), line feed (ASCII LF, 0x0a), or carriage return (ASCII CR, 0x0d) at any position.¶',98517,99458);
INSERT INTO "passages" VALUES('S1-P117',1,117,'A field value MUST NOT start or end with an ASCII whitespace character (ASCII SP or HTAB, 0x20 or 0x09).¶

A request or response that contains a field that violates any of these conditions MUST be treated as malformed (Section 8.1.1). In particular, an intermediary that does not process fields when forwarding messages MUST NOT forward fields that contain any of the values that are listed as prohibited above.¶

When a request message violates one of these requirements, an implementation SHOULD generate a 400 (Bad Request) status code (see Section 15.5.1 of [HTTP]), unless a more suitable status code is defined or the status code cannot be sent (e.g., because the error occurs in a trailer field).¶

8.2.2. Connection-Specific Header Fields',99460,100206);
INSERT INTO "passages" VALUES('S1-P118',1,118,'HTTP/2 does not use the Connection header field (Section 7.6.1 of [HTTP]) to indicate connection-specific header fields; in this protocol, connection-specific metadata is conveyed by other means. An endpoint MUST NOT generate an HTTP/2 message containing connection-specific header fields. This includes the Connection header field and those listed as having connection-specific semantics in Section 7.6.1 of [HTTP] (that is, Proxy-Connection, Keep-Alive, Transfer-Encoding, and Upgrade). Any message containing connection-specific header fields MUST be treated as malformed (Section 8.1.1).¶

The only exception to this is the TE header field, which MAY be present in an HTTP/2 request; when it is, it MUST NOT contain any value other than "trailers".¶

An intermediary transforming an HTTP/1.x message to HTTP/2 MUST remove connection-specific header fields as discussed in Section 7.6.1 of [HTTP], or their messages will be treated by other HTTP/2 endpoints as malformed (Section 8.1.1).¶',100208,101199);
INSERT INTO "passages" VALUES('S1-P119',1,119,'8.2.3. Compressing the Cookie Header Field

The Cookie header field [COOKIE] uses a semicolon (";") to delimit cookie-pairs (or "crumbs"). This header field contains multiple values, but does not use a COMMA (",") as a separator, thereby preventing cookie-pairs from being sent on multiple field lines (see Section 5.2 of [HTTP]). This can significantly reduce compression efficiency, as updates to individual cookie-pairs would invalidate any field lines that are stored in the HPACK table.¶

To allow for better compression efficiency, the Cookie header field MAY be split into separate header fields, each with one or more cookie-pairs. If there are multiple Cookie header fields after decompression, these MUST be concatenated into a single octet string using the two-octet delimiter of 0x3b, 0x20 (the ASCII string "; ") before being passed into a non-HTTP/2 context, such as an HTTP/1.1 connection, or a generic HTTP server application.¶',101201,102144);
INSERT INTO "passages" VALUES('S1-P120',1,120,'Therefore, the following two lists of Cookie header fields are semantically equivalent.¶

cookie: a=b; c=d; e=f cookie: a=b cookie: c=d cookie: e=f

¶

8.3. HTTP Control Data

HTTP/2 uses special pseudo-header fields beginning with a '':'' character (ASCII 0x3a) to convey message control data (see Section 6.2 of [HTTP]).¶

Pseudo-header fields are not HTTP header fields. Endpoints MUST NOT generate pseudo-header fields other than those defined in this document. Note that an extension could negotiate the use of additional pseudo-header fields; see Section 5.5.¶

Pseudo-header fields are only valid in the context in which they are defined. Pseudo-header fields defined for requests MUST NOT appear in responses; pseudo-header fields defined for responses MUST NOT appear in requests. Pseudo-header fields MUST NOT appear in a trailer section. Endpoints MUST treat a request or response that contains undefined or invalid pseudo-header fields as malformed (Section 8.1.1).¶',102146,103122);
INSERT INTO "passages" VALUES('S1-P121',1,121,'All pseudo-header fields MUST appear in a field block before all regular field lines. Any request or response that contains a pseudo-header field that appears in a field block after a regular field line MUST be treated as malformed (Section 8.1.1).¶

The same pseudo-header field name MUST NOT appear more than once in a field block. A field block for an HTTP request or response that contains a repeated pseudo-header field name MUST be treated as malformed (Section 8.1.1).¶

8.3.1. Request Pseudo-Header Fields

The following pseudo-header fields are defined for HTTP/2 requests:¶

The ":method" pseudo-header field includes the HTTP method (Section 9 of [HTTP]).¶

The ":scheme" pseudo-header field includes the scheme portion of the request target. The scheme is taken from the target URI (Section 3.1 of [RFC3986]) when generating a request directly, or from the scheme of a translated request (for example, see Section 3.3 of [HTTP/1.1]). Scheme is omitted for CONNECT requests (Section 8.5).¶',103124,104124);
INSERT INTO "passages" VALUES('S1-P122',1,122,'":scheme" is not restricted to "http" and "https" schemed URIs. A proxy or gateway can translate requests for non-HTTP schemes, enabling the use of HTTP to interact with non-HTTP services.¶

The ":authority" pseudo-header field conveys the authority portion (Section 3.2 of [RFC3986]) of the target URI (Section 7.1 of [HTTP]). The recipient of an HTTP/2 request MUST NOT use the Host header field to determine the target URI if ":authority" is present.¶

Clients that generate HTTP/2 requests directly MUST use the ":authority" pseudo-header field to convey authority information, unless there is no authority information to convey (in which case it MUST NOT generate ":authority").¶',104126,104810);
INSERT INTO "passages" VALUES('S1-P123',1,123,'Clients MUST NOT generate a request with a Host header field that differs from the ":authority" pseudo-header field. A server SHOULD treat a request as malformed if it contains a Host header field that identifies an entity that differs from the entity in the ":authority" pseudo-header field. The values of fields need to be normalized to compare them (see Section 6.2 of [RFC3986]). An origin server can apply any normalization method, whereas other servers MUST perform scheme-based normalization (see Section 6.2.3 of [RFC3986]) of the two fields.¶

An intermediary that forwards a request over HTTP/2 MUST construct an ":authority" pseudo-header field using the authority information from the control data of the original request, unless the original request''s target URI does not contain authority information (in which case it MUST NOT generate ":authority"). Note that the Host header field is not the sole source of this information; see Section 7.2 of [HTTP].¶',104812,105781);
INSERT INTO "passages" VALUES('S1-P124',1,124,'An intermediary that needs to generate a Host header field (which might be necessary to construct an HTTP/1.1 request) MUST use the value from the ":authority" pseudo-header field as the value of the Host field, unless the intermediary also changes the request target. This replaces any existing Host field to avoid potential vulnerabilities in HTTP routing.¶

An intermediary that forwards a request over HTTP/2 MAY retain any Host header field.¶

Note that request targets for CONNECT or asterisk-form OPTIONS requests never include authority information; see Sections 7.1 and 7.2 of [HTTP].¶

":authority" MUST NOT include the deprecated userinfo subcomponent for "http" or "https" schemed URIs.¶',105783,106482);
INSERT INTO "passages" VALUES('S1-P125',1,125,'The ":path" pseudo-header field includes the path and query parts of the target URI (the absolute-path production and, optionally, a ''?'' character followed by the query production; see Section 4.1 of [HTTP]). A request in asterisk form (for OPTIONS) includes the value ''*'' for the ":path" pseudo-header field.¶

This pseudo-header field MUST NOT be empty for "http" or "https" URIs; "http" or "https" URIs that do not contain a path component MUST include a value of ''/''. The exceptions to this rule are:¶

an OPTIONS request for an "http" or "https" URI that does not include a path component; these MUST include a ":path" pseudo-header field with a value of ''*'' (see Section 7.1 of [HTTP]).¶

CONNECT requests (Section 8.5), where the ":path" pseudo-header field is omitted.¶',106484,107261);
INSERT INTO "passages" VALUES('S1-P126',1,126,'All HTTP/2 requests MUST include exactly one valid value for the ":method", ":scheme", and ":path" pseudo-header fields, unless they are CONNECT requests (Section 8.5). An HTTP request that omits mandatory pseudo-header fields is malformed (Section 8.1.1).¶

Individual HTTP/2 requests do not carry an explicit indicator of protocol version. All HTTP/2 requests implicitly have a protocol version of "2.0" (see Section 6.2 of [HTTP]).¶

8.3.2. Response Pseudo-Header Fields

For HTTP/2 responses, a single ":status" pseudo-header field is defined that carries the HTTP status code field (see Section 15 of [HTTP]). This pseudo-header field MUST be included in all responses, including interim responses; otherwise, the response is malformed (Section 8.1.1).¶

HTTP/2 responses implicitly have a protocol version of "2.0".¶

8.4. Server Push',107263,108103);
INSERT INTO "passages" VALUES('S1-P127',1,127,'HTTP/2 allows a server to preemptively send (or "push") responses (along with corresponding "promised" requests) to a client in association with a previous client-initiated request.¶

Server push was designed to allow a server to improve client-perceived performance by predicting what requests will follow those that it receives, thereby removing a round trip for them. For example, a request for HTML is often followed by requests for stylesheets and scripts referenced by that page. When these requests are pushed, the client does not need to wait to receive the references to them in the HTML and issue separate requests.¶',108105,108731);
INSERT INTO "passages" VALUES('S1-P128',1,128,'In practice, server push is difficult to use effectively, because it requires the server to correctly anticipate the additional requests the client will make, taking into account factors such as caching, content negotiation, and user behavior. Errors in prediction can lead to performance degradation, due to the opportunity cost that the additional data on the wire represents. In particular, pushing any significant amount of data can cause contention issues with responses that are more important.¶

A client can request that server push be disabled, though this is negotiated for each hop independently. The SETTINGS_ENABLE_PUSH setting can be set to 0 to indicate that server push is disabled.¶',108733,109432);
INSERT INTO "passages" VALUES('S1-P129',1,129,'Promised requests MUST be safe (see Section 9.2.1 of [HTTP]) and cacheable (see Section 9.2.3 of [HTTP]). Promised requests cannot include any content or a trailer section. Clients that receive a promised request that is not cacheable, that is not known to be safe, or that indicates the presence of request content MUST reset the promised stream with a stream error (Section 5.4.2) of type PROTOCOL_ERROR. Note that this could result in the promised stream being reset if the client does not recognize a newly defined method as being safe.¶

Pushed responses that are cacheable (see Section 3 of [CACHING]) can be stored by the client, if it implements an HTTP cache. Pushed responses are considered successfully validated on the origin server (e.g., if the "no-cache" cache response directive is present; see Section 5.2.2.4 of [CACHING]) while the stream identified by the promised stream identifier is still open.¶',109434,110352);
INSERT INTO "passages" VALUES('S1-P130',1,130,'Pushed responses that are not cacheable MUST NOT be stored by any HTTP cache. They MAY be made available to the application separately.¶

The server MUST include a value in the ":authority" pseudo-header field for which the server is authoritative (see Section 10.1). A client MUST treat a PUSH_PROMISE for which the server is not authoritative as a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

An intermediary can receive pushes from the server and choose not to forward them on to the client. In other words, how to make use of the pushed information is up to that intermediary. Equally, the intermediary might choose to make additional pushes to the client, without any action taken by the server.¶

A client cannot push. Thus, servers MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. A server cannot set the SETTINGS_ENABLE_PUSH setting to a value other than 0 (see Section 6.5.2).¶

8.4.1. Push Requests',110354,111332);
INSERT INTO "passages" VALUES('S1-P131',1,131,'Server push is semantically equivalent to a server responding to a request; however, in this case, that request is also sent by the server, as a PUSH_PROMISE frame.¶

The PUSH_PROMISE frame includes a field block that contains control data and a complete set of request header fields that the server attributes to the request. It is not possible to push a response to a request that includes message content.¶

Promised requests are always associated with an explicit request from the client. The PUSH_PROMISE frames sent by the server are sent on that explicit request''s stream. The PUSH_PROMISE frame also includes a promised stream identifier, chosen from the stream identifiers available to the server (see Section 5.1.1).¶',111334,112061);
INSERT INTO "passages" VALUES('S1-P132',1,132,'The header fields in PUSH_PROMISE and any subsequent CONTINUATION frames MUST be a valid and complete set of request header fields (Section 8.3.1). The server MUST include a method in the ":method" pseudo-header field that is safe and cacheable. If a client receives a PUSH_PROMISE that does not include a complete and valid set of header fields or the ":method" pseudo-header field identifies a method that is not safe, it MUST respond on the promised stream with a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

The server SHOULD send PUSH_PROMISE (Section 6.6) frames prior to sending any frames that reference the promised responses. This avoids a race where clients issue requests prior to receiving any PUSH_PROMISE frames.¶',112063,112801);
INSERT INTO "passages" VALUES('S1-P133',1,133,'For example, if the server receives a request for a document containing embedded links to multiple image files and the server chooses to push those additional images to the client, sending PUSH_PROMISE frames before the DATA frames that contain the image links ensures that the client is able to see that a resource will be pushed before discovering embedded links. Similarly, if the server pushes resources referenced by the field block (for instance, in Link header fields), sending a PUSH_PROMISE before sending the header ensures that clients do not request those resources.¶

PUSH_PROMISE frames MUST NOT be sent by the client.¶',112803,113436);
INSERT INTO "passages" VALUES('S1-P134',1,134,'PUSH_PROMISE frames can be sent by the server on any client-initiated stream, but the stream MUST be in either the "open" or "half-closed (remote)" state with respect to the server. PUSH_PROMISE frames are interspersed with the frames that comprise a response, though they cannot be interspersed with HEADERS and CONTINUATION frames that comprise a single field block.¶

Sending a PUSH_PROMISE frame creates a new stream and puts the stream into the "reserved (local)" state for the server and the "reserved (remote)" state for the client.¶

8.4.2. Push Responses

After sending the PUSH_PROMISE frame, the server can begin delivering the pushed response as a response (Section 8.3.2) on a server-initiated stream that uses the promised stream identifier. The server uses this stream to transmit an HTTP response, using the same sequence of frames as that defined in Section 8.1. This stream becomes "half-closed" to the client (Section 5.1) after the initial HEADERS frame is sent.¶',113438,114421);
INSERT INTO "passages" VALUES('S1-P135',1,135,'Once a client receives a PUSH_PROMISE frame and chooses to accept the pushed response, the client SHOULD NOT issue any requests for the promised response until after the promised stream has closed.¶

If the client determines, for any reason, that it does not wish to receive the pushed response from the server or if the server takes too long to begin sending the promised response, the client can send a RST_STREAM frame, using either the CANCEL or REFUSED_STREAM code and referencing the pushed stream''s identifier.¶',114423,114941);
INSERT INTO "passages" VALUES('S1-P136',1,136,'A client can use the SETTINGS_MAX_CONCURRENT_STREAMS setting to limit the number of responses that can be concurrently pushed by a server. Advertising a SETTINGS_MAX_CONCURRENT_STREAMS value of zero prevents the server from opening the streams necessary to push responses. However, this does not prevent the server from reserving streams using PUSH_PROMISE frames, because reserved streams do not count toward the concurrent stream limit. Clients that do not wish to receive pushed resources need to reset any unwanted reserved streams or set SETTINGS_ENABLE_PUSH to 0.¶

Clients receiving a pushed response MUST validate that either the server is authoritative (see Section 10.1) or the proxy that provided the pushed response is configured for the corresponding request. For example, a server that offers a certificate for only the example.com DNS-ID (see [RFC6125]) is not permitted to push a response for <https://www.example.org/doc>.¶',114943,115883);
INSERT INTO "passages" VALUES('S1-P137',1,137,'The response for a PUSH_PROMISE stream begins with a HEADERS frame, which immediately puts the stream into the "half-closed (remote)" state for the server and "half-closed (local)" state for the client, and ends with a frame with the END_STREAM flag set, which places the stream in the "closed" state.¶

8.5. The CONNECT Method

The CONNECT method (Section 9.3.6 of [HTTP]) is used to convert an HTTP connection into a tunnel to a remote host. CONNECT is primarily used with HTTP proxies to establish a TLS session with an origin server for the purposes of interacting with "https" resources.¶

In HTTP/2, the CONNECT method establishes a tunnel over a single HTTP/2 stream to a remote host, rather than converting the entire connection to a tunnel. A CONNECT header section is constructed as defined in Section 8.3.1 ("Request Pseudo-Header Fields"), with a few differences. Specifically:¶

The ":method" pseudo-header field is set to CONNECT.¶',115885,116830);
INSERT INTO "passages" VALUES('S1-P138',1,138,'The ":scheme" and ":path" pseudo-header fields MUST be omitted.¶

The ":authority" pseudo-header field contains the host and port to connect to (equivalent to the authority-form of the request-target of CONNECT requests; see Section 3.2.3 of [HTTP/1.1]).¶

A CONNECT request that does not conform to these restrictions is malformed (Section 8.1.1).¶

A proxy that supports CONNECT establishes a TCP connection [TCP] to the host and port identified in the ":authority" pseudo-header field. Once this connection is successfully established, the proxy sends a HEADERS frame containing a 2xx-series status code to the client, as defined in Section 9.3.6 of [HTTP].¶',116832,117493);
INSERT INTO "passages" VALUES('S1-P139',1,139,'After the initial HEADERS frame sent by each peer, all subsequent DATA frames correspond to data sent on the TCP connection. The frame payload of any DATA frames sent by the client is transmitted by the proxy to the TCP server; data received from the TCP server is assembled into DATA frames by the proxy. Frame types other than DATA or stream management frames (RST_STREAM, WINDOW_UPDATE, and PRIORITY) MUST NOT be sent on a connected stream and MUST be treated as a stream error (Section 5.4.2) if received.¶',117495,118005);
INSERT INTO "passages" VALUES('S1-P140',1,140,'The TCP connection can be closed by either peer. The END_STREAM flag on a DATA frame is treated as being equivalent to the TCP FIN bit. A client is expected to send a DATA frame with the END_STREAM flag set after receiving a frame with the END_STREAM flag set. A proxy that receives a DATA frame with the END_STREAM flag set sends the attached data with the FIN bit set on the last TCP segment. A proxy that receives a TCP segment with the FIN bit set sends a DATA frame with the END_STREAM flag set. Note that the final TCP segment or DATA frame could be empty.¶

A TCP connection error is signaled with RST_STREAM. A proxy treats any error in the TCP connection, which includes receiving a TCP segment with the RST bit set, as a stream error (Section 5.4.2) of type CONNECT_ERROR. Correspondingly, a proxy MUST send a TCP segment with the RST bit set if it detects an error with the stream or the HTTP/2 connection.¶

8.6. The Upgrade Header Field',118007,118956);
INSERT INTO "passages" VALUES('S1-P141',1,141,'HTTP/2 does not support the 101 (Switching Protocols) informational status code (Section 15.2.2 of [HTTP]).¶

The semantics of 101 (Switching Protocols) aren''t applicable to a multiplexed protocol. Similar functionality might be enabled through the use of extended CONNECT [RFC8441], and other protocols are able to use the same mechanisms that HTTP/2 uses to negotiate their use (see Section 3).¶

8.7. Request Reliability

In general, an HTTP client is unable to retry a non-idempotent request when an error occurs because there is no means to determine the nature of the error (see Section 9.2.2 of [HTTP]). It is possible that some server processing occurred prior to the error, which could result in undesirable effects if the request were reattempted.¶

HTTP/2 provides two mechanisms for providing a guarantee to a client that a request has not been processed:¶',118958,119826);
INSERT INTO "passages" VALUES('S1-P142',1,142,'The GOAWAY frame indicates the highest stream number that might have been processed. Requests on streams with higher numbers are therefore guaranteed to be safe to retry.¶

The REFUSED_STREAM error code can be included in a RST_STREAM frame to indicate that the stream is being closed prior to any processing having occurred. Any request that was sent on the reset stream can be safely retried.¶

Requests that have not been processed have not failed; clients MAY automatically retry them, even those with non-idempotent methods.¶

A server MUST NOT indicate that a stream has not been processed unless it can guarantee that fact. If frames that are on a stream are passed to the application layer for any stream, then REFUSED_STREAM MUST NOT be used for that stream, and a GOAWAY frame MUST include a stream identifier that is greater than or equal to the given stream identifier.¶',119828,120710);
INSERT INTO "passages" VALUES('S1-P143',1,143,'In addition to these mechanisms, the PING frame provides a way for a client to easily test a connection. Connections that remain idle can become broken, because some middleboxes (for instance, network address translators or load balancers) silently discard connection bindings. The PING frame allows a client to safely test whether a connection is still active without sending a request.¶

8.8. Examples

This section shows HTTP/1.1 requests and responses, with illustrations of equivalent HTTP/2 requests and responses.¶

8.8.1. Simple Request

An HTTP GET request includes control data and a request header with no message content and is therefore transmitted as a single HEADERS frame, followed by zero or more CONTINUATION frames containing the serialized block of request header fields. The HEADERS frame in the following has both the END_HEADERS and END_STREAM flags set; no CONTINUATION frames are sent.¶',120712,121623);
INSERT INTO "passages" VALUES('S1-P144',1,144,'GET /resource HTTP/1.1 HEADERS Host: example.org ==> + END_STREAM Accept: image/jpeg + END_HEADERS :method = GET :scheme = https :authority = example.org :path = /resource host = example.org accept = image/jpeg

¶

8.8.2. Simple Response

Similarly, a response that includes only control data and a response header is transmitted as a HEADERS frame (again, followed by zero or more CONTINUATION frames) containing the serialized block of response header fields.¶

HTTP/1.1 304 Not Modified HEADERS ETag: "xyzzy" ==> + END_STREAM Expires: Thu, 23 Jan ... + END_HEADERS :status = 304 etag = "xyzzy" expires = Thu, 23 Jan ...

¶

8.8.3. Complex Request',121625,122274);
INSERT INTO "passages" VALUES('S1-P145',1,145,'An HTTP POST request that includes control data and a request header with message content is transmitted as one HEADERS frame, followed by zero or more CONTINUATION frames containing the request header, followed by one or more DATA frames, with the last CONTINUATION (or HEADERS) frame having the END_HEADERS flag set and the final DATA frame having the END_STREAM flag set:¶

POST /resource HTTP/1.1 HEADERS Host: example.org ==> - END_STREAM Content-Type: image/jpeg - END_HEADERS Content-Length: 123 :method = POST :authority = example.org :path = /resource {binary data} :scheme = https CONTINUATION + END_HEADERS content-type = image/jpeg host = example.org content-length = 123 DATA + END_STREAM {binary data}

¶

Note that data contributing to any given field line could be spread between field block fragments. The allocation of field lines to frames in this example is illustrative only.¶

8.8.4. Response with Body',122276,123200);
INSERT INTO "passages" VALUES('S1-P146',1,146,'A response that includes control data and a response header with message content is transmitted as a HEADERS frame, followed by zero or more CONTINUATION frames, followed by one or more DATA frames, with the last DATA frame in the sequence having the END_STREAM flag set:¶

HTTP/1.1 200 OK HEADERS Content-Type: image/jpeg ==> - END_STREAM Content-Length: 123 + END_HEADERS :status = 200 {binary data} content-type = image/jpeg content-length = 123 DATA + END_STREAM {binary data}

¶

8.8.5. Informational Responses

An informational response using a 1xx status code other than 101 is transmitted as a HEADERS frame, followed by zero or more CONTINUATION frames.¶

A trailer section is sent as a field block after both the request or response field block and all the DATA frames have been sent. The HEADERS frame starting the field block that comprises the trailer section has the END_STREAM flag set.¶',123202,124104);
INSERT INTO "passages" VALUES('S1-P147',1,147,'The following example includes both a 100 (Continue) status code, which is sent in response to a request containing a "100-continue" token in the Expect header field, and a trailer section:¶

HTTP/1.1 100 Continue HEADERS Extension-Field: bar ==> - END_STREAM + END_HEADERS :status = 100 extension-field = bar HTTP/1.1 200 OK HEADERS Content-Type: image/jpeg ==> - END_STREAM Transfer-Encoding: chunked + END_HEADERS Trailer: Foo :status = 200 content-type = image/jpeg 123 trailer = Foo {binary data} 0 DATA Foo: bar - END_STREAM {binary data} HEADERS + END_STREAM + END_HEADERS foo = bar

¶

9. HTTP/2 Connections

This section outlines attributes of HTTP that improve interoperability, reduce exposure to known security vulnerabilities, or reduce the potential for implementation variation.¶

9.1. Connection Management',124106,124928);
INSERT INTO "passages" VALUES('S1-P148',1,148,'HTTP/2 connections are persistent. For best performance, it is expected that clients will not close connections until it is determined that no further communication with a server is necessary (for example, when a user navigates away from a particular web page) or until the server closes the connection.¶

Clients SHOULD NOT open more than one HTTP/2 connection to a given host and port pair, where the host is derived from a URI, a selected alternative service [ALT-SVC], or a configured proxy.¶

A client can create additional connections as replacements, either to replace connections that are near to exhausting the available stream identifier space (Section 5.1.1), to refresh the keying material for a TLS connection, or to replace connections that have encountered errors (Section 5.4.1).¶',124930,125726);
INSERT INTO "passages" VALUES('S1-P149',1,149,'A client MAY open multiple connections to the same IP address and TCP port using different Server Name Indication [TLS-EXT] values or to provide different TLS client certificates but SHOULD avoid creating multiple connections with the same configuration.¶

Servers are encouraged to maintain open connections for as long as possible but are permitted to terminate idle connections if necessary. When either endpoint chooses to close the transport-layer TCP connection, the terminating endpoint SHOULD first send a GOAWAY (Section 6.8) frame so that both endpoints can reliably determine whether previously sent frames have been processed and gracefully complete or terminate any necessary remaining tasks.¶

9.1.1. Connection Reuse',125728,126459);
INSERT INTO "passages" VALUES('S1-P150',1,150,'Connections that are made to an origin server, either directly or through a tunnel created using the CONNECT method (Section 8.5), MAY be reused for requests with multiple different URI authority components. A connection can be reused as long as the origin server is authoritative (Section 10.1). For TCP connections without TLS, this depends on the host having resolved to the same IP address.¶

For "https" resources, connection reuse additionally depends on having a certificate that is valid for the host in the URI. The certificate presented by the server MUST satisfy any checks that the client would perform when forming a new TLS connection for the host in the URI. A single certificate can be used to establish authority for multiple origins. Section 4.3 of [HTTP] describes how a client determines whether a server is authoritative for a URI.¶',126461,127314);
INSERT INTO "passages" VALUES('S1-P151',1,151,'In some deployments, reusing a connection for multiple origins can result in requests being directed to the wrong origin server. For example, TLS termination might be performed by a middlebox that uses the TLS Server Name Indication [TLS-EXT] extension to select an origin server. This means that it is possible for clients to send requests to servers that might not be the intended target for the request, even though the server is otherwise authoritative.¶

A server that does not wish clients to reuse connections can indicate that it is not authoritative for a request by sending a 421 (Misdirected Request) status code in response to the request (see Section 15.5.20 of [HTTP]).¶

A client that is configured to use a proxy over HTTP/2 directs requests to that proxy through a single connection. That is, all requests sent via a proxy reuse the connection to the proxy.¶

9.2. Use of TLS Features',127316,128217);
INSERT INTO "passages" VALUES('S1-P152',1,152,'Implementations of HTTP/2 MUST use TLS version 1.2 [TLS12] or higher for HTTP/2 over TLS. The general TLS usage guidance in [TLSBCP] SHOULD be followed, with some additional restrictions that are specific to HTTP/2.¶

The TLS implementation MUST support the Server Name Indication (SNI) [TLS-EXT] extension to TLS. If the server is identified by a domain name [DNS-TERMS], clients MUST send the server_name TLS extension unless an alternative mechanism to indicate the target host is used.¶

Requirements for deployments of HTTP/2 that negotiate TLS 1.3 [TLS13] are included in Section 9.2.3. Deployments of TLS 1.2 are subject to the requirements in Sections 9.2.1 and 9.2.2. Implementations are encouraged to provide defaults that comply, but it is recognized that deployments are ultimately responsible for compliance.¶

9.2.1. TLS 1.2 Features',128219,129066);
INSERT INTO "passages" VALUES('S1-P153',1,153,'This section describes restrictions on the TLS 1.2 feature set that can be used with HTTP/2. Due to deployment limitations, it might not be possible to fail TLS negotiation when these restrictions are not met. An endpoint MAY immediately terminate an HTTP/2 connection that does not meet these TLS requirements with a connection error (Section 5.4.1) of type INADEQUATE_SECURITY.¶

A deployment of HTTP/2 over TLS 1.2 MUST disable compression. TLS compression can lead to the exposure of information that would not otherwise be revealed [RFC3749]. Generic compression is unnecessary, since HTTP/2 provides compression features that are more aware of context and therefore likely to be more appropriate for use for performance, security, or other reasons.¶',129068,129823);
INSERT INTO "passages" VALUES('S1-P154',1,154,'A deployment of HTTP/2 over TLS 1.2 MUST disable renegotiation. An endpoint MUST treat a TLS renegotiation as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that disabling renegotiation can result in long-lived connections becoming unusable due to limits on the number of messages the underlying cipher suite can encipher.¶

An endpoint MAY use renegotiation to provide confidentiality protection for client credentials offered in the handshake, but any renegotiation MUST occur prior to sending the connection preface. A server SHOULD request a client certificate if it sees a renegotiation request immediately after establishing a connection.¶

This effectively prevents the use of renegotiation in response to a request for a specific protected resource. A future specification might provide a way to support this use case. Alternatively, a server might use an error (Section 5.4) of type HTTP_1_1_REQUIRED to request that the client use a protocol that supports renegotiation.¶',129825,130823);
INSERT INTO "passages" VALUES('S1-P155',1,155,'Implementations MUST support ephemeral key exchange sizes of at least 2048 bits for cipher suites that use ephemeral finite field Diffie-Hellman (DHE) (Section 8.1.2 of [TLS12]) and 224 bits for cipher suites that use ephemeral elliptic curve Diffie-Hellman (ECDHE) [RFC8422]. Clients MUST accept DHE sizes of up to 4096 bits. Endpoints MAY treat negotiation of key sizes smaller than the lower limits as a connection error (Section 5.4.1) of type INADEQUATE_SECURITY.¶

9.2.2. TLS 1.2 Cipher Suites

A deployment of HTTP/2 over TLS 1.2 SHOULD NOT use any of the prohibited cipher suites listed in Appendix A.¶

Endpoints MAY choose to generate a connection error (Section 5.4.1) of type INADEQUATE_SECURITY if one of the prohibited cipher suites is negotiated. A deployment that chooses to use a prohibited cipher suite risks triggering a connection error unless the set of potential peers is known to accept that cipher suite.¶',130825,131754);
INSERT INTO "passages" VALUES('S1-P156',1,156,'Implementations MUST NOT generate this error in reaction to the negotiation of a cipher suite that is not prohibited. Consequently, when clients offer a cipher suite that is not prohibited, they have to be prepared to use that cipher suite with HTTP/2.¶

The list of prohibited cipher suites includes the cipher suite that TLS 1.2 makes mandatory, which means that TLS 1.2 deployments could have non-intersecting sets of permitted cipher suites. To avoid this problem, which causes TLS handshake failures, deployments of HTTP/2 that use TLS 1.2 MUST support TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 [TLS-ECDHE] with the P-256 elliptic curve [RFC8422].¶',131756,132405);
INSERT INTO "passages" VALUES('S1-P157',1,157,'Note that clients might advertise support of cipher suites that are prohibited in order to allow for connection to servers that do not support HTTP/2. This allows servers to select HTTP/1.1 with a cipher suite that is prohibited in HTTP/2. However, this can result in HTTP/2 being negotiated with a prohibited cipher suite if the application protocol and cipher suite are independently selected.¶

9.2.3. TLS 1.3 Features

TLS 1.3 includes a number of features not available in earlier versions. This section discusses the use of these features.¶

HTTP/2 servers MUST NOT send post-handshake TLS 1.3 CertificateRequest messages. HTTP/2 clients MUST treat a TLS post-handshake CertificateRequest message as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶',132407,133172);
INSERT INTO "passages" VALUES('S1-P158',1,158,'The prohibition on post-handshake authentication applies even if the client offered the "post_handshake_auth" TLS extension. Post-handshake authentication support might be advertised independently of ALPN [TLS-ALPN]. Clients might offer the capability for use in other protocols, but inclusion of the extension cannot imply support within HTTP/2.¶

[TLS13] defines other post-handshake messages, NewSessionTicket and KeyUpdate, which can be used as they have no direct interaction with HTTP/2. Unless the use of a new type of TLS message depends on an interaction with the application-layer protocol, that TLS message can be sent after the handshake completes.¶

TLS early data MAY be used to send requests, provided that the guidance in [RFC8470] is observed. Clients send requests in early data assuming initial values for all server settings.¶

10. Security Considerations',133174,134049);
INSERT INTO "passages" VALUES('S1-P159',1,159,'The use of TLS is necessary to provide many of the security properties of this protocol. Many of the claims in this section do not hold unless TLS is used as described in Section 9.2.¶

10.1. Server Authority

HTTP/2 relies on the HTTP definition of authority for determining whether a server is authoritative in providing a given response (see Section 4.3 of [HTTP]). This relies on local name resolution for the "http" URI scheme and the authenticated server identity for the "https" scheme.¶

10.2. Cross-Protocol Attacks

In a cross-protocol attack, an attacker causes a client to initiate a transaction in one protocol toward a server that understands a different protocol. An attacker might be able to cause the transaction to appear as a valid transaction in the second protocol. In combination with the capabilities of the web context, this can be used to interact with poorly protected servers in private networks.¶',134051,134975);
INSERT INTO "passages" VALUES('S1-P160',1,160,'Completing a TLS handshake with an ALPN identifier for HTTP/2 can be considered sufficient protection against cross-protocol attacks. ALPN provides a positive indication that a server is willing to proceed with HTTP/2, which prevents attacks on other TLS-based protocols.¶

The encryption in TLS makes it difficult for attackers to control the data that could be used in a cross-protocol attack on a cleartext protocol.¶

The cleartext version of HTTP/2 has minimal protection against cross-protocol attacks. The connection preface (Section 3.4) contains a string that is designed to confuse HTTP/1.1 servers, but no special protection is offered for other protocols.¶

10.3. Intermediary Encapsulation Attacks',134977,135687);
INSERT INTO "passages" VALUES('S1-P161',1,161,'HPACK permits encoding of field names and values that might be treated as delimiters in other HTTP versions. An intermediary that translates an HTTP/2 request or response MUST validate fields according to the rules in Section 8.2 before translating a message to another HTTP version. Translating a field that includes invalid delimiters could be used to cause recipients to incorrectly interpret a message, which could be exploited by an attacker.¶

Section 8.2 does not include specific rules for validation of pseudo-header fields. If the values of these fields are used, additional validation is necessary. This is particularly important where ":scheme", ":authority", and ":path" are combined to form a single URI string [RFC3986]. Similar problems might occur when that URI or just ":path" is combined with ":method" to construct a request line (as in Section 3 of [HTTP/1.1]). Simple concatenation is not secure unless the input values are fully validated.¶',135689,136652);
INSERT INTO "passages" VALUES('S1-P162',1,162,'An intermediary can reject fields that contain invalid field names or values for other reasons -- in particular, those fields that do not conform to the HTTP ABNF grammar from Section 5 of [HTTP]. Intermediaries that do not perform any validation of fields other than the minimum required by Section 8.2 could forward messages that contain invalid field names or values.¶

An intermediary that receives any fields that require removal before forwarding (see Section 7.6.1 of [HTTP]) MUST remove or replace those header fields when forwarding messages. Additionally, intermediaries should take care when forwarding messages containing Content-Length fields to ensure that the message is well-formed (Section 8.1.1). This ensures that if the message is translated into HTTP/1.1 at any point, the framing will be correct.¶

10.4. Cacheability of Pushed Responses

Pushed responses do not have an explicit request from the client; the request is provided by the server in the PUSH_PROMISE frame.¶',136654,137646);
INSERT INTO "passages" VALUES('S1-P163',1,163,'Caching responses that are pushed is possible based on the guidance provided by the origin server in the Cache-Control header field. However, this can cause issues if a single server hosts more than one tenant. For example, a server might offer multiple users each a small portion of its URI space.¶

Where multiple tenants share space on the same server, that server MUST ensure that tenants are not able to push representations of resources that they do not have authority over. Failure to enforce this would allow a tenant to provide a representation that would be served out of cache, overriding the actual representation that the authoritative tenant provides.¶

Pushed responses for which an origin server is not authoritative (see Section 10.1) MUST NOT be used or cached.¶

10.5. Denial-of-Service Considerations',137648,138468);
INSERT INTO "passages" VALUES('S1-P164',1,164,'An HTTP/2 connection can demand a greater commitment of resources to operate than an HTTP/1.1 connection. Both field section compression and flow control depend on a commitment of a greater amount of state. Settings for these features ensure that memory commitments for these features are strictly bounded.¶

The number of PUSH_PROMISE frames is not constrained in the same fashion. A client that accepts server push SHOULD limit the number of streams it allows to be in the "reserved (remote)" state. An excessive number of server push streams can be treated as a stream error (Section 5.4.2) of type ENHANCE_YOUR_CALM.¶

A number of HTTP/2 implementations were found to be vulnerable to denial of service [NFLX-2019-002]. Below is a list of known ways that implementations might be subject to denial-of-service attacks:¶',138470,139292);
INSERT INTO "passages" VALUES('S1-P165',1,165,'Inefficient tracking of outstanding outbound frames can lead to overload if an adversary can cause large numbers of frames to be enqueued for sending. A peer could use one of several techniques to cause large numbers of frames to be generated:¶

Providing tiny increments to flow control in WINDOW_UPDATE frames can cause a sender to generate a large number of DATA frames.¶

An endpoint is required to respond to a PING frame.¶

Each SETTINGS frame requires acknowledgment.¶

An invalid request (or server push) can cause a peer to send RST_STREAM frames in response.¶

An attacker can provide large amounts of flow-control credit at the HTTP/2 layer but withhold credit at the TCP layer, preventing frames from being sent. An endpoint that constructs and remembers frames for sending without considering TCP limits might be subject to resource exhaustion.¶',139294,140152);
INSERT INTO "passages" VALUES('S1-P166',1,166,'Large numbers of small or empty frames can be abused to cause a peer to expend time processing frame headers. Caution is required here as some uses of small frames are entirely legitimate, such as the sending of an empty DATA or CONTINUATION frame at the end of a stream.¶

The SETTINGS frame might also be abused to cause a peer to expend additional processing time. This might be done by pointlessly changing settings, sending multiple undefined settings, or changing the same setting multiple times in the same frame.¶

Handling reprioritization with PRIORITY frames can require significant processing time and can lead to overload if many PRIORITY frames are sent.¶

Field section compression also provides opportunities for an attacker to waste processing resources; see Section 7 of [COMPRESSION] for more details on potential abuses.¶',140154,140995);
INSERT INTO "passages" VALUES('S1-P167',1,167,'Limits in SETTINGS cannot be reduced instantaneously, which leaves an endpoint exposed to behavior from a peer that could exceed the new limits. In particular, immediately after establishing a connection, limits set by a server are not known to clients and could be exceeded without being an obvious protocol violation.¶

Most of the features that might be exploited for denial of service -- such as SETTINGS changes, small frames, field section compression -- have legitimate uses. These features become a burden only when they are used unnecessarily or to excess.¶

An endpoint that doesn''t monitor use of these features exposes itself to a risk of denial of service. Implementations SHOULD track the use of these features and set limits on their use. An endpoint MAY treat activity that is suspicious as a connection error (Section 5.4.1) of type ENHANCE_YOUR_CALM.¶

10.5.1. Limits on Field Block Size',140997,141902);
INSERT INTO "passages" VALUES('S1-P168',1,168,'A large field block (Section 4.3) can cause an implementation to commit a large amount of state. Field lines that are critical for routing can appear toward the end of a field block, which prevents streaming of fields to their ultimate destination. This ordering and other reasons, such as ensuring cache correctness, mean that an endpoint might need to buffer the entire field block. Since there is no hard limit to the size of a field block, some endpoints could be forced to commit a large amount of available memory for field blocks.¶',141904,142442);
INSERT INTO "passages" VALUES('S1-P169',1,169,'An endpoint can use the SETTINGS_MAX_HEADER_LIST_SIZE to advise peers of limits that might apply on the size of uncompressed field blocks. This setting is only advisory, so endpoints MAY choose to send field blocks that exceed this limit and risk the request or response being treated as malformed. This setting is specific to a connection, so any request or response could encounter a hop with a lower, unknown limit. An intermediary can attempt to avoid this problem by passing on values presented by different peers, but they are not obliged to do so.¶

A server that receives a larger field block than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code [RFC6585]. A client can discard responses that it cannot process. The field block MUST be processed to ensure a consistent connection state, unless the connection is closed.¶

10.5.2. CONNECT Issues',142444,143339);
INSERT INTO "passages" VALUES('S1-P170',1,170,'The CONNECT method can be used to create disproportionate load on a proxy, since stream creation is relatively inexpensive when compared to the creation and maintenance of a TCP connection. A proxy might also maintain some resources for a TCP connection beyond the closing of the stream that carries the CONNECT request, since the outgoing TCP connection remains in the TIME_WAIT state. Therefore, a proxy cannot rely on SETTINGS_MAX_CONCURRENT_STREAMS alone to limit the resources consumed by CONNECT requests.¶

10.6. Use of Compression

Compression can allow an attacker to recover secret data when it is compressed in the same context as data under attacker control. HTTP/2 enables compression of field lines (Section 4.3); the following concerns also apply to the use of HTTP compressed content-codings (Section 8.4.1 of [HTTP]).¶',143341,144176);
INSERT INTO "passages" VALUES('S1-P171',1,171,'There are demonstrable attacks on compression that exploit the characteristics of the Web (e.g., [BREACH]). The attacker induces multiple requests containing varying plaintext, observing the length of the resulting ciphertext in each, which reveals a shorter length when a guess about the secret is correct.¶

Implementations communicating on a secure channel MUST NOT compress content that includes both confidential and attacker-controlled data unless separate compression dictionaries are used for each source of data. Compression MUST NOT be used if the source of data cannot be reliably determined. Generic stream compression, such as that provided by TLS, MUST NOT be used with HTTP/2 (see Section 9.2).¶

Further considerations regarding the compression of header fields are described in [COMPRESSION].¶

10.7. Use of Padding',144178,145010);
INSERT INTO "passages" VALUES('S1-P172',1,172,'Padding within HTTP/2 is not intended as a replacement for general purpose padding, such as that provided by TLS [TLS13]. Redundant padding could even be counterproductive. Correct application can depend on having specific knowledge of the data that is being padded.¶

To mitigate attacks that rely on compression, disabling or limiting compression might be preferable to padding as a countermeasure.¶

Padding can be used to obscure the exact size of frame content and is provided to mitigate specific attacks within HTTP -- for example, attacks where compressed content includes both attacker-controlled plaintext and secret data (e.g., [BREACH]).¶',145012,145662);
INSERT INTO "passages" VALUES('S1-P173',1,173,'Use of padding can result in less protection than might seem immediately obvious. At best, padding only makes it more difficult for an attacker to infer length information by increasing the number of frames an attacker has to observe. Incorrectly implemented padding schemes can be easily defeated. In particular, randomized padding with a predictable distribution provides very little protection; similarly, padding frame payloads to a fixed size exposes information as frame payload sizes cross the fixed-sized boundary, which could be possible if an attacker can control plaintext.¶

Intermediaries SHOULD retain padding for DATA frames but MAY drop padding for HEADERS and PUSH_PROMISE frames. A valid reason for an intermediary to change the amount of padding of frames is to improve the protections that padding provides.¶

10.8. Privacy Considerations',145664,146522);
INSERT INTO "passages" VALUES('S1-P174',1,174,'Several characteristics of HTTP/2 provide an observer an opportunity to correlate actions of a single client or server over time. These include the values of settings, the manner in which flow-control windows are managed, the way priorities are allocated to streams, the timing of reactions to stimulus, and the handling of any features that are controlled by settings.¶

As far as these create observable differences in behavior, they could be used as a basis for fingerprinting a specific client, as defined in Section 3.2 of [PRIVACY].¶

HTTP/2''s preference for using a single TCP connection allows correlation of a user''s activity on a site. Reusing connections for different origins allows tracking across those origins.¶

Because the PING and SETTINGS frames solicit immediate responses, they can be used by an endpoint to measure latency to their peer. This might have privacy implications in certain scenarios.¶

10.9. Remote Timing Attacks',146524,147472);
INSERT INTO "passages" VALUES('S1-P175',1,175,'Remote timing attacks extract secrets from servers by observing variations in the time that servers take when processing requests that use secrets. HTTP/2 enables concurrent request creation and processing, which can give attackers better control over when request processing commences. Multiple HTTP/2 requests can be included in the same IP packet or TLS record. HTTP/2 can therefore make remote timing attacks more efficient by eliminating variability in request delivery, leaving only request order and the delivery of responses as sources of timing variability.¶

Ensuring that processing time is not dependent on the value of a secret is the best defense against any form of timing attack.¶

11. IANA Considerations

This revision of HTTP/2 marks the HTTP2-Settings header field and the h2c upgrade token, both defined in [RFC7540], as obsolete.¶',147474,148326);
INSERT INTO "passages" VALUES('S1-P176',1,176,'Section 11 of [RFC7540] registered the h2 and h2c ALPN identifiers along with the PRI HTTP method. RFC 7540 also established a registry for frame types, settings, and error codes. These registrations and registries apply to HTTP/2, but are not redefined in this document.¶

IANA has updated references to RFC 7540 in the following registries to refer to this document: "TLS Application-Layer Protocol Negotiation (ALPN) Protocol IDs", "HTTP/2 Frame Type", "HTTP/2 Settings", "HTTP/2 Error Code", and "HTTP Method Registry". The registration of the PRI method has been updated to refer to Section 3.4; all other section numbers have not changed.¶

IANA has changed the policy on those portions of the "HTTP/2 Frame Type" and "HTTP/2 Settings" registries that were reserved for Experimental Use in RFC 7540. These portions of the registries shall operate on the same policy as the remainder of each registry.¶

11.1. HTTP2-Settings Header Field Registration',148328,149283);
INSERT INTO "passages" VALUES('S1-P177',1,177,'This section marks the HTTP2-Settings header field registered by Section 11.5 of [RFC7540] in the "Hypertext Transfer Protocol (HTTP) Field Name Registry" as obsolete. This capability has been removed: see Section 3.1. The registration is updated to include the details as required by Section 18.4 of [HTTP]:¶

Field Name:

HTTP2-Settings¶

Status:

obsoleted¶

Reference:

Section 3.2.1 of [RFC7540]¶

Comments:

Obsolete; see Section 11.1 of this document.¶

11.2. The h2c Upgrade Token

This section records the h2c upgrade token registered by Section 11.8 of [RFC7540] in the "Hypertext Transfer Protocol (HTTP) Upgrade Token Registry" as obsolete. This capability has been removed: see Section 3.1. The registration is updated as follows:¶

Value:

h2c¶

Description:

(OBSOLETE) Hypertext Transfer Protocol version 2 (HTTP/2)¶

Expected Version Tokens:

None¶

Reference:

Section 3.1 of this document¶

12. References

12.1. Normative References

[CACHING]',149285,150248);
INSERT INTO "passages" VALUES('S1-P178',1,178,'Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP Caching", STD 98, RFC 9111, DOI 10.17487/RFC9111, June 2022, <https://www.rfc-editor.org/info/rfc9111>.

[COMPRESSION]

Peon, R. and H. Ruellan, "HPACK: Header Compression for HTTP/2", RFC 7541, DOI 10.17487/RFC7541, May 2015, <https://www.rfc-editor.org/info/rfc7541>.

[COOKIE]

Barth, A., "HTTP State Management Mechanism", RFC 6265, DOI 10.17487/RFC6265, April 2011, <https://www.rfc-editor.org/info/rfc6265>.

[HTTP]

Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP Semantics", STD 97, RFC 9110, DOI 10.17487/RFC9110, June 2022, <https://www.rfc-editor.org/info/rfc9110>.

[QUIC]

Iyengar, J., Ed. and M. Thomson, Ed., "QUIC: A UDP-Based Multiplexed and Secure Transport", RFC 9000, DOI 10.17487/RFC9000, May 2021, <https://www.rfc-editor.org/info/rfc9000>.

[RFC2119]',150250,151109);
INSERT INTO "passages" VALUES('S1-P179',1,179,'Bradner, S., "Key words for use in RFCs to Indicate Requirement Levels", BCP 14, RFC 2119, DOI 10.17487/RFC2119, March 1997, <https://www.rfc-editor.org/info/rfc2119>.

[RFC3986]

Berners-Lee, T., Fielding, R., and L. Masinter, "Uniform Resource Identifier (URI): Generic Syntax", STD 66, RFC 3986, DOI 10.17487/RFC3986, January 2005, <https://www.rfc-editor.org/info/rfc3986>.

[RFC8174]

Leiba, B., "Ambiguity of Uppercase vs Lowercase in RFC 2119 Key Words", BCP 14, RFC 8174, DOI 10.17487/RFC8174, May 2017, <https://www.rfc-editor.org/info/rfc8174>.

[RFC8422]

Nir, Y., Josefsson, S., and M. Pegourie-Gonnard, "Elliptic Curve Cryptography (ECC) Cipher Suites for Transport Layer Security (TLS) Versions 1.2 and Earlier", RFC 8422, DOI 10.17487/RFC8422, August 2018, <https://www.rfc-editor.org/info/rfc8422>.

[RFC8470]

Thomson, M., Nottingham, M., and W. Tarreau, "Using Early Data in HTTP", RFC 8470, DOI 10.17487/RFC8470, September 2018, <https://www.rfc-editor.org/info/rfc8470>.

[TCP]',151111,152108);
INSERT INTO "passages" VALUES('S1-P180',1,180,'Postel, J., "Transmission Control Protocol", STD 7, RFC 793, DOI 10.17487/RFC0793, September 1981, <https://www.rfc-editor.org/info/rfc793>.

[TLS-ALPN]

Friedl, S., Popov, A., Langley, A., and E. Stephan, "Transport Layer Security (TLS) Application-Layer Protocol Negotiation Extension", RFC 7301, DOI 10.17487/RFC7301, July 2014, <https://www.rfc-editor.org/info/rfc7301>.

[TLS-ECDHE]

Rescorla, E., "TLS Elliptic Curve Cipher Suites with SHA-256/384 and AES Galois Counter Mode (GCM)", RFC 5289, DOI 10.17487/RFC5289, August 2008, <https://www.rfc-editor.org/info/rfc5289>.

[TLS-EXT]

Eastlake 3rd, D., "Transport Layer Security (TLS) Extensions: Extension Definitions", RFC 6066, DOI 10.17487/RFC6066, January 2011, <https://www.rfc-editor.org/info/rfc6066>.

[TLS12]

Dierks, T. and E. Rescorla, "The Transport Layer Security (TLS) Protocol Version 1.2", RFC 5246, DOI 10.17487/RFC5246, August 2008, <https://www.rfc-editor.org/info/rfc5246>.

[TLS13]',152110,153068);
INSERT INTO "passages" VALUES('S1-P181',1,181,'Rescorla, E., "The Transport Layer Security (TLS) Protocol Version 1.3", RFC 8446, DOI 10.17487/RFC8446, August 2018, <https://www.rfc-editor.org/info/rfc8446>.

[TLSBCP]

Sheffer, Y., Holz, R., and P. Saint-Andre, "Recommendations for Secure Use of Transport Layer Security (TLS) and Datagram Transport Layer Security (DTLS)", BCP 195, RFC 7525, DOI 10.17487/RFC7525, May 2015, <https://www.rfc-editor.org/info/rfc7525>.

12.2. Informative References

[ALT-SVC]

Nottingham, M., McManus, P., and J. Reschke, "HTTP Alternative Services", RFC 7838, DOI 10.17487/RFC7838, April 2016, <https://www.rfc-editor.org/info/rfc7838>.

[BREACH]

Gluck, Y., Harris, N., and A. Prado, "BREACH: Reviving the CRIME Attack", 12 July 2013, <https://breachattack.com/resources/BREACH%20-%20SSL,%20gone%20in%2030%20seconds.pdf>.

[DNS-TERMS]

Hoffman, P., Sullivan, A., and K. Fujiwara, "DNS Terminology", BCP 219, RFC 8499, DOI 10.17487/RFC8499, January 2019, <https://www.rfc-editor.org/info/rfc8499>.',153070,154055);
INSERT INTO "passages" VALUES('S1-P182',1,182,'[HTTP-PRIORITY]

Oku, K. and L. Pardue, "Extensible Prioritization Scheme for HTTP", RFC 9218, DOI 10.17487/RFC9218, June 2022, <https://www.rfc-editor.org/info/rfc9218>.

[HTTP/1.1]

Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP/1.1", STD 99, RFC 9112, DOI 10.17487/RFC9112, June 2022, <https://www.rfc-editor.org/info/rfc9112>.

[NFLX-2019-002]

Netflix, "HTTP/2 Denial of Service Advisory", 13 August 2019, <https://github.com/Netflix/security-bulletins/blob/master/advisories/third-party/2019-002.md>.

[PRIVACY]

Cooper, A., Tschofenig, H., Aboba, B., Peterson, J., Morris, J., Hansen, M., and R. Smith, "Privacy Considerations for Internet Protocols", RFC 6973, DOI 10.17487/RFC6973, July 2013, <https://www.rfc-editor.org/info/rfc6973>.

[RFC1122]

Braden, R., Ed., "Requirements for Internet Hosts - Communication Layers", STD 3, RFC 1122, DOI 10.17487/RFC1122, October 1989, <https://www.rfc-editor.org/info/rfc1122>.

[RFC3749]',154057,155015);
INSERT INTO "passages" VALUES('S1-P183',1,183,'Hollenbeck, S., "Transport Layer Security Protocol Compression Methods", RFC 3749, DOI 10.17487/RFC3749, May 2004, <https://www.rfc-editor.org/info/rfc3749>.

[RFC6125]

Saint-Andre, P. and J. Hodges, "Representation and Verification of Domain-Based Application Service Identity within Internet Public Key Infrastructure Using X.509 (PKIX) Certificates in the Context of Transport Layer Security (TLS)", RFC 6125, DOI 10.17487/RFC6125, March 2011, <https://www.rfc-editor.org/info/rfc6125>.

[RFC6585]

Nottingham, M. and R. Fielding, "Additional HTTP Status Codes", RFC 6585, DOI 10.17487/RFC6585, April 2012, <https://www.rfc-editor.org/info/rfc6585>.

[RFC7323]

Borman, D., Braden, B., Jacobson, V., and R. Scheffenegger, Ed., "TCP Extensions for High Performance", RFC 7323, DOI 10.17487/RFC7323, September 2014, <https://www.rfc-editor.org/info/rfc7323>.

[RFC7540]',155017,155888);
INSERT INTO "passages" VALUES('S1-P184',1,184,'Belshe, M., Peon, R., and M. Thomson, Ed., "Hypertext Transfer Protocol Version 2 (HTTP/2)", RFC 7540, DOI 10.17487/RFC7540, May 2015, <https://www.rfc-editor.org/info/rfc7540>.

[RFC8441]

McManus, P., "Bootstrapping WebSockets with HTTP/2", RFC 8441, DOI 10.17487/RFC8441, September 2018, <https://www.rfc-editor.org/info/rfc8441>.

[RFC8740]

Benjamin, D., "Using TLS 1.3 with HTTP/2", RFC 8740, DOI 10.17487/RFC8740, February 2020, <https://www.rfc-editor.org/info/rfc8740>.

[TALKING]

Huang, L., Chen, E., Barth, A., Rescorla, E., and C. Jackson, "Talking to Yourself for Fun and Profit", 2011, <https://www.adambarth.com/papers/2011/huang-chen-barth-rescorla-jackson.pdf>.

Appendix A. Prohibited TLS 1.2 Cipher Suites

An HTTP/2 implementation MAY treat the negotiation of any of the following cipher suites with TLS 1.2 as a connection error (Section 5.4.1) of type INADEQUATE_SECURITY:¶

TLS_NULL_WITH_NULL_NULL¶

TLS_RSA_WITH_NULL_MD5¶

TLS_RSA_WITH_NULL_SHA¶',155890,156860);
INSERT INTO "passages" VALUES('S1-P185',1,185,'TLS_RSA_EXPORT_WITH_RC4_40_MD5¶

TLS_RSA_WITH_RC4_128_MD5¶

TLS_RSA_WITH_RC4_128_SHA¶

TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5¶

TLS_RSA_WITH_IDEA_CBC_SHA¶

TLS_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_RSA_WITH_DES_CBC_SHA¶

TLS_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_DSS_WITH_DES_CBC_SHA¶

TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_RSA_WITH_DES_CBC_SHA¶

TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DHE_DSS_WITH_DES_CBC_SHA¶

TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DHE_RSA_WITH_DES_CBC_SHA¶

TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_anon_EXPORT_WITH_RC4_40_MD5¶

TLS_DH_anon_WITH_RC4_128_MD5¶

TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_anon_WITH_DES_CBC_SHA¶

TLS_DH_anon_WITH_3DES_EDE_CBC_SHA¶

TLS_KRB5_WITH_DES_CBC_SHA¶

TLS_KRB5_WITH_3DES_EDE_CBC_SHA¶

TLS_KRB5_WITH_RC4_128_SHA¶

TLS_KRB5_WITH_IDEA_CBC_SHA¶

TLS_KRB5_WITH_DES_CBC_MD5¶',156862,157850);
INSERT INTO "passages" VALUES('S1-P186',1,186,'TLS_KRB5_WITH_3DES_EDE_CBC_MD5¶

TLS_KRB5_WITH_RC4_128_MD5¶

TLS_KRB5_WITH_IDEA_CBC_MD5¶

TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA¶

TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA¶

TLS_KRB5_EXPORT_WITH_RC4_40_SHA¶

TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5¶

TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5¶

TLS_KRB5_EXPORT_WITH_RC4_40_MD5¶

TLS_PSK_WITH_NULL_SHA¶

TLS_DHE_PSK_WITH_NULL_SHA¶

TLS_RSA_PSK_WITH_NULL_SHA¶

TLS_RSA_WITH_AES_128_CBC_SHA¶

TLS_DH_DSS_WITH_AES_128_CBC_SHA¶

TLS_DH_RSA_WITH_AES_128_CBC_SHA¶

TLS_DHE_DSS_WITH_AES_128_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_128_CBC_SHA¶

TLS_DH_anon_WITH_AES_128_CBC_SHA¶

TLS_RSA_WITH_AES_256_CBC_SHA¶

TLS_DH_DSS_WITH_AES_256_CBC_SHA¶

TLS_DH_RSA_WITH_AES_256_CBC_SHA¶

TLS_DHE_DSS_WITH_AES_256_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_256_CBC_SHA¶

TLS_DH_anon_WITH_AES_256_CBC_SHA¶

TLS_RSA_WITH_NULL_SHA256¶

TLS_RSA_WITH_AES_128_CBC_SHA256¶

TLS_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DH_DSS_WITH_AES_128_CBC_SHA256¶

TLS_DH_RSA_WITH_AES_128_CBC_SHA256¶',157852,158817);
INSERT INTO "passages" VALUES('S1-P187',1,187,'TLS_DHE_DSS_WITH_AES_128_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_128_CBC_SHA256¶

TLS_DH_DSS_WITH_AES_256_CBC_SHA256¶

TLS_DH_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DHE_DSS_WITH_AES_256_CBC_SHA256¶

TLS_DHE_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DH_anon_WITH_AES_128_CBC_SHA256¶

TLS_DH_anon_WITH_AES_256_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA¶

TLS_PSK_WITH_RC4_128_SHA¶

TLS_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_PSK_WITH_AES_128_CBC_SHA¶

TLS_PSK_WITH_AES_256_CBC_SHA¶

TLS_DHE_PSK_WITH_RC4_128_SHA¶

TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_PSK_WITH_AES_128_CBC_SHA¶',158819,159810);
INSERT INTO "passages" VALUES('S1-P188',1,188,'TLS_DHE_PSK_WITH_AES_256_CBC_SHA¶

TLS_RSA_PSK_WITH_RC4_128_SHA¶

TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_RSA_PSK_WITH_AES_128_CBC_SHA¶

TLS_RSA_PSK_WITH_AES_256_CBC_SHA¶

TLS_RSA_WITH_SEED_CBC_SHA¶

TLS_DH_DSS_WITH_SEED_CBC_SHA¶

TLS_DH_RSA_WITH_SEED_CBC_SHA¶

TLS_DHE_DSS_WITH_SEED_CBC_SHA¶

TLS_DHE_RSA_WITH_SEED_CBC_SHA¶

TLS_DH_anon_WITH_SEED_CBC_SHA¶

TLS_RSA_WITH_AES_128_GCM_SHA256¶

TLS_RSA_WITH_AES_256_GCM_SHA384¶

TLS_DH_RSA_WITH_AES_128_GCM_SHA256¶

TLS_DH_RSA_WITH_AES_256_GCM_SHA384¶

TLS_DH_DSS_WITH_AES_128_GCM_SHA256¶

TLS_DH_DSS_WITH_AES_256_GCM_SHA384¶

TLS_DH_anon_WITH_AES_128_GCM_SHA256¶

TLS_DH_anon_WITH_AES_256_GCM_SHA384¶

TLS_PSK_WITH_AES_128_GCM_SHA256¶

TLS_PSK_WITH_AES_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_AES_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_AES_256_GCM_SHA384¶

TLS_PSK_WITH_AES_128_CBC_SHA256¶

TLS_PSK_WITH_AES_256_CBC_SHA384¶

TLS_PSK_WITH_NULL_SHA256¶

TLS_PSK_WITH_NULL_SHA384¶

TLS_DHE_PSK_WITH_AES_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_AES_256_CBC_SHA384¶',159812,160802);
INSERT INTO "passages" VALUES('S1-P189',1,189,'TLS_DHE_PSK_WITH_NULL_SHA256¶

TLS_DHE_PSK_WITH_NULL_SHA384¶

TLS_RSA_PSK_WITH_AES_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_AES_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_NULL_SHA256¶

TLS_RSA_PSK_WITH_NULL_SHA384¶

TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_EMPTY_RENEGOTIATION_INFO_SCSV¶

TLS_ECDH_ECDSA_WITH_NULL_SHA¶

TLS_ECDH_ECDSA_WITH_RC4_128_SHA¶

TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA¶

TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_NULL_SHA¶

TLS_ECDHE_ECDSA_WITH_RC4_128_SHA¶',160804,161789);
INSERT INTO "passages" VALUES('S1-P190',1,190,'TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA¶

TLS_ECDH_RSA_WITH_NULL_SHA¶

TLS_ECDH_RSA_WITH_RC4_128_SHA¶

TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_RSA_WITH_AES_128_CBC_SHA¶

TLS_ECDH_RSA_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_RSA_WITH_NULL_SHA¶

TLS_ECDHE_RSA_WITH_RC4_128_SHA¶

TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA¶

TLS_ECDH_anon_WITH_NULL_SHA¶

TLS_ECDH_anon_WITH_RC4_128_SHA¶

TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_anon_WITH_AES_128_CBC_SHA¶

TLS_ECDH_anon_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA¶',161791,162769);
INSERT INTO "passages" VALUES('S1-P191',1,191,'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384¶

TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384¶

TLS_ECDHE_PSK_WITH_RC4_128_SHA¶

TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384¶

TLS_ECDHE_PSK_WITH_NULL_SHA¶

TLS_ECDHE_PSK_WITH_NULL_SHA256¶

TLS_ECDHE_PSK_WITH_NULL_SHA384¶

TLS_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256¶

TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256¶',162771,163758);
INSERT INTO "passages" VALUES('S1-P192',1,192,'TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_anon_WITH_ARIA_128_CBC_SHA256¶

TLS_DH_anon_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_anon_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_anon_WITH_ARIA_256_GCM_SHA384¶

TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384¶',163760,164746);
INSERT INTO "passages" VALUES('S1-P193',1,193,'TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_PSK_WITH_ARIA_128_GCM_SHA256¶

TLS_PSK_WITH_ARIA_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384¶

TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384¶',164748,165724);
INSERT INTO "passages" VALUES('S1-P194',1,194,'TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_WITH_AES_128_CCM¶

TLS_RSA_WITH_AES_256_CCM¶',165726,166716);
INSERT INTO "passages" VALUES('S1-P195',1,195,'TLS_RSA_WITH_AES_128_CCM_8¶

TLS_RSA_WITH_AES_256_CCM_8¶

TLS_PSK_WITH_AES_128_CCM¶

TLS_PSK_WITH_AES_256_CCM¶

TLS_PSK_WITH_AES_128_CCM_8¶

TLS_PSK_WITH_AES_256_CCM_8¶

For more details, see Section 9.2.2.¶

Appendix B. Changes from RFC 7540

This revision includes the following substantive changes:¶

Use of TLS 1.3 was defined based on [RFC8740], which this document obsoletes.¶

The priority scheme defined in RFC 7540 is deprecated. Definitions for the format of the PRIORITY frame and the priority fields in the HEADERS frame have been retained, plus the rules governing when PRIORITY frames can be sent and received, but the semantics of these fields are only described in RFC 7540. The priority signaling scheme from RFC 7540 was not successful. Using the simpler signaling in [HTTP-PRIORITY] is recommended.¶',166718,167536);
INSERT INTO "passages" VALUES('S1-P196',1,196,'The HTTP/1.1 Upgrade mechanism is deprecated and no longer specified in this document. It was never widely deployed, with plaintext HTTP/2 users choosing to use the prior-knowledge implementation instead.¶

Validation for field names and values has been narrowed. The validation that is mandatory for intermediaries is precisely defined, and error reporting for requests has been amended to encourage sending 400-series status codes.¶

The ranges of codepoints for settings and frame types that were reserved for Experimental Use are now available for general use.¶

Connection-specific header fields -- which are prohibited -- are more precisely and comprehensively identified.¶

Host and ":authority" are no longer permitted to disagree.¶

Rules for sending Dynamic Table Size Update instructions after changes in settings have been clarified in Section 4.3.1.¶',167538,168401);
INSERT INTO "passages" VALUES('S1-P197',1,197,'Editorial changes are also included. In particular, changes to terminology and document structure are in response to updates to core HTTP semantics [HTTP]. Those documents now include some concepts that were first defined in RFC 7540, such as the 421 status code or connection coalescing.¶

Acknowledgments

Credit for non-trivial input to this document is owed to a large number of people who have contributed to the HTTP Working Group over the years. [RFC7540] contains a more extensive list of people that deserve acknowledgment for their contributions.¶

Contributors

Mike Belshe and Roberto Peon authored the text that this document is based on.¶

Authors'' Addresses

Martin Thomson (editor)

Mozilla

Australia

Email: mt@lowentropy.net

Cory Benfield (editor)

Apple Inc.

Email: cbenfield@apple.com

Datatracker

RFC 9113

RFC - Proposed Standard

Info

Contents

Prefs

Document

Document type

RFC - Proposed Standard

June 2022

View errata Report errata

Obsoletes RFC 8740, RFC 7540',168403,169399);
INSERT INTO "passages" VALUES('S1-P198',1,198,'Was draft-ietf-httpbis-http2bis (httpbis WG)

Select version

00

01

02

03

04

05

06

07

RFC 9113

Compare versions

RFC 9113 draft-ietf-httpbis-http2bis-07 draft-ietf-httpbis-http2bis-06 draft-ietf-httpbis-http2bis-05 draft-ietf-httpbis-http2bis-04 draft-ietf-httpbis-http2bis-03 draft-ietf-httpbis-http2bis-02 draft-ietf-httpbis-http2bis-01 draft-ietf-httpbis-http2bis-00 RFC 9113 draft-ietf-httpbis-http2bis-07 draft-ietf-httpbis-http2bis-06 draft-ietf-httpbis-http2bis-05 draft-ietf-httpbis-http2bis-04 draft-ietf-httpbis-http2bis-03 draft-ietf-httpbis-http2bis-02 draft-ietf-httpbis-http2bis-01 draft-ietf-httpbis-http2bis-00 Side-by-side Inline

Authors

M. Thomson , C. Benfield

Email authors

RFC stream

Other formats

txt html xml pdf w/errata bibtex

Additional resources

Mailing list discussion

Report a datatracker bug

Show sidebar by default

Yes No

Tab to show by default

Info Contents

HTMLization configuration

HTMLize the plaintext Plaintextify the HTML',169401,170384);
INSERT INTO "passages" VALUES('S1-P199',1,199,'Maximum font size Page dependencies

Inline Reference

Citation links

Go to reference section Go to linked document',170386,170502);
INSERT INTO "passages" VALUES('S2-P0',2,0,'Jump to content

Search

Search

HTTP/3

16 languages

Català

Čeština

Deutsch

Español

فارسی

Suomi

עברית

Italiano

日本語

한국어

Polski

Português

Русский

Українська

吴语

中文

Edit links

From Wikipedia, the free encyclopedia

HTTP network protocol introduced in 2022

HTTP/3

International standard

RFC 9114[1] (HTTP/3 also uses the completed QUIC protocol described in RFC 9000 and related RFCs such as RFC 9001)

Developed by

IETF

Introduced

June 2022

Website

https://httpwg.org/specs/rfc9114.html

HTTP/3 is the third major version of the Hypertext Transfer Protocol used to exchange information on the World Wide Web, complementing the widely deployed HTTP/1.1 and HTTP/2. Unlike previous versions which relied on the well-established TCP (published in 1974),[2] HTTP/3 uses QUIC (officially introduced in 2021),[3] a multiplexed transport protocol built on UDP.[4]',0,879);
INSERT INTO "passages" VALUES('S2-P1',2,1,'HTTP/3 uses similar semantics compared to earlier revisions of the protocol, including the same request methods, status codes, and message fields, but encodes them and maintains session state differently. However, partially due to the protocol''s adoption of QUIC, HTTP/3 has lower latency and loads more quickly in real-world usage when compared with previous versions: in some cases over four times faster than with HTTP/1.1 (which, for many websites, is the only HTTP version deployed).[5][6]

As of July 2026, HTTP/3 is supported by more than 95% of major web browsers in use[7] and 40% of the top 10 million websites.[8] It has been supported by Chromium (and derived projects including Google Chrome, Microsoft Edge, Samsung Internet, and Opera)[9] since April 2020 and by Mozilla Firefox since May 2021.[7][10] Safari has implemented the standard since Sept 2024 (16+ supports HTTP/3 for all users, previously it was limited to a subset of users)[11]

History

[edit]',881,1854);
INSERT INTO "passages" VALUES('S2-P2',2,2,'Protocol stack of HTTP/3 compared to HTTP/1.1 and HTTP/2

HTTP/3 originates from an Internet Draft adopted by the QUIC working group. The original proposal was named "HTTP/2 Semantics Using The QUIC Transport Protocol",[12] and later renamed "Hypertext Transfer Protocol (HTTP) over QUIC".[13]

On 28 October 2018 in a mailing list discussion, Mark Nottingham, Chair of the IETF HTTP and QUIC Working Groups, proposed renaming HTTP-over-QUIC to HTTP/3, to "clearly identify it as another binding of HTTP semantics to the wire protocol [...] so people understand its separation from QUIC".[14] Nottingham''s proposal was accepted by fellow IETF members a few days later. The HTTP working group was chartered to assist the QUIC working group during the design of HTTP/3, then assume responsibility for maintenance after publication.[15]',1856,2689);
INSERT INTO "passages" VALUES('S2-P3',2,3,'Support for HTTP/3 was added to Chrome (Canary build) in September 2019 and then eventually reached stable builds, but was disabled by a feature flag. It was enabled by default in April 2020.[9] Firefox added support for HTTP/3 in November 2019 through a feature flag[7][16][17] and started enabling it by default in April 2021 in Firefox 88.[7][10] Experimental support for HTTP/3 was added to Safari Technology Preview on April 8, 2020[18] and was included with Safari 14 that ships with iOS 14 and macOS 11,.[19][20] Starting September 2024, HTTP/3 is supported for all users on Safari 16 or newer.[11]

On 6 June 2022, IETF published HTTP/3 as a Proposed Standard in RFC 9114[1].

Comparison with HTTP/1.1 and HTTP/2

[edit]',2691,3419);
INSERT INTO "passages" VALUES('S2-P4',2,4,'HTTP semantics are consistent across versions: the same request methods, status codes, and message fields are typically applicable to all versions. The differences are in the mapping of these semantics to underlying transports. Both HTTP/1.1 and HTTP/2 use TCP as their transport. HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP). The switch to QUIC aims to fix a major problem of HTTP/2 called "head-of-line blocking": because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was impacted by the lost packet. Because QUIC provides native multiplexing, lost packets only impact the streams where data has been lost.',3421,4284);
INSERT INTO "passages" VALUES('S2-P5',2,5,'The HTTPS DNS resource record as defined in RFC 9460[21] allows for connecting without first receiving the Alt-Svc header via previous HTTP versions, therefore removing the 1 RTT of handshaking of TCP.[22][23] There is client support for HTTPS resource records since Firefox 92, iOS 14, reported Safari 14 support, and Chromium supports it behind a flag.[24][25][26]

Implementations

[edit]

Client

[edit]

Browser support for HTTP/3

Browser

Version implemented (disabled by default)

Version shipped (enabled by default)

Comment

Chrome

Stable build (79)

December 2019

87[7]

April 2020[27]

Earlier versions implemented other drafts of QUIC

Edge

Stable build (79)

December 2019

87

April 2020

Edge 79 was the first version based on Chromium

Firefox

Stable build (72.0.1)

January 2020

88[10]

April 2021[28]

Safari

Stable build (14.0)

September 2020

16.4

September 2024

Apple tested HTTP/3 support on some Safari users starting with Safari 14.[29]',4286,5257);
INSERT INTO "passages" VALUES('S2-P6',2,6,'Starting September 2024, HTTP/3 is supported for all users on Safari 16 or newer.[11]

Libraries

[edit]

Open-source libraries that implement client or server logic for QUIC and HTTP/3 include[30]

Libraries implementing HTTP/3

Name

Client

Server

Programming language

Company

Repository

lsquic

Yes

Yes

C

LiteSpeed

https://github.com/litespeedtech/lsquic

nghttp3

Yes

Yes

C

https://github.com/ngtcp2/nghttp3

h2o

No

Yes

C

https://github.com/h2o/h2o

libcurl[31][32]

Yes

No

C

https://github.com/curl/curl

MsQuic[33]

Yes

Yes

C

Microsoft

https://github.com/microsoft/msquic

proxygen

Yes

Yes

C++

Facebook

https://github.com/facebook/proxygen#quic-and-http3

Cronet

Yes

Yes

C++

Google

https://github.com/chromium/chromium/tree/main/net/quic

.NET[34]

Yes

Yes

C# (using MsQuic)[35]

Microsoft

https://github.com/dotnet

quic-go

Yes

Yes

Go

https://github.com/quic-go/quic-go

http3

Yes

Yes

Haskell

https://github.com/kazu-yamamoto/http3

Kwik

Yes

Yes',5259,6257);
INSERT INTO "passages" VALUES('S2-P7',2,7,'Java

https://github.com/ptrd/kwik

Flupke

Yes

Yes

Java

https://bitbucket.org/pjtr/flupke

aioquic

Yes

Yes

Python

https://github.com/aiortc/aioquic

niquests

Yes

No

Python

https://github.com/jawah/niquests

quiche

Yes

Yes

Rust

Cloudflare

https://github.com/cloudflare/quiche

neqo

Yes

Yes

Rust

Mozilla

https://github.com/mozilla/neqo

quinn

Yes

Yes

Rust

https://github.com/quinn-rs/quinn

s2n-quic

Yes

Yes

Rust

Amazon Web Services

https://github.com/aws/s2n-quic

cowboy

No

Yes

Erlang

ninenines

https://github.com/ninenines/cowboy

quico

Yes

Yes

JavaScript

https://github.com/colocohen/quico

Server

[edit]

On 7 June 2021, LiteSpeed Web Server (and OpenLiteSpeed) 6.0.2 was released and became the first version to enable HTTP/3 by default.[36]

Caddy web server v2.6.0 (released 20 September 2022) has HTTP/3 enabled by default.[37]',6259,7134);
INSERT INTO "passages" VALUES('S2-P8',2,8,'nginx supports HTTP/3 since 1.25.0 (released 23 May 2023). A technology preview of nginx with HTTP/3 support was released in June 2020.[38] Binary packages of nginx with HTTP/3 support have been released in February 2023.[39]

Cloudflare distributes a patch for nginx that integrates the quiche HTTP/3 library into it.[40]

Microsoft IIS support for HTTP/3 is enabled natively with Windows Server 2022/Windows 11.[41]

HAProxy supports HTTP/3 over QUIC since version 2.6 released on 31 May 2022.[42][43]

Nimble Streamer supports HTTP/3 since 4.1.8-1[44] for HTTP-based protocols.

See also

[edit]

Internet portal

Fast and Secure Protocol – Terminal command scheme used to transfer data

References

[edit]

1 2 M. Bishop, ed. (June 2022). HTTP/3. Internet Engineering Task Force. doi:10.17487/RFC9114. ISSN 2070-1721. RFC 9114. Proposed Standard.',7136,7986);
INSERT INTO "passages" VALUES('S2-P9',2,9,'↑ V. Cerf; Y. Dalal; C. Sunshine (December 1974). SPECIFICATION OF INTERNET TRANSMISSION CONTROL PROGRAM. Network Working Group. doi:10.17487/RFC0675. RFC 675. Obsolete. Obsoleted by RFC 7805. NIC 2. INWG 72.

↑ J. Iyengar; M. Thomson, eds. (May 2021). QUIC: A UDP-Based Multiplexed and Secure Transport. Internet Engineering Task Force. doi:10.17487/RFC9000. ISSN 2070-1721. RFC 9000. Proposed Standard.

↑ "What is HTTP/3?". Cloudflare. Archived from the original on 4 July 2022. Retrieved 12 July 2022.

↑ Perna, Gianluca; Trevisan, Martino; Giordano, Danilo; Drago, Idilio (1 April 2022). "A first look at HTTP/3 adoption and performance". Computer Communications. 187: 115–124. doi:10.1016/j.comcom.2022.02.005. hdl:11368/3025202. ISSN 0140-3664. S2CID 246936473.

↑ "HTTP/3 is Fast". Request Metrics. Retrieved 1 July 2022.

1 2 3 4 5 ""HTTP/3" | Can I use... Support tables for HTML5, CSS3, etc". canIuse.com. Retrieved 11 August 2024.',7988,8930);
INSERT INTO "passages" VALUES('S2-P10',2,10,'↑ "Usage of HTTP/3 for websites". World Wide Web Technology Surveys. W3Techs. Retrieved 19 July 2026.

1 2 "Enabling QUIC in tip-of-tree". groups.google.com. Retrieved 8 April 2021.

1 2 3 Damjanovic, Dragana (16 April 2021). "QUIC and HTTP/3 Support now in Firefox Nightly and Beta". Mozilla Hacks – the Web developer blog. Retrieved 17 April 2021.

1 2 3 Jen Simmons (30 October 2024). "Updating Safari support for HTTP3". GitHub. Retrieved 20 July 2025.

↑ Shade, Robbie (8 July 2016). HTTP/2 Semantics Using The QUIC Transport Protocol. IETF. I-D draft-shade-quic-http2-mapping.

↑ Cimpanu, Catalin (12 November 2018). "HTTP-over-QUIC to be renamed HTTP/3". ZDNet. Retrieved 12 November 2018.

↑ Nottingham, Mark (28 October 2018). "Identifying our deliverables". IETF Mail Archive.

↑ "Hypertext Transfer Protocol Charter". ietf.org. Retrieved 2 September 2020.

↑ Daniel, Stenberg. "Daniel Stenberg announces HTTP/3 support in Firefox Nightly". Twitter. Retrieved 5 November 2019.',8932,9918);
INSERT INTO "passages" VALUES('S2-P11',2,11,'↑ Cimpanu, Catalin (26 September 2019). "Cloudflare, Google Chrome, and Firefox add HTTP/3 support". ZDNet. Retrieved 27 September 2019.

↑ "Release Notes for Safari Technology Preview 104". webkit.org. 8 April 2020. Retrieved 7 August 2020.

↑ "Safari 14 Release Notes". developer.apple.com. Retrieved 4 December 2020.

↑ Ng, Gary (23 June 2020). "Apple''s Safari Adds Support for HTTP3 in iOS 14 and macOS 11". iphoneincanada.ca. Retrieved 25 June 2021.

↑ Benjamin M. Schwartz; Mike Bishop; Erik Nygren (November 2023). Service Binding and Parameter Specification via the DNS (SVCB and HTTPS Resource Records). Internet Engineering Task Force. doi:10.17487/RFC9460. ISSN 2070-1721. RFC 9460. Proposed Standard.

↑ "HTTPS RR". MDN. Mozilla. Retrieved 25 October 2022.

↑ Schwartz, Benjamin M.; Bishop, Mike; Nygren, Erik (12 June 2020). Service binding and parameter specification via the DNS. IETF. I-D draft-ietf-dnsop-svcb-https.',9920,10853);
INSERT INTO "passages" VALUES('S2-P12',2,12,'↑ "Firefox 92 for developers". Mozilla Corporation. 7 September 2021. Retrieved 25 October 2022.

↑ "Feature: HTTP->HTTPS redirect for HTTPS DNS records". Google Inc. Retrieved 25 October 2022.

↑ Patrick Mevzek (24 August 2021). "What''s the use case of SVCB (type 65, service binding) RR". Stack Exchange Inc. Retrieved 25 October 2022.

↑ "Enabling QUIC in tip-of-tree". groups.google.com. Retrieved 9 April 2021.

↑ "Firefox Release Owners - MozillaWiki". wiki.mozilla.org. Retrieved 9 April 2021.

↑ Jen Simmons (4 April 2023). "HTTP/3 support shipped in Safari 14.0". GitHub. Retrieved 20 July 2025.

↑ "QUIC Implementations". GitHub. Retrieved 8 April 2021.

↑ "First HTTP/3 with curl". Daniel Stenberg. 5 August 2019. Retrieved 2 October 2019.

↑ "HTTP3 (and QUIC)". Daniel Stenberg. 23 August 2023. Retrieved 27 August 2023.

↑ "MsQuic is Open Source". 28 April 2020. Retrieved 28 April 2020.

↑ "HTTP/3 support in .NET 6". 17 September 2021. Retrieved 17 September 2021.',10855,11834);
INSERT INTO "passages" VALUES('S2-P13',2,13,'↑ "HTTP/3 support in .NET 6". .NET Blog. 17 September 2021. Retrieved 12 January 2022.

↑ "LiteSpeed Web Server Release Log - LiteSpeed Technologies". www.litespeedtech.com. Retrieved 12 February 2022. Enable HTTP/3 v1 by default.

↑ "Release 2.6.0 · caddyserver/caddy". Github. 22 September 2022. Retrieved 20 September 2022.

↑ "Introducing a Technology Preview of NGINX Support for QUIC and HTTP/3". nginx.com. 10 June 2020. Retrieved 11 June 2020.

↑ "Binary Packages Now Available for the Preview NGINX QUIC+HTTP/3 Implementation". nginx.com. 8 February 2023. Retrieved 30 March 2023.

↑ "Experiment with HTTP/3 using NGINX and quiche". The Cloudflare Blog. 17 October 2019. Retrieved 9 November 2019.

↑ Tratcher. "Use ASP.NET Core with HTTP/3 on IIS". docs.microsoft.com. Retrieved 29 April 2022.

↑ "Announcing HAProxy 2.6". HAProxy Blog. 31 May 2022.

↑ "QUIC Implementation in HAProxy". HAProxyConf video presentation. 25 January 2023.',11836,12781);
INSERT INTO "passages" VALUES('S2-P14',2,14,'↑ "HTTP/3 and QUIC support in Nimble Streamer". softvelum.com. 14 February 2025. Retrieved 17 February 2025.

External links

[edit]

Official website

IETF QUIC Working Group on GitHub

HTTP/3 explained (Daniel Stenberg)

HTTP/3 on canIuse.com

List of QUIC implementations on the IETF QUIC Working Group Wiki

v

t

e

Web interfaces

Server-side

Protocols

HTTP

v2

v3

Encryption

WebDAV

CGI

SCGI

FCGI

AJP

WSRP

WebSocket

Server APIs

C NSAPI

C ASAPI

C ISAPI

COM ASP

Jakarta Servlet

container

CLI OWIN

ASP.NET Handler

Python WSGI

Python ASGI

Ruby Rack

JavaScript JSGI

Perl PSGI

Portlet

container

Apache modules

mod_include

mod_jk

mod_lisp

mod_mono

mod_parrot

mod_perl

mod_php

mod_proxy

mod_python

mod_wsgi

mod_ruby

Phusion Passenger

Topics

Web service vs. Web resource

WOA vs. ROA

Open API

Webhook

Application server

comparison

Scripting

Client-side

Browser APIs

C NPAPI

LiveConnect

XPConnect

C NPRuntime

C PPAPI

NaCl

ActiveX

BHO

XBAP',12783,13775);
INSERT INTO "passages" VALUES('S2-P15',2,15,'Web APIs

WHATWG

Audio

Canvas

DOM

SSE

Video

WebSockets

Web messaging

Web storage

Web worker

XMLHttpRequest

W3C

DOM events

EME

File

Geolocation

IndexedDB

MSE

SVG

WebAssembly

WebAuthn

WebGPU

WebRTC

WebXR

Khronos

WebCL

WebGL

Others

Gears (discontinued)

Web SQL Database (discontinued)

WebUSB

Topics

Ajax and Remote scripting vs. DHTML

Browser extension

Cross-site scripting and CORS

Hydration

Mashup

Persistent data

Web IDL

Scripting

Related topics

Frontend and backend

Microservices

REST

GraphQL

Push technology

Solution stack

Web page

Static

Dynamic

Web standards

Web API security

Web application

Rich

Single-page

Progressive

Web framework

v

t

e

Web browsers

Features, standards & protocols

Features

Bookmarks

Extensions

Privacy mode

Web standards

HTML

v5

CSS

DOM

JavaScript

WebAssembly

Web storage

IndexedDB

WebGL

WebGPU

Protocols

HTTP

Encryption

Cookies

third-party

OCSP

WebRTC

WebSocket

Active

Blink-based',13777,14770);
INSERT INTO "passages" VALUES('S2-P16',2,16,'Proprietary

Google Chrome

Arc

Atlas

Avast

Cốc Cốc

Comet

Ecosia

Epic

Huawei

Maxthon

Microsoft Edge

Opera (Mobile)

Puffin

QQ

Samsung

Silk

Sleipnir

SRWare

UC

Vivaldi

Whale

Yandex

FOSS

Chromium

Brave

Dooble

Falkon

Otter

Supermium

ungoogled

Gecko-based

Firefox

Floorp

GNU IceCat

LibreWolf

Midori

Mullvad

SlimBrowser

SeaMonkey (uses unnamed Gecko fork)

Tor

Waterfox

Zen

Goanna-based

Basilisk

K-Meleon

Pale Moon

WebKit-based

Safari

GNOME Web

iCab

Orion

Multi-engine

360

DuckDuckGo

Konqueror

Lunascape

NetFront

qutebrowser

Other

Dillo

eww

Flow

Ladybird

Links

Lynx

NetSurf

Opera Mini

w3m

Discontinued

Blink-based

Beaker

Citrio

Flock

Redcore

Rockmelt

SalamWeb

Sputnik

Torch

Gecko-based

Beonex

Camino

Classilla

Conkeror

Firefox Lite

Galeon

Ghostzilla

IceDragon

Kazehakase

Kylo

Lotus

MicroB

Minimo

Mozilla suite

PirateBrowser

Pogo

Strata

Swiftfox

TenFourFox

Timberwolf

Waterfox Classic

xB

MSHTML-based',14772,15763);
INSERT INTO "passages" VALUES('S2-P17',2,17,'Internet Explorer

AOL

Deepnet

GreenBrowser

MediaBrowser

MSN Explorer

MSN Program Viewer

NeoPlanet

NetCaptor

SpaceTime

ZAC

WebKit-based

Arora

BOLT

Dolphin

Fluid

Google TV

Iris

Mercury

Nokia Symbian

OmniWeb

Opera Coast

Origyn

QtWeb

Shiira

Steel

surf

Uzbl

WebPositive

xombrero

Other

abaco

Amaya

Arachne

Arena

Blazer

Cake

CM

Deepfish

Edge Legacy

ELinks

Gazelle

HotJava

IBM Home Page Reader

IBM WebExplorer

IBrowse

Internet Explorer for Mac

KidZui

Line Mode

Mosaic

MSN TV

NetPositive

Netscape

Skweezer

Skyfire

ThunderHawk

Vision

WinWAP

WorldWideWeb

List

Comparison

Category

Retrieved from "https://en.wikipedia.org/w/index.php?title=HTTP/3&oldid=1378386113"

Categories:

Hypertext Transfer Protocol

Application layer protocols

Internet properties established in 2018

Hidden categories:

Articles with short description

Short description is different from Wikidata

Use dmy dates from January 2019

Search

Search

HTTP/3',15765,16747);
INSERT INTO "passages" VALUES('S2-P18',2,18,'16 languages Add topic',16749,16771);
INSERT INTO "passages" VALUES('S3-P0',3,0,'Skip to main content

Hypertext Transfer Protocol Version 3 (HTTP/3)

draft-ietf-quic-http-33

Status

IESG evaluation record

IESG writeups

Email expansions

History

Versions:

The information below is for an old version of the document.

Document

Type

This is an older version of an Internet-Draft that was ultimately published as RFC 9114.

Author

Mike Bishop

Last updated

2021-01-21 (Latest revision 2020-12-15)

Replaces

draft-shade-quic-http2-mapping

RFC stream

Internet Engineering Task Force (IETF)

Formats

txt html xml htmlized bibtex bibxml

Reviews

GENART Telechat review by Reese Enghardt Ready

SECDIR IETF Last Call review (of -32) by Hilarie Orman Ready

GENART IETF Last Call review (of -32) by Reese Enghardt Ready w/issues

Additional resources

Mailing list discussion

Stream

WG state

Submitted to IESG for Publication

Document shepherd

Lucas Pardue

Shepherd write-up

Show Last changed 2020-09-25

IESG

IESG state

Became RFC 9114 (Proposed Standard)',0,990);
INSERT INTO "passages" VALUES('S3-P1',3,1,'Consensus boilerplate

Yes

Telechat date

(None)

Needs 7 more YES or NO OBJECTION positions to pass.

Responsible AD

Magnus Westerlund

Send notices to

quic-chairs@ietf.org

IANA

IANA review state

IANA OK - Actions Needed

IANA expert review state

Expert Reviews OK

Email authors Email WG IPR References Referenced by Nits Nits v3 Search email archive

draft-ietf-quic-http-33

QUIC M. Bishop, Ed. Internet-Draft Akamai Intended status: Standards Track 15 December 2020 Expires: 18 June 2021 Hypertext Transfer Protocol Version 3 (HTTP/3) draft-ietf-quic-http-33 Abstract The QUIC transport protocol has several features that are desirable in a transport for HTTP, such as stream multiplexing, per-stream flow control, and low-latency connection establishment. This document describes a mapping of HTTP semantics over QUIC. This document also identifies HTTP/2 features that are subsumed by QUIC, and describes how HTTP/2 extensions can be ported to HTTP/3.',992,1957);
INSERT INTO "passages" VALUES('S3-P2',3,2,'DO NOT DEPLOY THIS VERSION OF HTTP DO NOT DEPLOY THIS VERSION OF HTTP/3 UNTIL IT IS IN AN RFC. This version is still a work in progress. For trial deployments, please use earlier versions. Note to Readers Discussion of this draft takes place on the QUIC working group mailing list (quic@ietf.org), which is archived at https://mailarchive.ietf.org/arch/search/?email_list=quic. Working Group information can be found at https://github.com/quicwg; source code and issues list for this draft can be found at https://github.com/quicwg/base-drafts/labels/-http. Status of This Memo This Internet-Draft is submitted in full conformance with the provisions of BCP 78 and BCP 79. Internet-Drafts are working documents of the Internet Engineering Task Force (IETF). Note that other groups may also distribute working documents as Internet-Drafts. The list of current Internet- Drafts is at https://datatracker.ietf.org/drafts/current/.',1958,2885);
INSERT INTO "passages" VALUES('S3-P3',3,3,'Internet-Drafts are draft documents valid for a maximum of six months and may be updated, replaced, or obsoleted by other documents at any time. It is inappropriate to use Internet-Drafts as reference material or to cite them other than as "work in progress." Bishop Expires 18 June 2021 [Page 1] Internet-Draft HTTP/3 December 2020 This Internet-Draft will expire on 18 June 2021. Copyright Notice Copyright (c) 2020 IETF Trust and the persons identified as the document authors. All rights reserved. This document is subject to BCP 78 and the IETF Trust''s Legal Provisions Relating to IETF Documents (https://trustee.ietf.org/ license-info) in effect on the date of publication of this document. Please review these documents carefully, as they describe your rights and restrictions with respect to this document.',2886,3701);
INSERT INTO "passages" VALUES('S3-P4',3,4,'Code Components extracted from this document must include Simplified BSD License text as described in Section 4.e of the Trust Legal Provisions and are provided without warranty as described in the Simplified BSD License. Table of Contents 1. Introduction . . . . . . . . . . . . . . . . . . . . . . . . 4 1.1. Prior versions of HTTP . . . . . . . . . . . . . . . . . 5 1.2. Delegation to QUIC . . . . . . . . . . . . . . . . . . . 5 2. HTTP/3 Protocol Overview . . . . . . . . . . . . . . . . . . 5 2.1. Document Organization . . . . . . . . . . . . . . . . . . 6 2.2. Conventions and Terminology . . . . . . . . . . . . . . . 7 3. Connection Setup and Management . . . . . . . . . . . . . . . 8 3.1. Discovering an HTTP/3 Endpoint . . . . . . . . . . . . . 8 3.1.1. HTTP Alternative Services . . . . . . . . . . . . . . 9 3.1.2. Other Schemes . . . . . . . . . . . . . . . . . . . . 10 3.2. Connection Establishment . . . . . . . . . . . . . . . . 10 3.3. Connection Reuse . . . . . . . . . . . . .',3702,4702);
INSERT INTO "passages" VALUES('S3-P5',3,5,'. . . . . . . 11 4. HTTP Request Lifecycle . . . . . . . . . . . . . . . . . . . 11 4.1. HTTP Message Exchanges . . . . . . . . . . . . . . . . . 11 4.1.1. Field Formatting and Compression . . . . . . . . . . 13 4.1.2. Request Cancellation and Rejection . . . . . . . . . 17 4.1.3. Malformed Requests and Responses . . . . . . . . . . 18 4.2. The CONNECT Method . . . . . . . . . . . . . . . . . . . 19 4.3. HTTP Upgrade . . . . . . . . . . . . . . . . . . . . . . 20 4.4. Server Push . . . . . . . . . . . . . . . . . . . . . . . 20 5. Connection Closure . . . . . . . . . . . . . . . . . . . . . 22 5.1. Idle Connections . . . . . . . . . . . . . . . . . . . . 22 5.2. Connection Shutdown . . . . . . . . . . . . . . . . . . . 23 5.3. Immediate Application Closure . . . . . . . . . . . . . . 25 5.4. Transport Closure . . . . . . . . . . . . . . . . . . . . 25 6. Stream Mapping and Usage . . . . . . . . . . . . . . . . . . 25 6.1. Bidirectional Streams . . . . . . . . . . . . . . . . . .',4703,5696);
INSERT INTO "passages" VALUES('S3-P6',3,6,'26 6.2. Unidirectional Streams . . . . . . . . . . . . . . . . . 26 6.2.1. Control Streams . . . . . . . . . . . . . . . . . . . 28 6.2.2. Push Streams . . . . . . . . . . . . . . . . . . . . 28 Bishop Expires 18 June 2021 [Page 2] Internet-Draft HTTP/3 December 2020 6.2.3. Reserved Stream Types . . . . . . . . . . . . . . . . 29 7. HTTP Framing Layer . . . . . . . . . . . . . . . . . . . . . 29 7.1. Frame Layout . . . . . . . . . . . . . . . . . . . . . . 30 7.2. Frame Definitions . . . . . . . . . . . . . . . . . . . . 31 7.2.1. DATA . . . . . . . . . . . . . . . . . . . . . . . . 31 7.2.2. HEADERS . . . . . . . . . . . . . . . . . . . . . . . 31 7.2.3. CANCEL_PUSH . . . . . . . . . . . . . . . . . . . . . 32 7.2.4. SETTINGS . . . . . . . . . . . . . . . . . . . . . . 33 7.2.5. PUSH_PROMISE . . . . . . . . . . . . . . . . . . . . 36 7.2.6. GOAWAY . . . . . . . . . . . . . . . . . . . . . . . 38 7.2.7. MAX_PUSH_ID . . . . . . . . . . . . . . . . . . . . . 38 7.2.8.',5697,6677);
INSERT INTO "passages" VALUES('S3-P7',3,7,'Reserved Frame Types . . . . . . . . . . . . . . . . 39 8. Error Handling . . . . . . . . . . . . . . . . . . . . . . . 40 8.1. HTTP/3 Error Codes . . . . . . . . . . . . . . . . . . . 40 9. Extensions to HTTP/3 . . . . . . . . . . . . . . . . . . . . 42 10. Security Considerations . . . . . . . . . . . . . . . . . . . 43 10.1. Server Authority . . . . . . . . . . . . . . . . . . . . 43 10.2. Cross-Protocol Attacks . . . . . . . . . . . . . . . . . 43 10.3. Intermediary Encapsulation Attacks . . . . . . . . . . . 43 10.4. Cacheability of Pushed Responses . . . . . . . . . . . . 44 10.5. Denial-of-Service Considerations . . . . . . . . . . . . 44 10.5.1. Limits on Field Section Size . . . . . . . . . . . . 45 10.5.2. CONNECT Issues . . . . . . . . . . . . . . . . . . . 46 10.6. Use of Compression . . . . . . . . . . . . . . . . . . . 46 10.7. Padding and Traffic Analysis . . . . . . . . . . . . . . 46 10.8. Frame Parsing . . . . . . . . . . . . . . . . . . . . . 47 10.9. Early Data . .',6678,7677);
INSERT INTO "passages" VALUES('S3-P8',3,8,'. . . . . . . . . . . . . . . . . . . . . 47 10.10. Migration . . . . . . . . . . . . . . . . . . . . . . . 48 10.11. Privacy Considerations . . . . . . . . . . . . . . . . . 48 11. IANA Considerations . . . . . . . . . . . . . . . . . . . . . 48 11.1. Registration of HTTP/3 Identification String . . . . . . 48 11.2. New Registries . . . . . . . . . . . . . . . . . . . . . 49 11.2.1. Frame Types . . . . . . . . . . . . . . . . . . . . 49 11.2.2. Settings Parameters . . . . . . . . . . . . . . . . 50 11.2.3. Error Codes . . . . . . . . . . . . . . . . . . . . 51 11.2.4. Stream Types . . . . . . . . . . . . . . . . . . . . 54 12. References . . . . . . . . . . . . . . . . . . . . . . . . . 54 12.1. Normative References . . . . . . . . . . . . . . . . . . 54 12.2. Informative References . . . . . . . . . . . . . . . . . 56 Appendix A. Considerations for Transitioning from HTTP/2 . . . . 57 A.1. Streams . . . . . . . . . . . . . . . . . . . . . . . . . 57 A.2. HTTP Frame Types . . . . . .',7678,8677);
INSERT INTO "passages" VALUES('S3-P9',3,9,'. . . . . . . . . . . . . . 58 A.2.1. Prioritization Differences . . . . . . . . . . . . . 59 A.2.2. Field Compression Differences . . . . . . . . . . . . 59 A.2.3. Flow Control Differences . . . . . . . . . . . . . . 59 A.2.4. Guidance for New Frame Type Definitions . . . . . . . 59 A.2.5. Mapping Between HTTP/2 and HTTP/3 Frame Types . . . . 60 A.3. HTTP/2 SETTINGS Parameters . . . . . . . . . . . . . . . 61 Bishop Expires 18 June 2021 [Page 3] Internet-Draft HTTP/3 December 2020 A.4. HTTP/2 Error Codes . . . . . . . . . . . . . . . . . . . 62 A.4.1. Mapping Between HTTP/2 and HTTP/3 Errors . . . . . . 63 Appendix B. Change Log . . . . . . . . . . . . . . . . . . . . . 64 B.1. Since draft-ietf-quic-http-32 . . . . . . . . . . . . . . 64 B.2. Since draft-ietf-quic-http-31 . . . . . . . . . . . . . . 64 B.3. Since draft-ietf-quic-http-30 . . . . . . . . . . . . . . 64 B.4. Since draft-ietf-quic-http-29 . . . . . . . . . . . . . . 64 B.5. Since draft-ietf-quic-http-28 . . . . . . . . .',8678,9677);
INSERT INTO "passages" VALUES('S3-P10',3,10,'. . . . . 64 B.6. Since draft-ietf-quic-http-27 . . . . . . . . . . . . . . 64 B.7. Since draft-ietf-quic-http-26 . . . . . . . . . . . . . . 65 B.8. Since draft-ietf-quic-http-25 . . . . . . . . . . . . . . 65 B.9. Since draft-ietf-quic-http-24 . . . . . . . . . . . . . . 65 B.10. Since draft-ietf-quic-http-23 . . . . . . . . . . . . . . 65 B.11. Since draft-ietf-quic-http-22 . . . . . . . . . . . . . . 65 B.12. Since draft-ietf-quic-http-21 . . . . . . . . . . . . . . 66 B.13. Since draft-ietf-quic-http-20 . . . . . . . . . . . . . . 66 B.14. Since draft-ietf-quic-http-19 . . . . . . . . . . . . . . 67 B.15. Since draft-ietf-quic-http-18 . . . . . . . . . . . . . . 67 B.16. Since draft-ietf-quic-http-17 . . . . . . . . . . . . . . 68 B.17. Since draft-ietf-quic-http-16 . . . . . . . . . . . . . . 68 B.18. Since draft-ietf-quic-http-15 . . . . . . . . . . . . . . 69 B.19. Since draft-ietf-quic-http-14 . . . . . . . . . . . . . . 69 B.20. Since draft-ietf-quic-http-13 . . . . . . . . .',9678,10678);
INSERT INTO "passages" VALUES('S3-P11',3,11,'. . . . . 69 B.21. Since draft-ietf-quic-http-12 . . . . . . . . . . . . . . 69 B.22. Since draft-ietf-quic-http-11 . . . . . . . . . . . . . . 70 B.23. Since draft-ietf-quic-http-10 . . . . . . . . . . . . . . 70 B.24. Since draft-ietf-quic-http-09 . . . . . . . . . . . . . . 70 B.25. Since draft-ietf-quic-http-08 . . . . . . . . . . . . . . 70 B.26. Since draft-ietf-quic-http-07 . . . . . . . . . . . . . . 70 B.27. Since draft-ietf-quic-http-06 . . . . . . . . . . . . . . 70 B.28. Since draft-ietf-quic-http-05 . . . . . . . . . . . . . . 70 B.29. Since draft-ietf-quic-http-04 . . . . . . . . . . . . . . 70 B.30. Since draft-ietf-quic-http-03 . . . . . . . . . . . . . . 71 B.31. Since draft-ietf-quic-http-02 . . . . . . . . . . . . . . 71 B.32. Since draft-ietf-quic-http-01 . . . . . . . . . . . . . . 71 B.33. Since draft-ietf-quic-http-00 . . . . . . . . . . . . . . 72 B.34. Since draft-shade-quic-http2-mapping-00 . . . . . . . . . 72 Acknowledgements . . . . . . . . . . . . . . . .',10679,11678);
INSERT INTO "passages" VALUES('S3-P12',3,12,'. . . . . . . . 72 Author''s Address . . . . . . . . . . . . . . . . . . . . . . . . 73 1. Introduction HTTP semantics ([SEMANTICS]) are used for a broad range of services on the Internet. These semantics have most commonly been used with HTTP/1.1, over a variety of transport and session layers, and with HTTP/2 over TLS. HTTP/3 supports the same semantics over a new transport protocol, QUIC. Bishop Expires 18 June 2021 [Page 4] Internet-Draft HTTP/3 December 2020 1.1. Prior versions of HTTP HTTP/1.1 ([HTTP11]) uses whitespace-delimited text fields to convey HTTP messages. While these exchanges are human-readable, using whitespace for message formatting leads to parsing complexity and excessive tolerance of variant behavior. Because HTTP/1.x does not include a multiplexing layer, multiple TCP connections are often used to service requests in parallel.',11679,12540);
INSERT INTO "passages" VALUES('S3-P13',3,13,'However, that has a negative impact on congestion control and network efficiency, since TCP does not share congestion control across multiple connections. HTTP/2 ([HTTP2]) introduced a binary framing and multiplexing layer to improve latency without modifying the transport layer. However, because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was directly impacted by the lost packet. 1.2. Delegation to QUIC The QUIC transport protocol incorporates stream multiplexing and per- stream flow control, similar to that provided by the HTTP/2 framing layer. By providing reliability at the stream level and congestion control across the entire connection, QUIC has the capability to improve the performance of HTTP compared to a TCP mapping.',12541,13447);
INSERT INTO "passages" VALUES('S3-P14',3,14,'QUIC also incorporates TLS 1.3 ([TLS13]) at the transport layer, offering comparable confidentiality and integrity to running TLS over TCP, with the improved connection setup latency of TCP Fast Open ([TFO]). This document defines a mapping of HTTP semantics over the QUIC transport protocol, drawing heavily on the design of HTTP/2. While delegating stream lifetime and flow control issues to QUIC, a similar binary framing is used on each stream. Some HTTP/2 features are subsumed by QUIC, while other features are implemented atop QUIC. QUIC is described in [QUIC-TRANSPORT]. For a full description of HTTP/2, see [HTTP2]. 2. HTTP/3 Protocol Overview HTTP/3 provides a transport for HTTP semantics using the QUIC transport protocol and an internal framing layer similar to HTTP/2. Once a client knows that an HTTP/3 server exists at a certain endpoint, it opens a QUIC connection. QUIC provides protocol negotiation, stream-based multiplexing, and flow control.',13448,14412);
INSERT INTO "passages" VALUES('S3-P15',3,15,'Discovery of an HTTP/3 endpoint is described in Section 3.1. Bishop Expires 18 June 2021 [Page 5] Internet-Draft HTTP/3 December 2020 Within each stream, the basic unit of HTTP/3 communication is a frame (Section 7.2). Each frame type serves a different purpose. For example, HEADERS and DATA frames form the basis of HTTP requests and responses (Section 4.1). Multiplexing of requests is performed using the QUIC stream abstraction, described in Section 2 of [QUIC-TRANSPORT]. Each request-response pair consumes a single QUIC stream. Streams are independent of each other, so one stream that is blocked or suffers packet loss does not prevent progress on other streams. Server push is an interaction mode introduced in HTTP/2 ([HTTP2]) that permits a server to push a request-response exchange to a client in anticipation of the client making the indicated request. This trades off network usage against a potential latency gain.',14413,15344);
INSERT INTO "passages" VALUES('S3-P16',3,16,'Several HTTP/3 frames are used to manage server push, such as PUSH_PROMISE, MAX_PUSH_ID, and CANCEL_PUSH. As in HTTP/2, request and response fields are compressed for transmission. Because HPACK ([HPACK]) relies on in-order transmission of compressed field sections (a guarantee not provided by QUIC), HTTP/3 replaces HPACK with QPACK ([QPACK]). QPACK uses separate unidirectional streams to modify and track field table state, while encoded field sections refer to the state of the table without modifying it. 2.1. Document Organization The following sections provide a detailed overview of the lifecycle of an HTTP/3 connection: * Connection Setup and Management (Section 3) covers how an HTTP/3 endpoint is discovered and an HTTP/3 connection is established. * HTTP Request Lifecycle (Section 4) describes how HTTP semantics are expressed using frames. * Connection Closure (Section 5) describes how HTTP/3 connections are terminated, either gracefully or abruptly.',15345,16313);
INSERT INTO "passages" VALUES('S3-P17',3,17,'The details of the wire protocol and interactions with the transport are described in subsequent sections: * Stream Mapping and Usage (Section 6) describes the way QUIC streams are used. * HTTP Framing Layer (Section 7) describes the frames used on most streams. Bishop Expires 18 June 2021 [Page 6] Internet-Draft HTTP/3 December 2020 * Error Handling (Section 8) describes how error conditions are handled and expressed, either on a particular stream or for the connection as a whole. Additional resources are provided in the final sections: * Extensions to HTTP/3 (Section 9) describes how new capabilities can be added in future documents. * A more detailed comparison between HTTP/2 and HTTP/3 can be found in Appendix A. 2.2.',16314,17045);
INSERT INTO "passages" VALUES('S3-P18',3,18,'Conventions and Terminology The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "NOT RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in BCP 14 [RFC2119] [RFC8174] when, and only when, they appear in all capitals, as shown here. This document uses the variable-length integer encoding from [QUIC-TRANSPORT]. The following terms are used: abort: An abrupt termination of a connection or stream, possibly due to an error condition. client: The endpoint that initiates an HTTP/3 connection. Clients send HTTP requests and receive HTTP responses. connection: A transport-layer connection between two endpoints, using QUIC as the transport protocol. connection error: An error that affects the entire HTTP/3 connection. endpoint: Either the client or server of the connection.',17046,17911);
INSERT INTO "passages" VALUES('S3-P19',3,19,'frame: The smallest unit of communication on a stream in HTTP/3, consisting of a header and a variable-length sequence of bytes structured according to the frame type. Protocol elements called "frames" exist in both this document and [QUIC-TRANSPORT]. Where frames from [QUIC-TRANSPORT] are referenced, the frame name will be prefaced with "QUIC." For example, "QUIC CONNECTION_CLOSE frames." References without this preface refer to frames defined in Section 7.2. Bishop Expires 18 June 2021 [Page 7] Internet-Draft HTTP/3 December 2020 HTTP/3 connection: A QUIC connection where the negotiated application protocol is HTTP/3. peer: An endpoint. When discussing a particular endpoint, "peer" refers to the endpoint that is remote to the primary subject of discussion. receiver: An endpoint that is receiving frames. sender: An endpoint that is transmitting frames. server: The endpoint that accepts an HTTP/3 connection. Servers receive HTTP requests and send HTTP responses.',17912,18888);
INSERT INTO "passages" VALUES('S3-P20',3,20,'stream: A bidirectional or unidirectional bytestream provided by the QUIC transport. All streams within an HTTP/3 connection can be considered "HTTP/3 streams," but multiple stream types are defined within HTTP/3. stream error: An application-level error on the individual stream. The term "payload data" is defined in Section 6.4 of [SEMANTICS]. Finally, the terms "resource", "message", "user agent", "origin server", "gateway", "intermediary", "proxy", and "tunnel" are defined in Section 3 of [SEMANTICS]. Packet diagrams in this document use the format defined in Section 1.3 of [QUIC-TRANSPORT] to illustrate the order and size of fields. 3. Connection Setup and Management 3.1.',18889,19573);
INSERT INTO "passages" VALUES('S3-P21',3,21,'Discovering an HTTP/3 Endpoint HTTP relies on the notion of an authoritative response: a response that has been determined to be the most appropriate response for that request given the state of the target resource at the time of response message origination by (or at the direction of) the origin server identified within the target URI. Locating an authoritative server for an HTTP URL is discussed in Section 4.3 of [SEMANTICS]. The "https" scheme associates authority with possession of a certificate that the client considers to be trustworthy for the host identified by the authority component of the URL. Bishop Expires 18 June 2021 [Page 8] Internet-Draft HTTP/3 December 2020 If a server presents a valid certificate and proof that it controls the corresponding private key, then a client will accept a secured TLS session with that server as being authoritative for all origins with the "https" scheme and a host identified in the certificate.',19574,20527);
INSERT INTO "passages" VALUES('S3-P22',3,22,'The host must be listed either as the CN field of the certificate subject or as a dNSName in the subjectAltName field of the certificate; see [RFC6125]. For a host that is an IP address, the client MUST verify that the address appears as an iPAddress in the subjectAltName field of the certificate. If the hostname or address is not present in the certificate, the client MUST NOT consider the server authoritative for origins containing that hostname or address. See Section 4.3 of [SEMANTICS] for more detail on authoritative access. A client MAY attempt access to a resource with an "https" URI by resolving the host identifier to an IP address, establishing a QUIC connection to that address on the indicated port, and sending an HTTP/3 request message targeting the URI to the server over that secured connection. Unless some other mechanism is used to select HTTP/3, the token "h3" is used in the Application Layer Protocol Negotiation (ALPN; see [RFC7301]) extension during the TLS handshake.',20528,21527);
INSERT INTO "passages" VALUES('S3-P23',3,23,'Connectivity problems (e.g., blocking UDP) can result in QUIC connection establishment failure; clients SHOULD attempt to use TCP- based versions of HTTP in this case. Servers MAY serve HTTP/3 on any UDP port; an alternative service advertisement always includes an explicit port, and URLs contain either an explicit port or a default port associated with the scheme. 3.1.1. HTTP Alternative Services An HTTP origin advertises the availability of an equivalent HTTP/3 endpoint via the Alt-Svc HTTP response header field or the HTTP/2 ALTSVC frame ([ALTSVC]), using the "h3" ALPN token.',21528,22113);
INSERT INTO "passages" VALUES('S3-P24',3,24,'For example, an origin could indicate in an HTTP response that HTTP/3 was available on UDP port 50781 at the same hostname by including the following header field: Alt-Svc: h3=":50781" On receipt of an Alt-Svc record indicating HTTP/3 support, a client MAY attempt to establish a QUIC connection to the indicated host and port; if this connection is successful, the client can send HTTP requests using the mapping described in this document. Bishop Expires 18 June 2021 [Page 9] Internet-Draft HTTP/3 December 2020 3.1.2. Other Schemes Although HTTP is independent of the transport protocol, the "http" scheme associates authority with the ability to receive TCP connections on the indicated port of whatever host is identified within the authority component. Because HTTP/3 does not use TCP, HTTP/3 cannot be used for direct access to the authoritative server for a resource identified by an "http" URI.',22114,23018);
INSERT INTO "passages" VALUES('S3-P25',3,25,'However, protocol extensions such as [ALTSVC] permit the authoritative server to identify other services that are also authoritative and that might be reachable over HTTP/3. Prior to making requests for an origin whose scheme is not "https", the client MUST ensure the server is willing to serve that scheme. For origins whose scheme is "http", an experimental method to accomplish this is described in [RFC8164]. Other mechanisms might be defined for various schemes in the future. 3.2. Connection Establishment HTTP/3 relies on QUIC version 1 as the underlying transport. The use of other QUIC transport versions with HTTP/3 MAY be defined by future specifications. QUIC version 1 uses TLS version 1.3 or greater as its handshake protocol. HTTP/3 clients MUST support a mechanism to indicate the target host to the server during the TLS handshake.',23019,23868);
INSERT INTO "passages" VALUES('S3-P26',3,26,'If the server is identified by a DNS name, clients MUST send the Server Name Indication (SNI; [RFC6066]) TLS extension unless an alternative mechanism to indicate the target host is used. QUIC connections are established as described in [QUIC-TRANSPORT]. During connection establishment, HTTP/3 support is indicated by selecting the ALPN token "h3" in the TLS handshake. Support for other application-layer protocols MAY be offered in the same handshake. While connection-level options pertaining to the core QUIC protocol are set in the initial crypto handshake, HTTP/3-specific settings are conveyed in the SETTINGS frame. After the QUIC connection is established, a SETTINGS frame (Section 7.2.4) MUST be sent by each endpoint as the initial frame of their respective HTTP control stream; see Section 6.2.1. Bishop Expires 18 June 2021 [Page 10] Internet-Draft HTTP/3 December 2020 3.3. Connection Reuse HTTP/3 connections are persistent across multiple requests.',23869,24835);
INSERT INTO "passages" VALUES('S3-P27',3,27,'For best performance, it is expected that clients will not close connections until it is determined that no further communication with a server is necessary (for example, when a user navigates away from a particular web page) or until the server closes the connection. Once a connection exists to a server endpoint, this connection MAY be reused for requests with multiple different URI authority components. Clients SHOULD NOT open more than one HTTP/3 connection to a given host and port pair, where the host is derived from a URI, a selected alternative service ([ALTSVC]), or a configured proxy. A client MAY open multiple HTTP/3 connections to the same IP address and UDP port using different transport or TLS configurations but SHOULD avoid creating multiple connections with the same configuration. Servers are encouraged to maintain open HTTP/3 connections for as long as possible but are permitted to terminate idle connections if necessary.',24836,25786);
INSERT INTO "passages" VALUES('S3-P28',3,28,'When either endpoint chooses to close the HTTP/3 connection, the terminating endpoint SHOULD first send a GOAWAY frame (Section 5.2) so that both endpoints can reliably determine whether previously sent frames have been processed and gracefully complete or terminate any necessary remaining tasks. A server that does not wish clients to reuse HTTP/3 connections for a particular origin can indicate that it is not authoritative for a request by sending a 421 (Misdirected Request) status code in response to the request; see Section 9.1.2 of [HTTP2]. 4. HTTP Request Lifecycle 4.1. HTTP Message Exchanges A client sends an HTTP request on a request stream, which is a client-initiated bidirectional QUIC stream; see Section 6.1. A client MUST send only a single request on a given stream. A server sends zero or more interim HTTP responses on the same stream as the request, followed by a single final HTTP response, as detailed below.',25787,26722);
INSERT INTO "passages" VALUES('S3-P29',3,29,'See Section 15 of [SEMANTICS] for a description of interim and final HTTP responses. Pushed responses are sent on a server-initiated unidirectional QUIC stream; see Section 6.2.2. A server sends zero or more interim HTTP responses, followed by a single final HTTP response, in the same manner as a standard response. Push is described in more detail in Section 4.4. Bishop Expires 18 June 2021 [Page 11] Internet-Draft HTTP/3 December 2020 On a given stream, receipt of multiple requests or receipt of an additional HTTP response following a final HTTP response MUST be treated as malformed (Section 4.1.3). An HTTP message (request or response) consists of: 1. the header field section, sent as a single HEADERS frame (see Section 7.2.2), 2. optionally, the payload data, if present, sent as a series of DATA frames (see Section 7.2.1), and 3. optionally, the trailer field section, if present, sent as a single HEADERS frame.',26723,27650);
INSERT INTO "passages" VALUES('S3-P30',3,30,'Header and trailer field sections are described in Sections 6.3 and 6.5 of [SEMANTICS]; the payload data is described in Section 6.4 of [SEMANTICS]. Receipt of an invalid sequence of frames MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. In particular, a DATA frame before any HEADERS frame, or a HEADERS or DATA frame after the trailing HEADERS frame is considered invalid. Other frame types, especially unknown frame types, might be permitted subject to their own rules; see Section 9. A server MAY send one or more PUSH_PROMISE frames (Section 7.2.5) before, after, or interleaved with the frames of a response message. These PUSH_PROMISE frames are not part of the response; see Section 4.4 for more details. PUSH_PROMISE frames are not permitted on push streams; a pushed response that includes PUSH_PROMISE frames MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8.',27651,28586);
INSERT INTO "passages" VALUES('S3-P31',3,31,'Frames of unknown types (Section 9), including reserved frames (Section 7.2.8) MAY be sent on a request or push stream before, after, or interleaved with other frames described in this section. The HEADERS and PUSH_PROMISE frames might reference updates to the QPACK dynamic table. While these updates are not directly part of the message exchange, they must be received and processed before the message can be consumed. See Section 4.1.1 for more details. The "chunked" transfer encoding defined in Section 7.1 of [HTTP11] MUST NOT be used. Bishop Expires 18 June 2021 [Page 12] Internet-Draft HTTP/3 December 2020 A response MAY consist of multiple messages when and only when one or more interim responses (1xx; see Section 15.2 of [SEMANTICS]) precede a final response to the same request. Interim responses do not contain payload data or trailers. An HTTP request/response exchange fully consumes a client-initiated bidirectional QUIC stream.',28587,29534);
INSERT INTO "passages" VALUES('S3-P32',3,32,'After sending a request, a client MUST close the stream for sending. Unless using the CONNECT method (see Section 4.2), clients MUST NOT make stream closure dependent on receiving a response to their request. After sending a final response, the server MUST close the stream for sending. At this point, the QUIC stream is fully closed. When a stream is closed, this indicates the end of the final HTTP message. Because some messages are large or unbounded, endpoints SHOULD begin processing partial HTTP messages once enough of the message has been received to make progress. If a client-initiated stream terminates without enough of the HTTP message to provide a complete response, the server SHOULD abort its response with the error code H3_REQUEST_INCOMPLETE; see Section 8. A server can send a complete response prior to the client sending an entire request if the response does not depend on any portion of the request that has not been sent and received.',29535,30494);
INSERT INTO "passages" VALUES('S3-P33',3,33,'When the server does not need to receive the remainder of the request, it MAY abort reading the request stream, send a complete response, and cleanly close the sending part of the stream. The error code H3_NO_ERROR SHOULD be used when requesting that the client stop sending on the request stream. Clients MUST NOT discard complete responses as a result of having their request terminated abruptly, though clients can always discard responses at their discretion for other reasons. If the server sends a partial or complete response but does not abort reading the request, clients SHOULD continue sending the body of the request and close the stream normally. 4.1.1. Field Formatting and Compression HTTP messages carry metadata as a series of key-value pairs called HTTP fields; see Sections 6.3 and 6.5 of [SEMANTICS]. For a listing of registered HTTP fields, see the "Hypertext Transfer Protocol (HTTP) Field Name Registry" maintained at https://www.iana.org/assignments/http-fields/.',30495,31482);
INSERT INTO "passages" VALUES('S3-P34',3,34,'*Note:* This registry will not exist until [SEMANTICS] is approved. *RFC Editor*, please remove this note prior to publication. Bishop Expires 18 June 2021 [Page 13] Internet-Draft HTTP/3 December 2020 As in previous versions of HTTP, field names are strings containing a subset of ASCII characters that are compared in a case-insensitive fashion. Properties of HTTP field names and values are discussed in more detail in Section 5.1 of [SEMANTICS]. As in HTTP/2, characters in field names MUST be converted to lowercase prior to their encoding. A request or response containing uppercase characters in field names MUST be treated as malformed (Section 4.1.3). Like HTTP/2, HTTP/3 does not use the Connection header field to indicate connection-specific fields; in this protocol, connection- specific metadata is conveyed by other means.',31483,32320);
INSERT INTO "passages" VALUES('S3-P35',3,35,'An endpoint MUST NOT generate an HTTP/3 field section containing connection-specific fields; any message containing connection-specific fields MUST be treated as malformed (Section 4.1.3). The only exception to this is the TE header field, which MAY be present in an HTTP/3 request header; when it is, it MUST NOT contain any value other than "trailers". This means that an intermediary transforming an HTTP/1.x message to HTTP/3 will need to remove any fields nominated by the Connection field, along with the Connection field itself. Such intermediaries SHOULD also remove other connection-specific fields, such as Keep- Alive, Proxy-Connection, Transfer-Encoding, and Upgrade, even if they are not nominated by the Connection field. 4.1.1.1. Pseudo-Header Fields Like HTTP/2, HTTP/3 employs a series of pseudo-header fields where the field name begins with the '':'' character (ASCII 0x3a).',32321,33212);
INSERT INTO "passages" VALUES('S3-P36',3,36,'These pseudo-header fields convey the target URI, the method of the request, and the status code for the response. Pseudo-header fields are not HTTP fields. Endpoints MUST NOT generate pseudo-header fields other than those defined in this document; however, an extension could negotiate a modification of this restriction; see Section 9. Pseudo-header fields are only valid in the context in which they are defined. Pseudo-header fields defined for requests MUST NOT appear in responses; pseudo-header fields defined for responses MUST NOT appear in requests. Pseudo-header fields MUST NOT appear in trailers. Endpoints MUST treat a request or response that contains undefined or invalid pseudo-header fields as malformed (Section 4.1.3). Bishop Expires 18 June 2021 [Page 14] Internet-Draft HTTP/3 December 2020 All pseudo-header fields MUST appear in the header field section before regular header fields.',33213,34120);
INSERT INTO "passages" VALUES('S3-P37',3,37,'Any request or response that contains a pseudo-header field that appears in a header field section after a regular header field MUST be treated as malformed (Section 4.1.3). The following pseudo-header fields are defined for requests: ":method": Contains the HTTP method (Section 9 of [SEMANTICS]) ":scheme": Contains the scheme portion of the target URI (Section 3.1 of [URI]) ":scheme" is not restricted to "http" and "https" schemed URIs. A proxy or gateway can translate requests for non-HTTP schemes, enabling the use of HTTP to interact with non-HTTP services. ":authority": Contains the authority portion of the target URI (Section 3.2 of [URI]). The authority MUST NOT include the deprecated "userinfo" subcomponent for "http" or "https" schemed URIs. To ensure that the HTTP/1.1 request line can be reproduced accurately, this pseudo-header field MUST be omitted when translating from an HTTP/1.1 request that has a request target in origin or asterisk form; see Section 3.2 of [HTTP11].',34121,35117);
INSERT INTO "passages" VALUES('S3-P38',3,38,'Clients that generate HTTP/3 requests directly SHOULD use the ":authority" pseudo-header field instead of the Host field. An intermediary that converts an HTTP/3 request to HTTP/1.1 MUST create a Host field if one is not present in a request by copying the value of the ":authority" pseudo-header field. ":path": Contains the path and query parts of the target URI (the "path-absolute" production and optionally a ''?'' character followed by the "query" production; see Sections 3.3 and 3.4 of [URI]. A request in asterisk form includes the value ''*'' for the ":path" pseudo-header field. This pseudo-header field MUST NOT be empty for "http" or "https" URIs; "http" or "https" URIs that do not contain a path component MUST include a value of ''/''. The exception to this rule is an OPTIONS request for an "http" or "https" URI that does not include a path component; these MUST include a ":path" pseudo-header field with a value of ''*''; see Section 3.2.4 of [HTTP11].',35118,36082);
INSERT INTO "passages" VALUES('S3-P39',3,39,'All HTTP/3 requests MUST include exactly one value for the ":method", ":scheme", and ":path" pseudo-header fields, unless it is a CONNECT request; see Section 4.2. Bishop Expires 18 June 2021 [Page 15] Internet-Draft HTTP/3 December 2020 If the ":scheme" pseudo-header field identifies a scheme that has a mandatory authority component (including "http" and "https"), the request MUST contain either an ":authority" pseudo-header field or a "Host" header field. If these fields are present, they MUST NOT be empty. If both fields are present, they MUST contain the same value. If the scheme does not have a mandatory authority component and none is provided in the request target, the request MUST NOT contain the ":authority" pseudo-header or "Host" header fields. An HTTP request that omits mandatory pseudo-header fields or contains invalid values for those pseudo-header fields is malformed (Section 4.1.3).',36083,36994);
INSERT INTO "passages" VALUES('S3-P40',3,40,'HTTP/3 does not define a way to carry the version identifier that is included in the HTTP/1.1 request line. For responses, a single ":status" pseudo-header field is defined that carries the HTTP status code; see Section 15 of [SEMANTICS]. This pseudo-header field MUST be included in all responses; otherwise, the response is malformed (Section 4.1.3). HTTP/3 does not define a way to carry the version or reason phrase that is included in an HTTP/1.1 status line. 4.1.1.2. Field Compression HTTP/3 uses QPACK field compression as described in [QPACK], a variation of HPACK that allows the flexibility to avoid compression- induced head-of-line blocking. See that document for additional details. To allow for better compression efficiency, the "Cookie" field ([RFC6265]) MAY be split into separate field lines, each with one or more cookie-pairs, before compression.',36995,37862);
INSERT INTO "passages" VALUES('S3-P41',3,41,'If a decompressed field section contains multiple cookie field lines, these MUST be concatenated into a single octet string using the two-octet delimiter of 0x3b, 0x20 (the ASCII string "; ") before being passed into a context other than HTTP/2 or HTTP/3, such as an HTTP/1.1 connection, or a generic HTTP server application. 4.1.1.3. Header Size Constraints An HTTP/3 implementation MAY impose a limit on the maximum size of the message header it will accept on an individual HTTP message. A server that receives a larger header section than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code ([RFC6585]). A client can discard responses that it cannot process. The size of a field list is calculated based on the Bishop Expires 18 June 2021 [Page 16] Internet-Draft HTTP/3 December 2020 uncompressed size of fields, including the length of the name and value in bytes plus an overhead of 32 bytes for each field.',37863,38816);
INSERT INTO "passages" VALUES('S3-P42',3,42,'If an implementation wishes to advise its peer of this limit, it can be conveyed as a number of bytes in the SETTINGS_MAX_FIELD_SECTION_SIZE parameter. An implementation that has received this parameter SHOULD NOT send an HTTP message header that exceeds the indicated size, as the peer will likely refuse to process it. However, an HTTP message can traverse one or more intermediaries before reaching the origin server; see Section 3.6 of [SEMANTICS]. Because this limit is applied separately by each implementation which processes the message, messages below this limit are not guaranteed to be accepted. 4.1.2. Request Cancellation and Rejection Once a request stream has been opened, the request MAY be cancelled by either endpoint. Clients cancel requests if the response is no longer of interest; servers cancel requests if they are unable to or choose not to respond.',38817,39691);
INSERT INTO "passages" VALUES('S3-P43',3,43,'When possible, it is RECOMMENDED that servers send an HTTP response with an appropriate status code rather than canceling a request it has already begun processing. Implementations SHOULD cancel requests by abruptly terminating any directions of a stream that are still open. This means resetting the sending parts of streams and aborting reading on receiving parts of streams; see Section 2.4 of [QUIC-TRANSPORT]. When the server cancels a request without performing any application processing, the request is considered "rejected." The server SHOULD abort its response stream with the error code H3_REQUEST_REJECTED. In this context, "processed" means that some data from the stream was passed to some higher layer of software that might have taken some action as a result. The client can treat requests rejected by the server as though they had never been sent at all, thereby allowing them to be retried later.',39692,40606);
INSERT INTO "passages" VALUES('S3-P44',3,44,'Servers MUST NOT use the H3_REQUEST_REJECTED error code for requests that were partially or fully processed. When a server abandons a response after partial processing, it SHOULD abort its response stream with the error code H3_REQUEST_CANCELLED. Client SHOULD use the error code H3_REQUEST_CANCELLED to cancel requests. Upon receipt of this error code, a server MAY abruptly terminate the response using the error code H3_REQUEST_REJECTED if no processing was performed. Clients MUST NOT use the H3_REQUEST_REJECTED error code, except when a server has requested closure of the request stream with this error code. Bishop Expires 18 June 2021 [Page 17] Internet-Draft HTTP/3 December 2020 If a stream is canceled after receiving a complete response, the client MAY ignore the cancellation and use the response. However, if a stream is cancelled after receiving a partial response, the response SHOULD NOT be used.',40607,41521);
INSERT INTO "passages" VALUES('S3-P45',3,45,'Only idempotent actions such as GET, PUT, or DELETE can be safely retried; a client SHOULD NOT automatically retry a request with a non-idempotent method unless it has some means to know that the request semantics are idempotent independent of the method or some means to detect that the original request was never applied. See Section 9.2.2 of [SEMANTICS] for more details. 4.1.3. Malformed Requests and Responses A malformed request or response is one that is an otherwise valid sequence of frames but is invalid due to: * the presence of prohibited fields or pseudo-header fields, * the absence of mandatory pseudo-header fields, * invalid values for pseudo-header fields, * pseudo-header fields after fields, * an invalid sequence of HTTP messages, * the inclusion of uppercase field names, or * the inclusion of invalid characters in field names or values. A request or response that includes payload data can include a Content-Length header field.',41522,42475);
INSERT INTO "passages" VALUES('S3-P46',3,46,'A request or response is also malformed if the value of a Content-Length header field does not equal the sum of the DATA frame lengths that form the payload data. A response that is defined to have no payload, as described in Section 6.4 of [SEMANTICS], can have a non-zero Content-Length field, even though no content is included in DATA frames. Intermediaries that process HTTP requests or responses (i.e., any intermediary not acting as a tunnel) MUST NOT forward a malformed request or response. Malformed requests or responses that are detected MUST be treated as a stream error (Section 8) of type H3_MESSAGE_ERROR. Bishop Expires 18 June 2021 [Page 18] Internet-Draft HTTP/3 December 2020 For malformed requests, a server MAY send an HTTP response indicating the error prior to closing or resetting the stream. Clients MUST NOT accept a malformed response.',42476,43339);
INSERT INTO "passages" VALUES('S3-P47',3,47,'Note that these requirements are intended to protect against several types of common attacks against HTTP; they are deliberately strict because being permissive can expose implementations to these vulnerabilities. 4.2. The CONNECT Method The CONNECT method requests that the recipient establish a tunnel to the destination origin server identified by the request-target; see Section 9.3.6 of [SEMANTICS]. It is primarily used with HTTP proxies to establish a TLS session with an origin server for the purposes of interacting with "https" resources. In HTTP/1.x, CONNECT is used to convert an entire HTTP connection into a tunnel to a remote host. In HTTP/2 and HTTP/3, the CONNECT method is used to establish a tunnel over a single stream.',43340,44079);
INSERT INTO "passages" VALUES('S3-P48',3,48,'A CONNECT request MUST be constructed as follows: * The ":method" pseudo-header field is set to "CONNECT" * The ":scheme" and ":path" pseudo-header fields are omitted * The ":authority" pseudo-header field contains the host and port to connect to (equivalent to the authority-form of the request-target of CONNECT requests; see Section 3.2.3 of [HTTP11]) The request stream remains open at the end of the request to carry the data to be transferred. A CONNECT request that does not conform to these restrictions is malformed; see Section 4.1.3. A proxy that supports CONNECT establishes a TCP connection ([RFC0793]) to the server identified in the ":authority" pseudo- header field. Once this connection is successfully established, the proxy sends a HEADERS frame containing a 2xx series status code to the client, as defined in Section 15.3 of [SEMANTICS]. All DATA frames on the stream correspond to data sent or received on the TCP connection.',44080,45027);
INSERT INTO "passages" VALUES('S3-P49',3,49,'The payload of any DATA frame sent by the client is transmitted by the proxy to the TCP server; data received from the TCP server is packaged into DATA frames by the proxy. Note that the size and number of TCP segments is not guaranteed to map predictably to the size and number of HTTP DATA or QUIC STREAM frames. Bishop Expires 18 June 2021 [Page 19] Internet-Draft HTTP/3 December 2020 Once the CONNECT method has completed, only DATA frames are permitted to be sent on the stream. Extension frames MAY be used if specifically permitted by the definition of the extension. Receipt of any other known frame type MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. The TCP connection can be closed by either peer. When the client ends the request stream (that is, the receive stream at the proxy enters the "Data Recvd" state), the proxy will set the FIN bit on its connection to the TCP server.',45028,45954);
INSERT INTO "passages" VALUES('S3-P50',3,50,'When the proxy receives a packet with the FIN bit set, it will close the send stream that it sends to the client. TCP connections that remain half-closed in a single direction are not invalid, but are often handled poorly by servers, so clients SHOULD NOT close a stream for sending while they still expect to receive data from the target of the CONNECT. A TCP connection error is signaled by abruptly terminating the stream. A proxy treats any error in the TCP connection, which includes receiving a TCP segment with the RST bit set, as a stream error of type H3_CONNECT_ERROR; see Section 8. Correspondingly, if a proxy detects an error with the stream or the QUIC connection, it MUST close the TCP connection. If the underlying TCP implementation permits it, the proxy SHOULD send a TCP segment with the RST bit set. 4.3.',45955,46779);
INSERT INTO "passages" VALUES('S3-P51',3,51,'HTTP Upgrade HTTP/3 does not support the HTTP Upgrade mechanism (Section 7.8 of [SEMANTICS]) or 101 (Switching Protocols) informational status code (Section 15.2.2 of [SEMANTICS]). 4.4. Server Push Server push is an interaction mode that permits a server to push a request-response exchange to a client in anticipation of the client making the indicated request. This trades off network usage against a potential latency gain. HTTP/3 server push is similar to what is described in Section 8.2 of [HTTP2], but uses different mechanisms. Each server push is assigned a unique Push ID by the server. The Push ID is used to refer to the push in various contexts throughout the lifetime of the HTTP/3 connection. The Push ID space begins at zero, and ends at a maximum value set by the MAX_PUSH_ID frame; see Section 7.2.7. In particular, a server is not able to push until after the client sends a MAX_PUSH_ID frame.',46780,47692);
INSERT INTO "passages" VALUES('S3-P52',3,52,'A client sends MAX_PUSH_ID frames to control the number of pushes that a server can promise. A server SHOULD use Push IDs sequentially, beginning from zero. A client MUST treat receipt of a push stream as Bishop Expires 18 June 2021 [Page 20] Internet-Draft HTTP/3 December 2020 a connection error of type H3_ID_ERROR (Section 8) when no MAX_PUSH_ID frame has been sent or when the stream references a Push ID that is greater than the maximum Push ID. The Push ID is used in one or more PUSH_PROMISE frames (Section 7.2.5) that carry the header section of the request message. These frames are sent on the request stream that generated the push. This allows the server push to be associated with a client request. When the same Push ID is promised on multiple request streams, the decompressed request field sections MUST contain the same fields in the same order, and both the name and the value in each field MUST be identical.',47693,48622);
INSERT INTO "passages" VALUES('S3-P53',3,53,'The Push ID is then included with the push stream that ultimately fulfills those promises; see Section 6.2.2. The push stream identifies the Push ID of the promise that it fulfills, then contains a response to the promised request as described in Section 4.1. Finally, the Push ID can be used in CANCEL_PUSH frames; see Section 7.2.3. Clients use this frame to indicate they do not wish to receive a promised resource. Servers use this frame to indicate they will not be fulfilling a previous promise. Not all requests can be pushed. A server MAY push requests that have the following properties: * cacheable; see Section 9.2.3 of [SEMANTICS] * safe; see Section 9.2.1 of [SEMANTICS] * does not include a request body or trailer section The server MUST include a value in the ":authority" pseudo-header field for which the server is authoritative; see Section 3.3.',48623,49487);
INSERT INTO "passages" VALUES('S3-P54',3,54,'Clients SHOULD send a CANCEL_PUSH frame upon receipt of a PUSH_PROMISE frame carrying a request that is not cacheable, is not known to be safe, that indicates the presence of a request body, or for which it does not consider the server authoritative. Any corresponding responses MUST NOT be used or cached. Each pushed response is associated with one or more client requests. The push is associated with the request stream on which the PUSH_PROMISE frame was received. The same server push can be associated with additional client requests using a PUSH_PROMISE frame with the same Push ID on multiple request streams. These associations do not affect the operation of the protocol, but MAY be considered by user agents when deciding how to use pushed resources. Bishop Expires 18 June 2021 [Page 21] Internet-Draft HTTP/3 December 2020 Ordering of a PUSH_PROMISE frame in relation to certain parts of the response is important.',49488,50415);
INSERT INTO "passages" VALUES('S3-P55',3,55,'The server SHOULD send PUSH_PROMISE frames prior to sending HEADERS or DATA frames that reference the promised responses. This reduces the chance that a client requests a resource that will be pushed by the server. Due to reordering, push stream data can arrive before the corresponding PUSH_PROMISE frame. When a client receives a new push stream with an as-yet-unknown Push ID, both the associated client request and the pushed request header fields are unknown. The client can buffer the stream data in expectation of the matching PUSH_PROMISE. The client can use stream flow control (see section 4.1 of [QUIC-TRANSPORT]) to limit the amount of data a server may commit to the pushed stream. Push stream data can also arrive after a client has canceled a push. In this case, the client can abort reading the stream with an error code of H3_REQUEST_CANCELLED. This asks the server not to transfer additional data and indicates that it will be discarded upon receipt.',50416,51384);
INSERT INTO "passages" VALUES('S3-P56',3,56,'Pushed responses that are cacheable (see Section 3 of [CACHING]) can be stored by the client, if it implements an HTTP cache. Pushed responses are considered successfully validated on the origin server (e.g., if the "no-cache" cache response directive is present; see Section 5.2.2.3 of [CACHING]) at the time the pushed response is received. Pushed responses that are not cacheable MUST NOT be stored by any HTTP cache. They MAY be made available to the application separately. 5. Connection Closure Once established, an HTTP/3 connection can be used for many requests and responses over time until the connection is closed. Connection closure can happen in any of several different ways. 5.1. Idle Connections Each QUIC endpoint declares an idle timeout during the handshake. If the QUIC connection remains idle (no packets received) for longer than this duration, the peer will assume that the connection has been closed.',51385,52309);
INSERT INTO "passages" VALUES('S3-P57',3,57,'HTTP/3 implementations will need to open a new HTTP/3 connection for new requests if the existing connection has been idle for longer than the idle timeout negotiated during the QUIC handshake, and SHOULD do so if approaching the idle timeout; see Section 10.1 of [QUIC-TRANSPORT]. Bishop Expires 18 June 2021 [Page 22] Internet-Draft HTTP/3 December 2020 HTTP clients are expected to request that the transport keep connections open while there are responses outstanding for requests or server pushes, as described in Section 10.1.2 of [QUIC-TRANSPORT]. If the client is not expecting a response from the server, allowing an idle connection to time out is preferred over expending effort maintaining a connection that might not be needed. A gateway MAY maintain connections in anticipation of need rather than incur the latency cost of connection establishment to servers. Servers SHOULD NOT actively keep connections open. 5.2.',52310,53239);
INSERT INTO "passages" VALUES('S3-P58',3,58,'Connection Shutdown Even when a connection is not idle, either endpoint can decide to stop using the connection and initiate a graceful connection close. Endpoints initiate the graceful shutdown of an HTTP/3 connection by sending a GOAWAY frame (Section 7.2.6). The GOAWAY frame contains an identifier that indicates to the receiver the range of requests or pushes that were or might be processed in this connection. The server sends a client-initiated bidirectional Stream ID; the client sends a Push ID (Section 4.4). Requests or pushes with the indicated identifier or greater are rejected (Section 4.1.2) by the sender of the GOAWAY. This identifier MAY be zero if no requests or pushes were processed. The information in the GOAWAY frame enables a client and server to agree on which requests or pushes were accepted prior to the shutdown of the HTTP/3 connection.',53240,54109);
INSERT INTO "passages" VALUES('S3-P59',3,59,'Upon sending a GOAWAY frame, the endpoint SHOULD explicitly cancel (see Section 4.1.2 and Section 7.2.3) any requests or pushes that have identifiers greater than or equal to that indicated, in order to clean up transport state for the affected streams. The endpoint SHOULD continue to do so as more requests or pushes arrive. Endpoints MUST NOT initiate new requests or promise new pushes on the connection after receipt of a GOAWAY frame from the peer. Clients MAY establish a new connection to send additional requests. Some requests or pushes might already be in transit: * Upon receipt of a GOAWAY frame, if the client has already sent requests with a Stream ID greater than or equal to the identifier contained in the GOAWAY frame, those requests will not be processed. Clients can safely retry unprocessed requests on a different HTTP connection. A client that is unable to retry requests loses all requests that are in flight when the server closes the connection.',54110,55082);
INSERT INTO "passages" VALUES('S3-P60',3,60,'Bishop Expires 18 June 2021 [Page 23] Internet-Draft HTTP/3 December 2020 Requests on Stream IDs less than the Stream ID in a GOAWAY frame from the server might have been processed; their status cannot be known until a response is received, the stream is reset individually, another GOAWAY is received, or the connection terminates. Servers MAY reject individual requests on streams below the indicated ID if these requests were not processed. * If a server receives a GOAWAY frame after having promised pushes with a Push ID greater than or equal to the identifier contained in the GOAWAY frame, those pushes will not be accepted. Servers SHOULD send a GOAWAY frame when the closing of a connection is known in advance, even if the advance notice is small, so that the remote peer can know whether a request has been partially processed or not.',55083,55928);
INSERT INTO "passages" VALUES('S3-P61',3,61,'For example, if an HTTP client sends a POST at the same time that a server closes a QUIC connection, the client cannot know if the server started to process that POST request if the server does not send a GOAWAY frame to indicate what streams it might have acted on. An endpoint MAY send multiple GOAWAY frames indicating different identifiers, but the identifier in each frame MUST NOT be greater than the identifier in any previous frame, since clients might already have retried unprocessed requests on another HTTP connection. Receiving a GOAWAY containing a larger identifier than previously received MUST be treated as a connection error of type H3_ID_ERROR; see Section 8. An endpoint that is attempting to gracefully shut down a connection can send a GOAWAY frame with a value set to the maximum possible value (2^62-4 for servers, 2^62-1 for clients). This ensures that the peer stops creating new requests or pushes.',55929,56855);
INSERT INTO "passages" VALUES('S3-P62',3,62,'After allowing time for any in-flight requests or pushes to arrive, the endpoint can send another GOAWAY frame indicating which requests or pushes it might accept before the end of the connection. This ensures that a connection can be cleanly shut down without losing requests. A client has more flexibility in the value it chooses for the Push ID in a GOAWAY that it sends. A value of 2^62 - 1 indicates that the server can continue fulfilling pushes that have already been promised. A smaller value indicates the client will reject pushes with Push IDs greater than or equal to this value. Like the server, the client MAY send subsequent GOAWAY frames so long as the specified Push ID is no greater than any previously sent value. Bishop Expires 18 June 2021 [Page 24] Internet-Draft HTTP/3 December 2020 Even when a GOAWAY indicates that a given request or push will not be processed or accepted upon receipt, the underlying transport resources still exist.',56856,57816);
INSERT INTO "passages" VALUES('S3-P63',3,63,'The endpoint that initiated these requests can cancel them to clean up transport state. Once all accepted requests and pushes have been processed, the endpoint can permit the connection to become idle, or MAY initiate an immediate closure of the connection. An endpoint that completes a graceful shutdown SHOULD use the H3_NO_ERROR error code when closing the connection. If a client has consumed all available bidirectional stream IDs with requests, the server need not send a GOAWAY frame, since the client is unable to make further requests. 5.3. Immediate Application Closure An HTTP/3 implementation can immediately close the QUIC connection at any time. This results in sending a QUIC CONNECTION_CLOSE frame to the peer indicating that the application layer has terminated the connection. The application error code in this frame indicates to the peer why the connection is being closed. See Section 8 for error codes that can be used when closing a connection in HTTP/3.',57817,58794);
INSERT INTO "passages" VALUES('S3-P64',3,64,'Before closing the connection, a GOAWAY frame MAY be sent to allow the client to retry some requests. Including the GOAWAY frame in the same packet as the QUIC CONNECTION_CLOSE frame improves the chances of the frame being received by clients. 5.4. Transport Closure For various reasons, the QUIC transport could indicate to the application layer that the connection has terminated. This might be due to an explicit closure by the peer, a transport-level error, or a change in network topology that interrupts connectivity. If a connection terminates without a GOAWAY frame, clients MUST assume that any request that was sent, whether in whole or in part, might have been processed. 6. Stream Mapping and Usage A QUIC stream provides reliable in-order delivery of bytes, but makes no guarantees about order of delivery with regard to bytes on other streams. On the wire, data is framed into QUIC STREAM frames, but this framing is invisible to the HTTP framing layer.',58795,59762);
INSERT INTO "passages" VALUES('S3-P65',3,65,'The transport layer buffers and orders received QUIC STREAM frames, exposing the data contained within as a reliable byte stream to the application. Bishop Expires 18 June 2021 [Page 25] Internet-Draft HTTP/3 December 2020 Although QUIC permits out-of-order delivery within a stream, HTTP/3 does not make use of this feature. QUIC streams can be either unidirectional, carrying data only from initiator to receiver, or bidirectional. Streams can be initiated by either the client or the server. For more detail on QUIC streams, see Section 2 of [QUIC-TRANSPORT]. When HTTP fields and data are sent over QUIC, the QUIC layer handles most of the stream management. HTTP does not need to do any separate multiplexing when using QUIC - data sent over a QUIC stream always maps to a particular HTTP transaction or to the entire HTTP/3 connection context. 6.1. Bidirectional Streams All client-initiated bidirectional streams are used for HTTP requests and responses.',59763,60724);
INSERT INTO "passages" VALUES('S3-P66',3,66,'A bidirectional stream ensures that the response can be readily correlated with the request. These streams are referred to as request streams. This means that the client''s first request occurs on QUIC stream 0, with subsequent requests on stream 4, 8, and so on. In order to permit these streams to open, an HTTP/3 server SHOULD configure non- zero minimum values for the number of permitted streams and the initial stream flow control window. So as to not unnecessarily limit parallelism, at least 100 requests SHOULD be permitted at a time. HTTP/3 does not use server-initiated bidirectional streams, though an extension could define a use for these streams. Clients MUST treat receipt of a server-initiated bidirectional stream as a connection error of type H3_STREAM_CREATION_ERROR (Section 8) unless such an extension has been negotiated. 6.2. Unidirectional Streams Unidirectional streams, in either direction, are used for a range of purposes.',60725,61675);
INSERT INTO "passages" VALUES('S3-P67',3,67,'The purpose is indicated by a stream type, which is sent as a variable-length integer at the start of the stream. The format and structure of data that follows this integer is determined by the stream type. Unidirectional Stream Header { Stream Type (i), } Figure 1: Unidirectional Stream Header Bishop Expires 18 June 2021 [Page 26] Internet-Draft HTTP/3 December 2020 Two stream types are defined in this document: control streams (Section 6.2.1) and push streams (Section 6.2.2). [QPACK] defines two additional stream types. Other stream types can be defined by extensions to HTTP/3; see Section 9 for more details. Some stream types are reserved (Section 6.2.3). The performance of HTTP/3 connections in the early phase of their lifetime is sensitive to the creation and exchange of data on unidirectional streams.',61676,62494);
INSERT INTO "passages" VALUES('S3-P68',3,68,'Endpoints that excessively restrict the number of streams or the flow control window of these streams will increase the chance that the remote peer reaches the limit early and becomes blocked. In particular, implementations should consider that remote peers may wish to exercise reserved stream behavior (Section 6.2.3) with some of the unidirectional streams they are permitted to use. To avoid blocking, the transport parameters sent by both clients and servers MUST allow the peer to create at least one unidirectional stream for the HTTP control stream plus the number of unidirectional streams required by mandatory extensions (three being the minimum number required for the base HTTP/3 protocol and QPACK), and SHOULD provide at least 1,024 bytes of flow control credit to each stream. Note that an endpoint is not required to grant additional credits to create more unidirectional streams if its peer consumes all the initial credits before creating the critical unidirectional streams.',62495,63489);
INSERT INTO "passages" VALUES('S3-P69',3,69,'Endpoints SHOULD create the HTTP control stream as well as the unidirectional streams required by mandatory extensions (such as the QPACK encoder and decoder streams) first, and then create additional streams as allowed by their peer. If the stream header indicates a stream type that is not supported by the recipient, the remainder of the stream cannot be consumed as the semantics are unknown. Recipients of unknown stream types MAY abort reading of the stream with an error code of H3_STREAM_CREATION_ERROR or a reserved error code (Section 8.1), but MUST NOT consider such streams to be a connection error of any kind. Implementations MAY send stream types before knowing whether the peer supports them. However, stream types that could modify the state or semantics of existing protocol components, including QPACK or other extensions, MUST NOT be sent until the peer is known to support them. A sender can close or reset a unidirectional stream unless otherwise specified.',63490,64469);
INSERT INTO "passages" VALUES('S3-P70',3,70,'A receiver MUST tolerate unidirectional streams being closed or reset prior to the reception of the unidirectional stream header. Bishop Expires 18 June 2021 [Page 27] Internet-Draft HTTP/3 December 2020 6.2.1. Control Streams A control stream is indicated by a stream type of 0x00. Data on this stream consists of HTTP/3 frames, as defined in Section 7.2. Each side MUST initiate a single control stream at the beginning of the connection and send its SETTINGS frame as the first frame on this stream. If the first frame of the control stream is any other frame type, this MUST be treated as a connection error of type H3_MISSING_SETTINGS. Only one control stream per peer is permitted; receipt of a second stream claiming to be a control stream MUST be treated as a connection error of type H3_STREAM_CREATION_ERROR. The sender MUST NOT close the control stream, and the receiver MUST NOT request that the sender close the control stream.',64470,65410);
INSERT INTO "passages" VALUES('S3-P71',3,71,'If either control stream is closed at any point, this MUST be treated as a connection error of type H3_CLOSED_CRITICAL_STREAM. Connection errors are described in Section 8. A pair of unidirectional streams is used rather than a single bidirectional stream. This allows either peer to send data as soon as it is able. Depending on whether 0-RTT is enabled on the QUIC connection, either client or server might be able to send stream data first after the cryptographic handshake completes. 6.2.2. Push Streams Server push is an optional feature introduced in HTTP/2 that allows a server to initiate a response before a request has been made. See Section 4.4 for more details. A push stream is indicated by a stream type of 0x01, followed by the Push ID of the promise that it fulfills, encoded as a variable-length integer.',65411,66232);
INSERT INTO "passages" VALUES('S3-P72',3,72,'The remaining data on this stream consists of HTTP/3 frames, as defined in Section 7.2, and fulfills a promised server push by zero or more interim HTTP responses followed by a single final HTTP response, as defined in Section 4.1. Server push and Push IDs are described in Section 4.4. Only servers can push; if a server receives a client-initiated push stream, this MUST be treated as a connection error of type H3_STREAM_CREATION_ERROR; see Section 8. Push Stream Header { Stream Type (i) = 0x01, Push ID (i), } Figure 2: Push Stream Header Bishop Expires 18 June 2021 [Page 28] Internet-Draft HTTP/3 December 2020 Each Push ID MUST only be used once in a push stream header. If a push stream header includes a Push ID that was used in another push stream header, the client MUST treat this as a connection error of type H3_ID_ERROR; see Section 8. 6.2.3.',66233,67091);
INSERT INTO "passages" VALUES('S3-P73',3,73,'Reserved Stream Types Stream types of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown types be ignored. These streams have no semantics, and can be sent when application-layer padding is desired. They MAY also be sent on connections where no data is currently being transferred. Endpoints MUST NOT consider these streams to have any meaning upon receipt. The payload and length of the stream are selected in any manner the sending implementation chooses. When sending a reserved stream type, the implementation MAY either terminate the stream cleanly or reset it. When resetting the stream, either the H3_NO_ERROR error code or a reserved error code (Section 8.1) SHOULD be used. 7. HTTP Framing Layer HTTP frames are carried on QUIC streams, as described in Section 6. HTTP/3 defines three stream types: control stream, request stream, and push stream.',67092,68017);
INSERT INTO "passages" VALUES('S3-P74',3,74,'This section describes HTTP/3 frame formats and their permitted stream types; see Table 1 for an overview. A comparison between HTTP/2 and HTTP/3 frames is provided in Appendix A.2.',68018,68199);
INSERT INTO "passages" VALUES('S3-P75',3,75,'Bishop Expires 18 June 2021 [Page 29] Internet-Draft HTTP/3 December 2020 +==============+================+================+========+=========+ | Frame | Control Stream | Request | Push | Section | | | | Stream | Stream | | +==============+================+================+========+=========+ | DATA | No | Yes | Yes | Section | | | | | | 7.2.1 | +--------------+----------------+----------------+--------+---------+ | HEADERS | No | Yes | Yes | Section | | | | | | 7.2.2 | +--------------+----------------+----------------+--------+---------+ | CANCEL_PUSH | Yes | No | No | Section | | | | | | 7.2.3 | +--------------+----------------+----------------+--------+---------+ | SETTINGS | Yes (1) | No | No | Section | | | | | | 7.2.4 | +--------------+----------------+----------------+--------+---------+ | PUSH_PROMISE | No | Yes | No | Section | | | | | | 7.2.5 | +--------------+----------------+----------------+--------+---------+ | GOAWAY | Yes | No | No | Section | | | | | | 7.2.6 | +--------------+----------------+----------------+--------+---------+ | MAX_PUSH_ID | Yes | No | No | Section | | | | | | 7.2.7 | +--------------+----------------+----------------+--------+---------+ | Reserved | Yes | Yes | Yes | Section | | | | | | 7.2.8 | +--------------+----------------+----------------+--------+---------+ Table 1: HTTP/3 Frames and Stream Type Overview Certain frames can only occur as the first frame of a particular stream type; these are indicated in Table 1 with a (1).',68200,69689);
INSERT INTO "passages" VALUES('S3-P76',3,76,'Specific guidance is provided in the relevant section. Note that, unlike QUIC frames, HTTP/3 frames can span multiple packets. 7.1. Frame Layout All frames have the following format: HTTP/3 Frame Format { Type (i), Length (i), Frame Payload (..), } Bishop Expires 18 June 2021 [Page 30] Internet-Draft HTTP/3 December 2020 Figure 3: HTTP/3 Frame Format A frame includes the following fields: Type: A variable-length integer that identifies the frame type. Length: A variable-length integer that describes the length in bytes of the Frame Payload. Frame Payload: A payload, the semantics of which are determined by the Type field. Each frame''s payload MUST contain exactly the fields identified in its description. A frame payload that contains additional bytes after the identified fields or a frame payload that terminates before the end of the identified fields MUST be treated as a connection error of type H3_FRAME_ERROR; see Section 8.',69690,70630);
INSERT INTO "passages" VALUES('S3-P77',3,77,'When a stream terminates cleanly, if the last frame on the stream was truncated, this MUST be treated as a connection error of type H3_FRAME_ERROR; see Section 8. Streams that terminate abruptly may be reset at any point in a frame. 7.2. Frame Definitions 7.2.1. DATA DATA frames (type=0x0) convey arbitrary, variable-length sequences of bytes associated with HTTP request or response payload data. DATA frames MUST be associated with an HTTP request or response. If a DATA frame is received on a control stream, the recipient MUST respond with a connection error of type H3_FRAME_UNEXPECTED; see Section 8. DATA Frame { Type (i) = 0x0, Length (i), Data (..), } Figure 4: DATA Frame 7.2.2. HEADERS The HEADERS frame (type=0x1) is used to carry an HTTP field section, encoded using QPACK. See [QPACK] for more details.',70631,71448);
INSERT INTO "passages" VALUES('S3-P78',3,78,'Bishop Expires 18 June 2021 [Page 31] Internet-Draft HTTP/3 December 2020 HEADERS Frame { Type (i) = 0x1, Length (i), Encoded Field Section (..), } Figure 5: HEADERS Frame HEADERS frames can only be sent on request or push streams. If a HEADERS frame is received on a control stream, the recipient MUST respond with a connection error (Section 8) of type H3_FRAME_UNEXPECTED. 7.2.3. CANCEL_PUSH The CANCEL_PUSH frame (type=0x3) is used to request cancellation of a server push prior to the push stream being received. The CANCEL_PUSH frame identifies a server push by Push ID (see Section 4.4), encoded as a variable-length integer. When a client sends CANCEL_PUSH, it is indicating that it does not wish to receive the promised resource. The server SHOULD abort sending the resource, but the mechanism to do so depends on the state of the corresponding push stream. If the server has not yet created a push stream, it does not create one.',71449,72388);
INSERT INTO "passages" VALUES('S3-P79',3,79,'If the push stream is open, the server SHOULD abruptly terminate that stream. If the push stream has already ended, the server MAY still abruptly terminate the stream or MAY take no action. A server sends CANCEL_PUSH to indicate that it will not be fulfilling a promise which was previously sent. The client cannot expect the corresponding promise to be fulfilled, unless it has already received and processed the promised response. Regardless of whether a push stream has been opened, a server SHOULD send a CANCEL_PUSH frame when it determines that promise will not be fulfilled. If a stream has already been opened, the server can abort sending on the stream with an error code of H3_REQUEST_CANCELLED. Sending a CANCEL_PUSH frame has no direct effect on the state of existing push streams. A client SHOULD NOT send a CANCEL_PUSH frame when it has already received a corresponding push stream.',72389,73285);
INSERT INTO "passages" VALUES('S3-P80',3,80,'A push stream could arrive after a client has sent a CANCEL_PUSH frame, because a server might not have processed the CANCEL_PUSH. The client SHOULD abort reading the stream with an error code of H3_REQUEST_CANCELLED. Bishop Expires 18 June 2021 [Page 32] Internet-Draft HTTP/3 December 2020 A CANCEL_PUSH frame is sent on the control stream. Receiving a CANCEL_PUSH frame on a stream other than the control stream MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. CANCEL_PUSH Frame { Type (i) = 0x3, Length (i), Push ID (..), } Figure 6: CANCEL_PUSH Frame The CANCEL_PUSH frame carries a Push ID encoded as a variable-length integer. The Push ID identifies the server push that is being cancelled; see Section 4.4. If a CANCEL_PUSH frame is received that references a Push ID greater than currently allowed on the connection, this MUST be treated as a connection error of type H3_ID_ERROR.',73286,74193);
INSERT INTO "passages" VALUES('S3-P81',3,81,'If the client receives a CANCEL_PUSH frame, that frame might identify a Push ID that has not yet been mentioned by a PUSH_PROMISE frame due to reordering. If a server receives a CANCEL_PUSH frame for a Push ID that has not yet been mentioned by a PUSH_PROMISE frame, this MUST be treated as a connection error of type H3_ID_ERROR. 7.2.4. SETTINGS The SETTINGS frame (type=0x4) conveys configuration parameters that affect how endpoints communicate, such as preferences and constraints on peer behavior. Individually, a SETTINGS parameter can also be referred to as a "setting"; the identifier and value of each setting parameter can be referred to as a "setting identifier" and a "setting value". SETTINGS frames always apply to an entire HTTP/3 connection, never a single stream. A SETTINGS frame MUST be sent as the first frame of each control stream (see Section 6.2.1) by each peer, and MUST NOT be sent subsequently.',74194,75115);
INSERT INTO "passages" VALUES('S3-P82',3,82,'If an endpoint receives a second SETTINGS frame on the control stream, the endpoint MUST respond with a connection error of type H3_FRAME_UNEXPECTED. SETTINGS frames MUST NOT be sent on any stream other than the control stream. If an endpoint receives a SETTINGS frame on a different stream, the endpoint MUST respond with a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 33] Internet-Draft HTTP/3 December 2020 SETTINGS parameters are not negotiated; they describe characteristics of the sending peer that can be used by the receiving peer. However, a negotiation can be implied by the use of SETTINGS - each peer uses SETTINGS to advertise a set of supported values. The definition of the setting would describe how each peer combines the two sets to conclude which choice will be used. SETTINGS does not provide a mechanism to identify when the choice takes effect. Different values for the same parameter can be advertised by each peer.',75116,76089);
INSERT INTO "passages" VALUES('S3-P83',3,83,'For example, a client might be willing to consume a very large response field section, while servers are more cautious about request size. The same setting identifier MUST NOT occur more than once in the SETTINGS frame. A receiver MAY treat the presence of duplicate setting identifiers as a connection error of type H3_SETTINGS_ERROR. The payload of a SETTINGS frame consists of zero or more parameters. Each parameter consists of a setting identifier and a value, both encoded as QUIC variable-length integers. Setting { Identifier (i), Value (i), } SETTINGS Frame { Type (i) = 0x4, Length (i), Setting (..) ..., } Figure 7: SETTINGS Frame An implementation MUST ignore the contents for any SETTINGS identifier it does not understand. 7.2.4.1. Defined SETTINGS Parameters The following settings are defined in HTTP/3: SETTINGS_MAX_FIELD_SECTION_SIZE (0x6): The default value is unlimited. See Section 4.1.1.3 for usage.',76090,77011);
INSERT INTO "passages" VALUES('S3-P84',3,84,'Bishop Expires 18 June 2021 [Page 34] Internet-Draft HTTP/3 December 2020 Setting identifiers of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown identifiers be ignored. Such settings have no defined meaning. Endpoints SHOULD include at least one such setting in their SETTINGS frame. Endpoints MUST NOT consider such settings to have any meaning upon receipt. Because the setting has no defined meaning, the value of the setting can be any value the implementation selects. Setting identifiers which were used in HTTP/2 where there is no corresponding HTTP/3 setting have also been reserved (Section 11.2.2). These settings MUST NOT be sent, and their receipt MUST be treated as a connection error of type H3_SETTINGS_ERROR. Additional settings can be defined by extensions to HTTP/3; see Section 9 for more details. 7.2.4.2.',77012,77909);
INSERT INTO "passages" VALUES('S3-P85',3,85,'Initialization An HTTP implementation MUST NOT send frames or requests that would be invalid based on its current understanding of the peer''s settings. All settings begin at an initial value. Each endpoint SHOULD use these initial values to send messages before the peer''s SETTINGS frame has arrived, as packets carrying the settings can be lost or delayed. When the SETTINGS frame arrives, any settings are changed to their new values. This removes the need to wait for the SETTINGS frame before sending messages. Endpoints MUST NOT require any data to be received from the peer prior to sending the SETTINGS frame; settings MUST be sent as soon as the transport is ready to send data. For servers, the initial value of each client setting is the default value. For clients using a 1-RTT QUIC connection, the initial value of each server setting is the default value.',77910,78778);
INSERT INTO "passages" VALUES('S3-P86',3,86,'1-RTT keys will always become available prior to the packet containing SETTINGS being processed by QUIC, even if the server sends SETTINGS immediately. Clients SHOULD NOT wait indefinitely for SETTINGS to arrive before sending requests, but SHOULD process received datagrams in order to increase the likelihood of processing SETTINGS before sending the first request. When a 0-RTT QUIC connection is being used, the initial value of each server setting is the value used in the previous session. Clients SHOULD store the settings the server provided in the HTTP/3 Bishop Expires 18 June 2021 [Page 35] Internet-Draft HTTP/3 December 2020 connection where resumption information was provided, but MAY opt not to store settings in certain cases (e.g., if the session ticket is received before the SETTINGS frame). A client MUST comply with stored settings - or default values, if no values are stored - when attempting 0-RTT.',78779,79702);
INSERT INTO "passages" VALUES('S3-P87',3,87,'Once a server has provided new settings, clients MUST comply with those values. A server can remember the settings that it advertised, or store an integrity-protected copy of the values in the ticket and recover the information when accepting 0-RTT data. A server uses the HTTP/3 settings values in determining whether to accept 0-RTT data. If the server cannot determine that the settings remembered by a client are compatible with its current settings, it MUST NOT accept 0-RTT data. Remembered settings are compatible if a client complying with those settings would not violate the server''s current settings. A server MAY accept 0-RTT and subsequently provide different settings in its SETTINGS frame. If 0-RTT data is accepted by the server, its SETTINGS frame MUST NOT reduce any limits or alter any values that might be violated by the client with its 0-RTT data. The server MUST include all settings that differ from their default values.',79703,80648);
INSERT INTO "passages" VALUES('S3-P88',3,88,'If a server accepts 0-RTT but then sends settings that are not compatible with the previously specified settings, this MUST be treated as a connection error of type H3_SETTINGS_ERROR. If a server accepts 0-RTT but then sends a SETTINGS frame that omits a setting value that the client understands (apart from reserved setting identifiers) that was previously specified to have a non-default value, this MUST be treated as a connection error of type H3_SETTINGS_ERROR. 7.2.5. PUSH_PROMISE The PUSH_PROMISE frame (type=0x5) is used to carry a promised request header field section from server to client on a request stream, as in HTTP/2. PUSH_PROMISE Frame { Type (i) = 0x5, Length (i), Push ID (i), Encoded Field Section (..), } Figure 8: PUSH_PROMISE Frame The payload consists of: Push ID: A variable-length integer that identifies the server push Bishop Expires 18 June 2021 [Page 36] Internet-Draft HTTP/3 December 2020 operation.',80649,81582);
INSERT INTO "passages" VALUES('S3-P89',3,89,'A Push ID is used in push stream headers (Section 4.4) and CANCEL_PUSH frames (Section 7.2.3). Encoded Field Section: QPACK-encoded request header fields for the promised response. See [QPACK] for more details. A server MUST NOT use a Push ID that is larger than the client has provided in a MAX_PUSH_ID frame (Section 7.2.7). A client MUST treat receipt of a PUSH_PROMISE frame that contains a larger Push ID than the client has advertised as a connection error of H3_ID_ERROR. A server MAY use the same Push ID in multiple PUSH_PROMISE frames. If so, the decompressed request header sets MUST contain the same fields in the same order, and both the name and the value in each field MUST be exact matches. Clients SHOULD compare the request header sections for resources promised multiple times. If a client receives a Push ID that has already been promised and detects a mismatch, it MUST respond with a connection error of type H3_GENERAL_PROTOCOL_ERROR.',81583,82540);
INSERT INTO "passages" VALUES('S3-P90',3,90,'If the decompressed field sections match exactly, the client SHOULD associate the pushed content with each stream on which a PUSH_PROMISE frame was received. Allowing duplicate references to the same Push ID is primarily to reduce duplication caused by concurrent requests. A server SHOULD avoid reusing a Push ID over a long period. Clients are likely to consume server push responses and not retain them for reuse over time. Clients that see a PUSH_PROMISE frame that uses a Push ID that they have already consumed and discarded are forced to ignore the promise. If a PUSH_PROMISE frame is received on the control stream, the client MUST respond with a connection error of type H3_FRAME_UNEXPECTED; see Section 8. A client MUST NOT send a PUSH_PROMISE frame. A server MUST treat the receipt of a PUSH_PROMISE frame as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. See Section 4.4 for a description of the overall server push mechanism.',82541,83495);
INSERT INTO "passages" VALUES('S3-P91',3,91,'Bishop Expires 18 June 2021 [Page 37] Internet-Draft HTTP/3 December 2020 7.2.6. GOAWAY The GOAWAY frame (type=0x7) is used to initiate graceful shutdown of an HTTP/3 connection by either endpoint. GOAWAY allows an endpoint to stop accepting new requests or pushes while still finishing processing of previously received requests and pushes. This enables administrative actions, like server maintenance. GOAWAY by itself does not close a connection. GOAWAY Frame { Type (i) = 0x7, Length (i), Stream ID/Push ID (..), } Figure 9: GOAWAY Frame The GOAWAY frame is always sent on the control stream. In the server to client direction, it carries a QUIC Stream ID for a client- initiated bidirectional stream encoded as a variable-length integer. A client MUST treat receipt of a GOAWAY frame containing a Stream ID of any other type as a connection error of type H3_ID_ERROR. In the client to server direction, the GOAWAY frame carries a Push ID encoded as a variable-length integer.',83496,84476);
INSERT INTO "passages" VALUES('S3-P92',3,92,'The GOAWAY frame applies to the entire connection, not a specific stream. A client MUST treat a GOAWAY frame on a stream other than the control stream as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. See Section 5.2 for more information on the use of the GOAWAY frame. 7.2.7. MAX_PUSH_ID The MAX_PUSH_ID frame (type=0xd) is used by clients to control the number of server pushes that the server can initiate. This sets the maximum value for a Push ID that the server can use in PUSH_PROMISE and CANCEL_PUSH frames. Consequently, this also limits the number of push streams that the server can initiate in addition to the limit maintained by the QUIC transport. The MAX_PUSH_ID frame is always sent on the control stream. Receipt of a MAX_PUSH_ID frame on any other stream MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 38] Internet-Draft HTTP/3 December 2020 A server MUST NOT send a MAX_PUSH_ID frame.',84477,85450);
INSERT INTO "passages" VALUES('S3-P93',3,93,'A client MUST treat the receipt of a MAX_PUSH_ID frame as a connection error of type H3_FRAME_UNEXPECTED. The maximum Push ID is unset when an HTTP/3 connection is created, meaning that a server cannot push until it receives a MAX_PUSH_ID frame. A client that wishes to manage the number of promised server pushes can increase the maximum Push ID by sending MAX_PUSH_ID frames as the server fulfills or cancels server pushes. MAX_PUSH_ID Frame { Type (i) = 0xd, Length (i), Push ID (i), } Figure 10: MAX_PUSH_ID Frame The MAX_PUSH_ID frame carries a single variable-length integer that identifies the maximum value for a Push ID that the server can use; see Section 4.4. A MAX_PUSH_ID frame cannot reduce the maximum Push ID; receipt of a MAX_PUSH_ID frame that contains a smaller value than previously received MUST be treated as a connection error of type H3_ID_ERROR. 7.2.8.',85451,86328);
INSERT INTO "passages" VALUES('S3-P94',3,94,'Reserved Frame Types Frame types of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown types be ignored (Section 9). These frames have no semantics, and MAY be sent on any stream where frames are allowed to be sent. This enables their use for application-layer padding. Endpoints MUST NOT consider these frames to have any meaning upon receipt. The payload and length of the frames are selected in any manner the implementation chooses. Frame types that were used in HTTP/2 where there is no corresponding HTTP/3 frame have also been reserved (Section 11.2.1). These frame types MUST NOT be sent, and their receipt MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 39] Internet-Draft HTTP/3 December 2020 8.',86329,87156);
INSERT INTO "passages" VALUES('S3-P95',3,95,'Error Handling When a stream cannot be completed successfully, QUIC allows the application to abruptly terminate (reset) that stream and communicate a reason; see Section 2.4 of [QUIC-TRANSPORT]. This is referred to as a "stream error." An HTTP/3 implementation can decide to close a QUIC stream and communicate the type of error. Wire encodings of error codes are defined in Section 8.1. Stream errors are distinct from HTTP status codes which indicate error conditions. Stream errors indicate that the sender did not transfer or consume the full request or response, while HTTP status codes indicate the result of a request that was successfully received. If an entire connection needs to be terminated, QUIC similarly provides mechanisms to communicate a reason; see Section 5.3 of [QUIC-TRANSPORT]. This is referred to as a "connection error." Similar to stream errors, an HTTP/3 implementation can terminate a QUIC connection and communicate the reason using an error code from Section 8.1.',87157,88152);
INSERT INTO "passages" VALUES('S3-P96',3,96,'Although the reasons for closing streams and connections are called "errors," these actions do not necessarily indicate a problem with the connection or either implementation. For example, a stream can be reset if the requested resource is no longer needed. An endpoint MAY choose to treat a stream error as a connection error under certain circumstances, closing the entire connection in response to a condition on a single stream. Implementations need to consider the impact on outstanding requests before making this choice. Because new error codes can be defined without negotiation (see Section 9), use of an error code in an unexpected context or receipt of an unknown error code MUST be treated as equivalent to H3_NO_ERROR. However, closing a stream can have other effects regardless of the error code; for example, see Section 4.1. 8.1.',88153,88998);
INSERT INTO "passages" VALUES('S3-P97',3,97,'HTTP/3 Error Codes The following error codes are defined for use when abruptly terminating streams, aborting reading of streams, or immediately closing HTTP/3 connections. H3_NO_ERROR (0x100): No error. This is used when the connection or stream needs to be closed, but there is no error to signal. H3_GENERAL_PROTOCOL_ERROR (0x101): Peer violated protocol Bishop Expires 18 June 2021 [Page 40] Internet-Draft HTTP/3 December 2020 requirements in a way that does not match a more specific error code, or endpoint declines to use the more specific error code. H3_INTERNAL_ERROR (0x102): An internal error has occurred in the HTTP stack. H3_STREAM_CREATION_ERROR (0x103): The endpoint detected that its peer created a stream that it will not accept. H3_CLOSED_CRITICAL_STREAM (0x104): A stream required by the HTTP/3 connection was closed or reset. H3_FRAME_UNEXPECTED (0x105): A frame was received that was not permitted in the current state or on the current stream.',88999,89965);
INSERT INTO "passages" VALUES('S3-P98',3,98,'H3_FRAME_ERROR (0x106): A frame that fails to satisfy layout requirements or with an invalid size was received. H3_EXCESSIVE_LOAD (0x107): The endpoint detected that its peer is exhibiting a behavior that might be generating excessive load. H3_ID_ERROR (0x108): A Stream ID or Push ID was used incorrectly, such as exceeding a limit, reducing a limit, or being reused. H3_SETTINGS_ERROR (0x109): An endpoint detected an error in the payload of a SETTINGS frame. H3_MISSING_SETTINGS (0x10a): No SETTINGS frame was received at the beginning of the control stream. H3_REQUEST_REJECTED (0x10b): A server rejected a request without performing any application processing. H3_REQUEST_CANCELLED (0x10c): The request or its response (including pushed response) is cancelled. H3_REQUEST_INCOMPLETE (0x10d): The client''s stream terminated without containing a fully-formed request. H3_MESSAGE_ERROR (0x10e): An HTTP message was malformed and cannot be processed.',89966,90917);
INSERT INTO "passages" VALUES('S3-P99',3,99,'H3_CONNECT_ERROR (0x10f): The TCP connection established in response to a CONNECT request was reset or abnormally closed. H3_VERSION_FALLBACK (0x110): The requested operation cannot be served over HTTP/3. The peer should retry over HTTP/1.1. Bishop Expires 18 June 2021 [Page 41] Internet-Draft HTTP/3 December 2020 Error codes of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown error codes be treated as equivalent to H3_NO_ERROR (Section 9). Implementations SHOULD select an error code from this space with some probability when they would have sent H3_NO_ERROR. 9. Extensions to HTTP/3 HTTP/3 permits extension of the protocol. Within the limitations described in this section, protocol extensions can be used to provide additional services or alter any aspect of the protocol. Extensions are effective only within the scope of a single HTTP/3 connection. This applies to the protocol elements defined in this document.',90918,91912);
INSERT INTO "passages" VALUES('S3-P100',3,100,'This does not affect the existing options for extending HTTP, such as defining new methods, status codes, or fields. Extensions are permitted to use new frame types (Section 7.2), new settings (Section 7.2.4.1), new error codes (Section 8), or new unidirectional stream types (Section 6.2). Registries are established for managing these extension points: frame types (Section 11.2.1), settings (Section 11.2.2), error codes (Section 11.2.3), and stream types (Section 11.2.4). Implementations MUST ignore unknown or unsupported values in all extensible protocol elements. Implementations MUST discard frames and unidirectional streams that have unknown or unsupported types. This means that any of these extension points can be safely used by extensions without prior arrangement or negotiation.',91913,92708);
INSERT INTO "passages" VALUES('S3-P101',3,101,'However, where a known frame type is required to be in a specific location, such as the SETTINGS frame as the first frame of the control stream (see Section 6.2.1), an unknown frame type does not satisfy that requirement and SHOULD be treated as an error. Extensions that could change the semantics of existing protocol components MUST be negotiated before being used. For example, an extension that changes the layout of the HEADERS frame cannot be used until the peer has given a positive signal that this is acceptable. Coordinating when such a revised layout comes into effect could prove complex. As such, allocating new identifiers for new definitions of existing protocol elements is likely to be more effective. Bishop Expires 18 June 2021 [Page 42] Internet-Draft HTTP/3 December 2020 This document does not mandate a specific method for negotiating the use of an extension but notes that a setting (Section 7.2.4.1) could be used for that purpose.',92709,93666);
INSERT INTO "passages" VALUES('S3-P102',3,102,'If both peers set a value that indicates willingness to use the extension, then the extension can be used. If a setting is used for extension negotiation, the default value MUST be defined in such a fashion that the extension is disabled if the setting is omitted. 10. Security Considerations The security considerations of HTTP/3 should be comparable to those of HTTP/2 with TLS. However, many of the considerations from Section 10 of [HTTP2] apply to [QUIC-TRANSPORT] and are discussed in that document. 10.1. Server Authority HTTP/3 relies on the HTTP definition of authority. The security considerations of establishing authority are discussed in Section 17.1 of [SEMANTICS]. 10.2. Cross-Protocol Attacks The use of ALPN in the TLS and QUIC handshakes establishes the target application protocol before application-layer bytes are processed. This ensures that endpoints have strong assurances that peers are using the same protocol.',93667,94603);
INSERT INTO "passages" VALUES('S3-P103',3,103,'This does not guarantee protection from all cross-protocol attacks. Section 21.5 of [QUIC-TRANSPORT] describes some ways in which the plaintext of QUIC packets can be used to perform request forgery against endpoints that don''t use authenticated transports. 10.3. Intermediary Encapsulation Attacks The HTTP/3 field encoding allows the expression of names that are not valid field names in the syntax used by HTTP (Section 5.1 of [SEMANTICS]). Requests or responses containing invalid field names MUST be treated as malformed (Section 4.1.3). An intermediary therefore cannot translate an HTTP/3 request or response containing an invalid field name into an HTTP/1.1 message. Bishop Expires 18 June 2021 [Page 43] Internet-Draft HTTP/3 December 2020 Similarly, HTTP/3 can transport field values that are not valid.',94604,95417);
INSERT INTO "passages" VALUES('S3-P104',3,104,'While most values that can be encoded will not alter field parsing, carriage return (CR, ASCII 0xd), line feed (LF, ASCII 0xa), and the zero character (NUL, ASCII 0x0) might be exploited by an attacker if they are translated verbatim. Any request or response that contains a character not permitted in a field value MUST be treated as malformed (Section 4.1.3). Valid characters are defined by the "field-content" ABNF rule in Section 5.5 of [SEMANTICS]. 10.4. Cacheability of Pushed Responses Pushed responses do not have an explicit request from the client; the request is provided by the server in the PUSH_PROMISE frame. Caching responses that are pushed is possible based on the guidance provided by the origin server in the Cache-Control header field. However, this can cause issues if a single server hosts more than one tenant. For example, a server might offer multiple users each a small portion of its URI space.',95418,96341);
INSERT INTO "passages" VALUES('S3-P105',3,105,'Where multiple tenants share space on the same server, that server MUST ensure that tenants are not able to push representations of resources that they do not have authority over. Failure to enforce this would allow a tenant to provide a representation that would be served out of cache, overriding the actual representation that the authoritative tenant provides. Clients are required to reject pushed responses for which an origin server is not authoritative; see Section 4.4. 10.5. Denial-of-Service Considerations An HTTP/3 connection can demand a greater commitment of resources to operate than an HTTP/1.1 or HTTP/2 connection. The use of field compression and flow control depend on a commitment of resources for storing a greater amount of state. Settings for these features ensure that memory commitments for these features are strictly bounded. The number of PUSH_PROMISE frames is constrained in a similar fashion.',96342,97267);
INSERT INTO "passages" VALUES('S3-P106',3,106,'A client that accepts server push SHOULD limit the number of Push IDs it issues at a time. Processing capacity cannot be guarded as effectively as state capacity. Bishop Expires 18 June 2021 [Page 44] Internet-Draft HTTP/3 December 2020 The ability to send undefined protocol elements that the peer is required to ignore can be abused to cause a peer to expend additional processing time. This might be done by setting multiple undefined SETTINGS parameters, unknown frame types, or unknown stream types. Note, however, that some uses are entirely legitimate, such as optional-to-understand extensions and padding to increase resistance to traffic analysis. Compression of field sections also offers some opportunities to waste processing resources; see Section 7 of [QPACK] for more details on potential abuses. All these features - i.e., server push, unknown protocol elements, field compression - have legitimate uses.',97268,98189);
INSERT INTO "passages" VALUES('S3-P107',3,107,'These features become a burden only when they are used unnecessarily or to excess. An endpoint that does not monitor this behavior exposes itself to a risk of denial-of-service attack. Implementations SHOULD track the use of these features and set limits on their use. An endpoint MAY treat activity that is suspicious as a connection error of type H3_EXCESSIVE_LOAD (Section 8), but false positives will result in disrupting valid connections and requests. 10.5.1. Limits on Field Section Size A large field section (Section 4.1) can cause an implementation to commit a large amount of state. Header fields that are critical for routing can appear toward the end of a header field section, which prevents streaming of the header field section to its ultimate destination. This ordering and other reasons, such as ensuring cache correctness, mean that an endpoint likely needs to buffer the entire header field section.',98190,99109);
INSERT INTO "passages" VALUES('S3-P108',3,108,'Since there is no hard limit to the size of a field section, some endpoints could be forced to commit a large amount of available memory for header fields. An endpoint can use the SETTINGS_MAX_FIELD_SECTION_SIZE (Section 4.1.1.3) setting to advise peers of limits that might apply on the size of field sections. This setting is only advisory, so endpoints MAY choose to send field sections that exceed this limit and risk having the request or response being treated as malformed. This setting is specific to an HTTP/3 connection, so any request or response could encounter a hop with a lower, unknown limit. An intermediary can attempt to avoid this problem by passing on values presented by different peers, but they are not obligated to do so. Bishop Expires 18 June 2021 [Page 45] Internet-Draft HTTP/3 December 2020 A server that receives a larger field section than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code ([RFC6585]).',99110,100085);
INSERT INTO "passages" VALUES('S3-P109',3,109,'A client can discard responses that it cannot process. 10.5.2. CONNECT Issues The CONNECT method can be used to create disproportionate load on a proxy, since stream creation is relatively inexpensive when compared to the creation and maintenance of a TCP connection. A proxy might also maintain some resources for a TCP connection beyond the closing of the stream that carries the CONNECT request, since the outgoing TCP connection remains in the TIME_WAIT state. Therefore, a proxy cannot rely on QUIC stream limits alone to control the resources consumed by CONNECT requests. 10.6. Use of Compression Compression can allow an attacker to recover secret data when it is compressed in the same context as data under attacker control. HTTP/3 enables compression of fields (Section 4.1.1); the following concerns also apply to the use of HTTP compressed content-codings; see Section 8.5.1 of [SEMANTICS].',100086,100989);
INSERT INTO "passages" VALUES('S3-P110',3,110,'There are demonstrable attacks on compression that exploit the characteristics of the web (e.g., [BREACH]). The attacker induces multiple requests containing varying plaintext, observing the length of the resulting ciphertext in each, which reveals a shorter length when a guess about the secret is correct. Implementations communicating on a secure channel MUST NOT compress content that includes both confidential and attacker-controlled data unless separate compression contexts are used for each source of data. Compression MUST NOT be used if the source of data cannot be reliably determined. Further considerations regarding the compression of fields sections are described in [QPACK]. 10.7. Padding and Traffic Analysis Padding can be used to obscure the exact size of frame content and is provided to mitigate specific attacks within HTTP, for example, attacks where compressed content includes both attacker-controlled plaintext and secret data (e.g., [BREACH]).',100990,101961);
INSERT INTO "passages" VALUES('S3-P111',3,111,'Bishop Expires 18 June 2021 [Page 46] Internet-Draft HTTP/3 December 2020 Where HTTP/2 employs PADDING frames and Padding fields in other frames to make a connection more resistant to traffic analysis, HTTP/3 can either rely on transport-layer padding or employ the reserved frame and stream types discussed in Section 7.2.8 and Section 6.2.3. These methods of padding produce different results in terms of the granularity of padding, how padding is arranged in relation to the information that is being protected, whether padding is applied in the case of packet loss, and how an implementation might control padding. Reserved stream types can be used to give the appearance of sending traffic even when the connection is idle. Because HTTP traffic often occurs in bursts, apparent traffic can be used to obscure the timing or duration of such bursts, even to the point of appearing to send a constant stream of data.',101962,102880);
INSERT INTO "passages" VALUES('S3-P112',3,112,'However, as such traffic is still flow controlled by the receiver, a failure to promptly drain such streams and provide additional flow control credit can limit the sender''s ability to send real traffic. To mitigate attacks that rely on compression, disabling or limiting compression might be preferable to padding as a countermeasure. Use of padding can result in less protection than might seem immediately obvious. Redundant padding could even be counterproductive. At best, padding only makes it more difficult for an attacker to infer length information by increasing the number of frames an attacker has to observe. Incorrectly implemented padding schemes can be easily defeated. In particular, randomized padding with a predictable distribution provides very little protection; similarly, padding payloads to a fixed size exposes information as payload sizes cross the fixed-sized boundary, which could be possible if an attacker can control plaintext. 10.8.',102881,103846);
INSERT INTO "passages" VALUES('S3-P113',3,113,'Frame Parsing Several protocol elements contain nested length elements, typically in the form of frames with an explicit length containing variable- length integers. This could pose a security risk to an incautious implementer. An implementation MUST ensure that the length of a frame exactly matches the length of the fields it contains. 10.9. Early Data The use of 0-RTT with HTTP/3 creates an exposure to replay attack. The anti-replay mitigations in [HTTP-REPLAY] MUST be applied when using HTTP/3 with 0-RTT. Bishop Expires 18 June 2021 [Page 47] Internet-Draft HTTP/3 December 2020 10.10. Migration Certain HTTP implementations use the client address for logging or access-control purposes.',103847,104543);
INSERT INTO "passages" VALUES('S3-P114',3,114,'Since a QUIC client''s address might change during a connection (and future versions might support simultaneous use of multiple addresses), such implementations will need to either actively retrieve the client''s current address or addresses when they are relevant or explicitly accept that the original address might change. 10.11. Privacy Considerations Several characteristics of HTTP/3 provide an observer an opportunity to correlate actions of a single client or server over time. These include the value of settings, the timing of reactions to stimulus, and the handling of any features that are controlled by settings. As far as these create observable differences in behavior, they could be used as a basis for fingerprinting a specific client. HTTP/3''s preference for using a single QUIC connection allows correlation of a user''s activity on a site. Reusing connections for different origins allows for correlation of activity across those origins.',104544,105499);
INSERT INTO "passages" VALUES('S3-P115',3,115,'Several features of QUIC solicit immediate responses and can be used by an endpoint to measure latency to their peer; this might have privacy implications in certain scenarios. 11. IANA Considerations This document registers a new ALPN protocol ID (Section 11.1) and creates new registries that manage the assignment of codepoints in HTTP/3. 11.1. Registration of HTTP/3 Identification String This document creates a new registration for the identification of HTTP/3 in the "Application Layer Protocol Negotiation (ALPN) Protocol IDs" registry established in [RFC7301]. The "h3" string identifies HTTP/3: Protocol: HTTP/3 Identification Sequence: 0x68 0x33 ("h3") Specification: This document Bishop Expires 18 June 2021 [Page 48] Internet-Draft HTTP/3 December 2020 11.2. New Registries New registries created in this document operate under the QUIC registration policy documented in Section 22.1 of [QUIC-TRANSPORT].',105500,106418);
INSERT INTO "passages" VALUES('S3-P116',3,116,'These registries all include the common set of fields listed in Section 22.1.1 of [QUIC-TRANSPORT]. These registries [SHALL be/are] collected under a "Hypertext Transfer Protocol version 3 (HTTP/3) Parameters" heading. The initial allocations in these registries created in this document are all assigned permanent status and list a change controller of the IETF and a contact of the HTTP working group (ietf-http-wg@w3.org). 11.2.1. Frame Types This document establishes a registry for HTTP/3 frame type codes. The "HTTP/3 Frame Type" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126].',106419,107337);
INSERT INTO "passages" VALUES('S3-P117',3,117,'While this registry is separate from the "HTTP/2 Frame Type" registry defined in [HTTP2], it is preferable that the assignments parallel each other where the code spaces overlap. If an entry is present in only one registry, every effort SHOULD be made to avoid assigning the corresponding value to an unrelated operation. In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following field: Frame Type: A name or label for the frame type. Specifications of frame types MUST include a description of the frame layout and its semantics, including any parts of the frame that are conditionally present. The entries in Table 2 are registered by this document.',107338,108058);
INSERT INTO "passages" VALUES('S3-P118',3,118,'Bishop Expires 18 June 2021 [Page 49] Internet-Draft HTTP/3 December 2020 +==============+=======+===============+ | Frame Type | Value | Specification | +==============+=======+===============+ | DATA | 0x0 | Section 7.2.1 | +--------------+-------+---------------+ | HEADERS | 0x1 | Section 7.2.2 | +--------------+-------+---------------+ | Reserved | 0x2 | N/A | +--------------+-------+---------------+ | CANCEL_PUSH | 0x3 | Section 7.2.3 | +--------------+-------+---------------+ | SETTINGS | 0x4 | Section 7.2.4 | +--------------+-------+---------------+ | PUSH_PROMISE | 0x5 | Section 7.2.5 | +--------------+-------+---------------+ | Reserved | 0x6 | N/A | +--------------+-------+---------------+ | GOAWAY | 0x7 | Section 7.2.6 | +--------------+-------+---------------+ | Reserved | 0x8 | N/A | +--------------+-------+---------------+ | Reserved | 0x9 | N/A | +--------------+-------+---------------+ | MAX_PUSH_ID | 0xd | Section 7.2.7 | +--------------+-------+---------------+ Table 2: Initial HTTP/3 Frame Types Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values.',108059,109306);
INSERT INTO "passages" VALUES('S3-P119',3,119,'11.2.2. Settings Parameters This document establishes a registry for HTTP/3 settings. The "HTTP/3 Settings" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. Bishop Expires 18 June 2021 [Page 50] Internet-Draft HTTP/3 December 2020 While this registry is separate from the "HTTP/2 Settings" registry defined in [HTTP2], it is preferable that the assignments parallel each other. If an entry is present in only one registry, every effort SHOULD be made to avoid assigning the corresponding value to an unrelated operation.',109307,110161);
INSERT INTO "passages" VALUES('S3-P120',3,120,'In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following fields: Setting Name: A symbolic name for the setting. Specifying a setting name is optional. Default: The value of the setting unless otherwise indicated. A default SHOULD be the most restrictive possible value. The entries in Table 3 are registered by this document.',110162,110557);
INSERT INTO "passages" VALUES('S3-P121',3,121,'+========================+=======+=================+===========+ | Setting Name | Value | Specification | Default | +========================+=======+=================+===========+ | Reserved | 0x2 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x3 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x4 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x5 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | MAX_FIELD_SECTION_SIZE | 0x6 | Section 7.2.4.1 | Unlimited | +------------------------+-------+-----------------+-----------+ Table 3: Initial HTTP/3 Settings Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 11.2.3.',110558,111509);
INSERT INTO "passages" VALUES('S3-P122',3,122,'Error Codes This document establishes a registry for HTTP/3 error codes. The "HTTP/3 Error Code" registry manages a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. Bishop Expires 18 June 2021 [Page 51] Internet-Draft HTTP/3 December 2020 Registrations for error codes are required to include a description of the error code. An expert reviewer is advised to examine new registrations for possible duplication with existing error codes. Use of existing registrations is to be encouraged, but not mandated. Use of values that are registered in the "HTTP/2 Error Code" registry is discouraged.',111510,112416);
INSERT INTO "passages" VALUES('S3-P123',3,123,'In addition to common fields as described in Section 11.2, this registry includes two additional fields. Permanent registrations in this registry MUST include the following field: Name: A name for the error code. Description: A brief description of the error code semantics. The entries in Table 4 are registered by this document. These error codes were selected from the range that operates on a Specification Required policy to avoid collisions with HTTP/2 error codes.',112417,112888);
INSERT INTO "passages" VALUES('S3-P124',3,124,'+===========================+========+==============+===============+ | Name | Value | Description | Specification | +===========================+========+==============+===============+ | H3_NO_ERROR | 0x0100 | No error | Section 8.1 | +---------------------------+--------+--------------+---------------+ | H3_GENERAL_PROTOCOL_ERROR | 0x0101 | General | Section 8.1 | | | | protocol | | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_INTERNAL_ERROR | 0x0102 | Internal | Section 8.1 | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_STREAM_CREATION_ERROR | 0x0103 | Stream | Section 8.1 | | | | creation | | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_CLOSED_CRITICAL_STREAM | 0x0104 | Critical | Section 8.1 | | | | stream was | | | | | closed | | +---------------------------+--------+--------------+---------------+ | H3_FRAME_UNEXPECTED | 0x0105 | Frame not | Section 8.1 | | | | permitted | | | | | in the | | | | | current | | | | | state | | +---------------------------+--------+--------------+---------------+ | H3_FRAME_ERROR | 0x0106 | Frame | Section 8.1 | | | | violated | | | | | layout or | | Bishop Expires 18 June 2021 [Page 52] Internet-Draft HTTP/3 December 2020 | | | size rules | | +---------------------------+--------+--------------+---------------+ | H3_EXCESSIVE_LOAD | 0x0107 | Peer | Section 8.1 | | | | generating | | | | | excessive |',112889,114388);
INSERT INTO "passages" VALUES('S3-P125',3,125,'| | | | load | | +---------------------------+--------+--------------+---------------+ | H3_ID_ERROR | 0x0108 | An | Section 8.1 | | | | identifier | | | | | was used | | | | | incorrectly | | +---------------------------+--------+--------------+---------------+ | H3_SETTINGS_ERROR | 0x0109 | SETTINGS | Section 8.1 | | | | frame | | | | | contained | | | | | invalid | | | | | values | | +---------------------------+--------+--------------+---------------+ | H3_MISSING_SETTINGS | 0x010a | No SETTINGS | Section 8.1 | | | | frame | | | | | received | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_REJECTED | 0x010b | Request not | Section 8.1 | | | | processed | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_CANCELLED | 0x010c | Data no | Section 8.1 | | | | longer | | | | | needed | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_INCOMPLETE | 0x010d | Stream | Section 8.1 | | | | terminated | | | | | early | | +---------------------------+--------+--------------+---------------+ | H3_MESSAGE_ERROR | 0x010e | Malformed | Section 8.1 | | | | message | | +---------------------------+--------+--------------+---------------+ | H3_CONNECT_ERROR | 0x010f | TCP reset | Section 8.1 | | | | or error on | | | | | CONNECT | | | | | request | | +---------------------------+--------+--------------+---------------+ | H3_VERSION_FALLBACK | 0x0110 | Retry over | Section 8.1 | | | |',114389,115886);
INSERT INTO "passages" VALUES('S3-P126',3,126,'HTTP/1.1 | | +---------------------------+--------+--------------+---------------+ Table 4: Initial HTTP/3 Error Codes Bishop Expires 18 June 2021 [Page 53] Internet-Draft HTTP/3 December 2020 Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 11.2.4. Stream Types This document establishes a registry for HTTP/3 unidirectional stream types. The "HTTP/3 Stream Type" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126].',115887,116803);
INSERT INTO "passages" VALUES('S3-P127',3,127,'In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following fields: Stream Type: A name or label for the stream type. Sender: Which endpoint on an HTTP/3 connection may initiate a stream of this type. Values are "Client", "Server", or "Both". Specifications for permanent registrations MUST include a description of the stream type, including the layout and semantics of the stream contents. The entries in the following table are registered by this document.',116804,117330);
INSERT INTO "passages" VALUES('S3-P128',3,128,'+================+=======+===============+========+ | Stream Type | Value | Specification | Sender | +================+=======+===============+========+ | Control Stream | 0x00 | Section 6.2.1 | Both | +----------------+-------+---------------+--------+ | Push Stream | 0x01 | Section 4.4 | Server | +----------------+-------+---------------+--------+ Table 5 Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 12. References 12.1. Normative References Bishop Expires 18 June 2021 [Page 54] Internet-Draft HTTP/3 December 2020 [ALTSVC] Nottingham, M., McManus, P., and J. Reschke, "HTTP Alternative Services", RFC 7838, DOI 10.17487/RFC7838, April 2016, <https://www.rfc-editor.org/info/rfc7838>. [CACHING] Fielding, R., Nottingham, M., and J.',117331,118241);
INSERT INTO "passages" VALUES('S3-P129',3,129,'Reschke, "HTTP Caching", Work in Progress, Internet-Draft, draft-ietf- httpbis-cache-13, 14 December 2020, <http://www.ietf.org/ internet-drafts/draft-ietf-httpbis-cache-13.txt>. [HTTP-REPLAY] Thomson, M., Nottingham, M., and W. Tarreau, "Using Early Data in HTTP", RFC 8470, DOI 10.17487/RFC8470, September 2018, <https://www.rfc-editor.org/info/rfc8470>. [QPACK] Krasic, C., Bishop, M., and A. Frindell, Ed., "QPACK: Header Compression for HTTP over QUIC", Work in Progress, Internet-Draft, draft-ietf-quic-qpack-20, 15 December 2020, <https://tools.ietf.org/html/draft-ietf-quic-qpack-20>. [QUIC-TRANSPORT] Iyengar, J., Ed. and M. Thomson, Ed., "QUIC: A UDP-Based Multiplexed and Secure Transport", Work in Progress, Internet-Draft, draft-ietf-quic-transport-34, 15 December 2020, <https://tools.ietf.org/html/draft-ietf-quic- transport-34>. [RFC0793] Postel, J., "Transmission Control Protocol", STD 7, RFC 793, DOI 10.17487/RFC0793, September 1981, <https://www.rfc-editor.org/info/rfc793>.',118242,119237);
INSERT INTO "passages" VALUES('S3-P130',3,130,'[RFC2119] Bradner, S., "Key words for use in RFCs to Indicate Requirement Levels", BCP 14, RFC 2119, DOI 10.17487/RFC2119, March 1997, <https://www.rfc-editor.org/info/rfc2119>. [RFC6066] Eastlake 3rd, D., "Transport Layer Security (TLS) Extensions: Extension Definitions", RFC 6066, DOI 10.17487/RFC6066, January 2011, <https://www.rfc-editor.org/info/rfc6066>. [RFC6125] Saint-Andre, P. and J. Hodges, "Representation and Verification of Domain-Based Application Service Identity within Internet Public Key Infrastructure Using X.509 (PKIX) Certificates in the Context of Transport Layer Security (TLS)", RFC 6125, DOI 10.17487/RFC6125, March 2011, <https://www.rfc-editor.org/info/rfc6125>. Bishop Expires 18 June 2021 [Page 55] Internet-Draft HTTP/3 December 2020 [RFC6265] Barth, A., "HTTP State Management Mechanism", RFC 6265, DOI 10.17487/RFC6265, April 2011, <https://www.rfc-editor.org/info/rfc6265>. [RFC7301] Friedl, S., Popov, A., Langley, A., and E.',119238,120201);
INSERT INTO "passages" VALUES('S3-P131',3,131,'Stephan, "Transport Layer Security (TLS) Application-Layer Protocol Negotiation Extension", RFC 7301, DOI 10.17487/RFC7301, July 2014, <https://www.rfc-editor.org/info/rfc7301>. [RFC8126] Cotton, M., Leiba, B., and T. Narten, "Guidelines for Writing an IANA Considerations Section in RFCs", BCP 26, RFC 8126, DOI 10.17487/RFC8126, June 2017, <https://www.rfc-editor.org/info/rfc8126>. [RFC8174] Leiba, B., "Ambiguity of Uppercase vs Lowercase in RFC 2119 Key Words", BCP 14, RFC 8174, DOI 10.17487/RFC8174, May 2017, <https://www.rfc-editor.org/info/rfc8174>. [SEMANTICS] Fielding, R., Nottingham, M., and J. Reschke, "HTTP Semantics", Work in Progress, Internet-Draft, draft-ietf- httpbis-semantics-13, 14 December 2020, <http://www.ietf.org/internet-drafts/draft-ietf-httpbis- semantics-13.txt>. [URI] Berners-Lee, T., Fielding, R., and L.',120202,121043);
INSERT INTO "passages" VALUES('S3-P132',3,132,'Masinter, "Uniform Resource Identifier (URI): Generic Syntax", STD 66, RFC 3986, DOI 10.17487/RFC3986, January 2005, <https://www.rfc-editor.org/info/rfc3986>. 12.2. Informative References [BREACH] Gluck, Y., Harris, N., and A. Prado, "BREACH: Reviving the CRIME Attack", July 2013, <http://breachattack.com/resources/ BREACH%20-%20SSL,%20gone%20in%2030%20seconds.pdf>. [HPACK] Peon, R. and H. Ruellan, "HPACK: Header Compression for HTTP/2", RFC 7541, DOI 10.17487/RFC7541, May 2015, <https://www.rfc-editor.org/info/rfc7541>. [HTTP11] Fielding, R., Nottingham, M., and J. Reschke, "HTTP/1.1", Work in Progress, Internet-Draft, draft-ietf-httpbis- messaging-13, 14 December 2020, <http://www.ietf.org/ internet-drafts/draft-ietf-httpbis-messaging-13.txt>. Bishop Expires 18 June 2021 [Page 56] Internet-Draft HTTP/3 December 2020 [HTTP2] Belshe, M., Peon, R., and M.',121044,121911);
INSERT INTO "passages" VALUES('S3-P133',3,133,'Thomson, Ed., "Hypertext Transfer Protocol Version 2 (HTTP/2)", RFC 7540, DOI 10.17487/RFC7540, May 2015, <https://www.rfc-editor.org/info/rfc7540>. [RFC6585] Nottingham, M. and R. Fielding, "Additional HTTP Status Codes", RFC 6585, DOI 10.17487/RFC6585, April 2012, <https://www.rfc-editor.org/info/rfc6585>. [RFC8164] Nottingham, M. and M. Thomson, "Opportunistic Security for HTTP/2", RFC 8164, DOI 10.17487/RFC8164, May 2017, <https://www.rfc-editor.org/info/rfc8164>. [TFO] Cheng, Y., Chu, J., Radhakrishnan, S., and A. Jain, "TCP Fast Open", RFC 7413, DOI 10.17487/RFC7413, December 2014, <https://www.rfc-editor.org/info/rfc7413>. [TLS13] Rescorla, E., "The Transport Layer Security (TLS) Protocol Version 1.3", RFC 8446, DOI 10.17487/RFC8446, August 2018, <https://www.rfc-editor.org/info/rfc8446>. Appendix A. Considerations for Transitioning from HTTP/2 HTTP/3 is strongly informed by HTTP/2, and bears many similarities.',121912,122843);
INSERT INTO "passages" VALUES('S3-P134',3,134,'This section describes the approach taken to design HTTP/3, points out important differences from HTTP/2, and describes how to map HTTP/2 extensions into HTTP/3. HTTP/3 begins from the premise that similarity to HTTP/2 is preferable, but not a hard requirement. HTTP/3 departs from HTTP/2 where QUIC differs from TCP, either to take advantage of QUIC features (like streams) or to accommodate important shortcomings (such as a lack of total ordering). These differences make HTTP/3 similar to HTTP/2 in key aspects, such as the relationship of requests and responses to streams. However, the details of the HTTP/3 design are substantially different from HTTP/2. These departures are noted in this section. A.1. Streams HTTP/3 permits use of a larger number of streams (2^62-1) than HTTP/2.',122844,123633);
INSERT INTO "passages" VALUES('S3-P135',3,135,'The same considerations about exhaustion of stream identifier space apply, though the space is significantly larger such that it is likely that other limits in QUIC are reached first, such as the limit on the connection flow control window. Bishop Expires 18 June 2021 [Page 57] Internet-Draft HTTP/3 December 2020 In contrast to HTTP/2, stream concurrency in HTTP/3 is managed by QUIC. QUIC considers a stream closed when all data has been received and sent data has been acknowledged by the peer. HTTP/2 considers a stream closed when the frame containing the END_STREAM bit has been committed to the transport. As a result, the stream for an equivalent exchange could remain "active" for a longer period of time. HTTP/3 servers might choose to permit a larger number of concurrent client-initiated bidirectional streams to achieve equivalent concurrency to HTTP/2, depending on the expected usage patterns.',123634,124543);
INSERT INTO "passages" VALUES('S3-P136',3,136,'Due to the presence of other unidirectional stream types, HTTP/3 does not rely exclusively on the number of concurrent unidirectional streams to control the number of concurrent in-flight pushes. Instead, HTTP/3 clients use the MAX_PUSH_ID frame to control the number of pushes received from an HTTP/3 server. A.2. HTTP Frame Types Many framing concepts from HTTP/2 can be elided on QUIC, because the transport deals with them. Because frames are already on a stream, they can omit the stream number. Because frames do not block multiplexing (QUIC''s multiplexing occurs below this layer), the support for variable-maximum-length packets can be removed. Because stream termination is handled by QUIC, an END_STREAM flag is not required. This permits the removal of the Flags field from the generic frame layout. Frame payloads are largely drawn from [HTTP2]. However, QUIC includes many features (e.g., flow control) that are also present in HTTP/2.',124544,125492);
INSERT INTO "passages" VALUES('S3-P137',3,137,'In these cases, the HTTP mapping does not re-implement them. As a result, several HTTP/2 frame types are not required in HTTP/3. Where an HTTP/2-defined frame is no longer used, the frame ID has been reserved in order to maximize portability between HTTP/2 and HTTP/3 implementations. However, even equivalent frames between the two mappings are not identical. Many of the differences arise from the fact that HTTP/2 provides an absolute ordering between frames across all streams, while QUIC provides this guarantee on each stream only. As a result, if a frame type makes assumptions that frames from different streams will still be received in the order sent, HTTP/3 will break them. Some examples of feature adaptations are described below, as well as general guidance to extension frame implementors converting an HTTP/2 extension to HTTP/3. Bishop Expires 18 June 2021 [Page 58] Internet-Draft HTTP/3 December 2020 A.2.1.',125493,126419);
INSERT INTO "passages" VALUES('S3-P138',3,138,'Prioritization Differences HTTP/2 specifies priority assignments in PRIORITY frames and (optionally) in HEADERS frames. HTTP/3 does not provide a means of signaling priority. Note that while there is no explicit signaling for priority, this does not mean that prioritization is not important for achieving good performance. A.2.2. Field Compression Differences HPACK was designed with the assumption of in-order delivery. A sequence of encoded field sections must arrive (and be decoded) at an endpoint in the same order in which they were encoded. This ensures that the dynamic state at the two endpoints remains in sync. Because this total ordering is not provided by QUIC, HTTP/3 uses a modified version of HPACK, called QPACK. QPACK uses a single unidirectional stream to make all modifications to the dynamic table, ensuring a total order of updates. All frames that contain encoded fields merely reference the table state at a given time without modifying it.',126420,127385);
INSERT INTO "passages" VALUES('S3-P139',3,139,'[QPACK] provides additional details. A.2.3. Flow Control Differences HTTP/2 specifies a stream flow control mechanism. Although all HTTP/2 frames are delivered on streams, only the DATA frame payload is subject to flow control. QUIC provides flow control for stream data and all HTTP/3 frame types defined in this document are sent on streams. Therefore, all frame headers and payload are subject to flow control. A.2.4. Guidance for New Frame Type Definitions Frame type definitions in HTTP/3 often use the QUIC variable-length integer encoding. In particular, Stream IDs use this encoding, which allows for a larger range of possible values than the encoding used in HTTP/2. Some frames in HTTP/3 use an identifier rather than a Stream ID (e.g., Push IDs). Redefinition of the encoding of extension frame types might be necessary if the encoding includes a Stream ID.',127386,128255);
INSERT INTO "passages" VALUES('S3-P140',3,140,'Because the Flags field is not present in generic HTTP/3 frames, those frames that depend on the presence of flags need to allocate space for flags as part of their frame payload. Bishop Expires 18 June 2021 [Page 59] Internet-Draft HTTP/3 December 2020 Other than these issues, frame type HTTP/2 extensions are typically portable to QUIC simply by replacing Stream 0 in HTTP/2 with a control stream in HTTP/3. HTTP/3 extensions will not assume ordering, but would not be harmed by ordering, and would be portable to HTTP/2 in the same manner. A.2.5. Mapping Between HTTP/2 and HTTP/3 Frame Types DATA (0x0): Padding is not defined in HTTP/3 frames. See Section 7.2.1. HEADERS (0x1): The PRIORITY region of HEADERS is not defined in HTTP/3 frames. Padding is not defined in HTTP/3 frames. See Section 7.2.2. PRIORITY (0x2): As described in Appendix A.2.1, HTTP/3 does not provide a means of signaling priority.',128256,129166);
INSERT INTO "passages" VALUES('S3-P141',3,141,'RST_STREAM (0x3): RST_STREAM frames do not exist in HTTP/3, since QUIC provides stream lifecycle management. The same code point is used for the CANCEL_PUSH frame (Section 7.2.3). SETTINGS (0x4): SETTINGS frames are sent only at the beginning of the connection. See Section 7.2.4 and Appendix A.3. PUSH_PROMISE (0x5): The PUSH_PROMISE frame does not reference a stream; instead the push stream references the PUSH_PROMISE frame using a Push ID. See Section 7.2.5. PING (0x6): PING frames do not exist in HTTP/3, as QUIC provides equivalent functionality. GOAWAY (0x7): GOAWAY does not contain an error code. In the client to server direction, it carries a Push ID instead of a server initiated stream ID. See Section 7.2.6. WINDOW_UPDATE (0x8): WINDOW_UPDATE frames do not exist in HTTP/3, since QUIC provides flow control. CONTINUATION (0x9): CONTINUATION frames do not exist in HTTP/3; instead, larger HEADERS/PUSH_PROMISE frames than HTTP/2 are permitted.',129167,130125);
INSERT INTO "passages" VALUES('S3-P142',3,142,'Bishop Expires 18 June 2021 [Page 60] Internet-Draft HTTP/3 December 2020 Frame types defined by extensions to HTTP/2 need to be separately registered for HTTP/3 if still applicable. The IDs of frames defined in [HTTP2] have been reserved for simplicity. Note that the frame type space in HTTP/3 is substantially larger (62 bits versus 8 bits), so many HTTP/3 frame types have no equivalent HTTP/2 code points. See Section 11.2.1. A.3. HTTP/2 SETTINGS Parameters An important difference from HTTP/2 is that settings are sent once, as the first frame of the control stream, and thereafter cannot change. This eliminates many corner cases around synchronization of changes. Some transport-level options that HTTP/2 specifies via the SETTINGS frame are superseded by QUIC transport parameters in HTTP/3. The HTTP-level options that are retained in HTTP/3 have the same value as in HTTP/2. The superseded settings are reserved, and their receipt is an error.',130126,131080);
INSERT INTO "passages" VALUES('S3-P143',3,143,'See Section 7.2.4.1 for discussion of both the retained and reserved values. Below is a listing of how each HTTP/2 SETTINGS parameter is mapped: SETTINGS_HEADER_TABLE_SIZE: See [QPACK]. SETTINGS_ENABLE_PUSH: This is removed in favor of the MAX_PUSH_ID frame, which provides a more granular control over server push. Specifying a setting with the identifier 0x2 (corresponding to the SETTINGS_ENABLE_PUSH parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_MAX_CONCURRENT_STREAMS: QUIC controls the largest open Stream ID as part of its flow control logic. Specifying a setting with the identifier 0x3 (corresponding to the SETTINGS_MAX_CONCURRENT_STREAMS parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_INITIAL_WINDOW_SIZE: QUIC requires both stream and connection flow control window sizes to be specified in the initial transport handshake.',131081,131947);
INSERT INTO "passages" VALUES('S3-P144',3,144,'Specifying a setting with the identifier 0x4 (corresponding to the SETTINGS_INITIAL_WINDOW_SIZE parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_MAX_FRAME_SIZE: This setting has no equivalent in HTTP/3. Specifying a setting with the identifier 0x5 (corresponding to the SETTINGS_MAX_FRAME_SIZE parameter) in the HTTP/3 SETTINGS frame is an error. Bishop Expires 18 June 2021 [Page 61] Internet-Draft HTTP/3 December 2020 SETTINGS_MAX_HEADER_LIST_SIZE: This setting identifier has been renamed SETTINGS_MAX_FIELD_SECTION_SIZE. In HTTP/3, setting values are variable-length integers (6, 14, 30, or 62 bits long) rather than fixed-length 32-bit fields as in HTTP/2. This will often produce a shorter encoding, but can produce a longer encoding for settings that use the full 32-bit space. Settings ported from HTTP/2 might choose to redefine their value to limit it to 30 bits for more efficient encoding, or to make use of the 62-bit space if more than 30 bits are required.',131948,132933);
INSERT INTO "passages" VALUES('S3-P145',3,145,'Settings need to be defined separately for HTTP/2 and HTTP/3. The IDs of settings defined in [HTTP2] have been reserved for simplicity. Note that the settings identifier space in HTTP/3 is substantially larger (62 bits versus 16 bits), so many HTTP/3 settings have no equivalent HTTP/2 code point. See Section 11.2.2. As QUIC streams might arrive out of order, endpoints are advised not to wait for the peers'' settings to arrive before responding to other streams. See Section 7.2.4.2. A.4. HTTP/2 Error Codes QUIC has the same concepts of "stream" and "connection" errors that HTTP/2 provides. However, the differences between HTTP/2 and HTTP/3 mean that error codes are not directly portable between versions. The HTTP/2 error codes defined in Section 7 of [HTTP2] logically map to the HTTP/3 error codes as follows: NO_ERROR (0x0): H3_NO_ERROR in Section 8.1. PROTOCOL_ERROR (0x1): This is mapped to H3_GENERAL_PROTOCOL_ERROR except in cases where more specific error codes have been defined.',132934,133929);
INSERT INTO "passages" VALUES('S3-P146',3,146,'Such cases include H3_FRAME_UNEXPECTED, H3_MESSAGE_ERROR, and H3_CLOSED_CRITICAL_STREAM defined in Section 8.1. INTERNAL_ERROR (0x2): H3_INTERNAL_ERROR in Section 8.1. FLOW_CONTROL_ERROR (0x3): Not applicable, since QUIC handles flow control. SETTINGS_TIMEOUT (0x4): Not applicable, since no acknowledgement of SETTINGS is defined. STREAM_CLOSED (0x5): Not applicable, since QUIC handles stream management. Bishop Expires 18 June 2021 [Page 62] Internet-Draft HTTP/3 December 2020 FRAME_SIZE_ERROR (0x6): H3_FRAME_ERROR error code defined in Section 8.1. REFUSED_STREAM (0x7): H3_REQUEST_REJECTED (in Section 8.1) is used to indicate that a request was not processed. Otherwise, not applicable because QUIC handles stream management. CANCEL (0x8): H3_REQUEST_CANCELLED in Section 8.1. COMPRESSION_ERROR (0x9): Multiple error codes are defined in [QPACK]. CONNECT_ERROR (0xa): H3_CONNECT_ERROR in Section 8.1. ENHANCE_YOUR_CALM (0xb): H3_EXCESSIVE_LOAD in Section 8.1.',133930,134897);
INSERT INTO "passages" VALUES('S3-P147',3,147,'INADEQUATE_SECURITY (0xc): Not applicable, since QUIC is assumed to provide sufficient security on all connections. HTTP_1_1_REQUIRED (0xd): H3_VERSION_FALLBACK in Section 8.1. Error codes need to be defined for HTTP/2 and HTTP/3 separately. See Section 11.2.3. A.4.1. Mapping Between HTTP/2 and HTTP/3 Errors An intermediary that converts between HTTP/2 and HTTP/3 may encounter error conditions from either upstream. It is useful to communicate the occurrence of error to the downstream but error codes largely reflect connection-local problems that generally do not make sense to propagate. An intermediary that encounters an error from an upstream origin can indicate this by sending an HTTP status code such as 502, which is suitable for a broad class of errors. There are some rare cases where it is beneficial to propagate the error by mapping it to the closest matching error type to the receiver.',134898,135803);
INSERT INTO "passages" VALUES('S3-P148',3,148,'For example, an intermediary that receives an HTTP/2 stream error of type REFUSED_STREAM from the origin has a clear signal that the request was not processed and that the request is safe to retry. Propagating this error condition to the client as an HTTP/3 stream error of type H3_REQUEST_REJECTED allows the client to take the action it deems most appropriate. In the reverse direction, the intermediary might deem it beneficial to pass on client request cancellations that are indicated by terminating a stream with H3_REQUEST_CANCELLED; see Section 4.1.2. Bishop Expires 18 June 2021 [Page 63] Internet-Draft HTTP/3 December 2020 Conversion between errors is described in the logical mapping. The error codes are defined in non-overlapping spaces in order to protect against accidental conversion that could result in the use of inappropriate or unknown error codes for the target version.',135804,136697);
INSERT INTO "passages" VALUES('S3-P149',3,149,'An intermediary is permitted to promote stream errors to connection errors but they should be aware of the cost to the HTTP/3 connection for what might be a temporary or intermittent error. Appendix B. Change Log *RFC Editor''s Note:* Please remove this section prior to publication of a final version of this document. B.1. Since draft-ietf-quic-http-32 * Removed draft version guidance; added final version string * Added H3_MESSAGE_ERROR for malformed messages B.2. Since draft-ietf-quic-http-31 Editorial changes only. B.3. Since draft-ietf-quic-http-30 Editorial changes only. B.4. Since draft-ietf-quic-http-29 * Require a connection error if a reserved frame type that corresponds to a frame in HTTP/2 is received (#3991, #3993) * Require a connection error if a reserved setting that corresponds to a setting in HTTP/2 is received (#3954, #3955) B.5.',136698,137555);
INSERT INTO "passages" VALUES('S3-P150',3,150,'Since draft-ietf-quic-http-28 * CANCEL_PUSH is recommended even when the stream is reset (#3698, #3700) * Use H3_ID_ERROR when GOAWAY contains a larger identifier (#3631, #3634) B.6. Since draft-ietf-quic-http-27 * Updated text to refer to latest HTTP revisions Bishop Expires 18 June 2021 [Page 64] Internet-Draft HTTP/3 December 2020 * Use the HTTP definition of authority for establishing and coalescing connections (#253, #2223, #3558) * Define use of GOAWAY from both endpoints (#2632, #3129) * Require either :authority or Host if the URI scheme has a mandatory authority component (#3408, #3475) B.7. Since draft-ietf-quic-http-26 * No changes B.8. Since draft-ietf-quic-http-25 * Require QUICv1 for HTTP/3 (#3117, #3323) * Remove DUPLICATE_PUSH and allow duplicate PUSH_PROMISE (#3275, #3309) * Clarify the definition of "malformed" (#3352, #3345) B.9.',137556,138416);
INSERT INTO "passages" VALUES('S3-P151',3,151,'Since draft-ietf-quic-http-24 * Removed H3_EARLY_RESPONSE error code; H3_NO_ERROR is recommended instead (#3130,#3208) * Unknown error codes are equivalent to H3_NO_ERROR (#3276,#3331) * Some error codes are reserved for greasing (#3325,#3360) B.10. Since draft-ietf-quic-http-23 * Removed "quic" Alt-Svc parameter (#3061,#3118) * Clients need not persist unknown settings for use in 0-RTT (#3110,#3113) * Clarify error cases around CANCEL_PUSH (#2819,#3083) B.11.',138417,138881);
INSERT INTO "passages" VALUES('S3-P152',3,152,'Since draft-ietf-quic-http-22 * Removed priority signaling (#2922,#2924) * Further changes to error codes (#2662,#2551): - Error codes renumbered Bishop Expires 18 June 2021 [Page 65] Internet-Draft HTTP/3 December 2020 - HTTP_MALFORMED_FRAME replaced by HTTP_FRAME_ERROR, HTTP_ID_ERROR, and others * Clarify how unknown frame types interact with required frame sequence (#2867,#2858) * Describe interactions with the transport in terms of defined interface terms (#2857,#2805) * Require the use of the "http-opportunistic" resource (RFC 8164) when scheme is "http" (#2439,#2973) * Settings identifiers cannot be duplicated (#2979) * Changes to SETTINGS frames in 0-RTT (#2972,#2790,#2945): - Servers must send all settings with non-default values in their SETTINGS frame, even when resuming - If a client doesn''t have settings associated with a 0-RTT ticket, it uses the defaults - Servers can''t accept early data if they cannot recover the settings the client will have remembered * Clarify that Upgrade and the 101 status code are prohibited (#2898,#2889) * Clarify that frame types reserved for greasing can occur on any stream, but frame types reserved due to HTTP/2 correspondence are prohibited (#2997,#2692,#2693) * Unknown error codes cannot be treated as errors (#2998,#2816) B.12.',138882,140173);
INSERT INTO "passages" VALUES('S3-P153',3,153,'Since draft-ietf-quic-http-21 No changes B.13.',140174,140220);
INSERT INTO "passages" VALUES('S3-P154',3,154,'Since draft-ietf-quic-http-20 * Prohibit closing the control stream (#2509, #2666) * Change default priority to use an orphan node (#2502, #2690) * Exclusive priorities are restored (#2754, #2781) * Restrict use of frames when using CONNECT (#2229, #2702) Bishop Expires 18 June 2021 [Page 66] Internet-Draft HTTP/3 December 2020 * Close and maybe reset streams if a connection error occurs for CONNECT (#2228, #2703) * Encourage provision of sufficient unidirectional streams for QPACK (#2100, #2529, #2762) * Allow extensions to use server-initiated bidirectional streams (#2711, #2773) * Clarify use of maximum header list size setting (#2516, #2774) * Extensive changes to error codes and conditions of their sending - Require connection errors for more error conditions (#2511, #2510) - Updated the error codes for illegal GOAWAY frames (#2714, #2707) - Specified error code for HEADERS on control stream (#2708) - Specified error code for servers receiving PUSH_PROMISE (#2709) - Specified error code for receiving DATA before HEADERS (#2715) - Describe malformed messages and their handling (#2410, #2764) - Remove HTTP_PUSH_ALREADY_IN_CACHE error (#2812, #2813) - Refactor Push ID related errors (#2818, #2820) - Rationalize HTTP/3 stream creation errors (#2821, #2822) B.14.',140221,141504);
INSERT INTO "passages" VALUES('S3-P155',3,155,'Since draft-ietf-quic-http-19 * SETTINGS_NUM_PLACEHOLDERS is 0x9 (#2443,#2530) * Non-zero bits in the Empty field of the PRIORITY frame MAY be treated as an error (#2501) B.15. Since draft-ietf-quic-http-18 * Resetting streams following a GOAWAY is recommended, but not required (#2256,#2457) * Use variable-length integers throughout (#2437,#2233,#2253,#2275) Bishop Expires 18 June 2021 [Page 67] Internet-Draft HTTP/3 December 2020 - Variable-length frame types, stream types, and settings identifiers - Renumbered stream type assignments - Modified associated reserved values * Frame layout switched from Length-Type-Value to Type-Length-Value (#2395,#2235) * Specified error code for servers receiving DUPLICATE_PUSH (#2497) * Use connection error for invalid PRIORITY (#2507, #2508) B.16. Since draft-ietf-quic-http-17 * HTTP_REQUEST_REJECTED is used to indicate a request can be retried (#2106, #2325) * Changed error code for GOAWAY on the wrong stream (#2231, #2343) B.17.',141505,142486);
INSERT INTO "passages" VALUES('S3-P156',3,156,'Since draft-ietf-quic-http-16 * Rename "HTTP/QUIC" to "HTTP/3" (#1973) * Changes to PRIORITY frame (#1865, #2075) - Permitted as first frame of request streams - Remove exclusive reprioritization - Changes to Prioritized Element Type bits * Define DUPLICATE_PUSH frame to refer to another PUSH_PROMISE (#2072) * Set defaults for settings, allow request before receiving SETTINGS (#1809, #1846, #2038) * Clarify message processing rules for streams that aren''t closed (#1972, #2003) * Removed reservation of error code 0 and moved HTTP_NO_ERROR to this value (#1922) * Removed prohibition of zero-length DATA frames (#2098) Bishop Expires 18 June 2021 [Page 68] Internet-Draft HTTP/3 December 2020 B.18. Since draft-ietf-quic-http-15 Substantial editorial reorganization; no technical changes. B.19.',142487,143285);
INSERT INTO "passages" VALUES('S3-P157',3,157,'Since draft-ietf-quic-http-14 * Recommend sensible values for QUIC transport parameters (#1720,#1806) * Define error for missing SETTINGS frame (#1697,#1808) * Setting values are variable-length integers (#1556,#1807) and do not have separate maximum values (#1820) * Expanded discussion of connection closure (#1599,#1717,#1712) * HTTP_VERSION_FALLBACK falls back to HTTP/1.1 (#1677,#1685) B.20. Since draft-ietf-quic-http-13 * Reserved some frame types for grease (#1333, #1446) * Unknown unidirectional stream types are tolerated, not errors; some reserved for grease (#1490, #1525) * Require settings to be remembered for 0-RTT, prohibit reductions (#1541, #1641) * Specify behavior for truncated requests (#1596, #1643) B.21.',143286,144016);
INSERT INTO "passages" VALUES('S3-P158',3,158,'Since draft-ietf-quic-http-12 * TLS SNI extension isn''t mandatory if an alternative method is used (#1459, #1462, #1466) * Removed flags from HTTP/3 frames (#1388, #1398) * Reserved frame types and settings for use in preserving extensibility (#1333, #1446) * Added general error code (#1391, #1397) * Unidirectional streams carry a type byte and are extensible (#910,#1359) * Priority mechanism now uses explicit placeholders to enable persistent structure in the tree (#441,#1421,#1422) Bishop Expires 18 June 2021 [Page 69] Internet-Draft HTTP/3 December 2020 B.22. Since draft-ietf-quic-http-11 * Moved QPACK table updates and acknowledgments to dedicated streams (#1121, #1122, #1238) B.23. Since draft-ietf-quic-http-10 * Settings need to be remembered when attempting and accepting 0-RTT (#1157, #1207) B.24.',144017,144832);
INSERT INTO "passages" VALUES('S3-P159',3,159,'Since draft-ietf-quic-http-09 * Selected QCRAM for header compression (#228, #1117) * The server_name TLS extension is now mandatory (#296, #495) * Specified handling of unsupported versions in Alt-Svc (#1093, #1097) B.25. Since draft-ietf-quic-http-08 * Clarified connection coalescing rules (#940, #1024) B.26. Since draft-ietf-quic-http-07 * Changes for integer encodings in QUIC (#595,#905) * Use unidirectional streams as appropriate (#515, #240, #281, #886) * Improvement to the description of GOAWAY (#604, #898) * Improve description of server push usage (#947, #950, #957) B.27. Since draft-ietf-quic-http-06 * Track changes in QUIC error code usage (#485) B.28. Since draft-ietf-quic-http-05 * Made push ID sequential, add MAX_PUSH_ID, remove SETTINGS_ENABLE_PUSH (#709) * Guidance about keep-alive and QUIC PINGs (#729) * Expanded text on GOAWAY and cancellation (#757) B.29.',144833,145719);
INSERT INTO "passages" VALUES('S3-P160',3,160,'Since draft-ietf-quic-http-04 Bishop Expires 18 June 2021 [Page 70] Internet-Draft HTTP/3 December 2020 * Cite RFC 5234 (#404) * Return to a single stream per request (#245,#557) * Use separate frame type and settings registries from HTTP/2 (#81) * SETTINGS_ENABLE_PUSH instead of SETTINGS_DISABLE_PUSH (#477) * Restored GOAWAY (#696) * Identify server push using Push ID rather than a stream ID (#702,#281) * DATA frames cannot be empty (#700) B.30. Since draft-ietf-quic-http-03 None. B.31. Since draft-ietf-quic-http-02 * Track changes in transport draft B.32.',145720,146283);
INSERT INTO "passages" VALUES('S3-P161',3,161,'Since draft-ietf-quic-http-01 * SETTINGS changes (#181): - SETTINGS can be sent only once at the start of a connection; no changes thereafter - SETTINGS_ACK removed - Settings can only occur in the SETTINGS frame a single time - Boolean format updated * Alt-Svc parameter changed from "v" to "quic"; format updated (#229) * Closing the connection control stream or any message control stream is a fatal error (#176) * HPACK Sequence counter can wrap (#173) * 0-RTT guidance added * Guide to differences from HTTP/2 and porting HTTP/2 extensions added (#127,#242) Bishop Expires 18 June 2021 [Page 71] Internet-Draft HTTP/3 December 2020 B.33.',146284,146926);
INSERT INTO "passages" VALUES('S3-P162',3,162,'Since draft-ietf-quic-http-00 * Changed "HTTP/2-over-QUIC" to "HTTP/QUIC" throughout (#11,#29) * Changed from using HTTP/2 framing within Stream 3 to new framing format and two-stream-per-request model (#71,#72,#73) * Adopted SETTINGS format from draft-bishop-httpbis-extended- settings-01 * Reworked SETTINGS_ACK to account for indeterminate inter-stream order (#75) * Described CONNECT pseudo-method (#95) * Updated ALPN token and Alt-Svc guidance (#13,#87) * Application-layer-defined error codes (#19,#74) B.34. Since draft-shade-quic-http2-mapping-00 * Adopted as base for draft-ietf-quic-http * Updated authors/editors list Acknowledgements The original authors of this specification were Robbie Shade and Mike Warres. The IETF QUIC Working Group received an enormous amount of support from many people.',146927,147736);
INSERT INTO "passages" VALUES('S3-P163',3,163,'Among others, the following people provided substantial contributions to this document: * Bence Beky * Daan De Meyer * Martin Duke * Roy Fielding * Alan Frindell * Alessandro Ghedini * Nick Harper Bishop Expires 18 June 2021 [Page 72] Internet-Draft HTTP/3 December 2020 * Ryan Hamilton * Christian Huitema * Subodh Iyengar * Robin Marx * Patrick McManus * Luca Niccolini * 奥 一穂 (Kazuho Oku) * Lucas Pardue * Roberto Peon * Julian Reschke * Eric Rescorla * Martin Seemann * Ben Schwartz * Ian Swett * Willy Taureau * Martin Thomson * Dmitri Tikhonov * Tatsuhiro Tsujikawa A portion of Mike''s contribution was supported by Microsoft during his employment there. Author''s Address Mike Bishop (editor) Akamai Email: mbishop@evequefou.be Bishop Expires 18 June 2021 [Page 73]',147737,148508);
INSERT INTO "passages" VALUES('S4-P0',4,0,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',0,907);
INSERT INTO "passages" VALUES('S4-P1',4,1,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',909,1840);
INSERT INTO "passages" VALUES('S4-P2',4,2,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',1842,2842);
INSERT INTO "passages" VALUES('S4-P3',4,3,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',2844,3804);
INSERT INTO "passages" VALUES('S4-P4',4,4,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',3806,4682);
INSERT INTO "passages" VALUES('S4-P5',4,5,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',4684,5672);
INSERT INTO "passages" VALUES('S4-P6',4,6,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',5674,6537);
INSERT INTO "passages" VALUES('S4-P7',4,7,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',6539,7413);
INSERT INTO "passages" VALUES('S4-P8',4,8,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',7415,8362);
INSERT INTO "passages" VALUES('S4-P9',4,9,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',8364,9354);
INSERT INTO "passages" VALUES('S4-P10',4,10,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',9356,10228);
INSERT INTO "passages" VALUES('S4-P11',4,11,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',10230,10866);
INSERT INTO "passages" VALUES('S4-P12',4,12,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',10868,12336);
INSERT INTO "passages" VALUES('S4-P13',4,13,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',12338,13015);
INSERT INTO "passages" VALUES('S4-P14',4,14,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',13017,13906);
INSERT INTO "passages" VALUES('S4-P15',4,15,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',13908,14860);
INSERT INTO "passages" VALUES('S4-P16',4,16,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',14862,15699);
INSERT INTO "passages" VALUES('S4-P17',4,17,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',15701,16623);
INSERT INTO "passages" VALUES('S4-P18',4,18,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',16625,17466);
INSERT INTO "passages" VALUES('S4-P19',4,19,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',17468,18382);
INSERT INTO "passages" VALUES('S4-P20',4,20,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',18384,19055);
INSERT INTO "passages" VALUES('S4-P21',4,21,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',19057,20023);
INSERT INTO "passages" VALUES('S4-P22',4,22,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',20025,20641);
INSERT INTO "passages" VALUES('S4-P23',4,23,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',20643,21612);
INSERT INTO "passages" VALUES('S4-P24',4,24,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',21614,22570);
INSERT INTO "passages" VALUES('S4-P25',4,25,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',22572,23552);
INSERT INTO "passages" VALUES('S4-P26',4,26,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',23554,24542);
INSERT INTO "passages" VALUES('S4-P27',4,27,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',24544,25316);
INSERT INTO "passages" VALUES('S4-P28',4,28,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',25318,26275);
INSERT INTO "passages" VALUES('S4-P29',4,29,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',26277,27277);
INSERT INTO "passages" VALUES('S4-P30',4,30,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',27279,27747);
INSERT INTO "passages" VALUES('S4-P31',4,31,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',27749,28399);
INSERT INTO "passages" VALUES('S4-P32',4,32,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',28401,29302);
INSERT INTO "passages" VALUES('S4-P33',4,33,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',29304,30239);
INSERT INTO "passages" VALUES('S4-P34',4,34,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',30241,30798);
INSERT INTO "passages" VALUES('S4-P35',4,35,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',30800,31458);
INSERT INTO "passages" VALUES('S4-P36',4,36,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',31460,32440);
INSERT INTO "passages" VALUES('S4-P37',4,37,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',32442,33330);
INSERT INTO "passages" VALUES('S4-P38',4,38,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',33332,34299);
INSERT INTO "passages" VALUES('S4-P39',4,39,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',34301,35290);
INSERT INTO "passages" VALUES('S4-P40',4,40,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',35292,36140);
INSERT INTO "passages" VALUES('S5-P0',5,0,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',0,976);
INSERT INTO "passages" VALUES('S5-P1',5,1,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',978,1189);
INSERT INTO "passages" VALUES('S6-P0',6,0,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',0,995);
INSERT INTO "passages" VALUES('S6-P1',6,1,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',997,1986);
INSERT INTO "passages" VALUES('S6-P2',6,2,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',1988,2885);
INSERT INTO "passages" VALUES('S6-P3',6,3,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',2887,3842);
INSERT INTO "passages" VALUES('S6-P4',6,4,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',3844,4836);
INSERT INTO "passages" VALUES('S6-P5',6,5,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',4838,5514);
INSERT INTO "passages" VALUES('S7-P0',7,0,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',0,889);
INSERT INTO "passages" VALUES('S7-P1',7,1,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',891,1787);
INSERT INTO "passages" VALUES('S7-P2',7,2,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',1789,2760);
INSERT INTO "passages" VALUES('S7-P3',7,3,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',2762,3365);
INSERT INTO "passages" VALUES('S7-P4',7,4,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',3367,4361);
INSERT INTO "passages" VALUES('S7-P5',7,5,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',4363,4993);
INSERT INTO "passages" VALUES('S8-P0',8,0,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',0,899);
INSERT INTO "passages" VALUES('S8-P1',8,1,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',901,1793);
INSERT INTO "passages" VALUES('S8-P2',8,2,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',1795,2564);
INSERT INTO "passages" VALUES('S8-P3',8,3,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',2566,3215);
INSERT INTO "passages" VALUES('S8-P4',8,4,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',3217,4214);
INSERT INTO "passages" VALUES('S8-P5',8,5,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',4216,5173);
INSERT INTO "passages" VALUES('S8-P6',8,6,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',5175,5959);
INSERT INTO "passages" VALUES('S8-P7',8,7,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',5961,6807);
INSERT INTO "passages" VALUES('S8-P8',8,8,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',6809,7693);
INSERT INTO "passages" VALUES('S8-P9',8,9,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',7695,8667);
INSERT INTO "passages" VALUES('S8-P10',8,10,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',8669,9656);
INSERT INTO "passages" VALUES('S8-P11',8,11,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',9658,10653);
INSERT INTO "passages" VALUES('S8-P12',8,12,'[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]',10655,10672);
CREATE TABLE report_citations (
    id INTEGER PRIMARY KEY,
    report_claim_id INTEGER NOT NULL REFERENCES report_claims(id),
    passage_id TEXT NOT NULL REFERENCES passages(id),
    role TEXT NOT NULL,
    quotes TEXT NOT NULL DEFAULT '[]',
    source_id INTEGER NOT NULL,
    url TEXT NOT NULL,
    title TEXT,
    UNIQUE (report_claim_id, passage_id)
);
INSERT INTO "report_citations" VALUES(1,1,'S1-P0','claim_evidence','["RFC 9113\n\nHTTP/2\n\nJune 2022"]',1,'https://datatracker.ietf.org/doc/html/rfc9113','RFC 9113 - HTTP/2');
INSERT INTO "report_citations" VALUES(2,2,'S2-P2','claim_evidence','["On 28 October 2018 in a mailing list discussion, Mark Nottingham, Chair of the IETF HTTP and QUIC Working Groups, proposed renaming HTTP-over-QUIC to HTTP/3, to \"clearly identify it as another binding of HTTP semantics to the wire protocol [...] so people understand its separation from QUIC\"."]',2,'https://en.wikipedia.org/wiki/HTTP/3','HTTP/3 - Wikipedia');
INSERT INTO "report_citations" VALUES(3,3,'S1-P11','claim_evidence','["The string \"h2\" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS); see Section 9.2."]',1,'https://datatracker.ietf.org/doc/html/rfc9113','RFC 9113 - HTTP/2');
INSERT INTO "report_citations" VALUES(4,4,'S2-P4','claim_evidence','["Both HTTP/1.1 and HTTP/2 use TCP as their transport. HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP)."]',2,'https://en.wikipedia.org/wiki/HTTP/3','HTTP/3 - Wikipedia');
INSERT INTO "report_citations" VALUES(5,5,'S2-P4','claim_evidence','["The switch to QUIC aims to fix a major problem of HTTP/2 called \"head-of-line blocking\": because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was impacted by the lost packet. Because QUIC provides native multiplexing, lost packets only impact the streams where data has been lost."]',2,'https://en.wikipedia.org/wiki/HTTP/3','HTTP/3 - Wikipedia');
CREATE TABLE report_claim_roles (
    report_claim_id INTEGER PRIMARY KEY REFERENCES report_claims(id),
    role TEXT NOT NULL CHECK (role IN ('direct_answer', 'relevant_context')),
    requirement_keys TEXT NOT NULL DEFAULT '[]',
    reason TEXT NOT NULL DEFAULT ''
);
CREATE TABLE report_claims (
    id INTEGER PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES reports(id),
    section_id INTEGER NOT NULL REFERENCES report_sections(id),
    position INTEGER NOT NULL,
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    claim_version INTEGER NOT NULL,
    claim_text TEXT NOT NULL,
    semantic_result_id INTEGER NOT NULL REFERENCES verification_results(id),
    UNIQUE (report_id, claim_id)
);
INSERT INTO "report_claims" VALUES(1,2,4,1,6,2,'The HTTP/2 specification was published as RFC 9113 in June 2022.',12);
INSERT INTO "report_claims" VALUES(2,2,5,1,5,1,'The article describes that on 28 October 2018, Mark Nottingham proposed renaming HTTP-over-QUIC to HTTP/3.',10);
INSERT INTO "report_claims" VALUES(3,2,6,1,2,1,'HTTP/2 uses Transport Layer Security (TLS) when identified by the "h2" string.',7);
INSERT INTO "report_claims" VALUES(4,2,7,1,3,1,'HTTP/3 uses QUIC as its transport layer protocol.',8);
INSERT INTO "report_claims" VALUES(5,2,7,2,4,1,'HTTP/3 differs from HTTP/2 by using QUIC over UDP instead of TCP, which provides native multiplexing and avoids head-of-line blocking.',9);
CREATE TABLE report_gaps (
    id INTEGER PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES reports(id),
    requirement_key TEXT NOT NULL,
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    requirement_text TEXT NOT NULL,
    status TEXT NOT NULL,
    gap TEXT NOT NULL DEFAULT '',
    missing_kind TEXT NOT NULL DEFAULT 'none'
);
INSERT INTO "report_gaps" VALUES(1,1,'Q5.R1',5,'statement on release of financial results for fiscal year 2024','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(2,1,'Q5.R2',5,'indication of net profit or net loss in the report','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(3,1,'Q6.R1',6,'numerical value of net profit or loss','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(4,1,'Q6.R2',6,'currency and time period (fiscal year 2024)','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(5,1,'Q7.R1',7,'title and publication date of the document','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(6,1,'Q7.R2',7,'publisher (must be Mistral AI or authorized entity)','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(7,1,'Q7.R3',7,'direct link or citation to the source','unresolved','no eligible claim exists yet','other');
INSERT INTO "report_gaps" VALUES(8,2,'Q1.R1',1,'RFC publication date for HTTP/2','partially_addressed','The claim states June 2022 but does not provide the specific day of publication','date');
INSERT INTO "report_gaps" VALUES(9,2,'Q1.R2',1,'RFC number for HTTP/2','addressed','','none');
INSERT INTO "report_gaps" VALUES(10,2,'Q2.R1',2,'RFC publication date for HTTP/3','unresolved','No RFC publication date provided for HTTP/3','date');
INSERT INTO "report_gaps" VALUES(11,2,'Q2.R2',2,'RFC number for HTTP/3','unresolved','No RFC number provided for HTTP/3','primary_documentation');
INSERT INTO "report_gaps" VALUES(12,2,'Q3.R1',3,'name of transport protocol used by HTTP/2','unresolved','No explicit statement of the transport protocol name used by HTTP/2 is provided in the claims','detail');
INSERT INTO "report_gaps" VALUES(13,2,'Q3.R2',3,'description of how HTTP/2 uses TCP','unresolved','No description of how HTTP/2 uses TCP is provided; the claims only mention that HTTP/2 uses TLS and that it uses TCP as transport, but do not describe the manner or mechanism of that use','detail');
INSERT INTO "report_gaps" VALUES(14,2,'Q4.R1',4,'name of transport protocol used by HTTP/3','addressed','','none');
INSERT INTO "report_gaps" VALUES(15,2,'Q4.R2',4,'description of HTTP/3''s use of QUIC instead of TCP','addressed','','none');
CREATE TABLE report_omissions (
    id INTEGER PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES reports(id),
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    reason TEXT NOT NULL,
    UNIQUE (report_id, claim_id)
);
CREATE TABLE report_relevance (
    report_id INTEGER PRIMARY KEY REFERENCES reports(id),
    judged INTEGER NOT NULL,
    coverage_round INTEGER
);
CREATE TABLE report_sections (
    id INTEGER PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES reports(id),
    position INTEGER NOT NULL,
    label TEXT NOT NULL,
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    subquestion_text TEXT NOT NULL,
    UNIQUE (report_id, position)
);
INSERT INTO "report_sections" VALUES(1,1,1,'Section 1',5,'Has Mistral AI released an official financial statement or annual report for fiscal year 2024 that includes net profit or loss?');
INSERT INTO "report_sections" VALUES(2,1,2,'Section 2',6,'What is the net profit or net loss reported by Mistral AI for fiscal year 2024, if any?');
INSERT INTO "report_sections" VALUES(3,1,3,'Section 3',7,'Is there an official, publicly accessible document—such as an annual report, press release, or regulatory filing—published by Mistral AI that discloses the financial results for fiscal year 2024?');
INSERT INTO "report_sections" VALUES(4,2,1,'Section 1',1,'What is the publication date of the HTTP/2 specification as an RFC?');
INSERT INTO "report_sections" VALUES(5,2,2,'Section 2',2,'What is the publication date of the HTTP/3 specification as an RFC?');
INSERT INTO "report_sections" VALUES(6,2,3,'Section 3',3,'Which transport layer protocol does HTTP/2 use?');
INSERT INTO "report_sections" VALUES(7,2,4,'Section 4',4,'Which transport layer protocol does HTTP/3 use and how does it differ from HTTP/2''s transport?');
CREATE TABLE reports (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    outcome TEXT NOT NULL CHECK (outcome IN ('insufficient_evidence', 'claims_with_gaps', 'claims_all_requirements_addressed')),
    coverage_round INTEGER,
    corrective_rounds INTEGER NOT NULL,
    stop_reason TEXT,
    ordering TEXT NOT NULL CHECK (ordering IN ('model', 'deterministic')),
    ordering_reason TEXT,
    model TEXT,
    model_call_id INTEGER REFERENCES model_calls(id),
    created_at TEXT NOT NULL
);
INSERT INTO "reports" VALUES(1,2,'insufficient_evidence',1,1,'no progress: the eligible claims and every requirement status are unchanged','deterministic','no eligible claims: no synthesis call needed',NULL,NULL,'2026-10-22T14:06:31+00:00');
INSERT INTO "reports" VALUES(2,1,'claims_with_gaps',1,1,'search budget exhausted (0 of 0 searches used); 5 unmet requirement(s) could not be researched','deterministic','synthesizer not called: search budget exhausted (0 of 0 searches used); 5 unmet requirement(s) could not be researched',NULL,NULL,'2026-10-22T14:47:25+00:00');
CREATE TABLE research_selections (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    search_id INTEGER REFERENCES searches(id),
    url TEXT NOT NULL,
    reason TEXT,
    outcome TEXT NOT NULL,
    source_id INTEGER REFERENCES sources(id),
    fetch_attempt_id INTEGER REFERENCES fetch_attempts(id),
    created_at TEXT NOT NULL
);
INSERT INTO "research_selections" VALUES(1,1,1,1,'https://datatracker.ietf.org/doc/html/rfc9113','This is the official RFC 9113 document for HTTP/2, which provides the definitive publication date (June 2022) and confirms it obsoletes RFC 7540, the original HTTP/2 specification.','ok',1,1,'2026-10-22T13:59:21+00:00');
INSERT INTO "research_selections" VALUES(2,1,2,2,'https://en.wikipedia.org/wiki/HTTP/3','States that HTTP/3 was published as RFC 9114 on 6 June 2022, providing both the RFC number and publication date.','ok',2,2,'2026-10-22T14:00:00+00:00');
INSERT INTO "research_selections" VALUES(3,1,2,2,'https://datatracker.ietf.org/doc/draft-ietf-quic-http/33','Confirms the document was ultimately published as RFC 9114, giving context to the final RFC number and its development timeline.','ok',3,3,'2026-10-22T14:00:02+00:00');
INSERT INTO "research_selections" VALUES(4,1,2,2,'https://news.ycombinator.com/item?id=31647033','Mentions the publication of RFC 9114 and notes the date context around June 7, 2022, supporting the publication date of the HTTP/3 specification.','ok',4,4,'2026-10-22T14:00:03+00:00');
INSERT INTO "research_selections" VALUES(5,1,3,3,'https://datatracker.ietf.org/doc/html/rfc9113','This is the official IETF specification for HTTP/2, which directly states that HTTP/2 uses TCP and describes how it operates over a single, persistent TCP connection for multiplexed communication.','duplicate_url',1,5,'2026-10-22T14:00:42+00:00');
INSERT INTO "research_selections" VALUES(6,1,3,3,'https://http2.github.io','This page references the core HTTP/2 specifications including RFC 9113, providing authoritative links and context on how HTTP/2 uses TCP for efficient, multiplexed transport.','ok',5,6,'2026-10-22T14:00:42+00:00');
INSERT INTO "research_selections" VALUES(7,1,3,3,'https://www.imperva.com/learn/performance/http2','This reputable explanatory article describes how HTTP/2 uses a single TCP connection to enable multiplexing, solving inefficiencies present in HTTP/1.1.','ok',6,7,'2026-10-22T14:00:48+00:00');
INSERT INTO "research_selections" VALUES(8,1,4,5,'https://en.wikipedia.org/wiki/HTTP/3','Provides the name of the transport protocol used by HTTP/3 and explains its use of QUIC instead of TCP.','duplicate_url',2,8,'2026-10-22T14:01:28+00:00');
INSERT INTO "research_selections" VALUES(9,1,4,5,'https://www.cloudflare.com/learning/performance/what-is-http3','Describes HTTP/3''s use of QUIC over UDP and contrasts it with TCP used in previous versions.','ok',7,9,'2026-10-22T14:01:30+00:00');
INSERT INTO "research_selections" VALUES(10,1,4,5,'https://www.fastly.com/learning/what-is-http-3','Explains that HTTP/3 uses QUIC as its [withheld], and details how it changes connection management.','ok',8,10,'2026-10-22T14:01:31+00:00');
CREATE TABLE runs (
    id INTEGER PRIMARY KEY,
    question TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    stop_reason TEXT,
    verify_status TEXT NOT NULL DEFAULT 'not_started',
    verify_stop_reason TEXT,
    complete_status TEXT NOT NULL DEFAULT 'not_started',
    complete_stop_reason TEXT
);
INSERT INTO "runs" VALUES(1,'When were HTTP/2 and HTTP/3 published as RFCs, and how do their transport layers differ?','collection_finished','2026-10-22T13:58:14+00:00','2026-10-22T14:47:25+00:00',NULL,'completed',NULL,'stopped','search budget exhausted (0 of 0 searches used); 5 unmet requirement(s) could not be researched');
INSERT INTO "runs" VALUES(2,'Has Mistral AI publicly reported a net profit or loss for fiscal year 2024, and if so, what is the figure and which primary source states it?','collection_finished','2026-10-22T14:03:31+00:00','2026-10-22T14:06:31+00:00',NULL,'completed',NULL,'completed','no progress: the eligible claims and every requirement status are unchanged');
CREATE TABLE searches (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    subquestion_id INTEGER REFERENCES subquestions(id),
    query TEXT NOT NULL,
    provider TEXT NOT NULL,
    created_at TEXT NOT NULL,
    result_json TEXT,
    error TEXT
);
INSERT INTO "searches" VALUES(1,1,1,'HTTP/2 RFC publication date official specification','tavily','2026-10-22T13:59:10+00:00','{"hits": [{"title": "HTTP/2 - Wikipedia", "url": "https://en.wikipedia.org/wiki/HTTP/2", "snippet": "The Working Group presented HTTP/2 to the Internet Engineering Steering Group (IESG) for consideration as a Proposed Standard in December 2014, and IESG approved it to publish as Proposed Standard on February 17, 2015 (and was updated in February 2020 in regard to TLS 1.3 and again in June 2022). The initial HTTP/2 specification was published as RFC 7540 on May 14, 2015. [...] as an attack, and protocols designed by IETF should take steps to protect against passive monitoring (for example, through the use of opportunistic encryption). A number of specifications for opportunistic encryption of HTTP/2 have been provided, of which draft-nottingham-http2-encryption was adopted as an official work item of the working group, leading to the publication of RFC \"RFC (identifier)\") 8164 in May 2017. [...] | December 31, 2014 – January 14, 2015 | IETF Last Call for HTTP/2 |\n| January 22, 2015 | IESG telechat to review HTTP/2 as Proposed Standard |\n| February 17, 2015 | IESG approved HTTP/2 to publish as Proposed Standard |\n| May 14, 2015 | Publish HTTP/2 as RFC \"RFC (identifier)\") 7540 |\n| February 2020 | RFC \"RFC (identifier)\") 8740: HTTP/2 with TLS 1.3 |\n| June 2022 | RFC \"RFC (identifier)\") 9113: Further refinements |\n| April 2024 | DOS issues with CONTINUATION frames  |", "score": 0.8524574}, {"title": "The Evolution of HTTP – HTTP/2 Deep Dive", "url": "https://ably.com/topic/http2", "snippet": "[snippet withheld in the public demo]", "score": 0.73642004}, {"title": "HTTP/2 Specification Is Final · ma.ttias.be", "url": "https://ma.ttias.be/the-http2-spec-is-final", "snippet": "[snippet withheld in the public demo]", "score": 0.71829855}, {"title": "RFC 9113 - HTTP/2", "url": "https://datatracker.ietf.org/doc/html/rfc9113", "snippet": "|  |  |  |\n --- \n| RFC 9113 | HTTP/2 | June 2022 |\n| Thomson & Benfield | Standards Track | [Page] |\n\nStream:\n:   Internet Engineering Task Force (IETF)\n\nRFC:\n:   9113\n\nObsoletes:\n:   7540, 8740\n\nCategory:\n:   Standards Track\n\nPublished:\n\nISSN:\n:   2070-1721\n\nAuthors:\n:   M. Thomson, Ed.\n\n    C. Benfield, Ed.\n\n    Apple Inc.\n\n# RFC 9113\n\n# HTTP/2\n\n## Abstract [...] [RFC7323]\n:   Borman, D., Braden, B., Jacobson, V., and R. Scheffenegger, Ed., \"TCP Extensions for High Performance\", RFC 7323, DOI 10.17487/RFC7323, , <>.\n\n[RFC7540]\n:   Belshe, M., Peon, R., and M. Thomson, Ed., \"Hypertext Transfer Protocol Version 2 (HTTP/2)\", RFC 7540, DOI 10.17487/RFC7540, , <>.\n\n[RFC8441]\n:   McManus, P., \"Bootstrapping WebSockets with HTTP/2\", RFC 8441, DOI 10.17487/RFC8441, , <>. [...] |  |  |  |\n --- \n| Document | Document type | RFC - Proposed Standard   June 2022    View errata   Report errata  Obsoletes RFC 8740, RFC 7540\")  Was draft-ietf-httpbis-http2bis (httpbis WG) |\n| Select version |  00  01  02  03  04  05  06  07  RFC 9113 |\n| Compare versions |  |\n| Authors |  | M. Thomson , C. Benfield    Email authors |\n| RFC stream |  | IETF Logo IETF Logo |\n| Other formats |  | txt   html   xml   pdf   w/errata   bibtex |", "score": 0.67885995}, {"title": "RFC 8336 - The ORIGIN HTTP/2 Frame", "url": "https://httpwg.org/specs/rfc8336.html", "snippet": "[snippet withheld in the public demo]", "score": 0.63316137}], "usage": {"credits": 1}, "request_id": "c07c50a8-9a67-4fe2-88d1-defe507e047b"}',NULL);
INSERT INTO "searches" VALUES(2,1,2,'HTTP/3 RFC publication date official specification','tavily','2026-10-22T13:59:32+00:00','{"hits": [{"title": "HTTP/3 - Wikipedia", "url": "https://en.wikipedia.org/wiki/HTTP/3", "snippet": "On 6 June 2022, IETF published HTTP/3 as a Proposed Standard in RFC 9114.\n\n## Comparison with HTTP/1.1 and HTTP/2\n\n[edit] [...] 1. 1 2 M. Bishop, ed. (June 2022). HTTP/3. Internet Engineering Task Force. doi \"Doi (identifier)\"):10.17487/RFC9114. ISSN \"ISSN (identifier)\") 2070-1721. RFC \"RFC (identifier)\") 9114. Proposed Standard.\n2. ↑ V. Cerf; Y. Dalal; C. Sunshine (December 1974). SPECIFICATION OF INTERNET TRANSMISSION CONTROL PROGRAM. Network Working Group. doi \"Doi (identifier)\"):10.17487/RFC0675. RFC \"RFC (identifier)\") 675. Obsolete. Obsoleted by RFC 7805. NIC 2. INWG 72. [...] HTTP/3\n\n| International standard | RFC \"RFC (identifier)\") 9114 (HTTP/3 also uses the completed QUIC protocol described in RFC 9000 and related RFCs such as RFC 9001) |\n| Developed by | IETF |\n| Introduced | June 2022 |\n| Website |  |", "score": 0.83093774}, {"title": "HTTP/3: From root to tip | Cloudflare Blog", "url": "https://blog.cloudflare.com/http-3-from-root-to-tip", "snippet": "[snippet withheld in the public demo]", "score": 0.72884524}, {"title": "draft-ietf-quic-http-33 - Hypertext Transfer Protocol Version 3 (HTTP/3)", "url": "https://datatracker.ietf.org/doc/draft-ietf-quic-http/33", "snippet": "|  |  |  |\n --- \n| Document | Type | This is an older version of an Internet-Draft that was ultimately published as RFC 9114. |\n| Author |  | Mike Bishop |\n| Last updated | 2021-01-21 (Latest revision 2020-12-15) |\n| Replaces |  | draft-shade-quic-http2-mapping |\n| RFC stream |  | Internet Engineering Task Force (IETF) |\n| Formats |  | txt   html   xml   htmlized   bibtex   bibxml | [...] 18 June 2021 [Page 59]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 60]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 61]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 62]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 63]Internet-Draft HTTP/3 December 2020Appendix B. Change LogBishop Expires 18 June 2021 [Page 64]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 65]Internet-Draft HTTP/3 [...] 18 June 2021 [Page 20]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 21]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 22]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 23]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 24]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 25]Internet-Draft HTTP/3 December 2020Bishop Expires 18 June 2021 [Page 26]Internet-Draft HTTP/3 December 2020Bishop", "score": 0.650934}, {"title": "RFC 9114 – HTTP/3 | Hacker News", "url": "https://news.ycombinator.com/item?id=31647033", "snippet": "[snippet withheld in the public demo]", "score": 0.63316137}, {"title": "RFC 9412 - The ORIGIN Extension in HTTP/3", "url": "https://httpwg.org/specs/rfc9412.html", "snippet": "[snippet withheld in the public demo]", "score": 0.604703}], "usage": {"credits": 1}, "request_id": "c374ffbb-8133-4eb3-8b80-02bf0c169d12"}',NULL);
INSERT INTO "searches" VALUES(3,1,3,'HTTP/2 transport layer protocol official documentation','tavily','2026-10-22T14:00:13+00:00','{"hits": [{"title": "RFC 9113 - HTTP/2", "url": "https://datatracker.ietf.org/doc/html/rfc9113", "snippet": "This document obsoletes RFCs 7540 and 8740. Appendix B lists notable changes.¶\n\n## 2. HTTP/2 Protocol Overview\n\nHTTP/2 provides an optimized transport for HTTP semantics. HTTP/2 supports all of the core features of HTTP but aims to be more efficient than HTTP/1.1.¶\n\nHTTP/2 is a connection-oriented application-layer protocol that runs over a TCP connection ([TCP]). The client is the TCP connection initiator.¶ [...] The protocol defined in this document has two identifiers. Creating a connection based on either implies the use of the transport, framing, and message semantics described in this document.¶\n\n The string \"h2\" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS); see Section 9.2. This identifier is used in the TLS Application-Layer Protocol Negotiation (ALPN) extension [TLS-ALPN] field and in any place where HTTP/2 over TLS is identified.¶ [...] [TLS12]\n:   Dierks, T. and E. Rescorla, \"The Transport Layer Security (TLS) Protocol Version 1.2\", RFC 5246, DOI 10.17487/RFC5246, , <>.\n\n[TLS13]\n:   Rescorla, E., \"The Transport Layer Security (TLS) Protocol Version 1.3\", RFC 8446, DOI 10.17487/RFC8446, , <>.\n\n[TLSBCP]\n:   Sheffer, Y., Holz, R., and P. Saint-Andre, \"Recommendations for Secure Use of Transport Layer Security (TLS) and Datagram Transport Layer Security (DTLS)\", BCP 195, RFC 7525, DOI 10.17487/RFC7525, , <>.", "score": 0.66699636}, {"title": "HTTP/2 | Node.js v26.12.0 Documentation", "url": "https://nodejs.org/api/http2.html", "snippet": "[snippet withheld in the public demo]", "score": 0.575517}, {"title": "HTTP/2 Protocol | Junos OS | Juniper Networks", "url": "https://www.juniper.net/documentation/us/en/software/junos/application-identification/topics/topic-map/http2-protocol.html", "snippet": "[snippet withheld in the public demo]", "score": 0.5097406}, {"title": "HTTP/2", "url": "https://http2.github.io", "snippet": "[snippet withheld in the public demo]", "score": 0.46993434}, {"title": "What is HTTP/2 | How it Differs from HTTP/1.1 and SPDY | Imperva", "url": "https://www.imperva.com/learn/performance/http2", "snippet": "[snippet withheld in the public demo]", "score": 0.4179133}], "usage": {"credits": 1}, "request_id": "f3f1e69e-aa40-4128-82c9-168b357273c8"}',NULL);
INSERT INTO "searches" VALUES(4,1,3,'how does HTTP/2 use TCP specification','tavily','2026-10-22T14:00:15+00:00','{"hits": [{"title": "HTTP/2: 5 things every Enterprise Architect needs to know", "url": "https://www.redhat.com/en/blog/http2", "snippet": "[snippet withheld in the public demo]", "score": 0.7306941}, {"title": "Why does app using HTTP/2 only establish one TCP connection?", "url": "https://stackoverflow.com/questions/67554142/why-does-app-using-http-2-only-establish-one-tcp-connection", "snippet": "[snippet withheld in the public demo]", "score": 0.7295395}, {"title": "RFC 7540 - Hypertext Transfer Protocol Version 2 (HTTP/2)", "url": "https://httpwg.org/specs/rfc7540.html", "snippet": "[snippet withheld in the public demo]", "score": 0.72231215}, {"title": "RFC 9113 - HTTP/2", "url": "https://datatracker.ietf.org/doc/html/rfc9113", "snippet": "The TCP connection can be closed by either peer. The END\\_STREAM flag on a DATA frame is treated as being equivalent to the TCP FIN bit. A client is expected to send a DATA frame with the END\\_STREAM flag set after receiving a frame with the END\\_STREAM flag set. A proxy that receives a DATA frame with the END\\_STREAM flag set sends the attached data with the FIN bit set on the last TCP segment. A proxy that receives a TCP segment with the FIN bit set sends a DATA frame with the END\\_STREAM [...] The resulting protocol is more friendly to the network because fewer TCP connections can be used in comparison to HTTP/1.x. This means less competition with other flows and longer-lived connections, which in turn lead to better utilization of available network capacity. Note, however, that TCP head-of-line blocking is not addressed by this protocol.¶\n\nFinally, HTTP/2 also enables more efficient processing of messages through use of binary message framing.¶ [...] A client that knows that a server supports HTTP/2 can establish a TCP connection and send the connection preface (Section 3.4) followed by HTTP/2 frames. Servers can identify these connections by the presence of the connection preface. This only affects the establishment of HTTP/2 connections over cleartext TCP; HTTP/2 connections over TLS MUST use protocol negotiation in TLS [TLS-ALPN].¶\n\nLikewise, the server MUST send a connection preface (Section 3.4).¶", "score": 0.7159213}, {"title": "What is HTTP/2 | How it Differs from HTTP/1.1 and SPDY | Imperva", "url": "https://www.imperva.com/learn/performance/http2", "snippet": "[snippet withheld in the public demo]", "score": 0.7089592}], "usage": {"credits": 1}, "request_id": "425ba5ae-c818-43a3-a2d5-5bbe3fc484c5"}',NULL);
INSERT INTO "searches" VALUES(5,1,4,'What transport protocol does HTTP/3 use instead of TCP','tavily','2026-10-22T14:01:03+00:00','{"hits": [{"title": "HTTP/3 - Wikipedia", "url": "https://en.wikipedia.org/wiki/HTTP/3", "snippet": "HTTP/3 is the third major version of the Hypertext Transfer Protocol used to exchange information on the World Wide Web, complementing the widely deployed HTTP/1.1 and HTTP/2. Unlike previous versions which relied on the well-established TCP (published in 1974), HTTP/3 uses QUIC (officially introduced in 2021), a multiplexed transport protocol built on UDP. [...] HTTP semantics are consistent across versions: the same request methods, status codes, and message fields are typically applicable to all versions. The differences are in the mapping of these semantics to underlying transports. Both HTTP/1.1 and HTTP/2 use TCP as their transport. HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP). The switch to QUIC aims to fix a major problem of HTTP/2 called \"head-of-line", "score": 0.94339466}, {"title": "What Is HTTP/3? Key Features, Benefits - Fastly | Fastly", "url": "https://www.fastly.com/learning/what-is-http-3", "snippet": "[snippet withheld in the public demo]", "score": 0.939919}, {"title": "What is HTTP/3?", "url": "https://www.cloudflare.com/learning/performance/what-is-http3", "snippet": "[snippet withheld in the public demo]", "score": 0.9328032}, {"title": "A Closer Look at HTTP/3 & QUIC", "url": "https://medium.com/@gtamilarasan/a-closer-look-at-http3-quic-1b2b97a5cd50", "snippet": "[snippet withheld in the public demo]", "score": 0.90289277}, {"title": "Is HTTP/3 the Future of the Web?", "url": "https://deliciousbrains.com/is-http-3-the-future-of-the-web", "snippet": "[snippet withheld in the public demo]", "score": 0.90289277}], "usage": {"credits": 1}, "request_id": "16ac1716-2daf-40e8-be1d-88a3ebf580d9"}',NULL);
INSERT INTO "searches" VALUES(6,1,4,'How does HTTP/3 use QUIC compared to HTTP/2''s TCP','tavily','2026-10-22T14:01:06+00:00','{"hits": [{"title": "HTTP/2 vs. HTTP/3 - LogicMonitor", "url": "https://www.logicmonitor.com/deep-dive/http3-vs-http2/introduction", "snippet": "[snippet withheld in the public demo]", "score": 0.9409691}, {"title": "HTTP/2 vs HTTP/3: A look at key differences and similarities", "url": "https://ably.com/topic/http-2-vs-http-3", "snippet": "[snippet withheld in the public demo]", "score": 0.9123193}, {"title": "A Closer Look at HTTP/3 & QUIC", "url": "https://medium.com/@gtamilarasan/a-closer-look-at-http3-quic-1b2b97a5cd50", "snippet": "[snippet withheld in the public demo]", "score": 0.88564163}, {"title": "TIL: HTTP/3 Is Not Always Faster Than HTTP/2 - Ian Duncan", "url": "https://iankduncan.com/engineering/2026-02-10-http3-not-always-faster", "snippet": "[snippet withheld in the public demo]", "score": 0.8679453}, {"title": "What is HTTP/3?", "url": "https://www.cloudflare.com/learning/performance/what-is-http3", "snippet": "[snippet withheld in the public demo]", "score": 0.8488849}], "usage": {"credits": 1}, "request_id": "d0a134fd-9c00-4437-8fae-a4b4dda2aa56"}',NULL);
INSERT INTO "searches" VALUES(7,2,5,'Mistral AI official financial statement 2024 release','tavily','2026-10-22T14:04:41+00:00','{"hits": [{"title": "Mistral AI - Wikipedia", "url": "https://en.wikipedia.org/wiki/Mistral_AI", "snippet": "In June 2024, Mistral AI secured a €600 million ($645 million) funding round, increasing its valuation to €5.8 billion ($6.2 billion). Based on valuation, as of June 2024, the company was ranked fourth globally in the AI industry, and first outside the San Francisco Bay Area.\n\nIn April 2025, Mistral AI announced a €100 million partnership with the shipping company CMA CGM. [...] On 26 February 2024, Microsoft announced an investment of $16 million in Mistral AI.\n\nOn 16 April 2024, reporting revealed that Mistral was in talks to raise €500 million, a deal that would more than double its current valuation to at least €5 billion. [...] | Mixtral 8x22B | April 2024 | ? | 141 | Apache-2.0 | Similar to Mistral''s previous open models, Mixtral 8x22B was released via a BitTorrent link on Twitter on April 10, 2024, with a release on Hugging Face soon after. The model uses an architecture similar to that of Mistral 8x7B, but with each expert having 22 billion parameters instead of 7. In total, the model contains 141 billion parameters, as some parameters are shared among the experts, but offering higher performance. |", "score": 0.8884594}, {"title": "MISTRAL AI UK LTD filing history - Find and update company information - GOV.UK", "url": "https://find-and-update.company-information.service.gov.uk/company/14894136/filing-history", "snippet": "[snippet withheld in the public demo]", "score": 0.8184036}, {"title": "Mistral Stock Price, Funding, Valuation, Revenue & Financial Statements", "url": "https://www.cbinsights.com/company/mistral-ai/financials", "snippet": "[snippet withheld in the public demo]", "score": 0.78611463}, {"title": "Is AI Profitable: Mistral’s Path Toward Profit [Analysis] [2026] - Klover.ai", "url": "https://www.klover.ai/is_ai_profitable_mistrals_path_toward_profit_analysis_2026", "snippet": "[snippet withheld in the public demo]", "score": 0.71305263}, {"title": "Mistral revenue, valuation & funding | Sacra", "url": "https://sacra.com/c/mistral", "snippet": "[snippet withheld in the public demo]", "score": 0.68748367}], "usage": {"credits": 1}, "request_id": "56db6f7b-4a24-4259-9713-911f31a5db71"}',NULL);
INSERT INTO "searches" VALUES(8,2,5,'Mistral AI annual report 2024 net profit or loss','tavily','2026-10-22T14:04:45+00:00','{"hits": [{"title": "goog-20241231", "url": "https://www.sec.gov/Archives/edgar/data/1652044/000165204425000014/goog-20241231.htm", "snippet": "[snippet withheld in the public demo]", "score": 0.53692055}, {"title": "AI: Consolidated Financial Statements (ChatGPT, Claude, Deepseek, and Qwen)", "url": "https://www.youtube.com/watch?v=x88E47SuUIk", "snippet": "[snippet withheld in the public demo]", "score": 0.5150107}, {"title": "2024 Annual Report", "url": "https://www.msci.com/downloads/web/msci-com/annuals-and-proxies/2024-annual-report/MSCI%202024%20Annual%20Report.pdf", "snippet": "[snippet withheld in the public demo]", "score": 0.4920179}, {"title": "ANNUAL RESULTS ANNOUNCEMENT FOR THE YEAR ...", "url": "https://ir.mi.com/system/files-encrypted/nasdaq_kms/assets/2025/03/18/5-38-56/%E8%8B%B1%E6%96%87%E5%85%AC%E5%91%8A.pdf", "snippet": "[snippet withheld in the public demo]", "score": 0.4572585}, {"title": "2024 ANNUAL REPORT", "url": "https://filecache.investorroom.com/mr5ir_genuineparts/978/2024%20Annual%20Report.pdf", "snippet": "[snippet withheld in the public demo]", "score": 0.40967003}], "usage": {"credits": 1}, "request_id": "2c7ef582-8e3d-4703-a0c7-43640d629f11"}',NULL);
INSERT INTO "searches" VALUES(9,2,6,'Mistral AI net profit 2024 fiscal year reported financial results','tavily','2026-10-22T14:05:04+00:00','{"hits": [{"title": "Mistral AI - Wikipedia", "url": "https://en.wikipedia.org/wiki/Mistral_AI", "snippet": "In June 2024, Mistral AI secured a €600 million ($645 million) funding round, increasing its valuation to €5.8 billion ($6.2 billion). Based on valuation, as of June 2024, the company was ranked fourth globally in the AI industry, and first outside the San Francisco Bay Area.\n\nIn April 2025, Mistral AI announced a €100 million partnership with the shipping company CMA CGM. [...] On 26 February 2024, Microsoft announced an investment of $16 million in Mistral AI.\n\nOn 16 April 2024, reporting revealed that Mistral was in talks to raise €500 million, a deal that would more than double its current valuation to at least €5 billion. [...] 19. ↑ Bratton, Laura (12 June 2024). \"OpenAI''s French rival Mistral AI is now worth $6 billion. That''s still a fraction of its top competitors\". Quartz (publication) \"Quartz (publication)\"). Retrieved 13 June 2024.\n20. ↑ \"CMA CGM et Mistral AI nouent un partenariat de 100 millions d''euros dans l''intelligence artificielle\". Le Figaro (in French). 6 April 2025. Retrieved 24 June 2025.", "score": 0.81595254}, {"title": "Is AI Profitable: Mistral’s Path Toward Profit [Analysis] [2026] - Klover.ai", "url": "https://www.klover.ai/is_ai_profitable_mistrals_path_toward_profit_analysis_2026", "snippet": "[snippet withheld in the public demo]", "score": 0.80405265}, {"title": "Mistral AI Revenue 2026: $400M ARR, $23B Est. Valuation", "url": "https://getlatka.com/companies/mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.6836946}, {"title": "Mistral AI Statistics 2026: Users, Revenue & Growth", "url": "https://www.getpanto.ai/blog/mistral-ai-statistics", "snippet": "[snippet withheld in the public demo]", "score": 0.67037153}, {"title": "Mistral AI Surpasses $400M Revenue, 20x Growth in One Year | Rubén Domínguez Ibar posted on the topic | LinkedIn", "url": "https://www.linkedin.com/posts/rubendominguezibar_mistral-ai-just-20xd-revenue-in-one-year-activity-7428162306221469696-oXL4", "snippet": "[snippet withheld in the public demo]", "score": 0.62248284}], "usage": {"credits": 1}, "request_id": "1a8c6f41-a966-4d07-8afd-2eaebbd31a16"}',NULL);
INSERT INTO "searches" VALUES(10,2,6,'Mistral AI net loss 2024 official financial statement release','tavily','2026-10-22T14:05:06+00:00','{"hits": [{"title": "Is AI Profitable: Mistral’s Path Toward Profit [Analysis] [2026] - Klover.ai", "url": "https://www.klover.ai/is_ai_profitable_mistrals_path_toward_profit_analysis_2026", "snippet": "[snippet withheld in the public demo]", "score": 0.78334314}, {"title": "Mistral AI - Wikipedia", "url": "https://en.wikipedia.org/wiki/Mistral_AI", "snippet": "In June 2024, Mistral AI secured a €600 million ($645 million) funding round, increasing its valuation to €5.8 billion ($6.2 billion). Based on valuation, as of June 2024, the company was ranked fourth globally in the AI industry, and first outside the San Francisco Bay Area.\n\nIn April 2025, Mistral AI announced a €100 million partnership with the shipping company CMA CGM. [...] On 26 February 2024, Microsoft announced an investment of $16 million in Mistral AI.\n\nOn 16 April 2024, reporting revealed that Mistral was in talks to raise €500 million, a deal that would more than double its current valuation to at least €5 billion. [...] | Mixtral 8x22B | April 2024 | ? | 141 | Apache-2.0 | Similar to Mistral''s previous open models, Mixtral 8x22B was released via a BitTorrent link on Twitter on April 10, 2024, with a release on Hugging Face soon after. The model uses an architecture similar to that of Mistral 8x7B, but with each expert having 22 billion parameters instead of 7. In total, the model contains 141 billion parameters, as some parameters are shared among the experts, but offering higher performance. |", "score": 0.7418428}, {"title": "Mistral AI Revenue 2026: $400M ARR, $23B Est. Valuation", "url": "https://getlatka.com/companies/mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.5518883}, {"title": "Mistral AI raises 1.7B€ to accelerate technological progress with AI | Mistral AI", "url": "https://mistral.ai/news/mistral-ai-raises-1-7-b-to-accelerate-technological-progress-with-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.50930125}, {"title": "Mistral AI Statistics 2026: Users, Revenue & Growth", "url": "https://www.getpanto.ai/blog/mistral-ai-statistics", "snippet": "[snippet withheld in the public demo]", "score": 0.49187145}], "usage": {"credits": 1}, "request_id": "0ada4568-cf7b-4699-ad2a-dd62e0de8b88"}',NULL);
INSERT INTO "searches" VALUES(11,2,7,'Mistral AI official annual report 2024 financial results','tavily','2026-10-22T14:05:42+00:00','{"hits": [{"title": "9 Mistral AI Statistics (2025): Revenue, Valuation, Funding, Competitors, Investors, Context Window, Employees", "url": "https://taptwicedigital.com/stats/mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.9336793}, {"title": "Mistral AI — Company profile — Silicon Valley Investclub", "url": "https://siliconvalleyinvestclub.com/companies/mistral/tear-sheet.pdf", "snippet": "[snippet withheld in the public demo]", "score": 0.854509}, {"title": "Mistral AI surges revenue 20-fold to over $400 million ARR amid Europe''s AI push | MLQ News", "url": "https://mlq.ai/news/mistral-ai-surges-revenue-20-fold-to-over-400-million-arr-amid-europes-ai-push", "snippet": "[snippet withheld in the public demo]", "score": 0.84183896}, {"title": "Report: Mistral AI Business Breakdown & Founding Story | Contrary Research", "url": "https://research.contrary.com/company/mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.81595254}, {"title": "Who Owns Mistral AI? What the Company''s Own Filings Show - MRKT3.0", "url": "https://mrkt30.com/who-owns-mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.79845446}], "usage": {"credits": 1}, "request_id": "96bb705f-1e11-4b6c-adb1-597983a9756c"}',NULL);
INSERT INTO "searches" VALUES(12,2,7,'Mistral AI press release or regulatory filing fiscal year 2024 financial disclosure','tavily','2026-10-22T14:05:46+00:00','{"hits": [{"title": "ai-20240430", "url": "https://www.sec.gov/Archives/edgar/data/1577526/000162828024028786/ai-20240430.htm", "snippet": "[snippet withheld in the public demo]", "score": 0.82694983}, {"title": "Mistral AI - Wikipedia", "url": "https://en.wikipedia.org/wiki/Mistral_AI", "snippet": "On 26 February 2024, Microsoft announced an investment of $16 million in Mistral AI.\n\nOn 16 April 2024, reporting revealed that Mistral was in talks to raise €500 million, a deal that would more than double its current valuation to at least €5 billion. [...] In June 2024, Mistral AI secured a €600 million ($645 million) funding round, increasing its valuation to €5.8 billion ($6.2 billion). Based on valuation, as of June 2024, the company was ranked fourth globally in the AI industry, and first outside the San Francisco Bay Area.\n\nIn April 2025, Mistral AI announced a €100 million partnership with the shipping company CMA CGM. [...] | Mistral Large 2 24.11 | November 2024 | ? | 123 | Mistral Research License |  |\n| Pixtral Large 24.11 | November 2024 | ? | 124 | Mistral Research License | On November 19, 2024, the company introduced Pixtral Large, which integrates a 1-billion-parameter visual encoder coupled with Mistral Large 2. |\n| Ministral 8B 24.10 | October 2024 | ? | 8 | Mistral Research License |  |\n| Ministral 3B 24.10 | October 2024 | ? | 3 | Proprietary |  |", "score": 0.82117355}, {"title": "Mistral AI raises 1.7B€ to accelerate technological progress with AI | Mistral AI", "url": "https://mistral.ai/news/mistral-ai-raises-1-7-b-to-accelerate-technological-progress-with-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.635879}, {"title": "Making sovereign, open-weight AI the technology frontier | Mistral", "url": "https://mistral.ai/news/mistral-makes-sovereign-open-weight-ai-to-frontier", "snippet": "[snippet withheld in the public demo]", "score": 0.5726516}, {"title": "Mistral AI $2B Series C: US Investor Access Guide", "url": "https://angelinvestorsnetwork.com/venture-capital/mistral-ai-1-7-billion-series-c-us-accredited-investor-access-analysis", "snippet": "[snippet withheld in the public demo]", "score": 0.56690645}], "usage": {"credits": 1}, "request_id": "7b297ddf-1ffd-4ddf-9107-0eec324288b0"}',NULL);
INSERT INTO "searches" VALUES(13,2,5,'Mistral AI official financial statement 2024 release announcement','tavily','2026-10-22T14:06:09+00:00','{"hits": [{"title": "Mistral AI - Wikipedia", "url": "https://en.wikipedia.org/wiki/Mistral_AI", "snippet": "On 26 February 2024, Microsoft announced an investment of $16 million in Mistral AI.\n\nOn 16 April 2024, reporting revealed that Mistral was in talks to raise €500 million, a deal that would more than double its current valuation to at least €5 billion. [...] In June 2024, Mistral AI secured a €600 million ($645 million) funding round, increasing its valuation to €5.8 billion ($6.2 billion). Based on valuation, as of June 2024, the company was ranked fourth globally in the AI industry, and first outside the San Francisco Bay Area.\n\nIn April 2025, Mistral AI announced a €100 million partnership with the shipping company CMA CGM. [...] 62. 1 2 AI, Mistral (16 July 2024). \"MathΣtral\". mistral.ai. Retrieved 16 July 2024.\n63. ↑ David, Emilia (16 July 2024). \"Mistral releases Codestral Mamba for faster, longer code generation\". VentureBeat. Retrieved 17 July 2024.\n64. ↑ Sharma, Shubham (29 May 2024). \"Mistral announces Codestral, its first programming focused AI model\". VentureBeat. Retrieved 30 May 2024.", "score": 0.8861155}, {"title": "Mistral Stock Price, Funding, Valuation, Revenue & Financial Statements", "url": "https://www.cbinsights.com/company/mistral-ai/financials", "snippet": "[snippet withheld in the public demo]", "score": 0.7827459}, {"title": "Mistral AI raises 1.7B€ to accelerate technological progress with AI | Mistral AI", "url": "https://mistral.ai/news/mistral-ai-raises-1-7-b-to-accelerate-technological-progress-with-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.7251239}, {"title": "Making sovereign, open-weight AI the technology frontier | Mistral", "url": "https://mistral.ai/news/mistral-makes-sovereign-open-weight-ai-to-frontier", "snippet": "[snippet withheld in the public demo]", "score": 0.6708892}, {"title": "Mistral revenue, valuation & funding | Sacra", "url": "https://sacra.com/c/mistral", "snippet": "[snippet withheld in the public demo]", "score": 0.6641271}], "usage": {"credits": 1}, "request_id": "669e1b45-af61-427e-905f-897c9a42f206"}',NULL);
INSERT INTO "searches" VALUES(14,2,5,'Mistral AI official financial statement 2024 net profit or loss','tavily','2026-10-22T14:06:27+00:00','{"hits": [{"title": "Is AI Profitable: Mistral’s Path Toward Profit [Analysis] [2026] - Klover.ai", "url": "https://www.klover.ai/is_ai_profitable_mistrals_path_toward_profit_analysis_2026", "snippet": "[snippet withheld in the public demo]", "score": 0.818055}, {"title": "MISTRAL AI UK LTD filing history - Find and update company information - GOV.UK", "url": "https://find-and-update.company-information.service.gov.uk/company/14894136/filing-history", "snippet": "[snippet withheld in the public demo]", "score": 0.7476348}, {"title": "Mistral AI Exceeds $24 Billion Valuation After Samsung-Led Investment Round", "url": "https://finance.yahoo.com/technology/ai/articles/mistral-ai-exceeds-24-billion-053400987.html", "snippet": "[snippet withheld in the public demo]", "score": 0.6899958}, {"title": "Mistral AI Revenue 2026: $400M ARR, $23B Est. Valuation", "url": "https://getlatka.com/companies/mistral-ai", "snippet": "[snippet withheld in the public demo]", "score": 0.6899958}, {"title": "Mistral revenue, valuation & funding | Sacra", "url": "https://sacra.com/c/mistral", "snippet": "[snippet withheld in the public demo]", "score": 0.59033114}], "usage": {"credits": 1}, "request_id": "26e52adf-cfb2-4969-9f55-29797f0170de"}',NULL);
CREATE TABLE source_associations (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    subquestion_id INTEGER NOT NULL REFERENCES subquestions(id),
    source_id INTEGER NOT NULL REFERENCES sources(id),
    origin TEXT NOT NULL,
    passage_ids TEXT NOT NULL DEFAULT '[]',
    explanation TEXT,
    verification TEXT NOT NULL DEFAULT 'unverified',
    created_at TEXT NOT NULL,
    UNIQUE (subquestion_id, source_id)
);
INSERT INTO "source_associations" VALUES(1,1,1,1,'selected_from_search','[]','This is the official RFC 9113 document for HTTP/2, which provides the definitive publication date (June 2022) and confirms it obsoletes RFC 7540, the original HTTP/2 specification.','unverified','2026-10-22T13:59:21+00:00');
INSERT INTO "source_associations" VALUES(2,1,2,2,'selected_from_search','[]','States that HTTP/3 was published as RFC 9114 on 6 June 2022, providing both the RFC number and publication date.','unverified','2026-10-22T14:00:00+00:00');
INSERT INTO "source_associations" VALUES(3,1,2,3,'selected_from_search','[]','Confirms the document was ultimately published as RFC 9114, giving context to the final RFC number and its development timeline.','unverified','2026-10-22T14:00:02+00:00');
INSERT INTO "source_associations" VALUES(4,1,2,4,'selected_from_search','[]','Mentions the publication of RFC 9114 and notes the date context around June 7, 2022, supporting the publication date of the HTTP/3 specification.','unverified','2026-10-22T14:00:03+00:00');
INSERT INTO "source_associations" VALUES(5,1,3,1,'selected_from_search','[]','This is the official IETF specification for HTTP/2, which directly states that HTTP/2 uses TCP and describes how it operates over a single, persistent TCP connection for multiplexed communication.','unverified','2026-10-22T14:00:42+00:00');
INSERT INTO "source_associations" VALUES(6,1,3,5,'selected_from_search','[]','This page references the core HTTP/2 specifications including RFC 9113, providing authoritative links and context on how HTTP/2 uses TCP for efficient, multiplexed transport.','unverified','2026-10-22T14:00:42+00:00');
INSERT INTO "source_associations" VALUES(7,1,3,6,'selected_from_search','[]','This reputable explanatory article describes how HTTP/2 uses a single TCP connection to enable multiplexing, solving inefficiencies present in HTTP/1.1.','unverified','2026-10-22T14:00:48+00:00');
INSERT INTO "source_associations" VALUES(8,1,4,2,'selected_from_search','[]','Provides the name of the transport protocol used by HTTP/3 and explains its use of QUIC instead of TCP.','unverified','2026-10-22T14:01:28+00:00');
INSERT INTO "source_associations" VALUES(9,1,4,7,'selected_from_search','[]','Describes HTTP/3''s use of QUIC over UDP and contrasts it with TCP used in previous versions.','unverified','2026-10-22T14:01:30+00:00');
INSERT INTO "source_associations" VALUES(10,1,4,8,'selected_from_search','[]','Explains that HTTP/3 uses QUIC as its [withheld], and details how it changes connection management.','unverified','2026-10-22T14:01:31+00:00');
CREATE TABLE sources (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    requested_url TEXT NOT NULL,
    final_url TEXT NOT NULL,
    title TEXT,
    retrieved_at TEXT NOT NULL,
    content_type TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    snapshot TEXT NOT NULL,
    UNIQUE (run_id, content_hash),
    UNIQUE (run_id, requested_url)
);
INSERT INTO "sources" VALUES(1,1,'https://datatracker.ietf.org/doc/html/rfc9113','https://datatracker.ietf.org/doc/html/rfc9113','RFC 9113 - HTTP/2','2026-10-22T13:59:21+00:00','text/html; charset=utf-8','845567d400f591cbfe9b413a642fe1c896274a28961ae3d3787c85a9498040bc','Light

Dark

Auto

RFC 9113

HTTP/2

June 2022

Thomson & Benfield

Standards Track

[Page]

Stream:

Internet Engineering Task Force (IETF)

RFC:

9113

Obsoletes:

7540, 8740

Category:

Standards Track

Published:

June 2022

ISSN:

2070-1721

Authors:

M. Thomson, Ed.

Mozilla

C. Benfield, Ed.

Apple Inc.

RFC 9113

HTTP/2

Abstract

This specification describes an optimized expression of the semantics of the Hypertext Transfer Protocol (HTTP), referred to as HTTP version 2 (HTTP/2). HTTP/2 enables a more efficient use of network resources and a reduced latency by introducing field compression and allowing multiple concurrent exchanges on the same connection.¶

This document obsoletes RFCs 7540 and 8740.¶

Status of This Memo

This is an Internet Standards Track document.¶

This document is a product of the Internet Engineering Task Force (IETF). It represents the consensus of the IETF community. It has received public review and has been approved for publication by the Internet Engineering Steering Group (IESG). Further information on Internet Standards is available in Section 2 of RFC 7841.¶

Information about the current status of this document, any errata, and how to provide feedback on it may be obtained at https://www.rfc-editor.org/info/rfc9113.¶

Copyright Notice

Copyright (c) 2022 IETF Trust and the persons identified as the document authors. All rights reserved.¶

This document is subject to BCP 78 and the IETF Trust''s Legal Provisions Relating to IETF Documents (https://trustee.ietf.org/license-info) in effect on the date of publication of this document. Please review these documents carefully, as they describe your rights and restrictions with respect to this document. Code Components extracted from this document must include Revised BSD License text as described in Section 4.e of the Trust Legal Provisions and are provided without warranty as described in the Revised BSD License.¶

▲

Table of Contents

1. Introduction

The performance of applications using the Hypertext Transfer Protocol (HTTP, [HTTP]) is linked to how each version of HTTP uses the underlying transport, and the conditions under which the transport operates.¶

Making multiple concurrent requests can reduce latency and improve application performance. HTTP/1.0 allowed only one request to be outstanding at a time on a given TCP [TCP] connection. HTTP/1.1 [HTTP/1.1] added request pipelining, but this only partially addressed request concurrency and still suffers from application-layer head-of-line blocking. Therefore, HTTP/1.0 and HTTP/1.1 clients use multiple connections to a server to make concurrent requests.¶

Furthermore, HTTP fields are often repetitive and verbose, causing unnecessary network traffic as well as causing the initial TCP congestion window to quickly fill. This can result in excessive latency when multiple requests are made on a new TCP connection.¶

HTTP/2 addresses these issues by defining an optimized mapping of HTTP''s semantics to an underlying connection. Specifically, it allows interleaving of messages on the same connection and uses an efficient coding for HTTP fields. It also allows prioritization of requests, letting more important requests complete more quickly, further improving performance.¶

The resulting protocol is more friendly to the network because fewer TCP connections can be used in comparison to HTTP/1.x. This means less competition with other flows and longer-lived connections, which in turn lead to better utilization of available network capacity. Note, however, that TCP head-of-line blocking is not addressed by this protocol.¶

Finally, HTTP/2 also enables more efficient processing of messages through use of binary message framing.¶

This document obsoletes RFCs 7540 and 8740. Appendix B lists notable changes.¶

2. HTTP/2 Protocol Overview

HTTP/2 provides an optimized transport for HTTP semantics. HTTP/2 supports all of the core features of HTTP but aims to be more efficient than HTTP/1.1.¶

HTTP/2 is a connection-oriented application-layer protocol that runs over a TCP connection ([TCP]). The client is the TCP connection initiator.¶

The basic protocol unit in HTTP/2 is a frame (Section 4.1). Each frame type serves a different purpose. For example, HEADERS and DATA frames form the basis of HTTP requests and responses (Section 8.1); other frame types like SETTINGS, WINDOW_UPDATE, and PUSH_PROMISE are used in support of other HTTP/2 features.¶

Multiplexing of requests is achieved by having each HTTP request/response exchange associated with its own stream (Section 5). Streams are largely independent of each other, so a blocked or stalled request or response does not prevent progress on other streams.¶

Effective use of multiplexing depends on flow control and prioritization. Flow control (Section 5.2) ensures that it is possible to efficiently use multiplexed streams by restricting data that is transmitted to what the receiver is able to handle. Prioritization (Section 5.3) ensures that limited resources are used most effectively. This revision of HTTP/2 deprecates the priority signaling scheme from [RFC7540].¶

Because HTTP fields used in a connection can contain large amounts of redundant data, frames that contain them are compressed (Section 4.3). This has especially advantageous impact upon request sizes in the common case, allowing many requests to be compressed into one packet.¶

Finally, HTTP/2 adds a new, optional interaction mode whereby a server can push responses to a client (Section 8.4). This is intended to allow a server to speculatively send data to a client that the server anticipates the client will need, trading off some network usage against a potential latency gain. The server does this by synthesizing a request, which it sends as a PUSH_PROMISE frame. The server is then able to send a response to the synthetic request on a separate stream.¶

2.1. Document Organization

The HTTP/2 specification is split into four parts:¶

Starting HTTP/2 (Section 3) covers how an HTTP/2 connection is initiated.¶

The frame (Section 4) and stream (Section 5) layers describe the way HTTP/2 frames are structured and formed into multiplexed streams.¶

Frame (Section 6) and error (Section 7) definitions include details of the frame and error types used in HTTP/2.¶

HTTP mappings (Section 8) and additional requirements (Section 9) describe how HTTP semantics are expressed using frames and streams.¶

While some of the frame- and stream-layer concepts are isolated from HTTP, this specification does not define a completely generic frame layer. The frame and stream layers are tailored to the needs of HTTP.¶

2.2. Conventions and Terminology

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "NOT RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in BCP 14 [RFC2119] [RFC8174] when, and only when, they appear in all capitals, as shown here.¶

All numeric values are in network byte order. Values are unsigned unless otherwise indicated. Literal values are provided in decimal or hexadecimal as appropriate. Hexadecimal literals are prefixed with "0x" to distinguish them from decimal literals.¶

This specification describes binary formats using the conventions described in Section 1.3 of RFC 9000 [QUIC]. Note that this format uses network byte order and that high-valued bits are listed before low-valued bits.¶

The following terms are used:¶

client:

The endpoint that initiates an HTTP/2 connection. Clients send HTTP requests and receive HTTP responses.¶

connection:

A transport-layer connection between two endpoints.¶

connection error:

An error that affects the entire HTTP/2 connection.¶

endpoint:

Either the client or server of the connection.¶

frame:

The smallest unit of communication within an HTTP/2 connection, consisting of a header and a variable-length sequence of octets structured according to the frame type.¶

peer:

An endpoint. When discussing a particular endpoint, "peer" refers to the endpoint that is remote to the primary subject of discussion.¶

receiver:

An endpoint that is receiving frames.¶

sender:

An endpoint that is transmitting frames.¶

server:

The endpoint that accepts an HTTP/2 connection. Servers receive HTTP requests and send HTTP responses.¶

stream:

A bidirectional flow of frames within the HTTP/2 connection.¶

stream error:

An error on the individual HTTP/2 stream.¶

Finally, the terms "gateway", "intermediary", "proxy", and "tunnel" are defined in Section 3.7 of [HTTP]. Intermediaries act as both client and server at different times.¶

The term "content" as it applies to message bodies is defined in Section 6.4 of [HTTP].¶

3. Starting HTTP/2

Implementations that generate HTTP requests need to discover whether a server supports HTTP/2.¶

HTTP/2 uses the "http" and "https" URI schemes defined in Section 4.2 of [HTTP], with the same default port numbers as HTTP/1.1 [HTTP/1.1]. These URIs do not include any indication about what HTTP versions an upstream server (the immediate peer to which the client wishes to establish a connection) supports.¶

The means by which support for HTTP/2 is determined is different for "http" and "https" URIs. Discovery for "https" URIs is described in Section 3.2. HTTP/2 support for "http" URIs can only be discovered by out-of-band means and requires prior knowledge of the support as described in Section 3.3.¶

3.1. HTTP/2 Version Identification

The protocol defined in this document has two identifiers. Creating a connection based on either implies the use of the transport, framing, and message semantics described in this document.¶

The string "h2" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS); see Section 9.2. This identifier is used in the TLS Application-Layer Protocol Negotiation (ALPN) extension [TLS-ALPN] field and in any place where HTTP/2 over TLS is identified.¶

The "h2" string is serialized into an ALPN protocol identifier as the two-octet sequence: 0x68, 0x32.¶

The "h2c" string was previously used as a token for use in the HTTP Upgrade mechanism''s Upgrade header field (Section 7.8 of [HTTP]). This usage was never widely deployed and is deprecated by this document. The same applies to the HTTP2-Settings header field, which was used with the upgrade to "h2c".¶

3.2. Starting HTTP/2 for "https" URIs

A client that makes a request to an "https" URI uses TLS [TLS13] with the ALPN extension [TLS-ALPN].¶

HTTP/2 over TLS uses the "h2" protocol identifier. The "h2c" protocol identifier MUST NOT be sent by a client or selected by a server; the "h2c" protocol identifier describes a protocol that does not use TLS.¶

Once TLS negotiation is complete, both the client and the server MUST send a connection preface (Section 3.4).¶

3.3. Starting HTTP/2 with Prior Knowledge

A client can learn that a particular server supports HTTP/2 by other means. For example, a client could be configured with knowledge that a server supports HTTP/2.¶

A client that knows that a server supports HTTP/2 can establish a TCP connection and send the connection preface (Section 3.4) followed by HTTP/2 frames. Servers can identify these connections by the presence of the connection preface. This only affects the establishment of HTTP/2 connections over cleartext TCP; HTTP/2 connections over TLS MUST use protocol negotiation in TLS [TLS-ALPN].¶

Likewise, the server MUST send a connection preface (Section 3.4).¶

Without additional information, prior support for HTTP/2 is not a strong signal that a given server will support HTTP/2 for future connections. For example, it is possible for server configurations to change, for configurations to differ between instances in clustered servers, or for network conditions to change.¶

3.4. HTTP/2 Connection Preface

In HTTP/2, each endpoint is required to send a connection preface as a final confirmation of the protocol in use and to establish the initial settings for the HTTP/2 connection. The client and server each send a different connection preface.¶

The client connection preface starts with a sequence of 24 octets, which in hex notation is:¶

0x505249202a20485454502f322e300d0a0d0a534d0d0a0d0a

¶

That is, the connection preface starts with the string "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n". This sequence MUST be followed by a SETTINGS frame (Section 6.5), which MAY be empty. The client sends the client connection preface as the first application data octets of a connection.¶

The server connection preface consists of a potentially empty SETTINGS frame (Section 6.5) that MUST be the first frame the server sends in the HTTP/2 connection.¶

The SETTINGS frames received from a peer as part of the connection preface MUST be acknowledged (see Section 6.5.3) after sending the connection preface.¶

To avoid unnecessary latency, clients are permitted to send additional frames to the server immediately after sending the client connection preface, without waiting to receive the server connection preface. It is important to note, however, that the server connection preface SETTINGS frame might include settings that necessarily alter how a client is expected to communicate with the server. Upon receiving the SETTINGS frame, the client is expected to honor any settings established. In some configurations, it is possible for the server to transmit SETTINGS before the client sends additional frames, providing an opportunity to avoid this issue.¶

Clients and servers MUST treat an invalid connection preface as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. A GOAWAY frame (Section 6.8) MAY be omitted in this case, since an invalid preface indicates that the peer is not using HTTP/2.¶

4. HTTP Frames

Once the HTTP/2 connection is established, endpoints can begin exchanging frames.¶

4.1. Frame Format

All frames begin with a fixed 9-octet header followed by a variable-length frame payload.¶

HTTP Frame { Length (24), Type (8), Flags (8), Reserved (1), Stream Identifier (31), Frame Payload (..), }

Figure 1: Frame Layout

The fields of the frame header are defined as:¶

Length:

The length of the frame payload expressed as an unsigned 24-bit integer in units of octets. Values greater than 214 (16,384) MUST NOT be sent unless the receiver has set a larger value for SETTINGS_MAX_FRAME_SIZE.¶

The 9 octets of the frame header are not included in this value.¶

Type:

The 8-bit type of the frame. The frame type determines the format and semantics of the frame. Frames defined in this document are listed in Section 6. Implementations MUST ignore and discard frames of unknown types.¶

Flags:

An 8-bit field reserved for boolean flags specific to the frame type.¶

Flags are assigned semantics specific to the indicated frame type. Unused flags are those that have no defined semantics for a particular frame type. Unused flags MUST be ignored on receipt and MUST be left unset (0x00) when sending.¶

Reserved:

A reserved 1-bit field. The semantics of this bit are undefined, and the bit MUST remain unset (0x00) when sending and MUST be ignored when receiving.¶

Stream Identifier:

A stream identifier (see Section 5.1.1) expressed as an unsigned 31-bit integer. The value 0x00 is reserved for frames that are associated with the connection as a whole as opposed to an individual stream.¶

The structure and content of the frame payload are dependent entirely on the frame type.¶

4.2. Frame Size

The size of a frame payload is limited by the maximum size that a receiver advertises in the SETTINGS_MAX_FRAME_SIZE setting. This setting can have any value between 214 (16,384) and 224-1 (16,777,215) octets, inclusive.¶

All implementations MUST be capable of receiving and minimally processing frames up to 214 octets in length, plus the 9-octet frame header (Section 4.1). The size of the frame header is not included when describing frame sizes.¶

An endpoint MUST send an error code of FRAME_SIZE_ERROR if a frame exceeds the size defined in SETTINGS_MAX_FRAME_SIZE, exceeds any limit defined for the frame type, or is too small to contain mandatory frame data. A frame size error in a frame that could alter the state of the entire connection MUST be treated as a connection error (Section 5.4.1); this includes any frame carrying a field block (Section 4.3) (that is, HEADERS, PUSH_PROMISE, and CONTINUATION), a SETTINGS frame, and any frame with a stream identifier of 0.¶

Endpoints are not obligated to use all available space in a frame. Responsiveness can be improved by using frames that are smaller than the permitted maximum size. Sending large frames can result in delays in sending time-sensitive frames (such as RST_STREAM, WINDOW_UPDATE, or PRIORITY), which, if blocked by the transmission of a large frame, could affect performance.¶

4.3. Field Section Compression and Decompression

Field section compression is the process of compressing a set of field lines (Section 5.2 of [HTTP]) to form a field block. Field section decompression is the process of decoding a field block into a set of field lines. Details of HTTP/2 field section compression and decompression are defined in [COMPRESSION], which, for historical reasons, refers to these processes as header compression and decompression.¶

Each field block carries all of the compressed field lines of a single field section. Header sections also include control data associated with the message in the form of pseudo-header fields (Section 8.3) that use the same format as a field line.¶

Field blocks carry control data and header sections for requests, responses, promised requests, and pushed responses (see Section 8.4). All these messages, except for interim responses and requests contained in PUSH_PROMISE (Section 6.6) frames, can optionally include a field block that carries a trailer section.¶

A field section is a collection of field lines. Each of the field lines in a field block carries a single value. The serialized field block is then divided into one or more octet sequences, called field block fragments. The first field block fragment is transmitted within the frame payload of HEADERS (Section 6.2) or PUSH_PROMISE (Section 6.6), each of which could be followed by CONTINUATION (Section 6.10) frames to carry subsequent field block fragments.¶

The Cookie header field [COOKIE] is treated specially by the HTTP mapping (see Section 8.2.3).¶

A receiving endpoint reassembles the field block by concatenating its fragments and then decompresses the block to reconstruct the field section.¶

A complete field section consists of either:¶

a single HEADERS or PUSH_PROMISE frame, with the END_HEADERS flag set, or¶

a HEADERS or PUSH_PROMISE frame with the END_HEADERS flag unset and one or more CONTINUATION frames, where the last CONTINUATION frame has the END_HEADERS flag set.¶

Each field block is processed as a discrete unit. Field blocks MUST be transmitted as a contiguous sequence of frames, with no interleaved frames of any other type or from any other stream. The last frame in a sequence of HEADERS or CONTINUATION frames has the END_HEADERS flag set. The last frame in a sequence of PUSH_PROMISE or CONTINUATION frames has the END_HEADERS flag set. This allows a field block to be logically equivalent to a single frame.¶

Field block fragments can only be sent as the frame payload of HEADERS, PUSH_PROMISE, or CONTINUATION frames because these frames carry data that can modify the compression context maintained by a receiver. An endpoint receiving HEADERS, PUSH_PROMISE, or CONTINUATION frames needs to reassemble field blocks and perform decompression even if the frames are to be discarded. A receiver MUST terminate the connection with a connection error (Section 5.4.1) of type COMPRESSION_ERROR if it does not decompress a field block.¶

A decoding error in a field block MUST be treated as a connection error (Section 5.4.1) of type COMPRESSION_ERROR.¶

4.3.1. Compression State

Field compression is stateful. Each endpoint has an HPACK encoder context and an HPACK decoder context that are used for encoding and decoding all field blocks on a connection. Section 4 of [COMPRESSION] defines the dynamic table, which is the primary state for each context.¶

The dynamic table has a maximum size that is set by an HPACK decoder. An endpoint communicates the size chosen by its HPACK decoder context using the SETTINGS_HEADER_TABLE_SIZE setting; see Section 6.5.2. When a connection is established, the dynamic table size for the HPACK decoder and encoder at both endpoints starts at 4,096 bytes, the initial value of the SETTINGS_HEADER_TABLE_SIZE setting.¶

Any change to the maximum value set using SETTINGS_HEADER_TABLE_SIZE takes effect when the endpoint acknowledges settings (Section 6.5.3). The HPACK encoder at that endpoint can set the dynamic table to any size up to the maximum value set by the decoder. An HPACK encoder declares the size of the dynamic table with a Dynamic Table Size Update instruction (Section 6.3 of [COMPRESSION]).¶

Once an endpoint acknowledges a change to SETTINGS_HEADER_TABLE_SIZE that reduces the maximum below the current size of the dynamic table, its HPACK encoder MUST start the next field block with a Dynamic Table Size Update instruction that sets the dynamic table to a size that is less than or equal to the reduced maximum; see Section 4.2 of [COMPRESSION]. An endpoint MUST treat a field block that follows an acknowledgment of the reduction to the maximum dynamic table size as a connection error (Section 5.4.1) of type COMPRESSION_ERROR if it does not start with a conformant Dynamic Table Size Update instruction.¶

5. Streams and Multiplexing

A "stream" is an independent, bidirectional sequence of frames exchanged between the client and server within an HTTP/2 connection. Streams have several important characteristics:¶

A single HTTP/2 connection can contain multiple concurrently open streams, with either endpoint interleaving frames from multiple streams.¶

Streams can be established and used unilaterally or shared by either endpoint.¶

Streams can be closed by either endpoint.¶

The order in which frames are sent is significant. Recipients process frames in the order they are received. In particular, the order of HEADERS and DATA frames is semantically significant.¶

Streams are identified by an integer. Stream identifiers are assigned to streams by the endpoint initiating the stream.¶

5.1. Stream States

The lifecycle of a stream is shown in Figure 2.¶

¶

Figure 2: Stream States

send:

endpoint sends this frame¶

recv:

endpoint receives this frame¶

H:

HEADERS frame (with implied CONTINUATION frames)¶

ES:

END_STREAM flag¶

R:

RST_STREAM frame¶

PP:

PUSH_PROMISE frame (with implied CONTINUATION frames); state transitions are for the promised stream¶

Note that this diagram shows stream state transitions and the frames and flags that affect those transitions only. In this regard, CONTINUATION frames do not result in state transitions; they are effectively part of the HEADERS or PUSH_PROMISE that they follow. For the purpose of state transitions, the END_STREAM flag is processed as a separate event to the frame that bears it; a HEADERS frame with the END_STREAM flag set can cause two state transitions.¶

Both endpoints have a subjective view of the state of a stream that could be different when frames are in transit. Endpoints do not coordinate the creation of streams; they are created unilaterally by either endpoint. The negative consequences of a mismatch in states are limited to the "closed" state after sending RST_STREAM, where frames might be received for some time after closing.¶

Streams have the following states:¶

idle:

All streams start in the "idle" state.¶

The following transitions are valid from this state:¶

Sending a HEADERS frame as a client, or receiving a HEADERS frame as a server, causes the stream to become "open". The stream identifier is selected as described in Section 5.1.1. The same HEADERS frame can also cause a stream to immediately become "half-closed".¶

Sending a PUSH_PROMISE frame on another stream reserves the idle stream that is identified for later use. The stream state for the reserved stream transitions to "reserved (local)". Only a server may send PUSH_PROMISE frames.¶

Receiving a PUSH_PROMISE frame on another stream reserves an idle stream that is identified for later use. The stream state for the reserved stream transitions to "reserved (remote)". Only a client may receive PUSH_PROMISE frames.¶

Note that the PUSH_PROMISE frame is not sent on the idle stream but references the newly reserved stream in the Promised Stream ID field.¶

Opening a stream with a higher-valued stream identifier causes the stream to transition immediately to a "closed" state; note that this transition is not shown in the diagram.¶

Receiving any frame other than HEADERS or PRIORITY on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. If this stream is initiated by the server, as described in Section 5.1.1, then receiving a HEADERS frame MUST also be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

reserved (local):

A stream in the "reserved (local)" state is one that has been promised by sending a PUSH_PROMISE frame. A PUSH_PROMISE frame reserves an idle stream by associating the stream with an open stream that was initiated by the remote peer (see Section 8.4).¶

In this state, only the following transitions are possible:¶

The endpoint can send a HEADERS frame. This causes the stream to open in a "half-closed (remote)" state.¶

Either endpoint can send a RST_STREAM frame to cause the stream to become "closed". This releases the stream reservation.¶

An endpoint MUST NOT send any type of frame other than HEADERS, RST_STREAM, or PRIORITY in this state.¶

A PRIORITY or WINDOW_UPDATE frame MAY be received in this state. Receiving any type of frame other than RST_STREAM, PRIORITY, or WINDOW_UPDATE on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

reserved (remote):

A stream in the "reserved (remote)" state has been reserved by a remote peer.¶

In this state, only the following transitions are possible:¶

Receiving a HEADERS frame causes the stream to transition to "half-closed (local)".¶

Either endpoint can send a RST_STREAM frame to cause the stream to become "closed". This releases the stream reservation.¶

An endpoint MUST NOT send any type of frame other than RST_STREAM, WINDOW_UPDATE, or PRIORITY in this state.¶

Receiving any type of frame other than HEADERS, RST_STREAM, or PRIORITY on a stream in this state MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

open:

A stream in the "open" state may be used by both peers to send frames of any type. In this state, sending peers observe advertised stream-level flow-control limits (Section 5.2).¶

From this state, either endpoint can send a frame with an END_STREAM flag set, which causes the stream to transition into one of the "half-closed" states. An endpoint sending an END_STREAM flag causes the stream state to become "half-closed (local)"; an endpoint receiving an END_STREAM flag causes the stream state to become "half-closed (remote)".¶

Either endpoint can send a RST_STREAM frame from this state, causing it to transition immediately to "closed".¶

half-closed (local):

A stream that is in the "half-closed (local)" state cannot be used for sending frames other than WINDOW_UPDATE, PRIORITY, and RST_STREAM.¶

A stream transitions from this state to "closed" when a frame is received with the END_STREAM flag set or when either peer sends a RST_STREAM frame.¶

An endpoint can receive any type of frame in this state. Providing flow-control credit using WINDOW_UPDATE frames is necessary to continue receiving flow-controlled frames. In this state, a receiver can ignore WINDOW_UPDATE frames, which might arrive for a short period after a frame with the END_STREAM flag set is sent.¶

PRIORITY frames can be received in this state.¶

half-closed (remote):

A stream that is "half-closed (remote)" is no longer being used by the peer to send frames. In this state, an endpoint is no longer obligated to maintain a receiver flow-control window.¶

If an endpoint receives additional frames, other than WINDOW_UPDATE, PRIORITY, or RST_STREAM, for a stream that is in this state, it MUST respond with a stream error (Section 5.4.2) of type STREAM_CLOSED.¶

A stream that is "half-closed (remote)" can be used by the endpoint to send frames of any type. In this state, the endpoint continues to observe advertised stream-level flow-control limits (Section 5.2).¶

A stream can transition from this state to "closed" by sending a frame with the END_STREAM flag set or when either peer sends a RST_STREAM frame.¶

closed:

The "closed" state is the terminal state.¶

A stream enters the "closed" state after an endpoint both sends and receives a frame with an END_STREAM flag set. A stream also enters the "closed" state after an endpoint either sends or receives a RST_STREAM frame.¶

An endpoint MUST NOT send frames other than PRIORITY on a closed stream. An endpoint MAY treat receipt of any other type of frame on a closed stream as a connection error (Section 5.4.1) of type STREAM_CLOSED, except as noted below.¶

An endpoint that sends a frame with the END_STREAM flag set or a RST_STREAM frame might receive a WINDOW_UPDATE or RST_STREAM frame from its peer in the time before the peer receives and processes the frame that closes the stream.¶

An endpoint that sends a RST_STREAM frame on a stream that is in the "open" or "half-closed (local)" state could receive any type of frame. The peer might have sent or enqueued for sending these frames before processing the RST_STREAM frame. An endpoint MUST minimally process and then discard any frames it receives in this state. This means updating header compression state for HEADERS and PUSH_PROMISE frames. Receiving a PUSH_PROMISE frame also causes the promised stream to become "reserved (remote)", even when the PUSH_PROMISE frame is received on a closed stream. Additionally, the content of DATA frames counts toward the connection flow-control window.¶

An endpoint can perform this minimal processing for all streams that are in the "closed" state. Endpoints MAY use other signals to detect that a peer has received the frames that caused the stream to enter the "closed" state and treat receipt of any frame other than PRIORITY as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Endpoints can use frames that indicate that the peer has received the closing signal to drive this. Endpoints SHOULD NOT use timers for this purpose. For example, an endpoint that sends a SETTINGS frame after closing a stream can safely treat receipt of a DATA frame on that stream as an error after receiving an acknowledgment of the settings. Other things that might be used are PING frames, receiving data on streams that were created after closing the stream, or responses to requests created after closing the stream.¶

In the absence of more specific rules, implementations SHOULD treat the receipt of a frame that is not expressly permitted in the description of a state as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that PRIORITY can be sent and received in any stream state.¶

The rules in this section only apply to frames defined in this document. Receipt of frames for which the semantics are unknown cannot be treated as an error, as the conditions for sending and receiving those frames are also unknown; see Section 5.5.¶

An example of the state transitions for an HTTP request/response exchange can be found in Section 8.8. An example of the state transitions for server push can be found in Sections 8.4.1 and 8.4.2.¶

5.1.1. Stream Identifiers

Streams are identified by an unsigned 31-bit integer. Streams initiated by a client MUST use odd-numbered stream identifiers; those initiated by the server MUST use even-numbered stream identifiers. A stream identifier of zero (0x00) is used for connection control messages; the stream identifier of zero cannot be used to establish a new stream.¶

The identifier of a newly established stream MUST be numerically greater than all streams that the initiating endpoint has opened or reserved. This governs streams that are opened using a HEADERS frame and streams that are reserved using PUSH_PROMISE. An endpoint that receives an unexpected stream identifier MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A HEADERS frame will transition the client-initiated stream identified by the stream identifier in the frame header from "idle" to "open". A PUSH_PROMISE frame will transition the server-initiated stream identified by the Promised Stream ID field in the frame payload from "idle" to "reserved (local)" or "reserved (remote)". When a stream transitions out of the "idle" state, all streams in the "idle" state that might have been opened by the peer with a lower-valued stream identifier immediately transition to "closed". That is, an endpoint may skip a stream identifier, with the effect being that the skipped stream is immediately closed.¶

Stream identifiers cannot be reused. Long-lived connections can result in an endpoint exhausting the available range of stream identifiers. A client that is unable to establish a new stream identifier can establish a new connection for new streams. A server that is unable to establish a new stream identifier can send a GOAWAY frame so that the client is forced to open a new connection for new streams.¶

5.1.2. Stream Concurrency

A peer can limit the number of concurrently active streams using the SETTINGS_MAX_CONCURRENT_STREAMS parameter (see Section 6.5.2) within a SETTINGS frame. The maximum concurrent streams setting is specific to each endpoint and applies only to the peer that receives the setting. That is, clients specify the maximum number of concurrent streams the server can initiate, and servers specify the maximum number of concurrent streams the client can initiate.¶

Streams that are in the "open" state or in either of the "half-closed" states count toward the maximum number of streams that an endpoint is permitted to open. Streams in any of these three states count toward the limit advertised in the SETTINGS_MAX_CONCURRENT_STREAMS setting. Streams in either of the "reserved" states do not count toward the stream limit.¶

Endpoints MUST NOT exceed the limit set by their peer. An endpoint that receives a HEADERS frame that causes its advertised concurrent stream limit to be exceeded MUST treat this as a stream error (Section 5.4.2) of type PROTOCOL_ERROR or REFUSED_STREAM. The choice of error code determines whether the endpoint wishes to enable automatic retry (see Section 8.7 for details).¶

An endpoint that wishes to reduce the value of SETTINGS_MAX_CONCURRENT_STREAMS to a value that is below the current number of open streams can either close streams that exceed the new value or allow streams to complete.¶

5.2. Flow Control

Using streams for multiplexing introduces contention over use of the TCP connection, resulting in blocked streams. A flow-control scheme ensures that streams on the same connection do not destructively interfere with each other. Flow control is used for both individual streams and the connection as a whole.¶

HTTP/2 provides for flow control through use of the WINDOW_UPDATE frame (Section 6.9).¶

5.2.1. Flow-Control Principles

HTTP/2 stream flow control aims to allow a variety of flow-control algorithms to be used without requiring protocol changes. Flow control in HTTP/2 has the following characteristics:¶

Flow control is specific to a connection. HTTP/2 flow control operates between the endpoints of a single hop and not over the entire end-to-end path.¶

Flow control is based on WINDOW_UPDATE frames. Receivers advertise how many octets they are prepared to receive on a stream and for the entire connection. This is a credit-based scheme.¶

Flow control is directional with overall control provided by the receiver. A receiver MAY choose to set any window size that it desires for each stream and for the entire connection. A sender MUST respect flow-control limits imposed by a receiver. Clients, servers, and intermediaries all independently advertise their flow-control window as a receiver and abide by the flow-control limits set by their peer when sending.¶

The initial value for the flow-control window is 65,535 octets for both new streams and the overall connection.¶

The frame type determines whether flow control applies to a frame. Of the frames specified in this document, only DATA frames are subject to flow control; all other frame types do not consume space in the advertised flow-control window. This ensures that important control frames are not blocked by flow control.¶

An endpoint can choose to disable its own flow control, but an endpoint cannot ignore flow-control signals from its peer.¶

HTTP/2 defines only the format and semantics of the WINDOW_UPDATE frame (Section 6.9). This document does not stipulate how a receiver decides when to send this frame or the value that it sends, nor does it specify how a sender chooses to send packets. Implementations are able to select any algorithm that suits their needs.¶

Implementations are also responsible for prioritizing the sending of requests and responses, choosing how to avoid head-of-line blocking for requests, and managing the creation of new streams. Algorithm choices for these could interact with any flow-control algorithm.¶

5.2.2. Appropriate Use of Flow Control

Flow control is defined to protect endpoints that are operating under resource constraints. For example, a proxy needs to share memory between many connections and also might have a slow upstream connection and a fast downstream one. Flow control addresses cases where the receiver is unable to process data on one stream yet wants to continue to process other streams in the same connection.¶

Deployments that do not require this capability can advertise a flow-control window of the maximum size (231-1) and can maintain this window by sending a WINDOW_UPDATE frame when any data is received. This effectively disables flow control for that receiver. Conversely, a sender is always subject to the flow-control window advertised by the receiver.¶

Deployments with constrained resources (for example, memory) can employ flow control to limit the amount of memory a peer can consume. Note, however, that this can lead to suboptimal use of available network resources if flow control is enabled without knowledge of the bandwidth * delay product (see [RFC7323]).¶

Even with full awareness of the current bandwidth * delay product, implementation of flow control can be difficult. Endpoints MUST read and process HTTP/2 frames from the TCP receive buffer as soon as data is available. Failure to read promptly could lead to a deadlock when critical frames, such as WINDOW_UPDATE, are not read and acted upon. Reading frames promptly does not expose endpoints to resource exhaustion attacks, as HTTP/2 flow control limits resource commitments.¶

5.2.3. Flow-Control Performance

If an endpoint cannot ensure that its peer always has available flow-control window space that is greater than the peer''s bandwidth * delay product on this connection, its receive throughput will be limited by HTTP/2 flow control. This will result in degraded performance.¶

Sending timely WINDOW_UPDATE frames can improve performance. Endpoints will want to balance the need to improve receive throughput with the need to manage resource exhaustion risks and should take careful note of Section 10.5 in defining their strategy to manage window sizes.¶

5.3. Prioritization

In a multiplexed protocol like HTTP/2, prioritizing allocation of bandwidth and computation resources to streams can be critical to attaining good performance. A poor prioritization scheme can result in HTTP/2 providing poor performance. With no parallelism at the TCP layer, performance could be significantly worse than HTTP/1.1.¶

A good prioritization scheme benefits from the application of contextual knowledge such as the content of resources, how resources are interrelated, and how those resources will be used by a peer. In particular, clients can possess knowledge about the priority of requests that is relevant to server prioritization. In those cases, having clients provide priority information can improve performance.¶

5.3.1. Background on Priority in RFC 7540

RFC 7540 defined a rich system for signaling priority of requests. However, this system proved to be complex, and it was not uniformly implemented.¶

The flexible scheme meant that it was possible for clients to express priorities in very different ways, with little consistency in the approaches that were adopted. For servers, implementing generic support for the scheme was complex. Implementation of priorities was uneven in both clients and servers. Many server deployments ignored client signals when prioritizing their handling of requests.¶

In short, the prioritization signaling in RFC 7540 [RFC7540] was not successful.¶

5.3.2. Priority Signaling in This Document

This update to HTTP/2 deprecates the priority signaling defined in RFC 7540 [RFC7540]. The bulk of the text related to priority signals is not included in this document. The description of frame fields and some of the mandatory handling is retained to ensure that implementations of this document remain interoperable with implementations that use the priority signaling described in RFC 7540.¶

A thorough description of the RFC 7540 priority scheme remains in Section 5.3 of [RFC7540].¶

Signaling priority information is necessary to attain good performance in many cases. Where signaling priority information is important, endpoints are encouraged to use an alternative scheme, such as the scheme described in [HTTP-PRIORITY].¶

Though the priority signaling from RFC 7540 was not widely adopted, the information it provides can still be useful in the absence of better information. Endpoints that receive priority signals in HEADERS or PRIORITY frames can benefit from applying that information. In particular, implementations that consume these signals would not benefit from discarding these priority signals in the absence of alternatives.¶

Servers SHOULD use other contextual information in determining priority of requests in the absence of any priority signals. Servers MAY interpret the complete absence of signals as an indication that the client has not implemented the feature. The defaults described in Section 5.3.5 of [RFC7540] are known to have poor performance under most conditions, and their use is unlikely to be deliberate.¶

5.4. Error Handling

HTTP/2 framing permits two classes of errors:¶

An error condition that renders the entire connection unusable is a connection error.¶

An error in an individual stream is a stream error.¶

A list of error codes is included in Section 7.¶

It is possible that an endpoint will encounter frames that would cause multiple errors. Implementations MAY discover multiple errors during processing, but they SHOULD report at most one stream and one connection error as a result.¶

The first stream error reported for a given stream prevents any other errors on that stream from being reported. In comparison, the protocol permits multiple GOAWAY frames, though an endpoint SHOULD report just one type of connection error unless an error is encountered during graceful shutdown. If this occurs, an endpoint MAY send an additional GOAWAY frame with the new error code, in addition to any prior GOAWAY that contained NO_ERROR.¶

If an endpoint detects multiple different errors, it MAY choose to report any one of those errors. If a frame causes a connection error, that error MUST be reported. Additionally, an endpoint MAY use any applicable error code when it detects an error condition; a generic error code (such as PROTOCOL_ERROR or INTERNAL_ERROR) can always be used in place of more specific error codes.¶

5.4.1. Connection Error Handling

A connection error is any error that prevents further processing of the frame layer or corrupts any connection state.¶

An endpoint that encounters a connection error SHOULD first send a GOAWAY frame (Section 6.8) with the stream identifier of the last stream that it successfully received from its peer. The GOAWAY frame includes an error code (Section 7) that indicates why the connection is terminating. After sending the GOAWAY frame for an error condition, the endpoint MUST close the TCP connection.¶

It is possible that the GOAWAY will not be reliably received by the receiving endpoint. In the event of a connection error, GOAWAY only provides a best-effort attempt to communicate with the peer about why the connection is being terminated.¶

An endpoint can end a connection at any time. In particular, an endpoint MAY choose to treat a stream error as a connection error. Endpoints SHOULD send a GOAWAY frame when ending a connection, providing that circumstances permit it.¶

5.4.2. Stream Error Handling

A stream error is an error related to a specific stream that does not affect processing of other streams.¶

An endpoint that detects a stream error sends a RST_STREAM frame (Section 6.4) that contains the stream identifier of the stream where the error occurred. The RST_STREAM frame includes an error code that indicates the type of error.¶

A RST_STREAM is the last frame that an endpoint can send on a stream. The peer that sends the RST_STREAM frame MUST be prepared to receive any frames that were sent or enqueued for sending by the remote peer. These frames can be ignored, except where they modify connection state (such as the state maintained for field section compression (Section 4.3) or flow control).¶

Normally, an endpoint SHOULD NOT send more than one RST_STREAM frame for any stream. However, an endpoint MAY send additional RST_STREAM frames if it receives frames on a closed stream after more than a round-trip time. This behavior is permitted to deal with misbehaving implementations.¶

To avoid looping, an endpoint MUST NOT send a RST_STREAM in response to a RST_STREAM frame.¶

5.4.3. Connection Termination

If the TCP connection is closed or reset while streams remain in the "open" or "half-closed" states, then the affected streams cannot be automatically retried (see Section 8.7 for details).¶

5.5. Extending HTTP/2

HTTP/2 permits extension of the protocol. Within the limitations described in this section, protocol extensions can be used to provide additional services or alter any aspect of the protocol. Extensions are effective only within the scope of a single HTTP/2 connection.¶

This applies to the protocol elements defined in this document. This does not affect the existing options for extending HTTP, such as defining new methods, status codes, or fields (see Section 16 of [HTTP]).¶

Extensions are permitted to use new frame types (Section 4.1), new settings (Section 6.5), or new error codes (Section 7). Registries for managing these extension points are defined in Section 11 of [RFC7540].¶

Implementations MUST ignore unknown or unsupported values in all extensible protocol elements. Implementations MUST discard frames that have unknown or unsupported types. This means that any of these extension points can be safely used by extensions without prior arrangement or negotiation. However, extension frames that appear in the middle of a field block (Section 4.3) are not permitted; these MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Extensions SHOULD avoid changing protocol elements defined in this document or elements for which no extension mechanism is defined. This includes changes to the layout of frames, additions or changes to the way that frames are composed into HTTP messages (Section 8.1), the definition of pseudo-header fields, or changes to any protocol element that a compliant endpoint might treat as a connection error (Section 5.4.1).¶

An extension that changes existing protocol elements or state MUST be negotiated before being used. For example, an extension that changes the layout of the HEADERS frame cannot be used until the peer has given a positive signal that this is acceptable. In this case, it could also be necessary to coordinate when the revised layout comes into effect. For example, treating frames other than DATA frames as flow controlled requires a change in semantics that both endpoints need to understand, so this can only be done through negotiation.¶

This document doesn''t mandate a specific method for negotiating the use of an extension but notes that a setting (Section 6.5.2) could be used for that purpose. If both peers set a value that indicates willingness to use the extension, then the extension can be used. If a setting is used for extension negotiation, the initial value MUST be defined in such a fashion that the extension is initially disabled.¶

6. Frame Definitions

This specification defines a number of frame types, each identified by a unique 8-bit type code. Each frame type serves a distinct purpose in the establishment and management of either the connection as a whole or individual streams.¶

The transmission of specific frame types can alter the state of a connection. If endpoints fail to maintain a synchronized view of the connection state, successful communication within the connection will no longer be possible. Therefore, it is important that endpoints have a shared comprehension of how the state is affected by the use of any given frame.¶

6.1. DATA

DATA frames (type=0x00) convey arbitrary, variable-length sequences of octets associated with a stream. One or more DATA frames are used, for instance, to carry HTTP request or response message contents.¶

DATA frames MAY also contain padding. Padding can be added to DATA frames to obscure the size of messages. Padding is a security feature; see Section 10.7.¶

DATA Frame { Length (24), Type (8) = 0x00, Unused Flags (4), PADDED Flag (1), Unused Flags (2), END_STREAM Flag (1), Reserved (1), Stream Identifier (31), [Pad Length (8)], Data (..), Padding (..2040), }

Figure 3: DATA Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The DATA frame contains the following additional fields:¶

Pad Length:

An 8-bit field containing the length of the frame padding in units of octets. This field is conditional and is only present if the PADDED flag is set.¶

Data:

Application data. The amount of data is the remainder of the frame payload after subtracting the length of the other fields that are present.¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The DATA frame defines the following flags:¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶

END_STREAM (0x01):

When set, the END_STREAM flag indicates that this frame is the last that the endpoint will send for the identified stream. Setting this flag causes the stream to enter one of the "half-closed" states or the "closed" state (Section 5.1).¶

DATA frames MUST be associated with a stream. If a DATA frame is received whose Stream Identifier field is 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

DATA frames are subject to flow control and can only be sent when a stream is in the "open" or "half-closed (remote)" state. The entire DATA frame payload is included in flow control, including the Pad Length and Padding fields if present. If a DATA frame is received whose stream is not in the "open" or "half-closed (local)" state, the recipient MUST respond with a stream error (Section 5.4.2) of type STREAM_CLOSED.¶

The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.2. HEADERS

The HEADERS frame (type=0x01) is used to open a stream (Section 5.1), and additionally carries a field block fragment. Despite the name, a HEADERS frame can carry a header section or a trailer section. HEADERS frames can be sent on a stream in the "idle", "reserved (local)", "open", or "half-closed (remote)" state.¶

HEADERS Frame { Length (24), Type (8) = 0x01, Unused Flags (2), PRIORITY Flag (1), Unused Flag (1), PADDED Flag (1), END_HEADERS Flag (1), Unused Flag (1), END_STREAM Flag (1), Reserved (1), Stream Identifier (31), [Pad Length (8)], [Exclusive (1)], [Stream Dependency (31)], [Weight (8)], Field Block Fragment (..), Padding (..2040), }

Figure 4: HEADERS Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The HEADERS frame payload has the following additional fields:¶

Pad Length:

An 8-bit field containing the length of the frame padding in units of octets. This field is only present if the PADDED flag is set.¶

Exclusive:

A single-bit flag. This field is only present if the PRIORITY flag is set. Priority signals in HEADERS frames are deprecated; see Section 5.3.2.¶

Stream Dependency:

A 31-bit stream identifier. This field is only present if the PRIORITY flag is set.¶

Weight:

An unsigned 8-bit integer. This field is only present if the PRIORITY flag is set.¶

Field Block Fragment:

A field block fragment (Section 4.3).¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The HEADERS frame defines the following flags:¶

PRIORITY (0x20):

When set, the PRIORITY flag indicates that the Exclusive, Stream Dependency, and Weight fields are present.¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶

END_HEADERS (0x04):

When set, the END_HEADERS flag indicates that this frame contains an entire field block (Section 4.3) and is not followed by any CONTINUATION frames.¶

A HEADERS frame without the END_HEADERS flag set MUST be followed by a CONTINUATION frame for the same stream. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

END_STREAM (0x01):

When set, the END_STREAM flag indicates that the field block (Section 4.3) is the last that the endpoint will send for the identified stream.¶

A HEADERS frame with the END_STREAM flag set signals the end of a stream. However, a HEADERS frame with the END_STREAM flag set can be followed by CONTINUATION frames on the same stream. Logically, the CONTINUATION frames are part of the HEADERS frame.¶

The frame payload of a HEADERS frame contains a field block fragment (Section 4.3). A field block that does not fit within a HEADERS frame is continued in a CONTINUATION frame (Section 6.10).¶

HEADERS frames MUST be associated with a stream. If a HEADERS frame is received whose Stream Identifier field is 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The HEADERS frame changes the connection state as described in Section 4.3.¶

The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.3. PRIORITY

The PRIORITY frame (type=0x02) is deprecated; see Section 5.3.2. A PRIORITY frame can be sent in any stream state, including idle or closed streams.¶

PRIORITY Frame { Length (24) = 0x05, Type (8) = 0x02, Unused Flags (8), Reserved (1), Stream Identifier (31), Exclusive (1), Stream Dependency (31), Weight (8), }

Figure 5: PRIORITY Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a PRIORITY frame contains the following additional fields:¶

Exclusive:

A single-bit flag.¶

Stream Dependency:

A 31-bit stream identifier.¶

Weight:

An unsigned 8-bit integer.¶

The PRIORITY frame does not define any flags.¶

The PRIORITY frame always identifies a stream. If a PRIORITY frame is received with a stream identifier of 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Sending or receiving a PRIORITY frame does not affect the state of any stream (Section 5.1). The PRIORITY frame can be sent on a stream in any state, including "idle" or "closed". A PRIORITY frame cannot be sent between consecutive frames that comprise a single field block (Section 4.3).¶

A PRIORITY frame with a length other than 5 octets MUST be treated as a stream error (Section 5.4.2) of type FRAME_SIZE_ERROR.¶

6.4. RST_STREAM

The RST_STREAM frame (type=0x03) allows for immediate termination of a stream. RST_STREAM is sent to request cancellation of a stream or to indicate that an error condition has occurred.¶

RST_STREAM Frame { Length (24) = 0x04, Type (8) = 0x03, Unused Flags (8), Reserved (1), Stream Identifier (31), Error Code (32), }

Figure 6: RST_STREAM Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. Additionally, the RST_STREAM frame contains a single unsigned, 32-bit integer identifying the error code (Section 7). The error code indicates why the stream is being terminated.¶

The RST_STREAM frame does not define any flags.¶

The RST_STREAM frame fully terminates the referenced stream and causes it to enter the "closed" state. After receiving a RST_STREAM on a stream, the receiver MUST NOT send additional frames for that stream, except for PRIORITY. However, after sending the RST_STREAM, the sending endpoint MUST be prepared to receive and process additional frames sent on the stream that might have been sent by the peer prior to the arrival of the RST_STREAM.¶

RST_STREAM frames MUST be associated with a stream. If a RST_STREAM frame is received with a stream identifier of 0x00, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

RST_STREAM frames MUST NOT be sent for a stream in the "idle" state. If a RST_STREAM frame identifying an idle stream is received, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A RST_STREAM frame with a length other than 4 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.5. SETTINGS

The SETTINGS frame (type=0x04) conveys configuration parameters that affect how endpoints communicate, such as preferences and constraints on peer behavior. The SETTINGS frame is also used to acknowledge the receipt of those settings. Individually, a configuration parameter from a SETTINGS frame is referred to as a "setting".¶

Settings are not negotiated; they describe characteristics of the sending peer, which are used by the receiving peer. Different values for the same setting can be advertised by each peer. For example, a client might set a high initial flow-control window, whereas a server might set a lower value to conserve resources.¶

A SETTINGS frame MUST be sent by both endpoints at the start of a connection and MAY be sent at any other time by either endpoint over the lifetime of the connection. Implementations MUST support all of the settings defined by this specification.¶

Each parameter in a SETTINGS frame replaces any existing value for that parameter. Settings are processed in the order in which they appear, and a receiver of a SETTINGS frame does not need to maintain any state other than the current value of each setting. Therefore, the value of a SETTINGS parameter is the last value that is seen by a receiver.¶

SETTINGS frames are acknowledged by the receiving peer. To enable this, the SETTINGS frame defines the ACK flag:¶

ACK (0x01):

When set, the ACK flag indicates that this frame acknowledges receipt and application of the peer''s SETTINGS frame. When this bit is set, the frame payload of the SETTINGS frame MUST be empty. Receipt of a SETTINGS frame with the ACK flag set and a length field value other than 0 MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR. For more information, see Section 6.5.3 ("Settings Synchronization").¶

SETTINGS frames always apply to a connection, never a single stream. The stream identifier for a SETTINGS frame MUST be zero (0x00). If an endpoint receives a SETTINGS frame whose Stream Identifier field is anything other than 0x00, the endpoint MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The SETTINGS frame affects connection state. A badly formed or incomplete SETTINGS frame MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A SETTINGS frame with a length other than a multiple of 6 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.5.1. SETTINGS Format

The frame payload of a SETTINGS frame consists of zero or more settings, each consisting of an unsigned 16-bit setting identifier and an unsigned 32-bit value.¶

SETTINGS Frame { Length (24), Type (8) = 0x04, Unused Flags (7), ACK Flag (1), Reserved (1), Stream Identifier (31) = 0, Setting (48) ..., } Setting { Identifier (16), Value (32), }

Figure 7: SETTINGS Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a SETTINGS frame contains any number of Setting fields, each of which consists of:¶

Identifier:

A 16-bit setting identifier; see Section 6.5.2.¶

Value:

A 32-bit value for the setting.¶

6.5.2. Defined Settings

The following settings are defined:¶

SETTINGS_HEADER_TABLE_SIZE (0x01):

This setting allows the sender to inform the remote endpoint of the maximum size of the compression table used to decode field blocks, in units of octets. The encoder can select any size equal to or less than this value by using signaling specific to the compression format inside a field block (see [COMPRESSION]). The initial value is 4,096 octets.¶

SETTINGS_ENABLE_PUSH (0x02):

This setting can be used to enable or disable server push. A server MUST NOT send a PUSH_PROMISE frame if it receives this parameter set to a value of 0; see Section 8.4. A client that has both set this parameter to 0 and had it acknowledged MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The initial value of SETTINGS_ENABLE_PUSH is 1. For a client, this value indicates that it is willing to receive PUSH_PROMISE frames. For a server, this initial value has no effect, and is equivalent to the value 0. Any value other than 0 or 1 MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A server MUST NOT explicitly set this value to 1. A server MAY choose to omit this setting when it sends a SETTINGS frame, but if a server does include a value, it MUST be 0. A client MUST treat receipt of a SETTINGS frame with SETTINGS_ENABLE_PUSH set to 1 as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

SETTINGS_MAX_CONCURRENT_STREAMS (0x03):

This setting indicates the maximum number of concurrent streams that the sender will allow. This limit is directional: it applies to the number of streams that the sender permits the receiver to create. Initially, there is no limit to this value. It is recommended that this value be no smaller than 100, so as to not unnecessarily limit parallelism.¶

A value of 0 for SETTINGS_MAX_CONCURRENT_STREAMS SHOULD NOT be treated as special by endpoints. A zero value does prevent the creation of new streams; however, this can also happen for any limit that is exhausted with active streams. Servers SHOULD only set a zero value for short durations; if a server does not wish to accept requests, closing the connection is more appropriate.¶

SETTINGS_INITIAL_WINDOW_SIZE (0x04):

This setting indicates the sender''s initial window size (in units of octets) for stream-level flow control. The initial value is 216-1 (65,535) octets.¶

This setting affects the window size of all streams (see Section 6.9.2).¶

Values above the maximum flow-control window size of 231-1 MUST be treated as a connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR.¶

SETTINGS_MAX_FRAME_SIZE (0x05):

This setting indicates the size of the largest frame payload that the sender is willing to receive, in units of octets.¶

The initial value is 214 (16,384) octets. The value advertised by an endpoint MUST be between this initial value and the maximum allowed frame size (224-1 or 16,777,215 octets), inclusive. Values outside this range MUST be treated as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

SETTINGS_MAX_HEADER_LIST_SIZE (0x06):

This advisory setting informs a peer of the maximum field section size that the sender is prepared to accept, in units of octets. The value is based on the uncompressed size of field lines, including the length of the name and value in units of octets plus an overhead of 32 octets for each field line.¶

For any given request, a lower limit than what is advertised MAY be enforced. The initial value of this setting is unlimited.¶

An endpoint that receives a SETTINGS frame with any unknown or unsupported identifier MUST ignore that setting.¶

6.5.3. Settings Synchronization

Most values in SETTINGS benefit from or require an understanding of when the peer has received and applied the changed parameter values. In order to provide such synchronization timepoints, the recipient of a SETTINGS frame in which the ACK flag is not set MUST apply the updated settings as soon as possible upon receipt. SETTINGS frames are acknowledged in the order in which they are received.¶

The values in the SETTINGS frame MUST be processed in the order they appear, with no other frame processing between values. Unsupported settings MUST be ignored. Once all values have been processed, the recipient MUST immediately emit a SETTINGS frame with the ACK flag set. Upon receiving a SETTINGS frame with the ACK flag set, the sender of the altered settings can rely on the values from the oldest unacknowledged SETTINGS frame having been applied.¶

If the sender of a SETTINGS frame does not receive an acknowledgment within a reasonable amount of time, it MAY issue a connection error (Section 5.4.1) of type SETTINGS_TIMEOUT. In setting a timeout, some allowance needs to be made for processing delays at the peer; a timeout that is solely based on the round-trip time between endpoints might result in spurious errors.¶

6.6. PUSH_PROMISE

The PUSH_PROMISE frame (type=0x05) is used to notify the peer endpoint in advance of streams the sender intends to initiate. The PUSH_PROMISE frame includes the unsigned 31-bit identifier of the stream the endpoint plans to create along with a field section that provides additional context for the stream. Section 8.4 contains a thorough description of the use of PUSH_PROMISE frames.¶

PUSH_PROMISE Frame { Length (24), Type (8) = 0x05, Unused Flags (4), PADDED Flag (1), END_HEADERS Flag (1), Unused Flags (2), Reserved (1), Stream Identifier (31), [Pad Length (8)], Reserved (1), Promised Stream ID (31), Field Block Fragment (..), Padding (..2040), }

Figure 8: PUSH_PROMISE Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The PUSH_PROMISE frame payload has the following additional fields:¶

Pad Length:

An 8-bit field containing the length of the frame padding in units of octets. This field is only present if the PADDED flag is set.¶

Promised Stream ID:

An unsigned 31-bit integer that identifies the stream that is reserved by the PUSH_PROMISE. The promised stream identifier MUST be a valid choice for the next stream sent by the sender (see "new stream identifier" in Section 5.1.1).¶

Field Block Fragment:

A field block fragment (Section 4.3) containing the request control data and a header section.¶

Padding:

Padding octets that contain no application semantic value. Padding octets MUST be set to zero when sending. A receiver is not obligated to verify padding but MAY treat non-zero padding as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The PUSH_PROMISE frame defines the following flags:¶

PADDED (0x08):

When set, the PADDED flag indicates that the Pad Length field and any padding that it describes are present.¶

END_HEADERS (0x04):

When set, the END_HEADERS flag indicates that this frame contains an entire field block (Section 4.3) and is not followed by any CONTINUATION frames.¶

A PUSH_PROMISE frame without the END_HEADERS flag set MUST be followed by a CONTINUATION frame for the same stream. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

PUSH_PROMISE frames MUST only be sent on a peer-initiated stream that is in either the "open" or "half-closed (remote)" state. The stream identifier of a PUSH_PROMISE frame indicates the stream it is associated with. If the Stream Identifier field specifies the value 0x00, a recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Promised streams are not required to be used in the order they are promised. The PUSH_PROMISE only reserves stream identifiers for later use.¶

PUSH_PROMISE MUST NOT be sent if the SETTINGS_ENABLE_PUSH setting of the peer endpoint is set to 0. An endpoint that has set this setting and has received acknowledgment MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Recipients of PUSH_PROMISE frames can choose to reject promised streams by returning a RST_STREAM referencing the promised stream identifier back to the sender of the PUSH_PROMISE.¶

A PUSH_PROMISE frame modifies the connection state in two ways. First, the inclusion of a field block (Section 4.3) potentially modifies the state maintained for field section compression. Second, PUSH_PROMISE also reserves a stream for later use, causing the promised stream to enter the "reserved (local)" or "reserved (remote)" state. A sender MUST NOT send a PUSH_PROMISE on a stream unless that stream is either "open" or "half-closed (remote)"; the sender MUST ensure that the promised stream is a valid choice for a new stream identifier (Section 5.1.1) (that is, the promised stream MUST be in the "idle" state).¶

Since PUSH_PROMISE reserves a stream, ignoring a PUSH_PROMISE frame causes the stream state to become indeterminate. A receiver MUST treat the receipt of a PUSH_PROMISE on a stream that is neither "open" nor "half-closed (local)" as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. However, an endpoint that has sent RST_STREAM on the associated stream MUST handle PUSH_PROMISE frames that might have been created before the RST_STREAM frame is received and processed.¶

A receiver MUST treat the receipt of a PUSH_PROMISE that promises an illegal stream identifier (Section 5.1.1) as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that an illegal stream identifier is an identifier for a stream that is not currently in the "idle" state.¶

The total number of padding octets is determined by the value of the Pad Length field. If the length of the padding is the length of the frame payload or greater, the recipient MUST treat this as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

6.7. PING

The PING frame (type=0x06) is a mechanism for measuring a minimal round-trip time from the sender, as well as determining whether an idle connection is still functional. PING frames can be sent from any endpoint.¶

PING Frame { Length (24) = 0x08, Type (8) = 0x06, Unused Flags (7), ACK Flag (1), Reserved (1), Stream Identifier (31) = 0, Opaque Data (64), }

Figure 9: PING Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4.¶

In addition to the frame header, PING frames MUST contain 8 octets of opaque data in the frame payload. A sender can include any value it chooses and use those octets in any fashion.¶

Receivers of a PING frame that does not include an ACK flag MUST send a PING frame with the ACK flag set in response, with an identical frame payload. PING responses SHOULD be given higher priority than any other frame.¶

The PING frame defines the following flags:¶

ACK (0x01):

When set, the ACK flag indicates that this PING frame is a PING response. An endpoint MUST set this flag in PING responses. An endpoint MUST NOT respond to PING frames containing this flag.¶

PING frames are not associated with any individual stream. If a PING frame is received with a Stream Identifier field value other than 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

Receipt of a PING frame with a length field value other than 8 MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.8. GOAWAY

The GOAWAY frame (type=0x07) is used to initiate shutdown of a connection or to signal serious error conditions. GOAWAY allows an endpoint to gracefully stop accepting new streams while still finishing processing of previously established streams. This enables administrative actions, like server maintenance.¶

There is an inherent race condition between an endpoint starting new streams and the remote peer sending a GOAWAY frame. To deal with this case, the GOAWAY contains the stream identifier of the last peer-initiated stream that was or might be processed on the sending endpoint in this connection. For instance, if the server sends a GOAWAY frame, the identified stream is the highest-numbered stream initiated by the client.¶

Once the GOAWAY is sent, the sender will ignore frames sent on streams initiated by the receiver if the stream has an identifier higher than the included last stream identifier. Receivers of a GOAWAY frame MUST NOT open additional streams on the connection, although a new connection can be established for new streams.¶

If the receiver of the GOAWAY has sent data on streams with a higher stream identifier than what is indicated in the GOAWAY frame, those streams are not or will not be processed. The receiver of the GOAWAY frame can treat the streams as though they had never been created at all, thereby allowing those streams to be retried later on a new connection.¶

Endpoints SHOULD always send a GOAWAY frame before closing a connection so that the remote peer can know whether a stream has been partially processed or not. For example, if an HTTP client sends a POST at the same time that a server closes a connection, the client cannot know if the server started to process that POST request if the server does not send a GOAWAY frame to indicate what streams it might have acted on.¶

An endpoint might choose to close a connection without sending a GOAWAY for misbehaving peers.¶

A GOAWAY frame might not immediately precede closing of the connection; a receiver of a GOAWAY that has no more use for the connection SHOULD still send a GOAWAY frame before terminating the connection.¶

GOAWAY Frame { Length (24), Type (8) = 0x07, Unused Flags (8), Reserved (1), Stream Identifier (31) = 0, Reserved (1), Last-Stream-ID (31), Error Code (32), Additional Debug Data (..), }

Figure 10: GOAWAY Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4.¶

The GOAWAY frame does not define any flags.¶

The GOAWAY frame applies to the connection, not a specific stream. An endpoint MUST treat a GOAWAY frame with a stream identifier other than 0x00 as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The last stream identifier in the GOAWAY frame contains the highest-numbered stream identifier for which the sender of the GOAWAY frame might have taken some action on or might yet take action on. All streams up to and including the identified stream might have been processed in some way. The last stream identifier can be set to 0 if no streams were processed.¶

If a connection terminates without a GOAWAY frame, the last stream identifier is effectively the highest possible stream identifier.¶

On streams with lower- or equal-numbered identifiers that were not closed completely prior to the connection being closed, reattempting requests, transactions, or any protocol activity is not possible, except for idempotent actions like HTTP GET, PUT, or DELETE. Any protocol activity that uses higher-numbered streams can be safely retried using a new connection.¶

Activity on streams numbered lower than or equal to the last stream identifier might still complete successfully. The sender of a GOAWAY frame might gracefully shut down a connection by sending a GOAWAY frame, maintaining the connection in an "open" state until all in-progress streams complete.¶

An endpoint MAY send multiple GOAWAY frames if circumstances change. For instance, an endpoint that sends GOAWAY with NO_ERROR during graceful shutdown could subsequently encounter a condition that requires immediate termination of the connection. The last stream identifier from the last GOAWAY frame received indicates which streams could have been acted upon. Endpoints MUST NOT increase the value they send in the last stream identifier, since the peers might already have retried unprocessed requests on another connection.¶

A client that is unable to retry requests loses all requests that are in flight when the server closes the connection. This is especially true for intermediaries that might not be serving clients using HTTP/2. A server that is attempting to gracefully shut down a connection SHOULD send an initial GOAWAY frame with the last stream identifier set to 231-1 and a NO_ERROR code. This signals to the client that a shutdown is imminent and that initiating further requests is prohibited. After allowing time for any in-flight stream creation (at least one round-trip time), the server MAY send another GOAWAY frame with an updated last stream identifier. This ensures that a connection can be cleanly shut down without losing requests.¶

After sending a GOAWAY frame, the sender can discard frames for streams initiated by the receiver with identifiers higher than the identified last stream. However, any frames that alter connection state cannot be completely ignored. For instance, HEADERS, PUSH_PROMISE, and CONTINUATION frames MUST be minimally processed to ensure that the state maintained for field section compression is consistent (see Section 4.3); similarly, DATA frames MUST be counted toward the connection flow-control window. Failure to process these frames can cause flow control or field section compression state to become unsynchronized.¶

The GOAWAY frame also contains a 32-bit error code (Section 7) that contains the reason for closing the connection.¶

Endpoints MAY append opaque data to the frame payload of any GOAWAY frame. Additional debug data is intended for diagnostic purposes only and carries no semantic value. Debug information could contain security- or privacy-sensitive data. Logged or otherwise persistently stored debug data MUST have adequate safeguards to prevent unauthorized access.¶

6.9. WINDOW_UPDATE

The WINDOW_UPDATE frame (type=0x08) is used to implement flow control; see Section 5.2 for an overview.¶

Flow control operates at two levels: on each individual stream and on the entire connection.¶

Both types of flow control are hop by hop, that is, only between the two endpoints. Intermediaries do not forward WINDOW_UPDATE frames between dependent connections. However, throttling of data transfer by any receiver can indirectly cause the propagation of flow-control information toward the original sender.¶

Flow control only applies to frames that are identified as being subject to flow control. Of the frame types defined in this document, this includes only DATA frames. Frames that are exempt from flow control MUST be accepted and processed, unless the receiver is unable to assign resources to handling the frame. A receiver MAY respond with a stream error (Section 5.4.2) or connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR if it is unable to accept a frame.¶

WINDOW_UPDATE Frame { Length (24) = 0x04, Type (8) = 0x08, Unused Flags (8), Reserved (1), Stream Identifier (31), Reserved (1), Window Size Increment (31), }

Figure 11: WINDOW_UPDATE Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The frame payload of a WINDOW_UPDATE frame is one reserved bit plus an unsigned 31-bit integer indicating the number of octets that the sender can transmit in addition to the existing flow-control window. The legal range for the increment to the flow-control window is 1 to 231-1 (2,147,483,647) octets.¶

The WINDOW_UPDATE frame does not define any flags.¶

The WINDOW_UPDATE frame can be specific to a stream or to the entire connection. In the former case, the frame''s stream identifier indicates the affected stream; in the latter, the value "0" indicates that the entire connection is the subject of the frame.¶

A receiver MUST treat the receipt of a WINDOW_UPDATE frame with a flow-control window increment of 0 as a stream error (Section 5.4.2) of type PROTOCOL_ERROR; errors on the connection flow-control window MUST be treated as a connection error (Section 5.4.1).¶

WINDOW_UPDATE can be sent by a peer that has sent a frame with the END_STREAM flag set. This means that a receiver could receive a WINDOW_UPDATE frame on a stream in a "half-closed (remote)" or "closed" state. A receiver MUST NOT treat this as an error (see Section 5.1).¶

A receiver that receives a flow-controlled frame MUST always account for its contribution against the connection flow-control window, unless the receiver treats this as a connection error (Section 5.4.1). This is necessary even if the frame is in error. The sender counts the frame toward the flow-control window, but if the receiver does not, the flow-control window at the sender and receiver can become different.¶

A WINDOW_UPDATE frame with a length other than 4 octets MUST be treated as a connection error (Section 5.4.1) of type FRAME_SIZE_ERROR.¶

6.9.1. The Flow-Control Window

Flow control in HTTP/2 is implemented using a window kept by each sender on every stream. The flow-control window is a simple integer value that indicates how many octets of data the sender is permitted to transmit; as such, its size is a measure of the buffering capacity of the receiver.¶

Two flow-control windows are applicable: the stream flow-control window and the connection flow-control window. The sender MUST NOT send a flow-controlled frame with a length that exceeds the space available in either of the flow-control windows advertised by the receiver. Frames with zero length with the END_STREAM flag set (that is, an empty DATA frame) MAY be sent if there is no available space in either flow-control window.¶

For flow-control calculations, the 9-octet frame header is not counted.¶

After sending a flow-controlled frame, the sender reduces the space available in both windows by the length of the transmitted frame.¶

The receiver of a frame sends a WINDOW_UPDATE frame as it consumes data and frees up space in flow-control windows. Separate WINDOW_UPDATE frames are sent for the stream- and connection-level flow-control windows. Receivers are advised to have mechanisms in place to avoid sending WINDOW_UPDATE frames with very small increments; see Section 4.2.3.3 of [RFC1122].¶

A sender that receives a WINDOW_UPDATE frame updates the corresponding window by the amount specified in the frame.¶

A sender MUST NOT allow a flow-control window to exceed 231-1 octets. If a sender receives a WINDOW_UPDATE that causes a flow-control window to exceed this maximum, it MUST terminate either the stream or the connection, as appropriate. For streams, the sender sends a RST_STREAM with an error code of FLOW_CONTROL_ERROR; for the connection, a GOAWAY frame with an error code of FLOW_CONTROL_ERROR is sent.¶

Flow-controlled frames from the sender and WINDOW_UPDATE frames from the receiver are completely asynchronous with respect to each other. This property allows a receiver to aggressively update the window size kept by the sender to prevent streams from stalling.¶

6.9.2. Initial Flow-Control Window Size

When an HTTP/2 connection is first established, new streams are created with an initial flow-control window size of 65,535 octets. The connection flow-control window is also 65,535 octets. Both endpoints can adjust the initial window size for new streams by including a value for SETTINGS_INITIAL_WINDOW_SIZE in the SETTINGS frame. The connection flow-control window can only be changed using WINDOW_UPDATE frames.¶

Prior to receiving a SETTINGS frame that sets a value for SETTINGS_INITIAL_WINDOW_SIZE, an endpoint can only use the default initial window size when sending flow-controlled frames. Similarly, the connection flow-control window is set based on the default initial window size until a WINDOW_UPDATE frame is received.¶

In addition to changing the flow-control window for streams that are not yet active, a SETTINGS frame can alter the initial flow-control window size for streams with active flow-control windows (that is, streams in the "open" or "half-closed (remote)" state). When the value of SETTINGS_INITIAL_WINDOW_SIZE changes, a receiver MUST adjust the size of all stream flow-control windows that it maintains by the difference between the new value and the old value.¶

A change to SETTINGS_INITIAL_WINDOW_SIZE can cause the available space in a flow-control window to become negative. A sender MUST track the negative flow-control window and MUST NOT send new flow-controlled frames until it receives WINDOW_UPDATE frames that cause the flow-control window to become positive.¶

For example, if the client sends 60 KB immediately on connection establishment and the server sets the initial window size to be 16 KB, the client will recalculate the available flow-control window to be -44 KB on receipt of the SETTINGS frame. The client retains a negative flow-control window until WINDOW_UPDATE frames restore the window to being positive, after which the client can resume sending.¶

A SETTINGS frame cannot alter the connection flow-control window.¶

An endpoint MUST treat a change to SETTINGS_INITIAL_WINDOW_SIZE that causes any flow-control window to exceed the maximum size as a connection error (Section 5.4.1) of type FLOW_CONTROL_ERROR.¶

6.9.3. Reducing the Stream Window Size

A receiver that wishes to use a smaller flow-control window than the current size can send a new SETTINGS frame. However, the receiver MUST be prepared to receive data that exceeds this window size, since the sender might send data that exceeds the lower limit prior to processing the SETTINGS frame.¶

After sending a SETTINGS frame that reduces the initial flow-control window size, a receiver MAY continue to process streams that exceed flow-control limits. Allowing streams to continue does not allow the receiver to immediately reduce the space it reserves for flow-control windows. Progress on these streams can also stall, since WINDOW_UPDATE frames are needed to allow the sender to resume sending. The receiver MAY instead send a RST_STREAM with an error code of FLOW_CONTROL_ERROR for the affected streams.¶

6.10. CONTINUATION

The CONTINUATION frame (type=0x09) is used to continue a sequence of field block fragments (Section 4.3). Any number of CONTINUATION frames can be sent, as long as the preceding frame is on the same stream and is a HEADERS, PUSH_PROMISE, or CONTINUATION frame without the END_HEADERS flag set.¶

CONTINUATION Frame { Length (24), Type (8) = 0x09, Unused Flags (5), END_HEADERS Flag (1), Unused Flags (2), Reserved (1), Stream Identifier (31), Field Block Fragment (..), }

Figure 12: CONTINUATION Frame Format

The Length, Type, Unused Flag(s), Reserved, and Stream Identifier fields are described in Section 4. The CONTINUATION frame payload contains a field block fragment (Section 4.3).¶

The CONTINUATION frame defines the following flag:¶

END_HEADERS (0x04):

When set, the END_HEADERS flag indicates that this frame ends a field block (Section 4.3).¶

If the END_HEADERS flag is not set, this frame MUST be followed by another CONTINUATION frame. A receiver MUST treat the receipt of any other type of frame or a frame on a different stream as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The CONTINUATION frame changes the connection state as defined in Section 4.3.¶

CONTINUATION frames MUST be associated with a stream. If a CONTINUATION frame is received with a Stream Identifier field of 0x00, the recipient MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

A CONTINUATION frame MUST be preceded by a HEADERS, PUSH_PROMISE or CONTINUATION frame without the END_HEADERS flag set. A recipient that observes violation of this rule MUST respond with a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

7. Error Codes

Error codes are 32-bit fields that are used in RST_STREAM and GOAWAY frames to convey the reasons for the stream or connection error.¶

Error codes share a common code space. Some error codes apply only to either streams or the entire connection and have no defined semantics in the other context.¶

The following error codes are defined:¶

NO_ERROR (0x00):

The associated condition is not a result of an error. For example, a GOAWAY might include this code to indicate graceful shutdown of a connection.¶

PROTOCOL_ERROR (0x01):

The endpoint detected an unspecific protocol error. This error is for use when a more specific error code is not available.¶

INTERNAL_ERROR (0x02):

The endpoint encountered an unexpected internal error.¶

FLOW_CONTROL_ERROR (0x03):

The endpoint detected that its peer violated the flow-control protocol.¶

SETTINGS_TIMEOUT (0x04):

The endpoint sent a SETTINGS frame but did not receive a response in a timely manner. See Section 6.5.3 ("Settings Synchronization").¶

STREAM_CLOSED (0x05):

The endpoint received a frame after a stream was half-closed.¶

FRAME_SIZE_ERROR (0x06):

The endpoint received a frame with an invalid size.¶

REFUSED_STREAM (0x07):

The endpoint refused the stream prior to performing any application processing (see Section 8.7 for details).¶

CANCEL (0x08):

The endpoint uses this error code to indicate that the stream is no longer needed.¶

COMPRESSION_ERROR (0x09):

The endpoint is unable to maintain the field section compression context for the connection.¶

CONNECT_ERROR (0x0a):

The connection established in response to a CONNECT request (Section 8.5) was reset or abnormally closed.¶

ENHANCE_YOUR_CALM (0x0b):

The endpoint detected that its peer is exhibiting a behavior that might be generating excessive load.¶

INADEQUATE_SECURITY (0x0c):

The underlying transport has properties that do not meet minimum security requirements (see Section 9.2).¶

HTTP_1_1_REQUIRED (0x0d):

The endpoint requires that HTTP/1.1 be used instead of HTTP/2.¶

Unknown or unsupported error codes MUST NOT trigger any special behavior. These MAY be treated by an implementation as being equivalent to INTERNAL_ERROR.¶

8. Expressing HTTP Semantics in HTTP/2

HTTP/2 is an instantiation of the HTTP message abstraction (Section 6 of [HTTP]).¶

8.1. HTTP Message Framing

A client sends an HTTP request on a new stream, using a previously unused stream identifier (Section 5.1.1). A server sends an HTTP response on the same stream as the request.¶

An HTTP message (request or response) consists of:¶

one HEADERS frame (followed by zero or more CONTINUATION frames) containing the header section (see Section 6.3 of [HTTP]),¶

zero or more DATA frames containing the message content (see Section 6.4 of [HTTP]), and¶

optionally, one HEADERS frame (followed by zero or more CONTINUATION frames) containing the trailer section, if present (see Section 6.5 of [HTTP]).¶

For a response only, a server MAY send any number of interim responses before the HEADERS frame containing a final response. An interim response consists of a HEADERS frame (which might be followed by zero or more CONTINUATION frames) containing the control data and header section of an interim (1xx) HTTP response (see Section 15 of [HTTP]). A HEADERS frame with the END_STREAM flag set that carries an informational status code is malformed (Section 8.1.1).¶

The last frame in the sequence bears an END_STREAM flag, noting that a HEADERS frame with the END_STREAM flag set can be followed by CONTINUATION frames that carry any remaining fragments of the field block.¶

Other frames (from any stream) MUST NOT occur between the HEADERS frame and any CONTINUATION frames that might follow.¶

HTTP/2 uses DATA frames to carry message content. The chunked transfer encoding defined in Section 7.1 of [HTTP/1.1] cannot be used in HTTP/2; see Section 8.2.2.¶

Trailer fields are carried in a field block that also terminates the stream. That is, trailer fields comprise a sequence starting with a HEADERS frame, followed by zero or more CONTINUATION frames, where the HEADERS frame bears an END_STREAM flag. Trailers MUST NOT include pseudo-header fields (Section 8.3). An endpoint that receives pseudo-header fields in trailers MUST treat the request or response as malformed (Section 8.1.1).¶

An endpoint that receives a HEADERS frame without the END_STREAM flag set after receiving the HEADERS frame that opens a request or after receiving a final (non-informational) status code MUST treat the corresponding request or response as malformed (Section 8.1.1).¶

An HTTP request/response exchange fully consumes a single stream. A request starts with the HEADERS frame that puts the stream into the "open" state. The request ends with a frame with the END_STREAM flag set, which causes the stream to become "half-closed (local)" for the client and "half-closed (remote)" for the server. A response stream starts with zero or more interim responses in HEADERS frames, followed by a HEADERS frame containing a final status code.¶

An HTTP response is complete after the server sends -- or the client receives -- a frame with the END_STREAM flag set (including any CONTINUATION frames needed to complete a field block). A server can send a complete response prior to the client sending an entire request if the response does not depend on any portion of the request that has not been sent and received. When this is true, a server MAY request that the client abort transmission of a request without error by sending a RST_STREAM with an error code of NO_ERROR after sending a complete response (i.e., a frame with the END_STREAM flag set). Clients MUST NOT discard responses as a result of receiving such a RST_STREAM, though clients can always discard responses at their discretion for other reasons.¶

8.1.1. Malformed Messages

A malformed request or response is one that is an otherwise valid sequence of HTTP/2 frames but is invalid due to the presence of extraneous frames, prohibited fields or pseudo-header fields, the absence of mandatory pseudo-header fields, the inclusion of uppercase field names, or invalid field names and/or values (in certain circumstances; see Section 8.2).¶

A request or response that includes message content can include a content-length header field. A request or response is also malformed if the value of a content-length header field does not equal the sum of the DATA frame payload lengths that form the content, unless the message is defined as having no content. For example, 204 or 304 responses contain no content, as does the response to a HEAD request. A response that is defined to have no content, as described in Section 6.4.1 of [HTTP], MAY have a non-zero content-length header field, even though no content is included in DATA frames.¶

Intermediaries that process HTTP requests or responses (i.e., any intermediary not acting as a tunnel) MUST NOT forward a malformed request or response. Malformed requests or responses that are detected MUST be treated as a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

For malformed requests, a server MAY send an HTTP response prior to closing or resetting the stream. Clients MUST NOT accept a malformed response.¶

Endpoints that progressively process messages might have performed some processing before identifying a request or response as malformed. For instance, it might be possible to generate an informational or 404 status code without having received a complete request. Similarly, intermediaries might forward incomplete messages before detecting errors. A server MAY generate a final response before receiving an entire request when the response does not depend on the remainder of the request being correct.¶

These requirements are intended to protect against several types of common attacks against HTTP; they are deliberately strict because being permissive can expose implementations to these vulnerabilities.¶

8.2. HTTP Fields

HTTP fields (Section 5 of [HTTP]) are conveyed by HTTP/2 in the HEADERS, CONTINUATION, and PUSH_PROMISE frames, compressed with HPACK [COMPRESSION].¶

Field names MUST be converted to lowercase when constructing an HTTP/2 message.¶

8.2.1. Field Validity

The definitions of field names and values in HTTP prohibit some characters that HPACK might be able to convey. HTTP/2 implementations SHOULD validate field names and values according to their definitions in Sections 5.1 and 5.5 of [HTTP], respectively, and treat messages that contain prohibited characters as malformed (Section 8.1.1).¶

Failure to validate fields can be exploited for request smuggling attacks. In particular, unvalidated fields might enable attacks when messages are forwarded using HTTP/1.1 [HTTP/1.1], where characters such as carriage return (CR), line feed (LF), and COLON are used as delimiters. Implementations MUST perform the following minimal validation of field names and values:¶

A field name MUST NOT contain characters in the ranges 0x00-0x20, 0x41-0x5a, or 0x7f-0xff (all ranges inclusive). This specifically excludes all non-visible ASCII characters, ASCII SP (0x20), and uppercase characters (''A'' to ''Z'', ASCII 0x41 to 0x5a).¶

With the exception of pseudo-header fields (Section 8.3), which have a name that starts with a single colon, field names MUST NOT include a colon (ASCII COLON, 0x3a).¶

A field value MUST NOT contain the zero value (ASCII NUL, 0x00), line feed (ASCII LF, 0x0a), or carriage return (ASCII CR, 0x0d) at any position.¶

A field value MUST NOT start or end with an ASCII whitespace character (ASCII SP or HTAB, 0x20 or 0x09).¶

A request or response that contains a field that violates any of these conditions MUST be treated as malformed (Section 8.1.1). In particular, an intermediary that does not process fields when forwarding messages MUST NOT forward fields that contain any of the values that are listed as prohibited above.¶

When a request message violates one of these requirements, an implementation SHOULD generate a 400 (Bad Request) status code (see Section 15.5.1 of [HTTP]), unless a more suitable status code is defined or the status code cannot be sent (e.g., because the error occurs in a trailer field).¶

8.2.2. Connection-Specific Header Fields

HTTP/2 does not use the Connection header field (Section 7.6.1 of [HTTP]) to indicate connection-specific header fields; in this protocol, connection-specific metadata is conveyed by other means. An endpoint MUST NOT generate an HTTP/2 message containing connection-specific header fields. This includes the Connection header field and those listed as having connection-specific semantics in Section 7.6.1 of [HTTP] (that is, Proxy-Connection, Keep-Alive, Transfer-Encoding, and Upgrade). Any message containing connection-specific header fields MUST be treated as malformed (Section 8.1.1).¶

The only exception to this is the TE header field, which MAY be present in an HTTP/2 request; when it is, it MUST NOT contain any value other than "trailers".¶

An intermediary transforming an HTTP/1.x message to HTTP/2 MUST remove connection-specific header fields as discussed in Section 7.6.1 of [HTTP], or their messages will be treated by other HTTP/2 endpoints as malformed (Section 8.1.1).¶

8.2.3. Compressing the Cookie Header Field

The Cookie header field [COOKIE] uses a semicolon (";") to delimit cookie-pairs (or "crumbs"). This header field contains multiple values, but does not use a COMMA (",") as a separator, thereby preventing cookie-pairs from being sent on multiple field lines (see Section 5.2 of [HTTP]). This can significantly reduce compression efficiency, as updates to individual cookie-pairs would invalidate any field lines that are stored in the HPACK table.¶

To allow for better compression efficiency, the Cookie header field MAY be split into separate header fields, each with one or more cookie-pairs. If there are multiple Cookie header fields after decompression, these MUST be concatenated into a single octet string using the two-octet delimiter of 0x3b, 0x20 (the ASCII string "; ") before being passed into a non-HTTP/2 context, such as an HTTP/1.1 connection, or a generic HTTP server application.¶

Therefore, the following two lists of Cookie header fields are semantically equivalent.¶

cookie: a=b; c=d; e=f cookie: a=b cookie: c=d cookie: e=f

¶

8.3. HTTP Control Data

HTTP/2 uses special pseudo-header fields beginning with a '':'' character (ASCII 0x3a) to convey message control data (see Section 6.2 of [HTTP]).¶

Pseudo-header fields are not HTTP header fields. Endpoints MUST NOT generate pseudo-header fields other than those defined in this document. Note that an extension could negotiate the use of additional pseudo-header fields; see Section 5.5.¶

Pseudo-header fields are only valid in the context in which they are defined. Pseudo-header fields defined for requests MUST NOT appear in responses; pseudo-header fields defined for responses MUST NOT appear in requests. Pseudo-header fields MUST NOT appear in a trailer section. Endpoints MUST treat a request or response that contains undefined or invalid pseudo-header fields as malformed (Section 8.1.1).¶

All pseudo-header fields MUST appear in a field block before all regular field lines. Any request or response that contains a pseudo-header field that appears in a field block after a regular field line MUST be treated as malformed (Section 8.1.1).¶

The same pseudo-header field name MUST NOT appear more than once in a field block. A field block for an HTTP request or response that contains a repeated pseudo-header field name MUST be treated as malformed (Section 8.1.1).¶

8.3.1. Request Pseudo-Header Fields

The following pseudo-header fields are defined for HTTP/2 requests:¶

The ":method" pseudo-header field includes the HTTP method (Section 9 of [HTTP]).¶

The ":scheme" pseudo-header field includes the scheme portion of the request target. The scheme is taken from the target URI (Section 3.1 of [RFC3986]) when generating a request directly, or from the scheme of a translated request (for example, see Section 3.3 of [HTTP/1.1]). Scheme is omitted for CONNECT requests (Section 8.5).¶

":scheme" is not restricted to "http" and "https" schemed URIs. A proxy or gateway can translate requests for non-HTTP schemes, enabling the use of HTTP to interact with non-HTTP services.¶

The ":authority" pseudo-header field conveys the authority portion (Section 3.2 of [RFC3986]) of the target URI (Section 7.1 of [HTTP]). The recipient of an HTTP/2 request MUST NOT use the Host header field to determine the target URI if ":authority" is present.¶

Clients that generate HTTP/2 requests directly MUST use the ":authority" pseudo-header field to convey authority information, unless there is no authority information to convey (in which case it MUST NOT generate ":authority").¶

Clients MUST NOT generate a request with a Host header field that differs from the ":authority" pseudo-header field. A server SHOULD treat a request as malformed if it contains a Host header field that identifies an entity that differs from the entity in the ":authority" pseudo-header field. The values of fields need to be normalized to compare them (see Section 6.2 of [RFC3986]). An origin server can apply any normalization method, whereas other servers MUST perform scheme-based normalization (see Section 6.2.3 of [RFC3986]) of the two fields.¶

An intermediary that forwards a request over HTTP/2 MUST construct an ":authority" pseudo-header field using the authority information from the control data of the original request, unless the original request''s target URI does not contain authority information (in which case it MUST NOT generate ":authority"). Note that the Host header field is not the sole source of this information; see Section 7.2 of [HTTP].¶

An intermediary that needs to generate a Host header field (which might be necessary to construct an HTTP/1.1 request) MUST use the value from the ":authority" pseudo-header field as the value of the Host field, unless the intermediary also changes the request target. This replaces any existing Host field to avoid potential vulnerabilities in HTTP routing.¶

An intermediary that forwards a request over HTTP/2 MAY retain any Host header field.¶

Note that request targets for CONNECT or asterisk-form OPTIONS requests never include authority information; see Sections 7.1 and 7.2 of [HTTP].¶

":authority" MUST NOT include the deprecated userinfo subcomponent for "http" or "https" schemed URIs.¶

The ":path" pseudo-header field includes the path and query parts of the target URI (the absolute-path production and, optionally, a ''?'' character followed by the query production; see Section 4.1 of [HTTP]). A request in asterisk form (for OPTIONS) includes the value ''*'' for the ":path" pseudo-header field.¶

This pseudo-header field MUST NOT be empty for "http" or "https" URIs; "http" or "https" URIs that do not contain a path component MUST include a value of ''/''. The exceptions to this rule are:¶

an OPTIONS request for an "http" or "https" URI that does not include a path component; these MUST include a ":path" pseudo-header field with a value of ''*'' (see Section 7.1 of [HTTP]).¶

CONNECT requests (Section 8.5), where the ":path" pseudo-header field is omitted.¶

All HTTP/2 requests MUST include exactly one valid value for the ":method", ":scheme", and ":path" pseudo-header fields, unless they are CONNECT requests (Section 8.5). An HTTP request that omits mandatory pseudo-header fields is malformed (Section 8.1.1).¶

Individual HTTP/2 requests do not carry an explicit indicator of protocol version. All HTTP/2 requests implicitly have a protocol version of "2.0" (see Section 6.2 of [HTTP]).¶

8.3.2. Response Pseudo-Header Fields

For HTTP/2 responses, a single ":status" pseudo-header field is defined that carries the HTTP status code field (see Section 15 of [HTTP]). This pseudo-header field MUST be included in all responses, including interim responses; otherwise, the response is malformed (Section 8.1.1).¶

HTTP/2 responses implicitly have a protocol version of "2.0".¶

8.4. Server Push

HTTP/2 allows a server to preemptively send (or "push") responses (along with corresponding "promised" requests) to a client in association with a previous client-initiated request.¶

Server push was designed to allow a server to improve client-perceived performance by predicting what requests will follow those that it receives, thereby removing a round trip for them. For example, a request for HTML is often followed by requests for stylesheets and scripts referenced by that page. When these requests are pushed, the client does not need to wait to receive the references to them in the HTML and issue separate requests.¶

In practice, server push is difficult to use effectively, because it requires the server to correctly anticipate the additional requests the client will make, taking into account factors such as caching, content negotiation, and user behavior. Errors in prediction can lead to performance degradation, due to the opportunity cost that the additional data on the wire represents. In particular, pushing any significant amount of data can cause contention issues with responses that are more important.¶

A client can request that server push be disabled, though this is negotiated for each hop independently. The SETTINGS_ENABLE_PUSH setting can be set to 0 to indicate that server push is disabled.¶

Promised requests MUST be safe (see Section 9.2.1 of [HTTP]) and cacheable (see Section 9.2.3 of [HTTP]). Promised requests cannot include any content or a trailer section. Clients that receive a promised request that is not cacheable, that is not known to be safe, or that indicates the presence of request content MUST reset the promised stream with a stream error (Section 5.4.2) of type PROTOCOL_ERROR. Note that this could result in the promised stream being reset if the client does not recognize a newly defined method as being safe.¶

Pushed responses that are cacheable (see Section 3 of [CACHING]) can be stored by the client, if it implements an HTTP cache. Pushed responses are considered successfully validated on the origin server (e.g., if the "no-cache" cache response directive is present; see Section 5.2.2.4 of [CACHING]) while the stream identified by the promised stream identifier is still open.¶

Pushed responses that are not cacheable MUST NOT be stored by any HTTP cache. They MAY be made available to the application separately.¶

The server MUST include a value in the ":authority" pseudo-header field for which the server is authoritative (see Section 10.1). A client MUST treat a PUSH_PROMISE for which the server is not authoritative as a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

An intermediary can receive pushes from the server and choose not to forward them on to the client. In other words, how to make use of the pushed information is up to that intermediary. Equally, the intermediary might choose to make additional pushes to the client, without any action taken by the server.¶

A client cannot push. Thus, servers MUST treat the receipt of a PUSH_PROMISE frame as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. A server cannot set the SETTINGS_ENABLE_PUSH setting to a value other than 0 (see Section 6.5.2).¶

8.4.1. Push Requests

Server push is semantically equivalent to a server responding to a request; however, in this case, that request is also sent by the server, as a PUSH_PROMISE frame.¶

The PUSH_PROMISE frame includes a field block that contains control data and a complete set of request header fields that the server attributes to the request. It is not possible to push a response to a request that includes message content.¶

Promised requests are always associated with an explicit request from the client. The PUSH_PROMISE frames sent by the server are sent on that explicit request''s stream. The PUSH_PROMISE frame also includes a promised stream identifier, chosen from the stream identifiers available to the server (see Section 5.1.1).¶

The header fields in PUSH_PROMISE and any subsequent CONTINUATION frames MUST be a valid and complete set of request header fields (Section 8.3.1). The server MUST include a method in the ":method" pseudo-header field that is safe and cacheable. If a client receives a PUSH_PROMISE that does not include a complete and valid set of header fields or the ":method" pseudo-header field identifies a method that is not safe, it MUST respond on the promised stream with a stream error (Section 5.4.2) of type PROTOCOL_ERROR.¶

The server SHOULD send PUSH_PROMISE (Section 6.6) frames prior to sending any frames that reference the promised responses. This avoids a race where clients issue requests prior to receiving any PUSH_PROMISE frames.¶

For example, if the server receives a request for a document containing embedded links to multiple image files and the server chooses to push those additional images to the client, sending PUSH_PROMISE frames before the DATA frames that contain the image links ensures that the client is able to see that a resource will be pushed before discovering embedded links. Similarly, if the server pushes resources referenced by the field block (for instance, in Link header fields), sending a PUSH_PROMISE before sending the header ensures that clients do not request those resources.¶

PUSH_PROMISE frames MUST NOT be sent by the client.¶

PUSH_PROMISE frames can be sent by the server on any client-initiated stream, but the stream MUST be in either the "open" or "half-closed (remote)" state with respect to the server. PUSH_PROMISE frames are interspersed with the frames that comprise a response, though they cannot be interspersed with HEADERS and CONTINUATION frames that comprise a single field block.¶

Sending a PUSH_PROMISE frame creates a new stream and puts the stream into the "reserved (local)" state for the server and the "reserved (remote)" state for the client.¶

8.4.2. Push Responses

After sending the PUSH_PROMISE frame, the server can begin delivering the pushed response as a response (Section 8.3.2) on a server-initiated stream that uses the promised stream identifier. The server uses this stream to transmit an HTTP response, using the same sequence of frames as that defined in Section 8.1. This stream becomes "half-closed" to the client (Section 5.1) after the initial HEADERS frame is sent.¶

Once a client receives a PUSH_PROMISE frame and chooses to accept the pushed response, the client SHOULD NOT issue any requests for the promised response until after the promised stream has closed.¶

If the client determines, for any reason, that it does not wish to receive the pushed response from the server or if the server takes too long to begin sending the promised response, the client can send a RST_STREAM frame, using either the CANCEL or REFUSED_STREAM code and referencing the pushed stream''s identifier.¶

A client can use the SETTINGS_MAX_CONCURRENT_STREAMS setting to limit the number of responses that can be concurrently pushed by a server. Advertising a SETTINGS_MAX_CONCURRENT_STREAMS value of zero prevents the server from opening the streams necessary to push responses. However, this does not prevent the server from reserving streams using PUSH_PROMISE frames, because reserved streams do not count toward the concurrent stream limit. Clients that do not wish to receive pushed resources need to reset any unwanted reserved streams or set SETTINGS_ENABLE_PUSH to 0.¶

Clients receiving a pushed response MUST validate that either the server is authoritative (see Section 10.1) or the proxy that provided the pushed response is configured for the corresponding request. For example, a server that offers a certificate for only the example.com DNS-ID (see [RFC6125]) is not permitted to push a response for <https://www.example.org/doc>.¶

The response for a PUSH_PROMISE stream begins with a HEADERS frame, which immediately puts the stream into the "half-closed (remote)" state for the server and "half-closed (local)" state for the client, and ends with a frame with the END_STREAM flag set, which places the stream in the "closed" state.¶

8.5. The CONNECT Method

The CONNECT method (Section 9.3.6 of [HTTP]) is used to convert an HTTP connection into a tunnel to a remote host. CONNECT is primarily used with HTTP proxies to establish a TLS session with an origin server for the purposes of interacting with "https" resources.¶

In HTTP/2, the CONNECT method establishes a tunnel over a single HTTP/2 stream to a remote host, rather than converting the entire connection to a tunnel. A CONNECT header section is constructed as defined in Section 8.3.1 ("Request Pseudo-Header Fields"), with a few differences. Specifically:¶

The ":method" pseudo-header field is set to CONNECT.¶

The ":scheme" and ":path" pseudo-header fields MUST be omitted.¶

The ":authority" pseudo-header field contains the host and port to connect to (equivalent to the authority-form of the request-target of CONNECT requests; see Section 3.2.3 of [HTTP/1.1]).¶

A CONNECT request that does not conform to these restrictions is malformed (Section 8.1.1).¶

A proxy that supports CONNECT establishes a TCP connection [TCP] to the host and port identified in the ":authority" pseudo-header field. Once this connection is successfully established, the proxy sends a HEADERS frame containing a 2xx-series status code to the client, as defined in Section 9.3.6 of [HTTP].¶

After the initial HEADERS frame sent by each peer, all subsequent DATA frames correspond to data sent on the TCP connection. The frame payload of any DATA frames sent by the client is transmitted by the proxy to the TCP server; data received from the TCP server is assembled into DATA frames by the proxy. Frame types other than DATA or stream management frames (RST_STREAM, WINDOW_UPDATE, and PRIORITY) MUST NOT be sent on a connected stream and MUST be treated as a stream error (Section 5.4.2) if received.¶

The TCP connection can be closed by either peer. The END_STREAM flag on a DATA frame is treated as being equivalent to the TCP FIN bit. A client is expected to send a DATA frame with the END_STREAM flag set after receiving a frame with the END_STREAM flag set. A proxy that receives a DATA frame with the END_STREAM flag set sends the attached data with the FIN bit set on the last TCP segment. A proxy that receives a TCP segment with the FIN bit set sends a DATA frame with the END_STREAM flag set. Note that the final TCP segment or DATA frame could be empty.¶

A TCP connection error is signaled with RST_STREAM. A proxy treats any error in the TCP connection, which includes receiving a TCP segment with the RST bit set, as a stream error (Section 5.4.2) of type CONNECT_ERROR. Correspondingly, a proxy MUST send a TCP segment with the RST bit set if it detects an error with the stream or the HTTP/2 connection.¶

8.6. The Upgrade Header Field

HTTP/2 does not support the 101 (Switching Protocols) informational status code (Section 15.2.2 of [HTTP]).¶

The semantics of 101 (Switching Protocols) aren''t applicable to a multiplexed protocol. Similar functionality might be enabled through the use of extended CONNECT [RFC8441], and other protocols are able to use the same mechanisms that HTTP/2 uses to negotiate their use (see Section 3).¶

8.7. Request Reliability

In general, an HTTP client is unable to retry a non-idempotent request when an error occurs because there is no means to determine the nature of the error (see Section 9.2.2 of [HTTP]). It is possible that some server processing occurred prior to the error, which could result in undesirable effects if the request were reattempted.¶

HTTP/2 provides two mechanisms for providing a guarantee to a client that a request has not been processed:¶

The GOAWAY frame indicates the highest stream number that might have been processed. Requests on streams with higher numbers are therefore guaranteed to be safe to retry.¶

The REFUSED_STREAM error code can be included in a RST_STREAM frame to indicate that the stream is being closed prior to any processing having occurred. Any request that was sent on the reset stream can be safely retried.¶

Requests that have not been processed have not failed; clients MAY automatically retry them, even those with non-idempotent methods.¶

A server MUST NOT indicate that a stream has not been processed unless it can guarantee that fact. If frames that are on a stream are passed to the application layer for any stream, then REFUSED_STREAM MUST NOT be used for that stream, and a GOAWAY frame MUST include a stream identifier that is greater than or equal to the given stream identifier.¶

In addition to these mechanisms, the PING frame provides a way for a client to easily test a connection. Connections that remain idle can become broken, because some middleboxes (for instance, network address translators or load balancers) silently discard connection bindings. The PING frame allows a client to safely test whether a connection is still active without sending a request.¶

8.8. Examples

This section shows HTTP/1.1 requests and responses, with illustrations of equivalent HTTP/2 requests and responses.¶

8.8.1. Simple Request

An HTTP GET request includes control data and a request header with no message content and is therefore transmitted as a single HEADERS frame, followed by zero or more CONTINUATION frames containing the serialized block of request header fields. The HEADERS frame in the following has both the END_HEADERS and END_STREAM flags set; no CONTINUATION frames are sent.¶

GET /resource HTTP/1.1 HEADERS Host: example.org ==> + END_STREAM Accept: image/jpeg + END_HEADERS :method = GET :scheme = https :authority = example.org :path = /resource host = example.org accept = image/jpeg

¶

8.8.2. Simple Response

Similarly, a response that includes only control data and a response header is transmitted as a HEADERS frame (again, followed by zero or more CONTINUATION frames) containing the serialized block of response header fields.¶

HTTP/1.1 304 Not Modified HEADERS ETag: "xyzzy" ==> + END_STREAM Expires: Thu, 23 Jan ... + END_HEADERS :status = 304 etag = "xyzzy" expires = Thu, 23 Jan ...

¶

8.8.3. Complex Request

An HTTP POST request that includes control data and a request header with message content is transmitted as one HEADERS frame, followed by zero or more CONTINUATION frames containing the request header, followed by one or more DATA frames, with the last CONTINUATION (or HEADERS) frame having the END_HEADERS flag set and the final DATA frame having the END_STREAM flag set:¶

POST /resource HTTP/1.1 HEADERS Host: example.org ==> - END_STREAM Content-Type: image/jpeg - END_HEADERS Content-Length: 123 :method = POST :authority = example.org :path = /resource {binary data} :scheme = https CONTINUATION + END_HEADERS content-type = image/jpeg host = example.org content-length = 123 DATA + END_STREAM {binary data}

¶

Note that data contributing to any given field line could be spread between field block fragments. The allocation of field lines to frames in this example is illustrative only.¶

8.8.4. Response with Body

A response that includes control data and a response header with message content is transmitted as a HEADERS frame, followed by zero or more CONTINUATION frames, followed by one or more DATA frames, with the last DATA frame in the sequence having the END_STREAM flag set:¶

HTTP/1.1 200 OK HEADERS Content-Type: image/jpeg ==> - END_STREAM Content-Length: 123 + END_HEADERS :status = 200 {binary data} content-type = image/jpeg content-length = 123 DATA + END_STREAM {binary data}

¶

8.8.5. Informational Responses

An informational response using a 1xx status code other than 101 is transmitted as a HEADERS frame, followed by zero or more CONTINUATION frames.¶

A trailer section is sent as a field block after both the request or response field block and all the DATA frames have been sent. The HEADERS frame starting the field block that comprises the trailer section has the END_STREAM flag set.¶

The following example includes both a 100 (Continue) status code, which is sent in response to a request containing a "100-continue" token in the Expect header field, and a trailer section:¶

HTTP/1.1 100 Continue HEADERS Extension-Field: bar ==> - END_STREAM + END_HEADERS :status = 100 extension-field = bar HTTP/1.1 200 OK HEADERS Content-Type: image/jpeg ==> - END_STREAM Transfer-Encoding: chunked + END_HEADERS Trailer: Foo :status = 200 content-type = image/jpeg 123 trailer = Foo {binary data} 0 DATA Foo: bar - END_STREAM {binary data} HEADERS + END_STREAM + END_HEADERS foo = bar

¶

9. HTTP/2 Connections

This section outlines attributes of HTTP that improve interoperability, reduce exposure to known security vulnerabilities, or reduce the potential for implementation variation.¶

9.1. Connection Management

HTTP/2 connections are persistent. For best performance, it is expected that clients will not close connections until it is determined that no further communication with a server is necessary (for example, when a user navigates away from a particular web page) or until the server closes the connection.¶

Clients SHOULD NOT open more than one HTTP/2 connection to a given host and port pair, where the host is derived from a URI, a selected alternative service [ALT-SVC], or a configured proxy.¶

A client can create additional connections as replacements, either to replace connections that are near to exhausting the available stream identifier space (Section 5.1.1), to refresh the keying material for a TLS connection, or to replace connections that have encountered errors (Section 5.4.1).¶

A client MAY open multiple connections to the same IP address and TCP port using different Server Name Indication [TLS-EXT] values or to provide different TLS client certificates but SHOULD avoid creating multiple connections with the same configuration.¶

Servers are encouraged to maintain open connections for as long as possible but are permitted to terminate idle connections if necessary. When either endpoint chooses to close the transport-layer TCP connection, the terminating endpoint SHOULD first send a GOAWAY (Section 6.8) frame so that both endpoints can reliably determine whether previously sent frames have been processed and gracefully complete or terminate any necessary remaining tasks.¶

9.1.1. Connection Reuse

Connections that are made to an origin server, either directly or through a tunnel created using the CONNECT method (Section 8.5), MAY be reused for requests with multiple different URI authority components. A connection can be reused as long as the origin server is authoritative (Section 10.1). For TCP connections without TLS, this depends on the host having resolved to the same IP address.¶

For "https" resources, connection reuse additionally depends on having a certificate that is valid for the host in the URI. The certificate presented by the server MUST satisfy any checks that the client would perform when forming a new TLS connection for the host in the URI. A single certificate can be used to establish authority for multiple origins. Section 4.3 of [HTTP] describes how a client determines whether a server is authoritative for a URI.¶

In some deployments, reusing a connection for multiple origins can result in requests being directed to the wrong origin server. For example, TLS termination might be performed by a middlebox that uses the TLS Server Name Indication [TLS-EXT] extension to select an origin server. This means that it is possible for clients to send requests to servers that might not be the intended target for the request, even though the server is otherwise authoritative.¶

A server that does not wish clients to reuse connections can indicate that it is not authoritative for a request by sending a 421 (Misdirected Request) status code in response to the request (see Section 15.5.20 of [HTTP]).¶

A client that is configured to use a proxy over HTTP/2 directs requests to that proxy through a single connection. That is, all requests sent via a proxy reuse the connection to the proxy.¶

9.2. Use of TLS Features

Implementations of HTTP/2 MUST use TLS version 1.2 [TLS12] or higher for HTTP/2 over TLS. The general TLS usage guidance in [TLSBCP] SHOULD be followed, with some additional restrictions that are specific to HTTP/2.¶

The TLS implementation MUST support the Server Name Indication (SNI) [TLS-EXT] extension to TLS. If the server is identified by a domain name [DNS-TERMS], clients MUST send the server_name TLS extension unless an alternative mechanism to indicate the target host is used.¶

Requirements for deployments of HTTP/2 that negotiate TLS 1.3 [TLS13] are included in Section 9.2.3. Deployments of TLS 1.2 are subject to the requirements in Sections 9.2.1 and 9.2.2. Implementations are encouraged to provide defaults that comply, but it is recognized that deployments are ultimately responsible for compliance.¶

9.2.1. TLS 1.2 Features

This section describes restrictions on the TLS 1.2 feature set that can be used with HTTP/2. Due to deployment limitations, it might not be possible to fail TLS negotiation when these restrictions are not met. An endpoint MAY immediately terminate an HTTP/2 connection that does not meet these TLS requirements with a connection error (Section 5.4.1) of type INADEQUATE_SECURITY.¶

A deployment of HTTP/2 over TLS 1.2 MUST disable compression. TLS compression can lead to the exposure of information that would not otherwise be revealed [RFC3749]. Generic compression is unnecessary, since HTTP/2 provides compression features that are more aware of context and therefore likely to be more appropriate for use for performance, security, or other reasons.¶

A deployment of HTTP/2 over TLS 1.2 MUST disable renegotiation. An endpoint MUST treat a TLS renegotiation as a connection error (Section 5.4.1) of type PROTOCOL_ERROR. Note that disabling renegotiation can result in long-lived connections becoming unusable due to limits on the number of messages the underlying cipher suite can encipher.¶

An endpoint MAY use renegotiation to provide confidentiality protection for client credentials offered in the handshake, but any renegotiation MUST occur prior to sending the connection preface. A server SHOULD request a client certificate if it sees a renegotiation request immediately after establishing a connection.¶

This effectively prevents the use of renegotiation in response to a request for a specific protected resource. A future specification might provide a way to support this use case. Alternatively, a server might use an error (Section 5.4) of type HTTP_1_1_REQUIRED to request that the client use a protocol that supports renegotiation.¶

Implementations MUST support ephemeral key exchange sizes of at least 2048 bits for cipher suites that use ephemeral finite field Diffie-Hellman (DHE) (Section 8.1.2 of [TLS12]) and 224 bits for cipher suites that use ephemeral elliptic curve Diffie-Hellman (ECDHE) [RFC8422]. Clients MUST accept DHE sizes of up to 4096 bits. Endpoints MAY treat negotiation of key sizes smaller than the lower limits as a connection error (Section 5.4.1) of type INADEQUATE_SECURITY.¶

9.2.2. TLS 1.2 Cipher Suites

A deployment of HTTP/2 over TLS 1.2 SHOULD NOT use any of the prohibited cipher suites listed in Appendix A.¶

Endpoints MAY choose to generate a connection error (Section 5.4.1) of type INADEQUATE_SECURITY if one of the prohibited cipher suites is negotiated. A deployment that chooses to use a prohibited cipher suite risks triggering a connection error unless the set of potential peers is known to accept that cipher suite.¶

Implementations MUST NOT generate this error in reaction to the negotiation of a cipher suite that is not prohibited. Consequently, when clients offer a cipher suite that is not prohibited, they have to be prepared to use that cipher suite with HTTP/2.¶

The list of prohibited cipher suites includes the cipher suite that TLS 1.2 makes mandatory, which means that TLS 1.2 deployments could have non-intersecting sets of permitted cipher suites. To avoid this problem, which causes TLS handshake failures, deployments of HTTP/2 that use TLS 1.2 MUST support TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 [TLS-ECDHE] with the P-256 elliptic curve [RFC8422].¶

Note that clients might advertise support of cipher suites that are prohibited in order to allow for connection to servers that do not support HTTP/2. This allows servers to select HTTP/1.1 with a cipher suite that is prohibited in HTTP/2. However, this can result in HTTP/2 being negotiated with a prohibited cipher suite if the application protocol and cipher suite are independently selected.¶

9.2.3. TLS 1.3 Features

TLS 1.3 includes a number of features not available in earlier versions. This section discusses the use of these features.¶

HTTP/2 servers MUST NOT send post-handshake TLS 1.3 CertificateRequest messages. HTTP/2 clients MUST treat a TLS post-handshake CertificateRequest message as a connection error (Section 5.4.1) of type PROTOCOL_ERROR.¶

The prohibition on post-handshake authentication applies even if the client offered the "post_handshake_auth" TLS extension. Post-handshake authentication support might be advertised independently of ALPN [TLS-ALPN]. Clients might offer the capability for use in other protocols, but inclusion of the extension cannot imply support within HTTP/2.¶

[TLS13] defines other post-handshake messages, NewSessionTicket and KeyUpdate, which can be used as they have no direct interaction with HTTP/2. Unless the use of a new type of TLS message depends on an interaction with the application-layer protocol, that TLS message can be sent after the handshake completes.¶

TLS early data MAY be used to send requests, provided that the guidance in [RFC8470] is observed. Clients send requests in early data assuming initial values for all server settings.¶

10. Security Considerations

The use of TLS is necessary to provide many of the security properties of this protocol. Many of the claims in this section do not hold unless TLS is used as described in Section 9.2.¶

10.1. Server Authority

HTTP/2 relies on the HTTP definition of authority for determining whether a server is authoritative in providing a given response (see Section 4.3 of [HTTP]). This relies on local name resolution for the "http" URI scheme and the authenticated server identity for the "https" scheme.¶

10.2. Cross-Protocol Attacks

In a cross-protocol attack, an attacker causes a client to initiate a transaction in one protocol toward a server that understands a different protocol. An attacker might be able to cause the transaction to appear as a valid transaction in the second protocol. In combination with the capabilities of the web context, this can be used to interact with poorly protected servers in private networks.¶

Completing a TLS handshake with an ALPN identifier for HTTP/2 can be considered sufficient protection against cross-protocol attacks. ALPN provides a positive indication that a server is willing to proceed with HTTP/2, which prevents attacks on other TLS-based protocols.¶

The encryption in TLS makes it difficult for attackers to control the data that could be used in a cross-protocol attack on a cleartext protocol.¶

The cleartext version of HTTP/2 has minimal protection against cross-protocol attacks. The connection preface (Section 3.4) contains a string that is designed to confuse HTTP/1.1 servers, but no special protection is offered for other protocols.¶

10.3. Intermediary Encapsulation Attacks

HPACK permits encoding of field names and values that might be treated as delimiters in other HTTP versions. An intermediary that translates an HTTP/2 request or response MUST validate fields according to the rules in Section 8.2 before translating a message to another HTTP version. Translating a field that includes invalid delimiters could be used to cause recipients to incorrectly interpret a message, which could be exploited by an attacker.¶

Section 8.2 does not include specific rules for validation of pseudo-header fields. If the values of these fields are used, additional validation is necessary. This is particularly important where ":scheme", ":authority", and ":path" are combined to form a single URI string [RFC3986]. Similar problems might occur when that URI or just ":path" is combined with ":method" to construct a request line (as in Section 3 of [HTTP/1.1]). Simple concatenation is not secure unless the input values are fully validated.¶

An intermediary can reject fields that contain invalid field names or values for other reasons -- in particular, those fields that do not conform to the HTTP ABNF grammar from Section 5 of [HTTP]. Intermediaries that do not perform any validation of fields other than the minimum required by Section 8.2 could forward messages that contain invalid field names or values.¶

An intermediary that receives any fields that require removal before forwarding (see Section 7.6.1 of [HTTP]) MUST remove or replace those header fields when forwarding messages. Additionally, intermediaries should take care when forwarding messages containing Content-Length fields to ensure that the message is well-formed (Section 8.1.1). This ensures that if the message is translated into HTTP/1.1 at any point, the framing will be correct.¶

10.4. Cacheability of Pushed Responses

Pushed responses do not have an explicit request from the client; the request is provided by the server in the PUSH_PROMISE frame.¶

Caching responses that are pushed is possible based on the guidance provided by the origin server in the Cache-Control header field. However, this can cause issues if a single server hosts more than one tenant. For example, a server might offer multiple users each a small portion of its URI space.¶

Where multiple tenants share space on the same server, that server MUST ensure that tenants are not able to push representations of resources that they do not have authority over. Failure to enforce this would allow a tenant to provide a representation that would be served out of cache, overriding the actual representation that the authoritative tenant provides.¶

Pushed responses for which an origin server is not authoritative (see Section 10.1) MUST NOT be used or cached.¶

10.5. Denial-of-Service Considerations

An HTTP/2 connection can demand a greater commitment of resources to operate than an HTTP/1.1 connection. Both field section compression and flow control depend on a commitment of a greater amount of state. Settings for these features ensure that memory commitments for these features are strictly bounded.¶

The number of PUSH_PROMISE frames is not constrained in the same fashion. A client that accepts server push SHOULD limit the number of streams it allows to be in the "reserved (remote)" state. An excessive number of server push streams can be treated as a stream error (Section 5.4.2) of type ENHANCE_YOUR_CALM.¶

A number of HTTP/2 implementations were found to be vulnerable to denial of service [NFLX-2019-002]. Below is a list of known ways that implementations might be subject to denial-of-service attacks:¶

Inefficient tracking of outstanding outbound frames can lead to overload if an adversary can cause large numbers of frames to be enqueued for sending. A peer could use one of several techniques to cause large numbers of frames to be generated:¶

Providing tiny increments to flow control in WINDOW_UPDATE frames can cause a sender to generate a large number of DATA frames.¶

An endpoint is required to respond to a PING frame.¶

Each SETTINGS frame requires acknowledgment.¶

An invalid request (or server push) can cause a peer to send RST_STREAM frames in response.¶

An attacker can provide large amounts of flow-control credit at the HTTP/2 layer but withhold credit at the TCP layer, preventing frames from being sent. An endpoint that constructs and remembers frames for sending without considering TCP limits might be subject to resource exhaustion.¶

Large numbers of small or empty frames can be abused to cause a peer to expend time processing frame headers. Caution is required here as some uses of small frames are entirely legitimate, such as the sending of an empty DATA or CONTINUATION frame at the end of a stream.¶

The SETTINGS frame might also be abused to cause a peer to expend additional processing time. This might be done by pointlessly changing settings, sending multiple undefined settings, or changing the same setting multiple times in the same frame.¶

Handling reprioritization with PRIORITY frames can require significant processing time and can lead to overload if many PRIORITY frames are sent.¶

Field section compression also provides opportunities for an attacker to waste processing resources; see Section 7 of [COMPRESSION] for more details on potential abuses.¶

Limits in SETTINGS cannot be reduced instantaneously, which leaves an endpoint exposed to behavior from a peer that could exceed the new limits. In particular, immediately after establishing a connection, limits set by a server are not known to clients and could be exceeded without being an obvious protocol violation.¶

Most of the features that might be exploited for denial of service -- such as SETTINGS changes, small frames, field section compression -- have legitimate uses. These features become a burden only when they are used unnecessarily or to excess.¶

An endpoint that doesn''t monitor use of these features exposes itself to a risk of denial of service. Implementations SHOULD track the use of these features and set limits on their use. An endpoint MAY treat activity that is suspicious as a connection error (Section 5.4.1) of type ENHANCE_YOUR_CALM.¶

10.5.1. Limits on Field Block Size

A large field block (Section 4.3) can cause an implementation to commit a large amount of state. Field lines that are critical for routing can appear toward the end of a field block, which prevents streaming of fields to their ultimate destination. This ordering and other reasons, such as ensuring cache correctness, mean that an endpoint might need to buffer the entire field block. Since there is no hard limit to the size of a field block, some endpoints could be forced to commit a large amount of available memory for field blocks.¶

An endpoint can use the SETTINGS_MAX_HEADER_LIST_SIZE to advise peers of limits that might apply on the size of uncompressed field blocks. This setting is only advisory, so endpoints MAY choose to send field blocks that exceed this limit and risk the request or response being treated as malformed. This setting is specific to a connection, so any request or response could encounter a hop with a lower, unknown limit. An intermediary can attempt to avoid this problem by passing on values presented by different peers, but they are not obliged to do so.¶

A server that receives a larger field block than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code [RFC6585]. A client can discard responses that it cannot process. The field block MUST be processed to ensure a consistent connection state, unless the connection is closed.¶

10.5.2. CONNECT Issues

The CONNECT method can be used to create disproportionate load on a proxy, since stream creation is relatively inexpensive when compared to the creation and maintenance of a TCP connection. A proxy might also maintain some resources for a TCP connection beyond the closing of the stream that carries the CONNECT request, since the outgoing TCP connection remains in the TIME_WAIT state. Therefore, a proxy cannot rely on SETTINGS_MAX_CONCURRENT_STREAMS alone to limit the resources consumed by CONNECT requests.¶

10.6. Use of Compression

Compression can allow an attacker to recover secret data when it is compressed in the same context as data under attacker control. HTTP/2 enables compression of field lines (Section 4.3); the following concerns also apply to the use of HTTP compressed content-codings (Section 8.4.1 of [HTTP]).¶

There are demonstrable attacks on compression that exploit the characteristics of the Web (e.g., [BREACH]). The attacker induces multiple requests containing varying plaintext, observing the length of the resulting ciphertext in each, which reveals a shorter length when a guess about the secret is correct.¶

Implementations communicating on a secure channel MUST NOT compress content that includes both confidential and attacker-controlled data unless separate compression dictionaries are used for each source of data. Compression MUST NOT be used if the source of data cannot be reliably determined. Generic stream compression, such as that provided by TLS, MUST NOT be used with HTTP/2 (see Section 9.2).¶

Further considerations regarding the compression of header fields are described in [COMPRESSION].¶

10.7. Use of Padding

Padding within HTTP/2 is not intended as a replacement for general purpose padding, such as that provided by TLS [TLS13]. Redundant padding could even be counterproductive. Correct application can depend on having specific knowledge of the data that is being padded.¶

To mitigate attacks that rely on compression, disabling or limiting compression might be preferable to padding as a countermeasure.¶

Padding can be used to obscure the exact size of frame content and is provided to mitigate specific attacks within HTTP -- for example, attacks where compressed content includes both attacker-controlled plaintext and secret data (e.g., [BREACH]).¶

Use of padding can result in less protection than might seem immediately obvious. At best, padding only makes it more difficult for an attacker to infer length information by increasing the number of frames an attacker has to observe. Incorrectly implemented padding schemes can be easily defeated. In particular, randomized padding with a predictable distribution provides very little protection; similarly, padding frame payloads to a fixed size exposes information as frame payload sizes cross the fixed-sized boundary, which could be possible if an attacker can control plaintext.¶

Intermediaries SHOULD retain padding for DATA frames but MAY drop padding for HEADERS and PUSH_PROMISE frames. A valid reason for an intermediary to change the amount of padding of frames is to improve the protections that padding provides.¶

10.8. Privacy Considerations

Several characteristics of HTTP/2 provide an observer an opportunity to correlate actions of a single client or server over time. These include the values of settings, the manner in which flow-control windows are managed, the way priorities are allocated to streams, the timing of reactions to stimulus, and the handling of any features that are controlled by settings.¶

As far as these create observable differences in behavior, they could be used as a basis for fingerprinting a specific client, as defined in Section 3.2 of [PRIVACY].¶

HTTP/2''s preference for using a single TCP connection allows correlation of a user''s activity on a site. Reusing connections for different origins allows tracking across those origins.¶

Because the PING and SETTINGS frames solicit immediate responses, they can be used by an endpoint to measure latency to their peer. This might have privacy implications in certain scenarios.¶

10.9. Remote Timing Attacks

Remote timing attacks extract secrets from servers by observing variations in the time that servers take when processing requests that use secrets. HTTP/2 enables concurrent request creation and processing, which can give attackers better control over when request processing commences. Multiple HTTP/2 requests can be included in the same IP packet or TLS record. HTTP/2 can therefore make remote timing attacks more efficient by eliminating variability in request delivery, leaving only request order and the delivery of responses as sources of timing variability.¶

Ensuring that processing time is not dependent on the value of a secret is the best defense against any form of timing attack.¶

11. IANA Considerations

This revision of HTTP/2 marks the HTTP2-Settings header field and the h2c upgrade token, both defined in [RFC7540], as obsolete.¶

Section 11 of [RFC7540] registered the h2 and h2c ALPN identifiers along with the PRI HTTP method. RFC 7540 also established a registry for frame types, settings, and error codes. These registrations and registries apply to HTTP/2, but are not redefined in this document.¶

IANA has updated references to RFC 7540 in the following registries to refer to this document: "TLS Application-Layer Protocol Negotiation (ALPN) Protocol IDs", "HTTP/2 Frame Type", "HTTP/2 Settings", "HTTP/2 Error Code", and "HTTP Method Registry". The registration of the PRI method has been updated to refer to Section 3.4; all other section numbers have not changed.¶

IANA has changed the policy on those portions of the "HTTP/2 Frame Type" and "HTTP/2 Settings" registries that were reserved for Experimental Use in RFC 7540. These portions of the registries shall operate on the same policy as the remainder of each registry.¶

11.1. HTTP2-Settings Header Field Registration

This section marks the HTTP2-Settings header field registered by Section 11.5 of [RFC7540] in the "Hypertext Transfer Protocol (HTTP) Field Name Registry" as obsolete. This capability has been removed: see Section 3.1. The registration is updated to include the details as required by Section 18.4 of [HTTP]:¶

Field Name:

HTTP2-Settings¶

Status:

obsoleted¶

Reference:

Section 3.2.1 of [RFC7540]¶

Comments:

Obsolete; see Section 11.1 of this document.¶

11.2. The h2c Upgrade Token

This section records the h2c upgrade token registered by Section 11.8 of [RFC7540] in the "Hypertext Transfer Protocol (HTTP) Upgrade Token Registry" as obsolete. This capability has been removed: see Section 3.1. The registration is updated as follows:¶

Value:

h2c¶

Description:

(OBSOLETE) Hypertext Transfer Protocol version 2 (HTTP/2)¶

Expected Version Tokens:

None¶

Reference:

Section 3.1 of this document¶

12. References

12.1. Normative References

[CACHING]

Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP Caching", STD 98, RFC 9111, DOI 10.17487/RFC9111, June 2022, <https://www.rfc-editor.org/info/rfc9111>.

[COMPRESSION]

Peon, R. and H. Ruellan, "HPACK: Header Compression for HTTP/2", RFC 7541, DOI 10.17487/RFC7541, May 2015, <https://www.rfc-editor.org/info/rfc7541>.

[COOKIE]

Barth, A., "HTTP State Management Mechanism", RFC 6265, DOI 10.17487/RFC6265, April 2011, <https://www.rfc-editor.org/info/rfc6265>.

[HTTP]

Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP Semantics", STD 97, RFC 9110, DOI 10.17487/RFC9110, June 2022, <https://www.rfc-editor.org/info/rfc9110>.

[QUIC]

Iyengar, J., Ed. and M. Thomson, Ed., "QUIC: A UDP-Based Multiplexed and Secure Transport", RFC 9000, DOI 10.17487/RFC9000, May 2021, <https://www.rfc-editor.org/info/rfc9000>.

[RFC2119]

Bradner, S., "Key words for use in RFCs to Indicate Requirement Levels", BCP 14, RFC 2119, DOI 10.17487/RFC2119, March 1997, <https://www.rfc-editor.org/info/rfc2119>.

[RFC3986]

Berners-Lee, T., Fielding, R., and L. Masinter, "Uniform Resource Identifier (URI): Generic Syntax", STD 66, RFC 3986, DOI 10.17487/RFC3986, January 2005, <https://www.rfc-editor.org/info/rfc3986>.

[RFC8174]

Leiba, B., "Ambiguity of Uppercase vs Lowercase in RFC 2119 Key Words", BCP 14, RFC 8174, DOI 10.17487/RFC8174, May 2017, <https://www.rfc-editor.org/info/rfc8174>.

[RFC8422]

Nir, Y., Josefsson, S., and M. Pegourie-Gonnard, "Elliptic Curve Cryptography (ECC) Cipher Suites for Transport Layer Security (TLS) Versions 1.2 and Earlier", RFC 8422, DOI 10.17487/RFC8422, August 2018, <https://www.rfc-editor.org/info/rfc8422>.

[RFC8470]

Thomson, M., Nottingham, M., and W. Tarreau, "Using Early Data in HTTP", RFC 8470, DOI 10.17487/RFC8470, September 2018, <https://www.rfc-editor.org/info/rfc8470>.

[TCP]

Postel, J., "Transmission Control Protocol", STD 7, RFC 793, DOI 10.17487/RFC0793, September 1981, <https://www.rfc-editor.org/info/rfc793>.

[TLS-ALPN]

Friedl, S., Popov, A., Langley, A., and E. Stephan, "Transport Layer Security (TLS) Application-Layer Protocol Negotiation Extension", RFC 7301, DOI 10.17487/RFC7301, July 2014, <https://www.rfc-editor.org/info/rfc7301>.

[TLS-ECDHE]

Rescorla, E., "TLS Elliptic Curve Cipher Suites with SHA-256/384 and AES Galois Counter Mode (GCM)", RFC 5289, DOI 10.17487/RFC5289, August 2008, <https://www.rfc-editor.org/info/rfc5289>.

[TLS-EXT]

Eastlake 3rd, D., "Transport Layer Security (TLS) Extensions: Extension Definitions", RFC 6066, DOI 10.17487/RFC6066, January 2011, <https://www.rfc-editor.org/info/rfc6066>.

[TLS12]

Dierks, T. and E. Rescorla, "The Transport Layer Security (TLS) Protocol Version 1.2", RFC 5246, DOI 10.17487/RFC5246, August 2008, <https://www.rfc-editor.org/info/rfc5246>.

[TLS13]

Rescorla, E., "The Transport Layer Security (TLS) Protocol Version 1.3", RFC 8446, DOI 10.17487/RFC8446, August 2018, <https://www.rfc-editor.org/info/rfc8446>.

[TLSBCP]

Sheffer, Y., Holz, R., and P. Saint-Andre, "Recommendations for Secure Use of Transport Layer Security (TLS) and Datagram Transport Layer Security (DTLS)", BCP 195, RFC 7525, DOI 10.17487/RFC7525, May 2015, <https://www.rfc-editor.org/info/rfc7525>.

12.2. Informative References

[ALT-SVC]

Nottingham, M., McManus, P., and J. Reschke, "HTTP Alternative Services", RFC 7838, DOI 10.17487/RFC7838, April 2016, <https://www.rfc-editor.org/info/rfc7838>.

[BREACH]

Gluck, Y., Harris, N., and A. Prado, "BREACH: Reviving the CRIME Attack", 12 July 2013, <https://breachattack.com/resources/BREACH%20-%20SSL,%20gone%20in%2030%20seconds.pdf>.

[DNS-TERMS]

Hoffman, P., Sullivan, A., and K. Fujiwara, "DNS Terminology", BCP 219, RFC 8499, DOI 10.17487/RFC8499, January 2019, <https://www.rfc-editor.org/info/rfc8499>.

[HTTP-PRIORITY]

Oku, K. and L. Pardue, "Extensible Prioritization Scheme for HTTP", RFC 9218, DOI 10.17487/RFC9218, June 2022, <https://www.rfc-editor.org/info/rfc9218>.

[HTTP/1.1]

Fielding, R., Ed., Nottingham, M., Ed., and J. Reschke, Ed., "HTTP/1.1", STD 99, RFC 9112, DOI 10.17487/RFC9112, June 2022, <https://www.rfc-editor.org/info/rfc9112>.

[NFLX-2019-002]

Netflix, "HTTP/2 Denial of Service Advisory", 13 August 2019, <https://github.com/Netflix/security-bulletins/blob/master/advisories/third-party/2019-002.md>.

[PRIVACY]

Cooper, A., Tschofenig, H., Aboba, B., Peterson, J., Morris, J., Hansen, M., and R. Smith, "Privacy Considerations for Internet Protocols", RFC 6973, DOI 10.17487/RFC6973, July 2013, <https://www.rfc-editor.org/info/rfc6973>.

[RFC1122]

Braden, R., Ed., "Requirements for Internet Hosts - Communication Layers", STD 3, RFC 1122, DOI 10.17487/RFC1122, October 1989, <https://www.rfc-editor.org/info/rfc1122>.

[RFC3749]

Hollenbeck, S., "Transport Layer Security Protocol Compression Methods", RFC 3749, DOI 10.17487/RFC3749, May 2004, <https://www.rfc-editor.org/info/rfc3749>.

[RFC6125]

Saint-Andre, P. and J. Hodges, "Representation and Verification of Domain-Based Application Service Identity within Internet Public Key Infrastructure Using X.509 (PKIX) Certificates in the Context of Transport Layer Security (TLS)", RFC 6125, DOI 10.17487/RFC6125, March 2011, <https://www.rfc-editor.org/info/rfc6125>.

[RFC6585]

Nottingham, M. and R. Fielding, "Additional HTTP Status Codes", RFC 6585, DOI 10.17487/RFC6585, April 2012, <https://www.rfc-editor.org/info/rfc6585>.

[RFC7323]

Borman, D., Braden, B., Jacobson, V., and R. Scheffenegger, Ed., "TCP Extensions for High Performance", RFC 7323, DOI 10.17487/RFC7323, September 2014, <https://www.rfc-editor.org/info/rfc7323>.

[RFC7540]

Belshe, M., Peon, R., and M. Thomson, Ed., "Hypertext Transfer Protocol Version 2 (HTTP/2)", RFC 7540, DOI 10.17487/RFC7540, May 2015, <https://www.rfc-editor.org/info/rfc7540>.

[RFC8441]

McManus, P., "Bootstrapping WebSockets with HTTP/2", RFC 8441, DOI 10.17487/RFC8441, September 2018, <https://www.rfc-editor.org/info/rfc8441>.

[RFC8740]

Benjamin, D., "Using TLS 1.3 with HTTP/2", RFC 8740, DOI 10.17487/RFC8740, February 2020, <https://www.rfc-editor.org/info/rfc8740>.

[TALKING]

Huang, L., Chen, E., Barth, A., Rescorla, E., and C. Jackson, "Talking to Yourself for Fun and Profit", 2011, <https://www.adambarth.com/papers/2011/huang-chen-barth-rescorla-jackson.pdf>.

Appendix A. Prohibited TLS 1.2 Cipher Suites

An HTTP/2 implementation MAY treat the negotiation of any of the following cipher suites with TLS 1.2 as a connection error (Section 5.4.1) of type INADEQUATE_SECURITY:¶

TLS_NULL_WITH_NULL_NULL¶

TLS_RSA_WITH_NULL_MD5¶

TLS_RSA_WITH_NULL_SHA¶

TLS_RSA_EXPORT_WITH_RC4_40_MD5¶

TLS_RSA_WITH_RC4_128_MD5¶

TLS_RSA_WITH_RC4_128_SHA¶

TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5¶

TLS_RSA_WITH_IDEA_CBC_SHA¶

TLS_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_RSA_WITH_DES_CBC_SHA¶

TLS_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_DSS_WITH_DES_CBC_SHA¶

TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_RSA_WITH_DES_CBC_SHA¶

TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DHE_DSS_WITH_DES_CBC_SHA¶

TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DHE_RSA_WITH_DES_CBC_SHA¶

TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_DH_anon_EXPORT_WITH_RC4_40_MD5¶

TLS_DH_anon_WITH_RC4_128_MD5¶

TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA¶

TLS_DH_anon_WITH_DES_CBC_SHA¶

TLS_DH_anon_WITH_3DES_EDE_CBC_SHA¶

TLS_KRB5_WITH_DES_CBC_SHA¶

TLS_KRB5_WITH_3DES_EDE_CBC_SHA¶

TLS_KRB5_WITH_RC4_128_SHA¶

TLS_KRB5_WITH_IDEA_CBC_SHA¶

TLS_KRB5_WITH_DES_CBC_MD5¶

TLS_KRB5_WITH_3DES_EDE_CBC_MD5¶

TLS_KRB5_WITH_RC4_128_MD5¶

TLS_KRB5_WITH_IDEA_CBC_MD5¶

TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA¶

TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA¶

TLS_KRB5_EXPORT_WITH_RC4_40_SHA¶

TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5¶

TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5¶

TLS_KRB5_EXPORT_WITH_RC4_40_MD5¶

TLS_PSK_WITH_NULL_SHA¶

TLS_DHE_PSK_WITH_NULL_SHA¶

TLS_RSA_PSK_WITH_NULL_SHA¶

TLS_RSA_WITH_AES_128_CBC_SHA¶

TLS_DH_DSS_WITH_AES_128_CBC_SHA¶

TLS_DH_RSA_WITH_AES_128_CBC_SHA¶

TLS_DHE_DSS_WITH_AES_128_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_128_CBC_SHA¶

TLS_DH_anon_WITH_AES_128_CBC_SHA¶

TLS_RSA_WITH_AES_256_CBC_SHA¶

TLS_DH_DSS_WITH_AES_256_CBC_SHA¶

TLS_DH_RSA_WITH_AES_256_CBC_SHA¶

TLS_DHE_DSS_WITH_AES_256_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_256_CBC_SHA¶

TLS_DH_anon_WITH_AES_256_CBC_SHA¶

TLS_RSA_WITH_NULL_SHA256¶

TLS_RSA_WITH_AES_128_CBC_SHA256¶

TLS_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DH_DSS_WITH_AES_128_CBC_SHA256¶

TLS_DH_RSA_WITH_AES_128_CBC_SHA256¶

TLS_DHE_DSS_WITH_AES_128_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA¶

TLS_DHE_RSA_WITH_AES_128_CBC_SHA256¶

TLS_DH_DSS_WITH_AES_256_CBC_SHA256¶

TLS_DH_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DHE_DSS_WITH_AES_256_CBC_SHA256¶

TLS_DHE_RSA_WITH_AES_256_CBC_SHA256¶

TLS_DH_anon_WITH_AES_128_CBC_SHA256¶

TLS_DH_anon_WITH_AES_256_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA¶

TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA¶

TLS_PSK_WITH_RC4_128_SHA¶

TLS_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_PSK_WITH_AES_128_CBC_SHA¶

TLS_PSK_WITH_AES_256_CBC_SHA¶

TLS_DHE_PSK_WITH_RC4_128_SHA¶

TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_DHE_PSK_WITH_AES_128_CBC_SHA¶

TLS_DHE_PSK_WITH_AES_256_CBC_SHA¶

TLS_RSA_PSK_WITH_RC4_128_SHA¶

TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_RSA_PSK_WITH_AES_128_CBC_SHA¶

TLS_RSA_PSK_WITH_AES_256_CBC_SHA¶

TLS_RSA_WITH_SEED_CBC_SHA¶

TLS_DH_DSS_WITH_SEED_CBC_SHA¶

TLS_DH_RSA_WITH_SEED_CBC_SHA¶

TLS_DHE_DSS_WITH_SEED_CBC_SHA¶

TLS_DHE_RSA_WITH_SEED_CBC_SHA¶

TLS_DH_anon_WITH_SEED_CBC_SHA¶

TLS_RSA_WITH_AES_128_GCM_SHA256¶

TLS_RSA_WITH_AES_256_GCM_SHA384¶

TLS_DH_RSA_WITH_AES_128_GCM_SHA256¶

TLS_DH_RSA_WITH_AES_256_GCM_SHA384¶

TLS_DH_DSS_WITH_AES_128_GCM_SHA256¶

TLS_DH_DSS_WITH_AES_256_GCM_SHA384¶

TLS_DH_anon_WITH_AES_128_GCM_SHA256¶

TLS_DH_anon_WITH_AES_256_GCM_SHA384¶

TLS_PSK_WITH_AES_128_GCM_SHA256¶

TLS_PSK_WITH_AES_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_AES_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_AES_256_GCM_SHA384¶

TLS_PSK_WITH_AES_128_CBC_SHA256¶

TLS_PSK_WITH_AES_256_CBC_SHA384¶

TLS_PSK_WITH_NULL_SHA256¶

TLS_PSK_WITH_NULL_SHA384¶

TLS_DHE_PSK_WITH_AES_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_AES_256_CBC_SHA384¶

TLS_DHE_PSK_WITH_NULL_SHA256¶

TLS_DHE_PSK_WITH_NULL_SHA384¶

TLS_RSA_PSK_WITH_AES_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_AES_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_NULL_SHA256¶

TLS_RSA_PSK_WITH_NULL_SHA384¶

TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256¶

TLS_EMPTY_RENEGOTIATION_INFO_SCSV¶

TLS_ECDH_ECDSA_WITH_NULL_SHA¶

TLS_ECDH_ECDSA_WITH_RC4_128_SHA¶

TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA¶

TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_NULL_SHA¶

TLS_ECDHE_ECDSA_WITH_RC4_128_SHA¶

TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA¶

TLS_ECDH_RSA_WITH_NULL_SHA¶

TLS_ECDH_RSA_WITH_RC4_128_SHA¶

TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_RSA_WITH_AES_128_CBC_SHA¶

TLS_ECDH_RSA_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_RSA_WITH_NULL_SHA¶

TLS_ECDHE_RSA_WITH_RC4_128_SHA¶

TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA¶

TLS_ECDH_anon_WITH_NULL_SHA¶

TLS_ECDH_anon_WITH_RC4_128_SHA¶

TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDH_anon_WITH_AES_128_CBC_SHA¶

TLS_ECDH_anon_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA¶

TLS_SRP_SHA_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA¶

TLS_SRP_SHA_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA¶

TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384¶

TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384¶

TLS_ECDHE_PSK_WITH_RC4_128_SHA¶

TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA¶

TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384¶

TLS_ECDHE_PSK_WITH_NULL_SHA¶

TLS_ECDHE_PSK_WITH_NULL_SHA256¶

TLS_ECDHE_PSK_WITH_NULL_SHA384¶

TLS_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256¶

TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_DH_anon_WITH_ARIA_128_CBC_SHA256¶

TLS_DH_anon_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384¶

TLS_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384¶

TLS_DH_anon_WITH_ARIA_128_GCM_SHA256¶

TLS_DH_anon_WITH_ARIA_256_GCM_SHA384¶

TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384¶

TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384¶

TLS_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_PSK_WITH_ARIA_128_GCM_SHA256¶

TLS_PSK_WITH_ARIA_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384¶

TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384¶

TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256¶

TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384¶

TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256¶

TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384¶

TLS_RSA_WITH_AES_128_CCM¶

TLS_RSA_WITH_AES_256_CCM¶

TLS_RSA_WITH_AES_128_CCM_8¶

TLS_RSA_WITH_AES_256_CCM_8¶

TLS_PSK_WITH_AES_128_CCM¶

TLS_PSK_WITH_AES_256_CCM¶

TLS_PSK_WITH_AES_128_CCM_8¶

TLS_PSK_WITH_AES_256_CCM_8¶

For more details, see Section 9.2.2.¶

Appendix B. Changes from RFC 7540

This revision includes the following substantive changes:¶

Use of TLS 1.3 was defined based on [RFC8740], which this document obsoletes.¶

The priority scheme defined in RFC 7540 is deprecated. Definitions for the format of the PRIORITY frame and the priority fields in the HEADERS frame have been retained, plus the rules governing when PRIORITY frames can be sent and received, but the semantics of these fields are only described in RFC 7540. The priority signaling scheme from RFC 7540 was not successful. Using the simpler signaling in [HTTP-PRIORITY] is recommended.¶

The HTTP/1.1 Upgrade mechanism is deprecated and no longer specified in this document. It was never widely deployed, with plaintext HTTP/2 users choosing to use the prior-knowledge implementation instead.¶

Validation for field names and values has been narrowed. The validation that is mandatory for intermediaries is precisely defined, and error reporting for requests has been amended to encourage sending 400-series status codes.¶

The ranges of codepoints for settings and frame types that were reserved for Experimental Use are now available for general use.¶

Connection-specific header fields -- which are prohibited -- are more precisely and comprehensively identified.¶

Host and ":authority" are no longer permitted to disagree.¶

Rules for sending Dynamic Table Size Update instructions after changes in settings have been clarified in Section 4.3.1.¶

Editorial changes are also included. In particular, changes to terminology and document structure are in response to updates to core HTTP semantics [HTTP]. Those documents now include some concepts that were first defined in RFC 7540, such as the 421 status code or connection coalescing.¶

Acknowledgments

Credit for non-trivial input to this document is owed to a large number of people who have contributed to the HTTP Working Group over the years. [RFC7540] contains a more extensive list of people that deserve acknowledgment for their contributions.¶

Contributors

Mike Belshe and Roberto Peon authored the text that this document is based on.¶

Authors'' Addresses

Martin Thomson (editor)

Mozilla

Australia

Email: mt@lowentropy.net

Cory Benfield (editor)

Apple Inc.

Email: cbenfield@apple.com

Datatracker

RFC 9113

RFC - Proposed Standard

Info

Contents

Prefs

Document

Document type

RFC - Proposed Standard

June 2022

View errata Report errata

Obsoletes RFC 8740, RFC 7540

Was draft-ietf-httpbis-http2bis (httpbis WG)

Select version

00

01

02

03

04

05

06

07

RFC 9113

Compare versions

RFC 9113 draft-ietf-httpbis-http2bis-07 draft-ietf-httpbis-http2bis-06 draft-ietf-httpbis-http2bis-05 draft-ietf-httpbis-http2bis-04 draft-ietf-httpbis-http2bis-03 draft-ietf-httpbis-http2bis-02 draft-ietf-httpbis-http2bis-01 draft-ietf-httpbis-http2bis-00 RFC 9113 draft-ietf-httpbis-http2bis-07 draft-ietf-httpbis-http2bis-06 draft-ietf-httpbis-http2bis-05 draft-ietf-httpbis-http2bis-04 draft-ietf-httpbis-http2bis-03 draft-ietf-httpbis-http2bis-02 draft-ietf-httpbis-http2bis-01 draft-ietf-httpbis-http2bis-00 Side-by-side Inline

Authors

M. Thomson , C. Benfield

Email authors

RFC stream

Other formats

txt html xml pdf w/errata bibtex

Additional resources

Mailing list discussion

Report a datatracker bug

Show sidebar by default

Yes No

Tab to show by default

Info Contents

HTMLization configuration

HTMLize the plaintext Plaintextify the HTML

Maximum font size Page dependencies

Inline Reference

Citation links

Go to reference section Go to linked document');
INSERT INTO "sources" VALUES(2,1,'https://en.wikipedia.org/wiki/HTTP/3','https://en.wikipedia.org/wiki/HTTP/3','HTTP/3 - Wikipedia','2026-10-22T14:00:00+00:00','text/html; charset=UTF-8','d0eb9679ee55ce40c49e271c3096d6559cf5f3e11cf3c87e95c5f4be69574c68','Jump to content

Search

Search

HTTP/3

16 languages

Català

Čeština

Deutsch

Español

فارسی

Suomi

עברית

Italiano

日本語

한국어

Polski

Português

Русский

Українська

吴语

中文

Edit links

From Wikipedia, the free encyclopedia

HTTP network protocol introduced in 2022

HTTP/3

International standard

RFC 9114[1] (HTTP/3 also uses the completed QUIC protocol described in RFC 9000 and related RFCs such as RFC 9001)

Developed by

IETF

Introduced

June 2022

Website

https://httpwg.org/specs/rfc9114.html

HTTP/3 is the third major version of the Hypertext Transfer Protocol used to exchange information on the World Wide Web, complementing the widely deployed HTTP/1.1 and HTTP/2. Unlike previous versions which relied on the well-established TCP (published in 1974),[2] HTTP/3 uses QUIC (officially introduced in 2021),[3] a multiplexed transport protocol built on UDP.[4]

HTTP/3 uses similar semantics compared to earlier revisions of the protocol, including the same request methods, status codes, and message fields, but encodes them and maintains session state differently. However, partially due to the protocol''s adoption of QUIC, HTTP/3 has lower latency and loads more quickly in real-world usage when compared with previous versions: in some cases over four times faster than with HTTP/1.1 (which, for many websites, is the only HTTP version deployed).[5][6]

As of July 2026, HTTP/3 is supported by more than 95% of major web browsers in use[7] and 40% of the top 10 million websites.[8] It has been supported by Chromium (and derived projects including Google Chrome, Microsoft Edge, Samsung Internet, and Opera)[9] since April 2020 and by Mozilla Firefox since May 2021.[7][10] Safari has implemented the standard since Sept 2024 (16+ supports HTTP/3 for all users, previously it was limited to a subset of users)[11]

History

[edit]

Protocol stack of HTTP/3 compared to HTTP/1.1 and HTTP/2

HTTP/3 originates from an Internet Draft adopted by the QUIC working group. The original proposal was named "HTTP/2 Semantics Using The QUIC Transport Protocol",[12] and later renamed "Hypertext Transfer Protocol (HTTP) over QUIC".[13]

On 28 October 2018 in a mailing list discussion, Mark Nottingham, Chair of the IETF HTTP and QUIC Working Groups, proposed renaming HTTP-over-QUIC to HTTP/3, to "clearly identify it as another binding of HTTP semantics to the wire protocol [...] so people understand its separation from QUIC".[14] Nottingham''s proposal was accepted by fellow IETF members a few days later. The HTTP working group was chartered to assist the QUIC working group during the design of HTTP/3, then assume responsibility for maintenance after publication.[15]

Support for HTTP/3 was added to Chrome (Canary build) in September 2019 and then eventually reached stable builds, but was disabled by a feature flag. It was enabled by default in April 2020.[9] Firefox added support for HTTP/3 in November 2019 through a feature flag[7][16][17] and started enabling it by default in April 2021 in Firefox 88.[7][10] Experimental support for HTTP/3 was added to Safari Technology Preview on April 8, 2020[18] and was included with Safari 14 that ships with iOS 14 and macOS 11,.[19][20] Starting September 2024, HTTP/3 is supported for all users on Safari 16 or newer.[11]

On 6 June 2022, IETF published HTTP/3 as a Proposed Standard in RFC 9114[1].

Comparison with HTTP/1.1 and HTTP/2

[edit]

HTTP semantics are consistent across versions: the same request methods, status codes, and message fields are typically applicable to all versions. The differences are in the mapping of these semantics to underlying transports. Both HTTP/1.1 and HTTP/2 use TCP as their transport. HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP). The switch to QUIC aims to fix a major problem of HTTP/2 called "head-of-line blocking": because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was impacted by the lost packet. Because QUIC provides native multiplexing, lost packets only impact the streams where data has been lost.

The HTTPS DNS resource record as defined in RFC 9460[21] allows for connecting without first receiving the Alt-Svc header via previous HTTP versions, therefore removing the 1 RTT of handshaking of TCP.[22][23] There is client support for HTTPS resource records since Firefox 92, iOS 14, reported Safari 14 support, and Chromium supports it behind a flag.[24][25][26]

Implementations

[edit]

Client

[edit]

Browser support for HTTP/3

Browser

Version implemented (disabled by default)

Version shipped (enabled by default)

Comment

Chrome

Stable build (79)

December 2019

87[7]

April 2020[27]

Earlier versions implemented other drafts of QUIC

Edge

Stable build (79)

December 2019

87

April 2020

Edge 79 was the first version based on Chromium

Firefox

Stable build (72.0.1)

January 2020

88[10]

April 2021[28]

Safari

Stable build (14.0)

September 2020

16.4

September 2024

Apple tested HTTP/3 support on some Safari users starting with Safari 14.[29]

Starting September 2024, HTTP/3 is supported for all users on Safari 16 or newer.[11]

Libraries

[edit]

Open-source libraries that implement client or server logic for QUIC and HTTP/3 include[30]

Libraries implementing HTTP/3

Name

Client

Server

Programming language

Company

Repository

lsquic

Yes

Yes

C

LiteSpeed

https://github.com/litespeedtech/lsquic

nghttp3

Yes

Yes

C

https://github.com/ngtcp2/nghttp3

h2o

No

Yes

C

https://github.com/h2o/h2o

libcurl[31][32]

Yes

No

C

https://github.com/curl/curl

MsQuic[33]

Yes

Yes

C

Microsoft

https://github.com/microsoft/msquic

proxygen

Yes

Yes

C++

Facebook

https://github.com/facebook/proxygen#quic-and-http3

Cronet

Yes

Yes

C++

Google

https://github.com/chromium/chromium/tree/main/net/quic

.NET[34]

Yes

Yes

C# (using MsQuic)[35]

Microsoft

https://github.com/dotnet

quic-go

Yes

Yes

Go

https://github.com/quic-go/quic-go

http3

Yes

Yes

Haskell

https://github.com/kazu-yamamoto/http3

Kwik

Yes

Yes

Java

https://github.com/ptrd/kwik

Flupke

Yes

Yes

Java

https://bitbucket.org/pjtr/flupke

aioquic

Yes

Yes

Python

https://github.com/aiortc/aioquic

niquests

Yes

No

Python

https://github.com/jawah/niquests

quiche

Yes

Yes

Rust

Cloudflare

https://github.com/cloudflare/quiche

neqo

Yes

Yes

Rust

Mozilla

https://github.com/mozilla/neqo

quinn

Yes

Yes

Rust

https://github.com/quinn-rs/quinn

s2n-quic

Yes

Yes

Rust

Amazon Web Services

https://github.com/aws/s2n-quic

cowboy

No

Yes

Erlang

ninenines

https://github.com/ninenines/cowboy

quico

Yes

Yes

JavaScript

https://github.com/colocohen/quico

Server

[edit]

On 7 June 2021, LiteSpeed Web Server (and OpenLiteSpeed) 6.0.2 was released and became the first version to enable HTTP/3 by default.[36]

Caddy web server v2.6.0 (released 20 September 2022) has HTTP/3 enabled by default.[37]

nginx supports HTTP/3 since 1.25.0 (released 23 May 2023). A technology preview of nginx with HTTP/3 support was released in June 2020.[38] Binary packages of nginx with HTTP/3 support have been released in February 2023.[39]

Cloudflare distributes a patch for nginx that integrates the quiche HTTP/3 library into it.[40]

Microsoft IIS support for HTTP/3 is enabled natively with Windows Server 2022/Windows 11.[41]

HAProxy supports HTTP/3 over QUIC since version 2.6 released on 31 May 2022.[42][43]

Nimble Streamer supports HTTP/3 since 4.1.8-1[44] for HTTP-based protocols.

See also

[edit]

Internet portal

Fast and Secure Protocol – Terminal command scheme used to transfer data

References

[edit]

1 2 M. Bishop, ed. (June 2022). HTTP/3. Internet Engineering Task Force. doi:10.17487/RFC9114. ISSN 2070-1721. RFC 9114. Proposed Standard.

↑ V. Cerf; Y. Dalal; C. Sunshine (December 1974). SPECIFICATION OF INTERNET TRANSMISSION CONTROL PROGRAM. Network Working Group. doi:10.17487/RFC0675. RFC 675. Obsolete. Obsoleted by RFC 7805. NIC 2. INWG 72.

↑ J. Iyengar; M. Thomson, eds. (May 2021). QUIC: A UDP-Based Multiplexed and Secure Transport. Internet Engineering Task Force. doi:10.17487/RFC9000. ISSN 2070-1721. RFC 9000. Proposed Standard.

↑ "What is HTTP/3?". Cloudflare. Archived from the original on 4 July 2022. Retrieved 12 July 2022.

↑ Perna, Gianluca; Trevisan, Martino; Giordano, Danilo; Drago, Idilio (1 April 2022). "A first look at HTTP/3 adoption and performance". Computer Communications. 187: 115–124. doi:10.1016/j.comcom.2022.02.005. hdl:11368/3025202. ISSN 0140-3664. S2CID 246936473.

↑ "HTTP/3 is Fast". Request Metrics. Retrieved 1 July 2022.

1 2 3 4 5 ""HTTP/3" | Can I use... Support tables for HTML5, CSS3, etc". canIuse.com. Retrieved 11 August 2024.

↑ "Usage of HTTP/3 for websites". World Wide Web Technology Surveys. W3Techs. Retrieved 19 July 2026.

1 2 "Enabling QUIC in tip-of-tree". groups.google.com. Retrieved 8 April 2021.

1 2 3 Damjanovic, Dragana (16 April 2021). "QUIC and HTTP/3 Support now in Firefox Nightly and Beta". Mozilla Hacks – the Web developer blog. Retrieved 17 April 2021.

1 2 3 Jen Simmons (30 October 2024). "Updating Safari support for HTTP3". GitHub. Retrieved 20 July 2025.

↑ Shade, Robbie (8 July 2016). HTTP/2 Semantics Using The QUIC Transport Protocol. IETF. I-D draft-shade-quic-http2-mapping.

↑ Cimpanu, Catalin (12 November 2018). "HTTP-over-QUIC to be renamed HTTP/3". ZDNet. Retrieved 12 November 2018.

↑ Nottingham, Mark (28 October 2018). "Identifying our deliverables". IETF Mail Archive.

↑ "Hypertext Transfer Protocol Charter". ietf.org. Retrieved 2 September 2020.

↑ Daniel, Stenberg. "Daniel Stenberg announces HTTP/3 support in Firefox Nightly". Twitter. Retrieved 5 November 2019.

↑ Cimpanu, Catalin (26 September 2019). "Cloudflare, Google Chrome, and Firefox add HTTP/3 support". ZDNet. Retrieved 27 September 2019.

↑ "Release Notes for Safari Technology Preview 104". webkit.org. 8 April 2020. Retrieved 7 August 2020.

↑ "Safari 14 Release Notes". developer.apple.com. Retrieved 4 December 2020.

↑ Ng, Gary (23 June 2020). "Apple''s Safari Adds Support for HTTP3 in iOS 14 and macOS 11". iphoneincanada.ca. Retrieved 25 June 2021.

↑ Benjamin M. Schwartz; Mike Bishop; Erik Nygren (November 2023). Service Binding and Parameter Specification via the DNS (SVCB and HTTPS Resource Records). Internet Engineering Task Force. doi:10.17487/RFC9460. ISSN 2070-1721. RFC 9460. Proposed Standard.

↑ "HTTPS RR". MDN. Mozilla. Retrieved 25 October 2022.

↑ Schwartz, Benjamin M.; Bishop, Mike; Nygren, Erik (12 June 2020). Service binding and parameter specification via the DNS. IETF. I-D draft-ietf-dnsop-svcb-https.

↑ "Firefox 92 for developers". Mozilla Corporation. 7 September 2021. Retrieved 25 October 2022.

↑ "Feature: HTTP->HTTPS redirect for HTTPS DNS records". Google Inc. Retrieved 25 October 2022.

↑ Patrick Mevzek (24 August 2021). "What''s the use case of SVCB (type 65, service binding) RR". Stack Exchange Inc. Retrieved 25 October 2022.

↑ "Enabling QUIC in tip-of-tree". groups.google.com. Retrieved 9 April 2021.

↑ "Firefox Release Owners - MozillaWiki". wiki.mozilla.org. Retrieved 9 April 2021.

↑ Jen Simmons (4 April 2023). "HTTP/3 support shipped in Safari 14.0". GitHub. Retrieved 20 July 2025.

↑ "QUIC Implementations". GitHub. Retrieved 8 April 2021.

↑ "First HTTP/3 with curl". Daniel Stenberg. 5 August 2019. Retrieved 2 October 2019.

↑ "HTTP3 (and QUIC)". Daniel Stenberg. 23 August 2023. Retrieved 27 August 2023.

↑ "MsQuic is Open Source". 28 April 2020. Retrieved 28 April 2020.

↑ "HTTP/3 support in .NET 6". 17 September 2021. Retrieved 17 September 2021.

↑ "HTTP/3 support in .NET 6". .NET Blog. 17 September 2021. Retrieved 12 January 2022.

↑ "LiteSpeed Web Server Release Log - LiteSpeed Technologies". www.litespeedtech.com. Retrieved 12 February 2022. Enable HTTP/3 v1 by default.

↑ "Release 2.6.0 · caddyserver/caddy". Github. 22 September 2022. Retrieved 20 September 2022.

↑ "Introducing a Technology Preview of NGINX Support for QUIC and HTTP/3". nginx.com. 10 June 2020. Retrieved 11 June 2020.

↑ "Binary Packages Now Available for the Preview NGINX QUIC+HTTP/3 Implementation". nginx.com. 8 February 2023. Retrieved 30 March 2023.

↑ "Experiment with HTTP/3 using NGINX and quiche". The Cloudflare Blog. 17 October 2019. Retrieved 9 November 2019.

↑ Tratcher. "Use ASP.NET Core with HTTP/3 on IIS". docs.microsoft.com. Retrieved 29 April 2022.

↑ "Announcing HAProxy 2.6". HAProxy Blog. 31 May 2022.

↑ "QUIC Implementation in HAProxy". HAProxyConf video presentation. 25 January 2023.

↑ "HTTP/3 and QUIC support in Nimble Streamer". softvelum.com. 14 February 2025. Retrieved 17 February 2025.

External links

[edit]

Official website

IETF QUIC Working Group on GitHub

HTTP/3 explained (Daniel Stenberg)

HTTP/3 on canIuse.com

List of QUIC implementations on the IETF QUIC Working Group Wiki

v

t

e

Web interfaces

Server-side

Protocols

HTTP

v2

v3

Encryption

WebDAV

CGI

SCGI

FCGI

AJP

WSRP

WebSocket

Server APIs

C NSAPI

C ASAPI

C ISAPI

COM ASP

Jakarta Servlet

container

CLI OWIN

ASP.NET Handler

Python WSGI

Python ASGI

Ruby Rack

JavaScript JSGI

Perl PSGI

Portlet

container

Apache modules

mod_include

mod_jk

mod_lisp

mod_mono

mod_parrot

mod_perl

mod_php

mod_proxy

mod_python

mod_wsgi

mod_ruby

Phusion Passenger

Topics

Web service vs. Web resource

WOA vs. ROA

Open API

Webhook

Application server

comparison

Scripting

Client-side

Browser APIs

C NPAPI

LiveConnect

XPConnect

C NPRuntime

C PPAPI

NaCl

ActiveX

BHO

XBAP

Web APIs

WHATWG

Audio

Canvas

DOM

SSE

Video

WebSockets

Web messaging

Web storage

Web worker

XMLHttpRequest

W3C

DOM events

EME

File

Geolocation

IndexedDB

MSE

SVG

WebAssembly

WebAuthn

WebGPU

WebRTC

WebXR

Khronos

WebCL

WebGL

Others

Gears (discontinued)

Web SQL Database (discontinued)

WebUSB

Topics

Ajax and Remote scripting vs. DHTML

Browser extension

Cross-site scripting and CORS

Hydration

Mashup

Persistent data

Web IDL

Scripting

Related topics

Frontend and backend

Microservices

REST

GraphQL

Push technology

Solution stack

Web page

Static

Dynamic

Web standards

Web API security

Web application

Rich

Single-page

Progressive

Web framework

v

t

e

Web browsers

Features, standards & protocols

Features

Bookmarks

Extensions

Privacy mode

Web standards

HTML

v5

CSS

DOM

JavaScript

WebAssembly

Web storage

IndexedDB

WebGL

WebGPU

Protocols

HTTP

Encryption

Cookies

third-party

OCSP

WebRTC

WebSocket

Active

Blink-based

Proprietary

Google Chrome

Arc

Atlas

Avast

Cốc Cốc

Comet

Ecosia

Epic

Huawei

Maxthon

Microsoft Edge

Opera (Mobile)

Puffin

QQ

Samsung

Silk

Sleipnir

SRWare

UC

Vivaldi

Whale

Yandex

FOSS

Chromium

Brave

Dooble

Falkon

Otter

Supermium

ungoogled

Gecko-based

Firefox

Floorp

GNU IceCat

LibreWolf

Midori

Mullvad

SlimBrowser

SeaMonkey (uses unnamed Gecko fork)

Tor

Waterfox

Zen

Goanna-based

Basilisk

K-Meleon

Pale Moon

WebKit-based

Safari

GNOME Web

iCab

Orion

Multi-engine

360

DuckDuckGo

Konqueror

Lunascape

NetFront

qutebrowser

Other

Dillo

eww

Flow

Ladybird

Links

Lynx

NetSurf

Opera Mini

w3m

Discontinued

Blink-based

Beaker

Citrio

Flock

Redcore

Rockmelt

SalamWeb

Sputnik

Torch

Gecko-based

Beonex

Camino

Classilla

Conkeror

Firefox Lite

Galeon

Ghostzilla

IceDragon

Kazehakase

Kylo

Lotus

MicroB

Minimo

Mozilla suite

PirateBrowser

Pogo

Strata

Swiftfox

TenFourFox

Timberwolf

Waterfox Classic

xB

MSHTML-based

Internet Explorer

AOL

Deepnet

GreenBrowser

MediaBrowser

MSN Explorer

MSN Program Viewer

NeoPlanet

NetCaptor

SpaceTime

ZAC

WebKit-based

Arora

BOLT

Dolphin

Fluid

Google TV

Iris

Mercury

Nokia Symbian

OmniWeb

Opera Coast

Origyn

QtWeb

Shiira

Steel

surf

Uzbl

WebPositive

xombrero

Other

abaco

Amaya

Arachne

Arena

Blazer

Cake

CM

Deepfish

Edge Legacy

ELinks

Gazelle

HotJava

IBM Home Page Reader

IBM WebExplorer

IBrowse

Internet Explorer for Mac

KidZui

Line Mode

Mosaic

MSN TV

NetPositive

Netscape

Skweezer

Skyfire

ThunderHawk

Vision

WinWAP

WorldWideWeb

List

Comparison

Category

Retrieved from "https://en.wikipedia.org/w/index.php?title=HTTP/3&oldid=1378386113"

Categories:

Hypertext Transfer Protocol

Application layer protocols

Internet properties established in 2018

Hidden categories:

Articles with short description

Short description is different from Wikidata

Use dmy dates from January 2019

Search

Search

HTTP/3

16 languages Add topic');
INSERT INTO "sources" VALUES(3,1,'https://datatracker.ietf.org/doc/draft-ietf-quic-http/33','https://datatracker.ietf.org/doc/draft-ietf-quic-http/33/','draft-ietf-quic-http-33 - Hypertext Transfer Protocol Version 3 (HTTP/3)','2026-10-22T14:00:01+00:00','text/html; charset=utf-8','1147c5c3d5745d5b230514304253483267267cf9ec8cdeb5b9bf1475ce817695','Skip to main content

Hypertext Transfer Protocol Version 3 (HTTP/3)

draft-ietf-quic-http-33

Status

IESG evaluation record

IESG writeups

Email expansions

History

Versions:

The information below is for an old version of the document.

Document

Type

This is an older version of an Internet-Draft that was ultimately published as RFC 9114.

Author

Mike Bishop

Last updated

2021-01-21 (Latest revision 2020-12-15)

Replaces

draft-shade-quic-http2-mapping

RFC stream

Internet Engineering Task Force (IETF)

Formats

txt html xml htmlized bibtex bibxml

Reviews

GENART Telechat review by Reese Enghardt Ready

SECDIR IETF Last Call review (of -32) by Hilarie Orman Ready

GENART IETF Last Call review (of -32) by Reese Enghardt Ready w/issues

Additional resources

Mailing list discussion

Stream

WG state

Submitted to IESG for Publication

Document shepherd

Lucas Pardue

Shepherd write-up

Show Last changed 2020-09-25

IESG

IESG state

Became RFC 9114 (Proposed Standard)

Consensus boilerplate

Yes

Telechat date

(None)

Needs 7 more YES or NO OBJECTION positions to pass.

Responsible AD

Magnus Westerlund

Send notices to

quic-chairs@ietf.org

IANA

IANA review state

IANA OK - Actions Needed

IANA expert review state

Expert Reviews OK

Email authors Email WG IPR References Referenced by Nits Nits v3 Search email archive

draft-ietf-quic-http-33

QUIC M. Bishop, Ed. Internet-Draft Akamai Intended status: Standards Track 15 December 2020 Expires: 18 June 2021 Hypertext Transfer Protocol Version 3 (HTTP/3) draft-ietf-quic-http-33 Abstract The QUIC transport protocol has several features that are desirable in a transport for HTTP, such as stream multiplexing, per-stream flow control, and low-latency connection establishment. This document describes a mapping of HTTP semantics over QUIC. This document also identifies HTTP/2 features that are subsumed by QUIC, and describes how HTTP/2 extensions can be ported to HTTP/3. DO NOT DEPLOY THIS VERSION OF HTTP DO NOT DEPLOY THIS VERSION OF HTTP/3 UNTIL IT IS IN AN RFC. This version is still a work in progress. For trial deployments, please use earlier versions. Note to Readers Discussion of this draft takes place on the QUIC working group mailing list (quic@ietf.org), which is archived at https://mailarchive.ietf.org/arch/search/?email_list=quic. Working Group information can be found at https://github.com/quicwg; source code and issues list for this draft can be found at https://github.com/quicwg/base-drafts/labels/-http. Status of This Memo This Internet-Draft is submitted in full conformance with the provisions of BCP 78 and BCP 79. Internet-Drafts are working documents of the Internet Engineering Task Force (IETF). Note that other groups may also distribute working documents as Internet-Drafts. The list of current Internet- Drafts is at https://datatracker.ietf.org/drafts/current/. Internet-Drafts are draft documents valid for a maximum of six months and may be updated, replaced, or obsoleted by other documents at any time. It is inappropriate to use Internet-Drafts as reference material or to cite them other than as "work in progress." Bishop Expires 18 June 2021 [Page 1] Internet-Draft HTTP/3 December 2020 This Internet-Draft will expire on 18 June 2021. Copyright Notice Copyright (c) 2020 IETF Trust and the persons identified as the document authors. All rights reserved. This document is subject to BCP 78 and the IETF Trust''s Legal Provisions Relating to IETF Documents (https://trustee.ietf.org/ license-info) in effect on the date of publication of this document. Please review these documents carefully, as they describe your rights and restrictions with respect to this document. Code Components extracted from this document must include Simplified BSD License text as described in Section 4.e of the Trust Legal Provisions and are provided without warranty as described in the Simplified BSD License. Table of Contents 1. Introduction . . . . . . . . . . . . . . . . . . . . . . . . 4 1.1. Prior versions of HTTP . . . . . . . . . . . . . . . . . 5 1.2. Delegation to QUIC . . . . . . . . . . . . . . . . . . . 5 2. HTTP/3 Protocol Overview . . . . . . . . . . . . . . . . . . 5 2.1. Document Organization . . . . . . . . . . . . . . . . . . 6 2.2. Conventions and Terminology . . . . . . . . . . . . . . . 7 3. Connection Setup and Management . . . . . . . . . . . . . . . 8 3.1. Discovering an HTTP/3 Endpoint . . . . . . . . . . . . . 8 3.1.1. HTTP Alternative Services . . . . . . . . . . . . . . 9 3.1.2. Other Schemes . . . . . . . . . . . . . . . . . . . . 10 3.2. Connection Establishment . . . . . . . . . . . . . . . . 10 3.3. Connection Reuse . . . . . . . . . . . . . . . . . . . . 11 4. HTTP Request Lifecycle . . . . . . . . . . . . . . . . . . . 11 4.1. HTTP Message Exchanges . . . . . . . . . . . . . . . . . 11 4.1.1. Field Formatting and Compression . . . . . . . . . . 13 4.1.2. Request Cancellation and Rejection . . . . . . . . . 17 4.1.3. Malformed Requests and Responses . . . . . . . . . . 18 4.2. The CONNECT Method . . . . . . . . . . . . . . . . . . . 19 4.3. HTTP Upgrade . . . . . . . . . . . . . . . . . . . . . . 20 4.4. Server Push . . . . . . . . . . . . . . . . . . . . . . . 20 5. Connection Closure . . . . . . . . . . . . . . . . . . . . . 22 5.1. Idle Connections . . . . . . . . . . . . . . . . . . . . 22 5.2. Connection Shutdown . . . . . . . . . . . . . . . . . . . 23 5.3. Immediate Application Closure . . . . . . . . . . . . . . 25 5.4. Transport Closure . . . . . . . . . . . . . . . . . . . . 25 6. Stream Mapping and Usage . . . . . . . . . . . . . . . . . . 25 6.1. Bidirectional Streams . . . . . . . . . . . . . . . . . . 26 6.2. Unidirectional Streams . . . . . . . . . . . . . . . . . 26 6.2.1. Control Streams . . . . . . . . . . . . . . . . . . . 28 6.2.2. Push Streams . . . . . . . . . . . . . . . . . . . . 28 Bishop Expires 18 June 2021 [Page 2] Internet-Draft HTTP/3 December 2020 6.2.3. Reserved Stream Types . . . . . . . . . . . . . . . . 29 7. HTTP Framing Layer . . . . . . . . . . . . . . . . . . . . . 29 7.1. Frame Layout . . . . . . . . . . . . . . . . . . . . . . 30 7.2. Frame Definitions . . . . . . . . . . . . . . . . . . . . 31 7.2.1. DATA . . . . . . . . . . . . . . . . . . . . . . . . 31 7.2.2. HEADERS . . . . . . . . . . . . . . . . . . . . . . . 31 7.2.3. CANCEL_PUSH . . . . . . . . . . . . . . . . . . . . . 32 7.2.4. SETTINGS . . . . . . . . . . . . . . . . . . . . . . 33 7.2.5. PUSH_PROMISE . . . . . . . . . . . . . . . . . . . . 36 7.2.6. GOAWAY . . . . . . . . . . . . . . . . . . . . . . . 38 7.2.7. MAX_PUSH_ID . . . . . . . . . . . . . . . . . . . . . 38 7.2.8. Reserved Frame Types . . . . . . . . . . . . . . . . 39 8. Error Handling . . . . . . . . . . . . . . . . . . . . . . . 40 8.1. HTTP/3 Error Codes . . . . . . . . . . . . . . . . . . . 40 9. Extensions to HTTP/3 . . . . . . . . . . . . . . . . . . . . 42 10. Security Considerations . . . . . . . . . . . . . . . . . . . 43 10.1. Server Authority . . . . . . . . . . . . . . . . . . . . 43 10.2. Cross-Protocol Attacks . . . . . . . . . . . . . . . . . 43 10.3. Intermediary Encapsulation Attacks . . . . . . . . . . . 43 10.4. Cacheability of Pushed Responses . . . . . . . . . . . . 44 10.5. Denial-of-Service Considerations . . . . . . . . . . . . 44 10.5.1. Limits on Field Section Size . . . . . . . . . . . . 45 10.5.2. CONNECT Issues . . . . . . . . . . . . . . . . . . . 46 10.6. Use of Compression . . . . . . . . . . . . . . . . . . . 46 10.7. Padding and Traffic Analysis . . . . . . . . . . . . . . 46 10.8. Frame Parsing . . . . . . . . . . . . . . . . . . . . . 47 10.9. Early Data . . . . . . . . . . . . . . . . . . . . . . . 47 10.10. Migration . . . . . . . . . . . . . . . . . . . . . . . 48 10.11. Privacy Considerations . . . . . . . . . . . . . . . . . 48 11. IANA Considerations . . . . . . . . . . . . . . . . . . . . . 48 11.1. Registration of HTTP/3 Identification String . . . . . . 48 11.2. New Registries . . . . . . . . . . . . . . . . . . . . . 49 11.2.1. Frame Types . . . . . . . . . . . . . . . . . . . . 49 11.2.2. Settings Parameters . . . . . . . . . . . . . . . . 50 11.2.3. Error Codes . . . . . . . . . . . . . . . . . . . . 51 11.2.4. Stream Types . . . . . . . . . . . . . . . . . . . . 54 12. References . . . . . . . . . . . . . . . . . . . . . . . . . 54 12.1. Normative References . . . . . . . . . . . . . . . . . . 54 12.2. Informative References . . . . . . . . . . . . . . . . . 56 Appendix A. Considerations for Transitioning from HTTP/2 . . . . 57 A.1. Streams . . . . . . . . . . . . . . . . . . . . . . . . . 57 A.2. HTTP Frame Types . . . . . . . . . . . . . . . . . . . . 58 A.2.1. Prioritization Differences . . . . . . . . . . . . . 59 A.2.2. Field Compression Differences . . . . . . . . . . . . 59 A.2.3. Flow Control Differences . . . . . . . . . . . . . . 59 A.2.4. Guidance for New Frame Type Definitions . . . . . . . 59 A.2.5. Mapping Between HTTP/2 and HTTP/3 Frame Types . . . . 60 A.3. HTTP/2 SETTINGS Parameters . . . . . . . . . . . . . . . 61 Bishop Expires 18 June 2021 [Page 3] Internet-Draft HTTP/3 December 2020 A.4. HTTP/2 Error Codes . . . . . . . . . . . . . . . . . . . 62 A.4.1. Mapping Between HTTP/2 and HTTP/3 Errors . . . . . . 63 Appendix B. Change Log . . . . . . . . . . . . . . . . . . . . . 64 B.1. Since draft-ietf-quic-http-32 . . . . . . . . . . . . . . 64 B.2. Since draft-ietf-quic-http-31 . . . . . . . . . . . . . . 64 B.3. Since draft-ietf-quic-http-30 . . . . . . . . . . . . . . 64 B.4. Since draft-ietf-quic-http-29 . . . . . . . . . . . . . . 64 B.5. Since draft-ietf-quic-http-28 . . . . . . . . . . . . . . 64 B.6. Since draft-ietf-quic-http-27 . . . . . . . . . . . . . . 64 B.7. Since draft-ietf-quic-http-26 . . . . . . . . . . . . . . 65 B.8. Since draft-ietf-quic-http-25 . . . . . . . . . . . . . . 65 B.9. Since draft-ietf-quic-http-24 . . . . . . . . . . . . . . 65 B.10. Since draft-ietf-quic-http-23 . . . . . . . . . . . . . . 65 B.11. Since draft-ietf-quic-http-22 . . . . . . . . . . . . . . 65 B.12. Since draft-ietf-quic-http-21 . . . . . . . . . . . . . . 66 B.13. Since draft-ietf-quic-http-20 . . . . . . . . . . . . . . 66 B.14. Since draft-ietf-quic-http-19 . . . . . . . . . . . . . . 67 B.15. Since draft-ietf-quic-http-18 . . . . . . . . . . . . . . 67 B.16. Since draft-ietf-quic-http-17 . . . . . . . . . . . . . . 68 B.17. Since draft-ietf-quic-http-16 . . . . . . . . . . . . . . 68 B.18. Since draft-ietf-quic-http-15 . . . . . . . . . . . . . . 69 B.19. Since draft-ietf-quic-http-14 . . . . . . . . . . . . . . 69 B.20. Since draft-ietf-quic-http-13 . . . . . . . . . . . . . . 69 B.21. Since draft-ietf-quic-http-12 . . . . . . . . . . . . . . 69 B.22. Since draft-ietf-quic-http-11 . . . . . . . . . . . . . . 70 B.23. Since draft-ietf-quic-http-10 . . . . . . . . . . . . . . 70 B.24. Since draft-ietf-quic-http-09 . . . . . . . . . . . . . . 70 B.25. Since draft-ietf-quic-http-08 . . . . . . . . . . . . . . 70 B.26. Since draft-ietf-quic-http-07 . . . . . . . . . . . . . . 70 B.27. Since draft-ietf-quic-http-06 . . . . . . . . . . . . . . 70 B.28. Since draft-ietf-quic-http-05 . . . . . . . . . . . . . . 70 B.29. Since draft-ietf-quic-http-04 . . . . . . . . . . . . . . 70 B.30. Since draft-ietf-quic-http-03 . . . . . . . . . . . . . . 71 B.31. Since draft-ietf-quic-http-02 . . . . . . . . . . . . . . 71 B.32. Since draft-ietf-quic-http-01 . . . . . . . . . . . . . . 71 B.33. Since draft-ietf-quic-http-00 . . . . . . . . . . . . . . 72 B.34. Since draft-shade-quic-http2-mapping-00 . . . . . . . . . 72 Acknowledgements . . . . . . . . . . . . . . . . . . . . . . . . 72 Author''s Address . . . . . . . . . . . . . . . . . . . . . . . . 73 1. Introduction HTTP semantics ([SEMANTICS]) are used for a broad range of services on the Internet. These semantics have most commonly been used with HTTP/1.1, over a variety of transport and session layers, and with HTTP/2 over TLS. HTTP/3 supports the same semantics over a new transport protocol, QUIC. Bishop Expires 18 June 2021 [Page 4] Internet-Draft HTTP/3 December 2020 1.1. Prior versions of HTTP HTTP/1.1 ([HTTP11]) uses whitespace-delimited text fields to convey HTTP messages. While these exchanges are human-readable, using whitespace for message formatting leads to parsing complexity and excessive tolerance of variant behavior. Because HTTP/1.x does not include a multiplexing layer, multiple TCP connections are often used to service requests in parallel. However, that has a negative impact on congestion control and network efficiency, since TCP does not share congestion control across multiple connections. HTTP/2 ([HTTP2]) introduced a binary framing and multiplexing layer to improve latency without modifying the transport layer. However, because the parallel nature of HTTP/2''s multiplexing is not visible to TCP''s loss recovery mechanisms, a lost or reordered packet causes all active transactions to experience a stall regardless of whether that transaction was directly impacted by the lost packet. 1.2. Delegation to QUIC The QUIC transport protocol incorporates stream multiplexing and per- stream flow control, similar to that provided by the HTTP/2 framing layer. By providing reliability at the stream level and congestion control across the entire connection, QUIC has the capability to improve the performance of HTTP compared to a TCP mapping. QUIC also incorporates TLS 1.3 ([TLS13]) at the transport layer, offering comparable confidentiality and integrity to running TLS over TCP, with the improved connection setup latency of TCP Fast Open ([TFO]). This document defines a mapping of HTTP semantics over the QUIC transport protocol, drawing heavily on the design of HTTP/2. While delegating stream lifetime and flow control issues to QUIC, a similar binary framing is used on each stream. Some HTTP/2 features are subsumed by QUIC, while other features are implemented atop QUIC. QUIC is described in [QUIC-TRANSPORT]. For a full description of HTTP/2, see [HTTP2]. 2. HTTP/3 Protocol Overview HTTP/3 provides a transport for HTTP semantics using the QUIC transport protocol and an internal framing layer similar to HTTP/2. Once a client knows that an HTTP/3 server exists at a certain endpoint, it opens a QUIC connection. QUIC provides protocol negotiation, stream-based multiplexing, and flow control. Discovery of an HTTP/3 endpoint is described in Section 3.1. Bishop Expires 18 June 2021 [Page 5] Internet-Draft HTTP/3 December 2020 Within each stream, the basic unit of HTTP/3 communication is a frame (Section 7.2). Each frame type serves a different purpose. For example, HEADERS and DATA frames form the basis of HTTP requests and responses (Section 4.1). Multiplexing of requests is performed using the QUIC stream abstraction, described in Section 2 of [QUIC-TRANSPORT]. Each request-response pair consumes a single QUIC stream. Streams are independent of each other, so one stream that is blocked or suffers packet loss does not prevent progress on other streams. Server push is an interaction mode introduced in HTTP/2 ([HTTP2]) that permits a server to push a request-response exchange to a client in anticipation of the client making the indicated request. This trades off network usage against a potential latency gain. Several HTTP/3 frames are used to manage server push, such as PUSH_PROMISE, MAX_PUSH_ID, and CANCEL_PUSH. As in HTTP/2, request and response fields are compressed for transmission. Because HPACK ([HPACK]) relies on in-order transmission of compressed field sections (a guarantee not provided by QUIC), HTTP/3 replaces HPACK with QPACK ([QPACK]). QPACK uses separate unidirectional streams to modify and track field table state, while encoded field sections refer to the state of the table without modifying it. 2.1. Document Organization The following sections provide a detailed overview of the lifecycle of an HTTP/3 connection: * Connection Setup and Management (Section 3) covers how an HTTP/3 endpoint is discovered and an HTTP/3 connection is established. * HTTP Request Lifecycle (Section 4) describes how HTTP semantics are expressed using frames. * Connection Closure (Section 5) describes how HTTP/3 connections are terminated, either gracefully or abruptly. The details of the wire protocol and interactions with the transport are described in subsequent sections: * Stream Mapping and Usage (Section 6) describes the way QUIC streams are used. * HTTP Framing Layer (Section 7) describes the frames used on most streams. Bishop Expires 18 June 2021 [Page 6] Internet-Draft HTTP/3 December 2020 * Error Handling (Section 8) describes how error conditions are handled and expressed, either on a particular stream or for the connection as a whole. Additional resources are provided in the final sections: * Extensions to HTTP/3 (Section 9) describes how new capabilities can be added in future documents. * A more detailed comparison between HTTP/2 and HTTP/3 can be found in Appendix A. 2.2. Conventions and Terminology The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "NOT RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in BCP 14 [RFC2119] [RFC8174] when, and only when, they appear in all capitals, as shown here. This document uses the variable-length integer encoding from [QUIC-TRANSPORT]. The following terms are used: abort: An abrupt termination of a connection or stream, possibly due to an error condition. client: The endpoint that initiates an HTTP/3 connection. Clients send HTTP requests and receive HTTP responses. connection: A transport-layer connection between two endpoints, using QUIC as the transport protocol. connection error: An error that affects the entire HTTP/3 connection. endpoint: Either the client or server of the connection. frame: The smallest unit of communication on a stream in HTTP/3, consisting of a header and a variable-length sequence of bytes structured according to the frame type. Protocol elements called "frames" exist in both this document and [QUIC-TRANSPORT]. Where frames from [QUIC-TRANSPORT] are referenced, the frame name will be prefaced with "QUIC." For example, "QUIC CONNECTION_CLOSE frames." References without this preface refer to frames defined in Section 7.2. Bishop Expires 18 June 2021 [Page 7] Internet-Draft HTTP/3 December 2020 HTTP/3 connection: A QUIC connection where the negotiated application protocol is HTTP/3. peer: An endpoint. When discussing a particular endpoint, "peer" refers to the endpoint that is remote to the primary subject of discussion. receiver: An endpoint that is receiving frames. sender: An endpoint that is transmitting frames. server: The endpoint that accepts an HTTP/3 connection. Servers receive HTTP requests and send HTTP responses. stream: A bidirectional or unidirectional bytestream provided by the QUIC transport. All streams within an HTTP/3 connection can be considered "HTTP/3 streams," but multiple stream types are defined within HTTP/3. stream error: An application-level error on the individual stream. The term "payload data" is defined in Section 6.4 of [SEMANTICS]. Finally, the terms "resource", "message", "user agent", "origin server", "gateway", "intermediary", "proxy", and "tunnel" are defined in Section 3 of [SEMANTICS]. Packet diagrams in this document use the format defined in Section 1.3 of [QUIC-TRANSPORT] to illustrate the order and size of fields. 3. Connection Setup and Management 3.1. Discovering an HTTP/3 Endpoint HTTP relies on the notion of an authoritative response: a response that has been determined to be the most appropriate response for that request given the state of the target resource at the time of response message origination by (or at the direction of) the origin server identified within the target URI. Locating an authoritative server for an HTTP URL is discussed in Section 4.3 of [SEMANTICS]. The "https" scheme associates authority with possession of a certificate that the client considers to be trustworthy for the host identified by the authority component of the URL. Bishop Expires 18 June 2021 [Page 8] Internet-Draft HTTP/3 December 2020 If a server presents a valid certificate and proof that it controls the corresponding private key, then a client will accept a secured TLS session with that server as being authoritative for all origins with the "https" scheme and a host identified in the certificate. The host must be listed either as the CN field of the certificate subject or as a dNSName in the subjectAltName field of the certificate; see [RFC6125]. For a host that is an IP address, the client MUST verify that the address appears as an iPAddress in the subjectAltName field of the certificate. If the hostname or address is not present in the certificate, the client MUST NOT consider the server authoritative for origins containing that hostname or address. See Section 4.3 of [SEMANTICS] for more detail on authoritative access. A client MAY attempt access to a resource with an "https" URI by resolving the host identifier to an IP address, establishing a QUIC connection to that address on the indicated port, and sending an HTTP/3 request message targeting the URI to the server over that secured connection. Unless some other mechanism is used to select HTTP/3, the token "h3" is used in the Application Layer Protocol Negotiation (ALPN; see [RFC7301]) extension during the TLS handshake. Connectivity problems (e.g., blocking UDP) can result in QUIC connection establishment failure; clients SHOULD attempt to use TCP- based versions of HTTP in this case. Servers MAY serve HTTP/3 on any UDP port; an alternative service advertisement always includes an explicit port, and URLs contain either an explicit port or a default port associated with the scheme. 3.1.1. HTTP Alternative Services An HTTP origin advertises the availability of an equivalent HTTP/3 endpoint via the Alt-Svc HTTP response header field or the HTTP/2 ALTSVC frame ([ALTSVC]), using the "h3" ALPN token. For example, an origin could indicate in an HTTP response that HTTP/3 was available on UDP port 50781 at the same hostname by including the following header field: Alt-Svc: h3=":50781" On receipt of an Alt-Svc record indicating HTTP/3 support, a client MAY attempt to establish a QUIC connection to the indicated host and port; if this connection is successful, the client can send HTTP requests using the mapping described in this document. Bishop Expires 18 June 2021 [Page 9] Internet-Draft HTTP/3 December 2020 3.1.2. Other Schemes Although HTTP is independent of the transport protocol, the "http" scheme associates authority with the ability to receive TCP connections on the indicated port of whatever host is identified within the authority component. Because HTTP/3 does not use TCP, HTTP/3 cannot be used for direct access to the authoritative server for a resource identified by an "http" URI. However, protocol extensions such as [ALTSVC] permit the authoritative server to identify other services that are also authoritative and that might be reachable over HTTP/3. Prior to making requests for an origin whose scheme is not "https", the client MUST ensure the server is willing to serve that scheme. For origins whose scheme is "http", an experimental method to accomplish this is described in [RFC8164]. Other mechanisms might be defined for various schemes in the future. 3.2. Connection Establishment HTTP/3 relies on QUIC version 1 as the underlying transport. The use of other QUIC transport versions with HTTP/3 MAY be defined by future specifications. QUIC version 1 uses TLS version 1.3 or greater as its handshake protocol. HTTP/3 clients MUST support a mechanism to indicate the target host to the server during the TLS handshake. If the server is identified by a DNS name, clients MUST send the Server Name Indication (SNI; [RFC6066]) TLS extension unless an alternative mechanism to indicate the target host is used. QUIC connections are established as described in [QUIC-TRANSPORT]. During connection establishment, HTTP/3 support is indicated by selecting the ALPN token "h3" in the TLS handshake. Support for other application-layer protocols MAY be offered in the same handshake. While connection-level options pertaining to the core QUIC protocol are set in the initial crypto handshake, HTTP/3-specific settings are conveyed in the SETTINGS frame. After the QUIC connection is established, a SETTINGS frame (Section 7.2.4) MUST be sent by each endpoint as the initial frame of their respective HTTP control stream; see Section 6.2.1. Bishop Expires 18 June 2021 [Page 10] Internet-Draft HTTP/3 December 2020 3.3. Connection Reuse HTTP/3 connections are persistent across multiple requests. For best performance, it is expected that clients will not close connections until it is determined that no further communication with a server is necessary (for example, when a user navigates away from a particular web page) or until the server closes the connection. Once a connection exists to a server endpoint, this connection MAY be reused for requests with multiple different URI authority components. Clients SHOULD NOT open more than one HTTP/3 connection to a given host and port pair, where the host is derived from a URI, a selected alternative service ([ALTSVC]), or a configured proxy. A client MAY open multiple HTTP/3 connections to the same IP address and UDP port using different transport or TLS configurations but SHOULD avoid creating multiple connections with the same configuration. Servers are encouraged to maintain open HTTP/3 connections for as long as possible but are permitted to terminate idle connections if necessary. When either endpoint chooses to close the HTTP/3 connection, the terminating endpoint SHOULD first send a GOAWAY frame (Section 5.2) so that both endpoints can reliably determine whether previously sent frames have been processed and gracefully complete or terminate any necessary remaining tasks. A server that does not wish clients to reuse HTTP/3 connections for a particular origin can indicate that it is not authoritative for a request by sending a 421 (Misdirected Request) status code in response to the request; see Section 9.1.2 of [HTTP2]. 4. HTTP Request Lifecycle 4.1. HTTP Message Exchanges A client sends an HTTP request on a request stream, which is a client-initiated bidirectional QUIC stream; see Section 6.1. A client MUST send only a single request on a given stream. A server sends zero or more interim HTTP responses on the same stream as the request, followed by a single final HTTP response, as detailed below. See Section 15 of [SEMANTICS] for a description of interim and final HTTP responses. Pushed responses are sent on a server-initiated unidirectional QUIC stream; see Section 6.2.2. A server sends zero or more interim HTTP responses, followed by a single final HTTP response, in the same manner as a standard response. Push is described in more detail in Section 4.4. Bishop Expires 18 June 2021 [Page 11] Internet-Draft HTTP/3 December 2020 On a given stream, receipt of multiple requests or receipt of an additional HTTP response following a final HTTP response MUST be treated as malformed (Section 4.1.3). An HTTP message (request or response) consists of: 1. the header field section, sent as a single HEADERS frame (see Section 7.2.2), 2. optionally, the payload data, if present, sent as a series of DATA frames (see Section 7.2.1), and 3. optionally, the trailer field section, if present, sent as a single HEADERS frame. Header and trailer field sections are described in Sections 6.3 and 6.5 of [SEMANTICS]; the payload data is described in Section 6.4 of [SEMANTICS]. Receipt of an invalid sequence of frames MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. In particular, a DATA frame before any HEADERS frame, or a HEADERS or DATA frame after the trailing HEADERS frame is considered invalid. Other frame types, especially unknown frame types, might be permitted subject to their own rules; see Section 9. A server MAY send one or more PUSH_PROMISE frames (Section 7.2.5) before, after, or interleaved with the frames of a response message. These PUSH_PROMISE frames are not part of the response; see Section 4.4 for more details. PUSH_PROMISE frames are not permitted on push streams; a pushed response that includes PUSH_PROMISE frames MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. Frames of unknown types (Section 9), including reserved frames (Section 7.2.8) MAY be sent on a request or push stream before, after, or interleaved with other frames described in this section. The HEADERS and PUSH_PROMISE frames might reference updates to the QPACK dynamic table. While these updates are not directly part of the message exchange, they must be received and processed before the message can be consumed. See Section 4.1.1 for more details. The "chunked" transfer encoding defined in Section 7.1 of [HTTP11] MUST NOT be used. Bishop Expires 18 June 2021 [Page 12] Internet-Draft HTTP/3 December 2020 A response MAY consist of multiple messages when and only when one or more interim responses (1xx; see Section 15.2 of [SEMANTICS]) precede a final response to the same request. Interim responses do not contain payload data or trailers. An HTTP request/response exchange fully consumes a client-initiated bidirectional QUIC stream. After sending a request, a client MUST close the stream for sending. Unless using the CONNECT method (see Section 4.2), clients MUST NOT make stream closure dependent on receiving a response to their request. After sending a final response, the server MUST close the stream for sending. At this point, the QUIC stream is fully closed. When a stream is closed, this indicates the end of the final HTTP message. Because some messages are large or unbounded, endpoints SHOULD begin processing partial HTTP messages once enough of the message has been received to make progress. If a client-initiated stream terminates without enough of the HTTP message to provide a complete response, the server SHOULD abort its response with the error code H3_REQUEST_INCOMPLETE; see Section 8. A server can send a complete response prior to the client sending an entire request if the response does not depend on any portion of the request that has not been sent and received. When the server does not need to receive the remainder of the request, it MAY abort reading the request stream, send a complete response, and cleanly close the sending part of the stream. The error code H3_NO_ERROR SHOULD be used when requesting that the client stop sending on the request stream. Clients MUST NOT discard complete responses as a result of having their request terminated abruptly, though clients can always discard responses at their discretion for other reasons. If the server sends a partial or complete response but does not abort reading the request, clients SHOULD continue sending the body of the request and close the stream normally. 4.1.1. Field Formatting and Compression HTTP messages carry metadata as a series of key-value pairs called HTTP fields; see Sections 6.3 and 6.5 of [SEMANTICS]. For a listing of registered HTTP fields, see the "Hypertext Transfer Protocol (HTTP) Field Name Registry" maintained at https://www.iana.org/assignments/http-fields/. *Note:* This registry will not exist until [SEMANTICS] is approved. *RFC Editor*, please remove this note prior to publication. Bishop Expires 18 June 2021 [Page 13] Internet-Draft HTTP/3 December 2020 As in previous versions of HTTP, field names are strings containing a subset of ASCII characters that are compared in a case-insensitive fashion. Properties of HTTP field names and values are discussed in more detail in Section 5.1 of [SEMANTICS]. As in HTTP/2, characters in field names MUST be converted to lowercase prior to their encoding. A request or response containing uppercase characters in field names MUST be treated as malformed (Section 4.1.3). Like HTTP/2, HTTP/3 does not use the Connection header field to indicate connection-specific fields; in this protocol, connection- specific metadata is conveyed by other means. An endpoint MUST NOT generate an HTTP/3 field section containing connection-specific fields; any message containing connection-specific fields MUST be treated as malformed (Section 4.1.3). The only exception to this is the TE header field, which MAY be present in an HTTP/3 request header; when it is, it MUST NOT contain any value other than "trailers". This means that an intermediary transforming an HTTP/1.x message to HTTP/3 will need to remove any fields nominated by the Connection field, along with the Connection field itself. Such intermediaries SHOULD also remove other connection-specific fields, such as Keep- Alive, Proxy-Connection, Transfer-Encoding, and Upgrade, even if they are not nominated by the Connection field. 4.1.1.1. Pseudo-Header Fields Like HTTP/2, HTTP/3 employs a series of pseudo-header fields where the field name begins with the '':'' character (ASCII 0x3a). These pseudo-header fields convey the target URI, the method of the request, and the status code for the response. Pseudo-header fields are not HTTP fields. Endpoints MUST NOT generate pseudo-header fields other than those defined in this document; however, an extension could negotiate a modification of this restriction; see Section 9. Pseudo-header fields are only valid in the context in which they are defined. Pseudo-header fields defined for requests MUST NOT appear in responses; pseudo-header fields defined for responses MUST NOT appear in requests. Pseudo-header fields MUST NOT appear in trailers. Endpoints MUST treat a request or response that contains undefined or invalid pseudo-header fields as malformed (Section 4.1.3). Bishop Expires 18 June 2021 [Page 14] Internet-Draft HTTP/3 December 2020 All pseudo-header fields MUST appear in the header field section before regular header fields. Any request or response that contains a pseudo-header field that appears in a header field section after a regular header field MUST be treated as malformed (Section 4.1.3). The following pseudo-header fields are defined for requests: ":method": Contains the HTTP method (Section 9 of [SEMANTICS]) ":scheme": Contains the scheme portion of the target URI (Section 3.1 of [URI]) ":scheme" is not restricted to "http" and "https" schemed URIs. A proxy or gateway can translate requests for non-HTTP schemes, enabling the use of HTTP to interact with non-HTTP services. ":authority": Contains the authority portion of the target URI (Section 3.2 of [URI]). The authority MUST NOT include the deprecated "userinfo" subcomponent for "http" or "https" schemed URIs. To ensure that the HTTP/1.1 request line can be reproduced accurately, this pseudo-header field MUST be omitted when translating from an HTTP/1.1 request that has a request target in origin or asterisk form; see Section 3.2 of [HTTP11]. Clients that generate HTTP/3 requests directly SHOULD use the ":authority" pseudo-header field instead of the Host field. An intermediary that converts an HTTP/3 request to HTTP/1.1 MUST create a Host field if one is not present in a request by copying the value of the ":authority" pseudo-header field. ":path": Contains the path and query parts of the target URI (the "path-absolute" production and optionally a ''?'' character followed by the "query" production; see Sections 3.3 and 3.4 of [URI]. A request in asterisk form includes the value ''*'' for the ":path" pseudo-header field. This pseudo-header field MUST NOT be empty for "http" or "https" URIs; "http" or "https" URIs that do not contain a path component MUST include a value of ''/''. The exception to this rule is an OPTIONS request for an "http" or "https" URI that does not include a path component; these MUST include a ":path" pseudo-header field with a value of ''*''; see Section 3.2.4 of [HTTP11]. All HTTP/3 requests MUST include exactly one value for the ":method", ":scheme", and ":path" pseudo-header fields, unless it is a CONNECT request; see Section 4.2. Bishop Expires 18 June 2021 [Page 15] Internet-Draft HTTP/3 December 2020 If the ":scheme" pseudo-header field identifies a scheme that has a mandatory authority component (including "http" and "https"), the request MUST contain either an ":authority" pseudo-header field or a "Host" header field. If these fields are present, they MUST NOT be empty. If both fields are present, they MUST contain the same value. If the scheme does not have a mandatory authority component and none is provided in the request target, the request MUST NOT contain the ":authority" pseudo-header or "Host" header fields. An HTTP request that omits mandatory pseudo-header fields or contains invalid values for those pseudo-header fields is malformed (Section 4.1.3). HTTP/3 does not define a way to carry the version identifier that is included in the HTTP/1.1 request line. For responses, a single ":status" pseudo-header field is defined that carries the HTTP status code; see Section 15 of [SEMANTICS]. This pseudo-header field MUST be included in all responses; otherwise, the response is malformed (Section 4.1.3). HTTP/3 does not define a way to carry the version or reason phrase that is included in an HTTP/1.1 status line. 4.1.1.2. Field Compression HTTP/3 uses QPACK field compression as described in [QPACK], a variation of HPACK that allows the flexibility to avoid compression- induced head-of-line blocking. See that document for additional details. To allow for better compression efficiency, the "Cookie" field ([RFC6265]) MAY be split into separate field lines, each with one or more cookie-pairs, before compression. If a decompressed field section contains multiple cookie field lines, these MUST be concatenated into a single octet string using the two-octet delimiter of 0x3b, 0x20 (the ASCII string "; ") before being passed into a context other than HTTP/2 or HTTP/3, such as an HTTP/1.1 connection, or a generic HTTP server application. 4.1.1.3. Header Size Constraints An HTTP/3 implementation MAY impose a limit on the maximum size of the message header it will accept on an individual HTTP message. A server that receives a larger header section than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code ([RFC6585]). A client can discard responses that it cannot process. The size of a field list is calculated based on the Bishop Expires 18 June 2021 [Page 16] Internet-Draft HTTP/3 December 2020 uncompressed size of fields, including the length of the name and value in bytes plus an overhead of 32 bytes for each field. If an implementation wishes to advise its peer of this limit, it can be conveyed as a number of bytes in the SETTINGS_MAX_FIELD_SECTION_SIZE parameter. An implementation that has received this parameter SHOULD NOT send an HTTP message header that exceeds the indicated size, as the peer will likely refuse to process it. However, an HTTP message can traverse one or more intermediaries before reaching the origin server; see Section 3.6 of [SEMANTICS]. Because this limit is applied separately by each implementation which processes the message, messages below this limit are not guaranteed to be accepted. 4.1.2. Request Cancellation and Rejection Once a request stream has been opened, the request MAY be cancelled by either endpoint. Clients cancel requests if the response is no longer of interest; servers cancel requests if they are unable to or choose not to respond. When possible, it is RECOMMENDED that servers send an HTTP response with an appropriate status code rather than canceling a request it has already begun processing. Implementations SHOULD cancel requests by abruptly terminating any directions of a stream that are still open. This means resetting the sending parts of streams and aborting reading on receiving parts of streams; see Section 2.4 of [QUIC-TRANSPORT]. When the server cancels a request without performing any application processing, the request is considered "rejected." The server SHOULD abort its response stream with the error code H3_REQUEST_REJECTED. In this context, "processed" means that some data from the stream was passed to some higher layer of software that might have taken some action as a result. The client can treat requests rejected by the server as though they had never been sent at all, thereby allowing them to be retried later. Servers MUST NOT use the H3_REQUEST_REJECTED error code for requests that were partially or fully processed. When a server abandons a response after partial processing, it SHOULD abort its response stream with the error code H3_REQUEST_CANCELLED. Client SHOULD use the error code H3_REQUEST_CANCELLED to cancel requests. Upon receipt of this error code, a server MAY abruptly terminate the response using the error code H3_REQUEST_REJECTED if no processing was performed. Clients MUST NOT use the H3_REQUEST_REJECTED error code, except when a server has requested closure of the request stream with this error code. Bishop Expires 18 June 2021 [Page 17] Internet-Draft HTTP/3 December 2020 If a stream is canceled after receiving a complete response, the client MAY ignore the cancellation and use the response. However, if a stream is cancelled after receiving a partial response, the response SHOULD NOT be used. Only idempotent actions such as GET, PUT, or DELETE can be safely retried; a client SHOULD NOT automatically retry a request with a non-idempotent method unless it has some means to know that the request semantics are idempotent independent of the method or some means to detect that the original request was never applied. See Section 9.2.2 of [SEMANTICS] for more details. 4.1.3. Malformed Requests and Responses A malformed request or response is one that is an otherwise valid sequence of frames but is invalid due to: * the presence of prohibited fields or pseudo-header fields, * the absence of mandatory pseudo-header fields, * invalid values for pseudo-header fields, * pseudo-header fields after fields, * an invalid sequence of HTTP messages, * the inclusion of uppercase field names, or * the inclusion of invalid characters in field names or values. A request or response that includes payload data can include a Content-Length header field. A request or response is also malformed if the value of a Content-Length header field does not equal the sum of the DATA frame lengths that form the payload data. A response that is defined to have no payload, as described in Section 6.4 of [SEMANTICS], can have a non-zero Content-Length field, even though no content is included in DATA frames. Intermediaries that process HTTP requests or responses (i.e., any intermediary not acting as a tunnel) MUST NOT forward a malformed request or response. Malformed requests or responses that are detected MUST be treated as a stream error (Section 8) of type H3_MESSAGE_ERROR. Bishop Expires 18 June 2021 [Page 18] Internet-Draft HTTP/3 December 2020 For malformed requests, a server MAY send an HTTP response indicating the error prior to closing or resetting the stream. Clients MUST NOT accept a malformed response. Note that these requirements are intended to protect against several types of common attacks against HTTP; they are deliberately strict because being permissive can expose implementations to these vulnerabilities. 4.2. The CONNECT Method The CONNECT method requests that the recipient establish a tunnel to the destination origin server identified by the request-target; see Section 9.3.6 of [SEMANTICS]. It is primarily used with HTTP proxies to establish a TLS session with an origin server for the purposes of interacting with "https" resources. In HTTP/1.x, CONNECT is used to convert an entire HTTP connection into a tunnel to a remote host. In HTTP/2 and HTTP/3, the CONNECT method is used to establish a tunnel over a single stream. A CONNECT request MUST be constructed as follows: * The ":method" pseudo-header field is set to "CONNECT" * The ":scheme" and ":path" pseudo-header fields are omitted * The ":authority" pseudo-header field contains the host and port to connect to (equivalent to the authority-form of the request-target of CONNECT requests; see Section 3.2.3 of [HTTP11]) The request stream remains open at the end of the request to carry the data to be transferred. A CONNECT request that does not conform to these restrictions is malformed; see Section 4.1.3. A proxy that supports CONNECT establishes a TCP connection ([RFC0793]) to the server identified in the ":authority" pseudo- header field. Once this connection is successfully established, the proxy sends a HEADERS frame containing a 2xx series status code to the client, as defined in Section 15.3 of [SEMANTICS]. All DATA frames on the stream correspond to data sent or received on the TCP connection. The payload of any DATA frame sent by the client is transmitted by the proxy to the TCP server; data received from the TCP server is packaged into DATA frames by the proxy. Note that the size and number of TCP segments is not guaranteed to map predictably to the size and number of HTTP DATA or QUIC STREAM frames. Bishop Expires 18 June 2021 [Page 19] Internet-Draft HTTP/3 December 2020 Once the CONNECT method has completed, only DATA frames are permitted to be sent on the stream. Extension frames MAY be used if specifically permitted by the definition of the extension. Receipt of any other known frame type MUST be treated as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. The TCP connection can be closed by either peer. When the client ends the request stream (that is, the receive stream at the proxy enters the "Data Recvd" state), the proxy will set the FIN bit on its connection to the TCP server. When the proxy receives a packet with the FIN bit set, it will close the send stream that it sends to the client. TCP connections that remain half-closed in a single direction are not invalid, but are often handled poorly by servers, so clients SHOULD NOT close a stream for sending while they still expect to receive data from the target of the CONNECT. A TCP connection error is signaled by abruptly terminating the stream. A proxy treats any error in the TCP connection, which includes receiving a TCP segment with the RST bit set, as a stream error of type H3_CONNECT_ERROR; see Section 8. Correspondingly, if a proxy detects an error with the stream or the QUIC connection, it MUST close the TCP connection. If the underlying TCP implementation permits it, the proxy SHOULD send a TCP segment with the RST bit set. 4.3. HTTP Upgrade HTTP/3 does not support the HTTP Upgrade mechanism (Section 7.8 of [SEMANTICS]) or 101 (Switching Protocols) informational status code (Section 15.2.2 of [SEMANTICS]). 4.4. Server Push Server push is an interaction mode that permits a server to push a request-response exchange to a client in anticipation of the client making the indicated request. This trades off network usage against a potential latency gain. HTTP/3 server push is similar to what is described in Section 8.2 of [HTTP2], but uses different mechanisms. Each server push is assigned a unique Push ID by the server. The Push ID is used to refer to the push in various contexts throughout the lifetime of the HTTP/3 connection. The Push ID space begins at zero, and ends at a maximum value set by the MAX_PUSH_ID frame; see Section 7.2.7. In particular, a server is not able to push until after the client sends a MAX_PUSH_ID frame. A client sends MAX_PUSH_ID frames to control the number of pushes that a server can promise. A server SHOULD use Push IDs sequentially, beginning from zero. A client MUST treat receipt of a push stream as Bishop Expires 18 June 2021 [Page 20] Internet-Draft HTTP/3 December 2020 a connection error of type H3_ID_ERROR (Section 8) when no MAX_PUSH_ID frame has been sent or when the stream references a Push ID that is greater than the maximum Push ID. The Push ID is used in one or more PUSH_PROMISE frames (Section 7.2.5) that carry the header section of the request message. These frames are sent on the request stream that generated the push. This allows the server push to be associated with a client request. When the same Push ID is promised on multiple request streams, the decompressed request field sections MUST contain the same fields in the same order, and both the name and the value in each field MUST be identical. The Push ID is then included with the push stream that ultimately fulfills those promises; see Section 6.2.2. The push stream identifies the Push ID of the promise that it fulfills, then contains a response to the promised request as described in Section 4.1. Finally, the Push ID can be used in CANCEL_PUSH frames; see Section 7.2.3. Clients use this frame to indicate they do not wish to receive a promised resource. Servers use this frame to indicate they will not be fulfilling a previous promise. Not all requests can be pushed. A server MAY push requests that have the following properties: * cacheable; see Section 9.2.3 of [SEMANTICS] * safe; see Section 9.2.1 of [SEMANTICS] * does not include a request body or trailer section The server MUST include a value in the ":authority" pseudo-header field for which the server is authoritative; see Section 3.3. Clients SHOULD send a CANCEL_PUSH frame upon receipt of a PUSH_PROMISE frame carrying a request that is not cacheable, is not known to be safe, that indicates the presence of a request body, or for which it does not consider the server authoritative. Any corresponding responses MUST NOT be used or cached. Each pushed response is associated with one or more client requests. The push is associated with the request stream on which the PUSH_PROMISE frame was received. The same server push can be associated with additional client requests using a PUSH_PROMISE frame with the same Push ID on multiple request streams. These associations do not affect the operation of the protocol, but MAY be considered by user agents when deciding how to use pushed resources. Bishop Expires 18 June 2021 [Page 21] Internet-Draft HTTP/3 December 2020 Ordering of a PUSH_PROMISE frame in relation to certain parts of the response is important. The server SHOULD send PUSH_PROMISE frames prior to sending HEADERS or DATA frames that reference the promised responses. This reduces the chance that a client requests a resource that will be pushed by the server. Due to reordering, push stream data can arrive before the corresponding PUSH_PROMISE frame. When a client receives a new push stream with an as-yet-unknown Push ID, both the associated client request and the pushed request header fields are unknown. The client can buffer the stream data in expectation of the matching PUSH_PROMISE. The client can use stream flow control (see section 4.1 of [QUIC-TRANSPORT]) to limit the amount of data a server may commit to the pushed stream. Push stream data can also arrive after a client has canceled a push. In this case, the client can abort reading the stream with an error code of H3_REQUEST_CANCELLED. This asks the server not to transfer additional data and indicates that it will be discarded upon receipt. Pushed responses that are cacheable (see Section 3 of [CACHING]) can be stored by the client, if it implements an HTTP cache. Pushed responses are considered successfully validated on the origin server (e.g., if the "no-cache" cache response directive is present; see Section 5.2.2.3 of [CACHING]) at the time the pushed response is received. Pushed responses that are not cacheable MUST NOT be stored by any HTTP cache. They MAY be made available to the application separately. 5. Connection Closure Once established, an HTTP/3 connection can be used for many requests and responses over time until the connection is closed. Connection closure can happen in any of several different ways. 5.1. Idle Connections Each QUIC endpoint declares an idle timeout during the handshake. If the QUIC connection remains idle (no packets received) for longer than this duration, the peer will assume that the connection has been closed. HTTP/3 implementations will need to open a new HTTP/3 connection for new requests if the existing connection has been idle for longer than the idle timeout negotiated during the QUIC handshake, and SHOULD do so if approaching the idle timeout; see Section 10.1 of [QUIC-TRANSPORT]. Bishop Expires 18 June 2021 [Page 22] Internet-Draft HTTP/3 December 2020 HTTP clients are expected to request that the transport keep connections open while there are responses outstanding for requests or server pushes, as described in Section 10.1.2 of [QUIC-TRANSPORT]. If the client is not expecting a response from the server, allowing an idle connection to time out is preferred over expending effort maintaining a connection that might not be needed. A gateway MAY maintain connections in anticipation of need rather than incur the latency cost of connection establishment to servers. Servers SHOULD NOT actively keep connections open. 5.2. Connection Shutdown Even when a connection is not idle, either endpoint can decide to stop using the connection and initiate a graceful connection close. Endpoints initiate the graceful shutdown of an HTTP/3 connection by sending a GOAWAY frame (Section 7.2.6). The GOAWAY frame contains an identifier that indicates to the receiver the range of requests or pushes that were or might be processed in this connection. The server sends a client-initiated bidirectional Stream ID; the client sends a Push ID (Section 4.4). Requests or pushes with the indicated identifier or greater are rejected (Section 4.1.2) by the sender of the GOAWAY. This identifier MAY be zero if no requests or pushes were processed. The information in the GOAWAY frame enables a client and server to agree on which requests or pushes were accepted prior to the shutdown of the HTTP/3 connection. Upon sending a GOAWAY frame, the endpoint SHOULD explicitly cancel (see Section 4.1.2 and Section 7.2.3) any requests or pushes that have identifiers greater than or equal to that indicated, in order to clean up transport state for the affected streams. The endpoint SHOULD continue to do so as more requests or pushes arrive. Endpoints MUST NOT initiate new requests or promise new pushes on the connection after receipt of a GOAWAY frame from the peer. Clients MAY establish a new connection to send additional requests. Some requests or pushes might already be in transit: * Upon receipt of a GOAWAY frame, if the client has already sent requests with a Stream ID greater than or equal to the identifier contained in the GOAWAY frame, those requests will not be processed. Clients can safely retry unprocessed requests on a different HTTP connection. A client that is unable to retry requests loses all requests that are in flight when the server closes the connection. Bishop Expires 18 June 2021 [Page 23] Internet-Draft HTTP/3 December 2020 Requests on Stream IDs less than the Stream ID in a GOAWAY frame from the server might have been processed; their status cannot be known until a response is received, the stream is reset individually, another GOAWAY is received, or the connection terminates. Servers MAY reject individual requests on streams below the indicated ID if these requests were not processed. * If a server receives a GOAWAY frame after having promised pushes with a Push ID greater than or equal to the identifier contained in the GOAWAY frame, those pushes will not be accepted. Servers SHOULD send a GOAWAY frame when the closing of a connection is known in advance, even if the advance notice is small, so that the remote peer can know whether a request has been partially processed or not. For example, if an HTTP client sends a POST at the same time that a server closes a QUIC connection, the client cannot know if the server started to process that POST request if the server does not send a GOAWAY frame to indicate what streams it might have acted on. An endpoint MAY send multiple GOAWAY frames indicating different identifiers, but the identifier in each frame MUST NOT be greater than the identifier in any previous frame, since clients might already have retried unprocessed requests on another HTTP connection. Receiving a GOAWAY containing a larger identifier than previously received MUST be treated as a connection error of type H3_ID_ERROR; see Section 8. An endpoint that is attempting to gracefully shut down a connection can send a GOAWAY frame with a value set to the maximum possible value (2^62-4 for servers, 2^62-1 for clients). This ensures that the peer stops creating new requests or pushes. After allowing time for any in-flight requests or pushes to arrive, the endpoint can send another GOAWAY frame indicating which requests or pushes it might accept before the end of the connection. This ensures that a connection can be cleanly shut down without losing requests. A client has more flexibility in the value it chooses for the Push ID in a GOAWAY that it sends. A value of 2^62 - 1 indicates that the server can continue fulfilling pushes that have already been promised. A smaller value indicates the client will reject pushes with Push IDs greater than or equal to this value. Like the server, the client MAY send subsequent GOAWAY frames so long as the specified Push ID is no greater than any previously sent value. Bishop Expires 18 June 2021 [Page 24] Internet-Draft HTTP/3 December 2020 Even when a GOAWAY indicates that a given request or push will not be processed or accepted upon receipt, the underlying transport resources still exist. The endpoint that initiated these requests can cancel them to clean up transport state. Once all accepted requests and pushes have been processed, the endpoint can permit the connection to become idle, or MAY initiate an immediate closure of the connection. An endpoint that completes a graceful shutdown SHOULD use the H3_NO_ERROR error code when closing the connection. If a client has consumed all available bidirectional stream IDs with requests, the server need not send a GOAWAY frame, since the client is unable to make further requests. 5.3. Immediate Application Closure An HTTP/3 implementation can immediately close the QUIC connection at any time. This results in sending a QUIC CONNECTION_CLOSE frame to the peer indicating that the application layer has terminated the connection. The application error code in this frame indicates to the peer why the connection is being closed. See Section 8 for error codes that can be used when closing a connection in HTTP/3. Before closing the connection, a GOAWAY frame MAY be sent to allow the client to retry some requests. Including the GOAWAY frame in the same packet as the QUIC CONNECTION_CLOSE frame improves the chances of the frame being received by clients. 5.4. Transport Closure For various reasons, the QUIC transport could indicate to the application layer that the connection has terminated. This might be due to an explicit closure by the peer, a transport-level error, or a change in network topology that interrupts connectivity. If a connection terminates without a GOAWAY frame, clients MUST assume that any request that was sent, whether in whole or in part, might have been processed. 6. Stream Mapping and Usage A QUIC stream provides reliable in-order delivery of bytes, but makes no guarantees about order of delivery with regard to bytes on other streams. On the wire, data is framed into QUIC STREAM frames, but this framing is invisible to the HTTP framing layer. The transport layer buffers and orders received QUIC STREAM frames, exposing the data contained within as a reliable byte stream to the application. Bishop Expires 18 June 2021 [Page 25] Internet-Draft HTTP/3 December 2020 Although QUIC permits out-of-order delivery within a stream, HTTP/3 does not make use of this feature. QUIC streams can be either unidirectional, carrying data only from initiator to receiver, or bidirectional. Streams can be initiated by either the client or the server. For more detail on QUIC streams, see Section 2 of [QUIC-TRANSPORT]. When HTTP fields and data are sent over QUIC, the QUIC layer handles most of the stream management. HTTP does not need to do any separate multiplexing when using QUIC - data sent over a QUIC stream always maps to a particular HTTP transaction or to the entire HTTP/3 connection context. 6.1. Bidirectional Streams All client-initiated bidirectional streams are used for HTTP requests and responses. A bidirectional stream ensures that the response can be readily correlated with the request. These streams are referred to as request streams. This means that the client''s first request occurs on QUIC stream 0, with subsequent requests on stream 4, 8, and so on. In order to permit these streams to open, an HTTP/3 server SHOULD configure non- zero minimum values for the number of permitted streams and the initial stream flow control window. So as to not unnecessarily limit parallelism, at least 100 requests SHOULD be permitted at a time. HTTP/3 does not use server-initiated bidirectional streams, though an extension could define a use for these streams. Clients MUST treat receipt of a server-initiated bidirectional stream as a connection error of type H3_STREAM_CREATION_ERROR (Section 8) unless such an extension has been negotiated. 6.2. Unidirectional Streams Unidirectional streams, in either direction, are used for a range of purposes. The purpose is indicated by a stream type, which is sent as a variable-length integer at the start of the stream. The format and structure of data that follows this integer is determined by the stream type. Unidirectional Stream Header { Stream Type (i), } Figure 1: Unidirectional Stream Header Bishop Expires 18 June 2021 [Page 26] Internet-Draft HTTP/3 December 2020 Two stream types are defined in this document: control streams (Section 6.2.1) and push streams (Section 6.2.2). [QPACK] defines two additional stream types. Other stream types can be defined by extensions to HTTP/3; see Section 9 for more details. Some stream types are reserved (Section 6.2.3). The performance of HTTP/3 connections in the early phase of their lifetime is sensitive to the creation and exchange of data on unidirectional streams. Endpoints that excessively restrict the number of streams or the flow control window of these streams will increase the chance that the remote peer reaches the limit early and becomes blocked. In particular, implementations should consider that remote peers may wish to exercise reserved stream behavior (Section 6.2.3) with some of the unidirectional streams they are permitted to use. To avoid blocking, the transport parameters sent by both clients and servers MUST allow the peer to create at least one unidirectional stream for the HTTP control stream plus the number of unidirectional streams required by mandatory extensions (three being the minimum number required for the base HTTP/3 protocol and QPACK), and SHOULD provide at least 1,024 bytes of flow control credit to each stream. Note that an endpoint is not required to grant additional credits to create more unidirectional streams if its peer consumes all the initial credits before creating the critical unidirectional streams. Endpoints SHOULD create the HTTP control stream as well as the unidirectional streams required by mandatory extensions (such as the QPACK encoder and decoder streams) first, and then create additional streams as allowed by their peer. If the stream header indicates a stream type that is not supported by the recipient, the remainder of the stream cannot be consumed as the semantics are unknown. Recipients of unknown stream types MAY abort reading of the stream with an error code of H3_STREAM_CREATION_ERROR or a reserved error code (Section 8.1), but MUST NOT consider such streams to be a connection error of any kind. Implementations MAY send stream types before knowing whether the peer supports them. However, stream types that could modify the state or semantics of existing protocol components, including QPACK or other extensions, MUST NOT be sent until the peer is known to support them. A sender can close or reset a unidirectional stream unless otherwise specified. A receiver MUST tolerate unidirectional streams being closed or reset prior to the reception of the unidirectional stream header. Bishop Expires 18 June 2021 [Page 27] Internet-Draft HTTP/3 December 2020 6.2.1. Control Streams A control stream is indicated by a stream type of 0x00. Data on this stream consists of HTTP/3 frames, as defined in Section 7.2. Each side MUST initiate a single control stream at the beginning of the connection and send its SETTINGS frame as the first frame on this stream. If the first frame of the control stream is any other frame type, this MUST be treated as a connection error of type H3_MISSING_SETTINGS. Only one control stream per peer is permitted; receipt of a second stream claiming to be a control stream MUST be treated as a connection error of type H3_STREAM_CREATION_ERROR. The sender MUST NOT close the control stream, and the receiver MUST NOT request that the sender close the control stream. If either control stream is closed at any point, this MUST be treated as a connection error of type H3_CLOSED_CRITICAL_STREAM. Connection errors are described in Section 8. A pair of unidirectional streams is used rather than a single bidirectional stream. This allows either peer to send data as soon as it is able. Depending on whether 0-RTT is enabled on the QUIC connection, either client or server might be able to send stream data first after the cryptographic handshake completes. 6.2.2. Push Streams Server push is an optional feature introduced in HTTP/2 that allows a server to initiate a response before a request has been made. See Section 4.4 for more details. A push stream is indicated by a stream type of 0x01, followed by the Push ID of the promise that it fulfills, encoded as a variable-length integer. The remaining data on this stream consists of HTTP/3 frames, as defined in Section 7.2, and fulfills a promised server push by zero or more interim HTTP responses followed by a single final HTTP response, as defined in Section 4.1. Server push and Push IDs are described in Section 4.4. Only servers can push; if a server receives a client-initiated push stream, this MUST be treated as a connection error of type H3_STREAM_CREATION_ERROR; see Section 8. Push Stream Header { Stream Type (i) = 0x01, Push ID (i), } Figure 2: Push Stream Header Bishop Expires 18 June 2021 [Page 28] Internet-Draft HTTP/3 December 2020 Each Push ID MUST only be used once in a push stream header. If a push stream header includes a Push ID that was used in another push stream header, the client MUST treat this as a connection error of type H3_ID_ERROR; see Section 8. 6.2.3. Reserved Stream Types Stream types of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown types be ignored. These streams have no semantics, and can be sent when application-layer padding is desired. They MAY also be sent on connections where no data is currently being transferred. Endpoints MUST NOT consider these streams to have any meaning upon receipt. The payload and length of the stream are selected in any manner the sending implementation chooses. When sending a reserved stream type, the implementation MAY either terminate the stream cleanly or reset it. When resetting the stream, either the H3_NO_ERROR error code or a reserved error code (Section 8.1) SHOULD be used. 7. HTTP Framing Layer HTTP frames are carried on QUIC streams, as described in Section 6. HTTP/3 defines three stream types: control stream, request stream, and push stream. This section describes HTTP/3 frame formats and their permitted stream types; see Table 1 for an overview. A comparison between HTTP/2 and HTTP/3 frames is provided in Appendix A.2. Bishop Expires 18 June 2021 [Page 29] Internet-Draft HTTP/3 December 2020 +==============+================+================+========+=========+ | Frame | Control Stream | Request | Push | Section | | | | Stream | Stream | | +==============+================+================+========+=========+ | DATA | No | Yes | Yes | Section | | | | | | 7.2.1 | +--------------+----------------+----------------+--------+---------+ | HEADERS | No | Yes | Yes | Section | | | | | | 7.2.2 | +--------------+----------------+----------------+--------+---------+ | CANCEL_PUSH | Yes | No | No | Section | | | | | | 7.2.3 | +--------------+----------------+----------------+--------+---------+ | SETTINGS | Yes (1) | No | No | Section | | | | | | 7.2.4 | +--------------+----------------+----------------+--------+---------+ | PUSH_PROMISE | No | Yes | No | Section | | | | | | 7.2.5 | +--------------+----------------+----------------+--------+---------+ | GOAWAY | Yes | No | No | Section | | | | | | 7.2.6 | +--------------+----------------+----------------+--------+---------+ | MAX_PUSH_ID | Yes | No | No | Section | | | | | | 7.2.7 | +--------------+----------------+----------------+--------+---------+ | Reserved | Yes | Yes | Yes | Section | | | | | | 7.2.8 | +--------------+----------------+----------------+--------+---------+ Table 1: HTTP/3 Frames and Stream Type Overview Certain frames can only occur as the first frame of a particular stream type; these are indicated in Table 1 with a (1). Specific guidance is provided in the relevant section. Note that, unlike QUIC frames, HTTP/3 frames can span multiple packets. 7.1. Frame Layout All frames have the following format: HTTP/3 Frame Format { Type (i), Length (i), Frame Payload (..), } Bishop Expires 18 June 2021 [Page 30] Internet-Draft HTTP/3 December 2020 Figure 3: HTTP/3 Frame Format A frame includes the following fields: Type: A variable-length integer that identifies the frame type. Length: A variable-length integer that describes the length in bytes of the Frame Payload. Frame Payload: A payload, the semantics of which are determined by the Type field. Each frame''s payload MUST contain exactly the fields identified in its description. A frame payload that contains additional bytes after the identified fields or a frame payload that terminates before the end of the identified fields MUST be treated as a connection error of type H3_FRAME_ERROR; see Section 8. When a stream terminates cleanly, if the last frame on the stream was truncated, this MUST be treated as a connection error of type H3_FRAME_ERROR; see Section 8. Streams that terminate abruptly may be reset at any point in a frame. 7.2. Frame Definitions 7.2.1. DATA DATA frames (type=0x0) convey arbitrary, variable-length sequences of bytes associated with HTTP request or response payload data. DATA frames MUST be associated with an HTTP request or response. If a DATA frame is received on a control stream, the recipient MUST respond with a connection error of type H3_FRAME_UNEXPECTED; see Section 8. DATA Frame { Type (i) = 0x0, Length (i), Data (..), } Figure 4: DATA Frame 7.2.2. HEADERS The HEADERS frame (type=0x1) is used to carry an HTTP field section, encoded using QPACK. See [QPACK] for more details. Bishop Expires 18 June 2021 [Page 31] Internet-Draft HTTP/3 December 2020 HEADERS Frame { Type (i) = 0x1, Length (i), Encoded Field Section (..), } Figure 5: HEADERS Frame HEADERS frames can only be sent on request or push streams. If a HEADERS frame is received on a control stream, the recipient MUST respond with a connection error (Section 8) of type H3_FRAME_UNEXPECTED. 7.2.3. CANCEL_PUSH The CANCEL_PUSH frame (type=0x3) is used to request cancellation of a server push prior to the push stream being received. The CANCEL_PUSH frame identifies a server push by Push ID (see Section 4.4), encoded as a variable-length integer. When a client sends CANCEL_PUSH, it is indicating that it does not wish to receive the promised resource. The server SHOULD abort sending the resource, but the mechanism to do so depends on the state of the corresponding push stream. If the server has not yet created a push stream, it does not create one. If the push stream is open, the server SHOULD abruptly terminate that stream. If the push stream has already ended, the server MAY still abruptly terminate the stream or MAY take no action. A server sends CANCEL_PUSH to indicate that it will not be fulfilling a promise which was previously sent. The client cannot expect the corresponding promise to be fulfilled, unless it has already received and processed the promised response. Regardless of whether a push stream has been opened, a server SHOULD send a CANCEL_PUSH frame when it determines that promise will not be fulfilled. If a stream has already been opened, the server can abort sending on the stream with an error code of H3_REQUEST_CANCELLED. Sending a CANCEL_PUSH frame has no direct effect on the state of existing push streams. A client SHOULD NOT send a CANCEL_PUSH frame when it has already received a corresponding push stream. A push stream could arrive after a client has sent a CANCEL_PUSH frame, because a server might not have processed the CANCEL_PUSH. The client SHOULD abort reading the stream with an error code of H3_REQUEST_CANCELLED. Bishop Expires 18 June 2021 [Page 32] Internet-Draft HTTP/3 December 2020 A CANCEL_PUSH frame is sent on the control stream. Receiving a CANCEL_PUSH frame on a stream other than the control stream MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. CANCEL_PUSH Frame { Type (i) = 0x3, Length (i), Push ID (..), } Figure 6: CANCEL_PUSH Frame The CANCEL_PUSH frame carries a Push ID encoded as a variable-length integer. The Push ID identifies the server push that is being cancelled; see Section 4.4. If a CANCEL_PUSH frame is received that references a Push ID greater than currently allowed on the connection, this MUST be treated as a connection error of type H3_ID_ERROR. If the client receives a CANCEL_PUSH frame, that frame might identify a Push ID that has not yet been mentioned by a PUSH_PROMISE frame due to reordering. If a server receives a CANCEL_PUSH frame for a Push ID that has not yet been mentioned by a PUSH_PROMISE frame, this MUST be treated as a connection error of type H3_ID_ERROR. 7.2.4. SETTINGS The SETTINGS frame (type=0x4) conveys configuration parameters that affect how endpoints communicate, such as preferences and constraints on peer behavior. Individually, a SETTINGS parameter can also be referred to as a "setting"; the identifier and value of each setting parameter can be referred to as a "setting identifier" and a "setting value". SETTINGS frames always apply to an entire HTTP/3 connection, never a single stream. A SETTINGS frame MUST be sent as the first frame of each control stream (see Section 6.2.1) by each peer, and MUST NOT be sent subsequently. If an endpoint receives a second SETTINGS frame on the control stream, the endpoint MUST respond with a connection error of type H3_FRAME_UNEXPECTED. SETTINGS frames MUST NOT be sent on any stream other than the control stream. If an endpoint receives a SETTINGS frame on a different stream, the endpoint MUST respond with a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 33] Internet-Draft HTTP/3 December 2020 SETTINGS parameters are not negotiated; they describe characteristics of the sending peer that can be used by the receiving peer. However, a negotiation can be implied by the use of SETTINGS - each peer uses SETTINGS to advertise a set of supported values. The definition of the setting would describe how each peer combines the two sets to conclude which choice will be used. SETTINGS does not provide a mechanism to identify when the choice takes effect. Different values for the same parameter can be advertised by each peer. For example, a client might be willing to consume a very large response field section, while servers are more cautious about request size. The same setting identifier MUST NOT occur more than once in the SETTINGS frame. A receiver MAY treat the presence of duplicate setting identifiers as a connection error of type H3_SETTINGS_ERROR. The payload of a SETTINGS frame consists of zero or more parameters. Each parameter consists of a setting identifier and a value, both encoded as QUIC variable-length integers. Setting { Identifier (i), Value (i), } SETTINGS Frame { Type (i) = 0x4, Length (i), Setting (..) ..., } Figure 7: SETTINGS Frame An implementation MUST ignore the contents for any SETTINGS identifier it does not understand. 7.2.4.1. Defined SETTINGS Parameters The following settings are defined in HTTP/3: SETTINGS_MAX_FIELD_SECTION_SIZE (0x6): The default value is unlimited. See Section 4.1.1.3 for usage. Bishop Expires 18 June 2021 [Page 34] Internet-Draft HTTP/3 December 2020 Setting identifiers of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown identifiers be ignored. Such settings have no defined meaning. Endpoints SHOULD include at least one such setting in their SETTINGS frame. Endpoints MUST NOT consider such settings to have any meaning upon receipt. Because the setting has no defined meaning, the value of the setting can be any value the implementation selects. Setting identifiers which were used in HTTP/2 where there is no corresponding HTTP/3 setting have also been reserved (Section 11.2.2). These settings MUST NOT be sent, and their receipt MUST be treated as a connection error of type H3_SETTINGS_ERROR. Additional settings can be defined by extensions to HTTP/3; see Section 9 for more details. 7.2.4.2. Initialization An HTTP implementation MUST NOT send frames or requests that would be invalid based on its current understanding of the peer''s settings. All settings begin at an initial value. Each endpoint SHOULD use these initial values to send messages before the peer''s SETTINGS frame has arrived, as packets carrying the settings can be lost or delayed. When the SETTINGS frame arrives, any settings are changed to their new values. This removes the need to wait for the SETTINGS frame before sending messages. Endpoints MUST NOT require any data to be received from the peer prior to sending the SETTINGS frame; settings MUST be sent as soon as the transport is ready to send data. For servers, the initial value of each client setting is the default value. For clients using a 1-RTT QUIC connection, the initial value of each server setting is the default value. 1-RTT keys will always become available prior to the packet containing SETTINGS being processed by QUIC, even if the server sends SETTINGS immediately. Clients SHOULD NOT wait indefinitely for SETTINGS to arrive before sending requests, but SHOULD process received datagrams in order to increase the likelihood of processing SETTINGS before sending the first request. When a 0-RTT QUIC connection is being used, the initial value of each server setting is the value used in the previous session. Clients SHOULD store the settings the server provided in the HTTP/3 Bishop Expires 18 June 2021 [Page 35] Internet-Draft HTTP/3 December 2020 connection where resumption information was provided, but MAY opt not to store settings in certain cases (e.g., if the session ticket is received before the SETTINGS frame). A client MUST comply with stored settings - or default values, if no values are stored - when attempting 0-RTT. Once a server has provided new settings, clients MUST comply with those values. A server can remember the settings that it advertised, or store an integrity-protected copy of the values in the ticket and recover the information when accepting 0-RTT data. A server uses the HTTP/3 settings values in determining whether to accept 0-RTT data. If the server cannot determine that the settings remembered by a client are compatible with its current settings, it MUST NOT accept 0-RTT data. Remembered settings are compatible if a client complying with those settings would not violate the server''s current settings. A server MAY accept 0-RTT and subsequently provide different settings in its SETTINGS frame. If 0-RTT data is accepted by the server, its SETTINGS frame MUST NOT reduce any limits or alter any values that might be violated by the client with its 0-RTT data. The server MUST include all settings that differ from their default values. If a server accepts 0-RTT but then sends settings that are not compatible with the previously specified settings, this MUST be treated as a connection error of type H3_SETTINGS_ERROR. If a server accepts 0-RTT but then sends a SETTINGS frame that omits a setting value that the client understands (apart from reserved setting identifiers) that was previously specified to have a non-default value, this MUST be treated as a connection error of type H3_SETTINGS_ERROR. 7.2.5. PUSH_PROMISE The PUSH_PROMISE frame (type=0x5) is used to carry a promised request header field section from server to client on a request stream, as in HTTP/2. PUSH_PROMISE Frame { Type (i) = 0x5, Length (i), Push ID (i), Encoded Field Section (..), } Figure 8: PUSH_PROMISE Frame The payload consists of: Push ID: A variable-length integer that identifies the server push Bishop Expires 18 June 2021 [Page 36] Internet-Draft HTTP/3 December 2020 operation. A Push ID is used in push stream headers (Section 4.4) and CANCEL_PUSH frames (Section 7.2.3). Encoded Field Section: QPACK-encoded request header fields for the promised response. See [QPACK] for more details. A server MUST NOT use a Push ID that is larger than the client has provided in a MAX_PUSH_ID frame (Section 7.2.7). A client MUST treat receipt of a PUSH_PROMISE frame that contains a larger Push ID than the client has advertised as a connection error of H3_ID_ERROR. A server MAY use the same Push ID in multiple PUSH_PROMISE frames. If so, the decompressed request header sets MUST contain the same fields in the same order, and both the name and the value in each field MUST be exact matches. Clients SHOULD compare the request header sections for resources promised multiple times. If a client receives a Push ID that has already been promised and detects a mismatch, it MUST respond with a connection error of type H3_GENERAL_PROTOCOL_ERROR. If the decompressed field sections match exactly, the client SHOULD associate the pushed content with each stream on which a PUSH_PROMISE frame was received. Allowing duplicate references to the same Push ID is primarily to reduce duplication caused by concurrent requests. A server SHOULD avoid reusing a Push ID over a long period. Clients are likely to consume server push responses and not retain them for reuse over time. Clients that see a PUSH_PROMISE frame that uses a Push ID that they have already consumed and discarded are forced to ignore the promise. If a PUSH_PROMISE frame is received on the control stream, the client MUST respond with a connection error of type H3_FRAME_UNEXPECTED; see Section 8. A client MUST NOT send a PUSH_PROMISE frame. A server MUST treat the receipt of a PUSH_PROMISE frame as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. See Section 4.4 for a description of the overall server push mechanism. Bishop Expires 18 June 2021 [Page 37] Internet-Draft HTTP/3 December 2020 7.2.6. GOAWAY The GOAWAY frame (type=0x7) is used to initiate graceful shutdown of an HTTP/3 connection by either endpoint. GOAWAY allows an endpoint to stop accepting new requests or pushes while still finishing processing of previously received requests and pushes. This enables administrative actions, like server maintenance. GOAWAY by itself does not close a connection. GOAWAY Frame { Type (i) = 0x7, Length (i), Stream ID/Push ID (..), } Figure 9: GOAWAY Frame The GOAWAY frame is always sent on the control stream. In the server to client direction, it carries a QUIC Stream ID for a client- initiated bidirectional stream encoded as a variable-length integer. A client MUST treat receipt of a GOAWAY frame containing a Stream ID of any other type as a connection error of type H3_ID_ERROR. In the client to server direction, the GOAWAY frame carries a Push ID encoded as a variable-length integer. The GOAWAY frame applies to the entire connection, not a specific stream. A client MUST treat a GOAWAY frame on a stream other than the control stream as a connection error of type H3_FRAME_UNEXPECTED; see Section 8. See Section 5.2 for more information on the use of the GOAWAY frame. 7.2.7. MAX_PUSH_ID The MAX_PUSH_ID frame (type=0xd) is used by clients to control the number of server pushes that the server can initiate. This sets the maximum value for a Push ID that the server can use in PUSH_PROMISE and CANCEL_PUSH frames. Consequently, this also limits the number of push streams that the server can initiate in addition to the limit maintained by the QUIC transport. The MAX_PUSH_ID frame is always sent on the control stream. Receipt of a MAX_PUSH_ID frame on any other stream MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 38] Internet-Draft HTTP/3 December 2020 A server MUST NOT send a MAX_PUSH_ID frame. A client MUST treat the receipt of a MAX_PUSH_ID frame as a connection error of type H3_FRAME_UNEXPECTED. The maximum Push ID is unset when an HTTP/3 connection is created, meaning that a server cannot push until it receives a MAX_PUSH_ID frame. A client that wishes to manage the number of promised server pushes can increase the maximum Push ID by sending MAX_PUSH_ID frames as the server fulfills or cancels server pushes. MAX_PUSH_ID Frame { Type (i) = 0xd, Length (i), Push ID (i), } Figure 10: MAX_PUSH_ID Frame The MAX_PUSH_ID frame carries a single variable-length integer that identifies the maximum value for a Push ID that the server can use; see Section 4.4. A MAX_PUSH_ID frame cannot reduce the maximum Push ID; receipt of a MAX_PUSH_ID frame that contains a smaller value than previously received MUST be treated as a connection error of type H3_ID_ERROR. 7.2.8. Reserved Frame Types Frame types of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown types be ignored (Section 9). These frames have no semantics, and MAY be sent on any stream where frames are allowed to be sent. This enables their use for application-layer padding. Endpoints MUST NOT consider these frames to have any meaning upon receipt. The payload and length of the frames are selected in any manner the implementation chooses. Frame types that were used in HTTP/2 where there is no corresponding HTTP/3 frame have also been reserved (Section 11.2.1). These frame types MUST NOT be sent, and their receipt MUST be treated as a connection error of type H3_FRAME_UNEXPECTED. Bishop Expires 18 June 2021 [Page 39] Internet-Draft HTTP/3 December 2020 8. Error Handling When a stream cannot be completed successfully, QUIC allows the application to abruptly terminate (reset) that stream and communicate a reason; see Section 2.4 of [QUIC-TRANSPORT]. This is referred to as a "stream error." An HTTP/3 implementation can decide to close a QUIC stream and communicate the type of error. Wire encodings of error codes are defined in Section 8.1. Stream errors are distinct from HTTP status codes which indicate error conditions. Stream errors indicate that the sender did not transfer or consume the full request or response, while HTTP status codes indicate the result of a request that was successfully received. If an entire connection needs to be terminated, QUIC similarly provides mechanisms to communicate a reason; see Section 5.3 of [QUIC-TRANSPORT]. This is referred to as a "connection error." Similar to stream errors, an HTTP/3 implementation can terminate a QUIC connection and communicate the reason using an error code from Section 8.1. Although the reasons for closing streams and connections are called "errors," these actions do not necessarily indicate a problem with the connection or either implementation. For example, a stream can be reset if the requested resource is no longer needed. An endpoint MAY choose to treat a stream error as a connection error under certain circumstances, closing the entire connection in response to a condition on a single stream. Implementations need to consider the impact on outstanding requests before making this choice. Because new error codes can be defined without negotiation (see Section 9), use of an error code in an unexpected context or receipt of an unknown error code MUST be treated as equivalent to H3_NO_ERROR. However, closing a stream can have other effects regardless of the error code; for example, see Section 4.1. 8.1. HTTP/3 Error Codes The following error codes are defined for use when abruptly terminating streams, aborting reading of streams, or immediately closing HTTP/3 connections. H3_NO_ERROR (0x100): No error. This is used when the connection or stream needs to be closed, but there is no error to signal. H3_GENERAL_PROTOCOL_ERROR (0x101): Peer violated protocol Bishop Expires 18 June 2021 [Page 40] Internet-Draft HTTP/3 December 2020 requirements in a way that does not match a more specific error code, or endpoint declines to use the more specific error code. H3_INTERNAL_ERROR (0x102): An internal error has occurred in the HTTP stack. H3_STREAM_CREATION_ERROR (0x103): The endpoint detected that its peer created a stream that it will not accept. H3_CLOSED_CRITICAL_STREAM (0x104): A stream required by the HTTP/3 connection was closed or reset. H3_FRAME_UNEXPECTED (0x105): A frame was received that was not permitted in the current state or on the current stream. H3_FRAME_ERROR (0x106): A frame that fails to satisfy layout requirements or with an invalid size was received. H3_EXCESSIVE_LOAD (0x107): The endpoint detected that its peer is exhibiting a behavior that might be generating excessive load. H3_ID_ERROR (0x108): A Stream ID or Push ID was used incorrectly, such as exceeding a limit, reducing a limit, or being reused. H3_SETTINGS_ERROR (0x109): An endpoint detected an error in the payload of a SETTINGS frame. H3_MISSING_SETTINGS (0x10a): No SETTINGS frame was received at the beginning of the control stream. H3_REQUEST_REJECTED (0x10b): A server rejected a request without performing any application processing. H3_REQUEST_CANCELLED (0x10c): The request or its response (including pushed response) is cancelled. H3_REQUEST_INCOMPLETE (0x10d): The client''s stream terminated without containing a fully-formed request. H3_MESSAGE_ERROR (0x10e): An HTTP message was malformed and cannot be processed. H3_CONNECT_ERROR (0x10f): The TCP connection established in response to a CONNECT request was reset or abnormally closed. H3_VERSION_FALLBACK (0x110): The requested operation cannot be served over HTTP/3. The peer should retry over HTTP/1.1. Bishop Expires 18 June 2021 [Page 41] Internet-Draft HTTP/3 December 2020 Error codes of the format "0x1f * N + 0x21" for non-negative integer values of N are reserved to exercise the requirement that unknown error codes be treated as equivalent to H3_NO_ERROR (Section 9). Implementations SHOULD select an error code from this space with some probability when they would have sent H3_NO_ERROR. 9. Extensions to HTTP/3 HTTP/3 permits extension of the protocol. Within the limitations described in this section, protocol extensions can be used to provide additional services or alter any aspect of the protocol. Extensions are effective only within the scope of a single HTTP/3 connection. This applies to the protocol elements defined in this document. This does not affect the existing options for extending HTTP, such as defining new methods, status codes, or fields. Extensions are permitted to use new frame types (Section 7.2), new settings (Section 7.2.4.1), new error codes (Section 8), or new unidirectional stream types (Section 6.2). Registries are established for managing these extension points: frame types (Section 11.2.1), settings (Section 11.2.2), error codes (Section 11.2.3), and stream types (Section 11.2.4). Implementations MUST ignore unknown or unsupported values in all extensible protocol elements. Implementations MUST discard frames and unidirectional streams that have unknown or unsupported types. This means that any of these extension points can be safely used by extensions without prior arrangement or negotiation. However, where a known frame type is required to be in a specific location, such as the SETTINGS frame as the first frame of the control stream (see Section 6.2.1), an unknown frame type does not satisfy that requirement and SHOULD be treated as an error. Extensions that could change the semantics of existing protocol components MUST be negotiated before being used. For example, an extension that changes the layout of the HEADERS frame cannot be used until the peer has given a positive signal that this is acceptable. Coordinating when such a revised layout comes into effect could prove complex. As such, allocating new identifiers for new definitions of existing protocol elements is likely to be more effective. Bishop Expires 18 June 2021 [Page 42] Internet-Draft HTTP/3 December 2020 This document does not mandate a specific method for negotiating the use of an extension but notes that a setting (Section 7.2.4.1) could be used for that purpose. If both peers set a value that indicates willingness to use the extension, then the extension can be used. If a setting is used for extension negotiation, the default value MUST be defined in such a fashion that the extension is disabled if the setting is omitted. 10. Security Considerations The security considerations of HTTP/3 should be comparable to those of HTTP/2 with TLS. However, many of the considerations from Section 10 of [HTTP2] apply to [QUIC-TRANSPORT] and are discussed in that document. 10.1. Server Authority HTTP/3 relies on the HTTP definition of authority. The security considerations of establishing authority are discussed in Section 17.1 of [SEMANTICS]. 10.2. Cross-Protocol Attacks The use of ALPN in the TLS and QUIC handshakes establishes the target application protocol before application-layer bytes are processed. This ensures that endpoints have strong assurances that peers are using the same protocol. This does not guarantee protection from all cross-protocol attacks. Section 21.5 of [QUIC-TRANSPORT] describes some ways in which the plaintext of QUIC packets can be used to perform request forgery against endpoints that don''t use authenticated transports. 10.3. Intermediary Encapsulation Attacks The HTTP/3 field encoding allows the expression of names that are not valid field names in the syntax used by HTTP (Section 5.1 of [SEMANTICS]). Requests or responses containing invalid field names MUST be treated as malformed (Section 4.1.3). An intermediary therefore cannot translate an HTTP/3 request or response containing an invalid field name into an HTTP/1.1 message. Bishop Expires 18 June 2021 [Page 43] Internet-Draft HTTP/3 December 2020 Similarly, HTTP/3 can transport field values that are not valid. While most values that can be encoded will not alter field parsing, carriage return (CR, ASCII 0xd), line feed (LF, ASCII 0xa), and the zero character (NUL, ASCII 0x0) might be exploited by an attacker if they are translated verbatim. Any request or response that contains a character not permitted in a field value MUST be treated as malformed (Section 4.1.3). Valid characters are defined by the "field-content" ABNF rule in Section 5.5 of [SEMANTICS]. 10.4. Cacheability of Pushed Responses Pushed responses do not have an explicit request from the client; the request is provided by the server in the PUSH_PROMISE frame. Caching responses that are pushed is possible based on the guidance provided by the origin server in the Cache-Control header field. However, this can cause issues if a single server hosts more than one tenant. For example, a server might offer multiple users each a small portion of its URI space. Where multiple tenants share space on the same server, that server MUST ensure that tenants are not able to push representations of resources that they do not have authority over. Failure to enforce this would allow a tenant to provide a representation that would be served out of cache, overriding the actual representation that the authoritative tenant provides. Clients are required to reject pushed responses for which an origin server is not authoritative; see Section 4.4. 10.5. Denial-of-Service Considerations An HTTP/3 connection can demand a greater commitment of resources to operate than an HTTP/1.1 or HTTP/2 connection. The use of field compression and flow control depend on a commitment of resources for storing a greater amount of state. Settings for these features ensure that memory commitments for these features are strictly bounded. The number of PUSH_PROMISE frames is constrained in a similar fashion. A client that accepts server push SHOULD limit the number of Push IDs it issues at a time. Processing capacity cannot be guarded as effectively as state capacity. Bishop Expires 18 June 2021 [Page 44] Internet-Draft HTTP/3 December 2020 The ability to send undefined protocol elements that the peer is required to ignore can be abused to cause a peer to expend additional processing time. This might be done by setting multiple undefined SETTINGS parameters, unknown frame types, or unknown stream types. Note, however, that some uses are entirely legitimate, such as optional-to-understand extensions and padding to increase resistance to traffic analysis. Compression of field sections also offers some opportunities to waste processing resources; see Section 7 of [QPACK] for more details on potential abuses. All these features - i.e., server push, unknown protocol elements, field compression - have legitimate uses. These features become a burden only when they are used unnecessarily or to excess. An endpoint that does not monitor this behavior exposes itself to a risk of denial-of-service attack. Implementations SHOULD track the use of these features and set limits on their use. An endpoint MAY treat activity that is suspicious as a connection error of type H3_EXCESSIVE_LOAD (Section 8), but false positives will result in disrupting valid connections and requests. 10.5.1. Limits on Field Section Size A large field section (Section 4.1) can cause an implementation to commit a large amount of state. Header fields that are critical for routing can appear toward the end of a header field section, which prevents streaming of the header field section to its ultimate destination. This ordering and other reasons, such as ensuring cache correctness, mean that an endpoint likely needs to buffer the entire header field section. Since there is no hard limit to the size of a field section, some endpoints could be forced to commit a large amount of available memory for header fields. An endpoint can use the SETTINGS_MAX_FIELD_SECTION_SIZE (Section 4.1.1.3) setting to advise peers of limits that might apply on the size of field sections. This setting is only advisory, so endpoints MAY choose to send field sections that exceed this limit and risk having the request or response being treated as malformed. This setting is specific to an HTTP/3 connection, so any request or response could encounter a hop with a lower, unknown limit. An intermediary can attempt to avoid this problem by passing on values presented by different peers, but they are not obligated to do so. Bishop Expires 18 June 2021 [Page 45] Internet-Draft HTTP/3 December 2020 A server that receives a larger field section than it is willing to handle can send an HTTP 431 (Request Header Fields Too Large) status code ([RFC6585]). A client can discard responses that it cannot process. 10.5.2. CONNECT Issues The CONNECT method can be used to create disproportionate load on a proxy, since stream creation is relatively inexpensive when compared to the creation and maintenance of a TCP connection. A proxy might also maintain some resources for a TCP connection beyond the closing of the stream that carries the CONNECT request, since the outgoing TCP connection remains in the TIME_WAIT state. Therefore, a proxy cannot rely on QUIC stream limits alone to control the resources consumed by CONNECT requests. 10.6. Use of Compression Compression can allow an attacker to recover secret data when it is compressed in the same context as data under attacker control. HTTP/3 enables compression of fields (Section 4.1.1); the following concerns also apply to the use of HTTP compressed content-codings; see Section 8.5.1 of [SEMANTICS]. There are demonstrable attacks on compression that exploit the characteristics of the web (e.g., [BREACH]). The attacker induces multiple requests containing varying plaintext, observing the length of the resulting ciphertext in each, which reveals a shorter length when a guess about the secret is correct. Implementations communicating on a secure channel MUST NOT compress content that includes both confidential and attacker-controlled data unless separate compression contexts are used for each source of data. Compression MUST NOT be used if the source of data cannot be reliably determined. Further considerations regarding the compression of fields sections are described in [QPACK]. 10.7. Padding and Traffic Analysis Padding can be used to obscure the exact size of frame content and is provided to mitigate specific attacks within HTTP, for example, attacks where compressed content includes both attacker-controlled plaintext and secret data (e.g., [BREACH]). Bishop Expires 18 June 2021 [Page 46] Internet-Draft HTTP/3 December 2020 Where HTTP/2 employs PADDING frames and Padding fields in other frames to make a connection more resistant to traffic analysis, HTTP/3 can either rely on transport-layer padding or employ the reserved frame and stream types discussed in Section 7.2.8 and Section 6.2.3. These methods of padding produce different results in terms of the granularity of padding, how padding is arranged in relation to the information that is being protected, whether padding is applied in the case of packet loss, and how an implementation might control padding. Reserved stream types can be used to give the appearance of sending traffic even when the connection is idle. Because HTTP traffic often occurs in bursts, apparent traffic can be used to obscure the timing or duration of such bursts, even to the point of appearing to send a constant stream of data. However, as such traffic is still flow controlled by the receiver, a failure to promptly drain such streams and provide additional flow control credit can limit the sender''s ability to send real traffic. To mitigate attacks that rely on compression, disabling or limiting compression might be preferable to padding as a countermeasure. Use of padding can result in less protection than might seem immediately obvious. Redundant padding could even be counterproductive. At best, padding only makes it more difficult for an attacker to infer length information by increasing the number of frames an attacker has to observe. Incorrectly implemented padding schemes can be easily defeated. In particular, randomized padding with a predictable distribution provides very little protection; similarly, padding payloads to a fixed size exposes information as payload sizes cross the fixed-sized boundary, which could be possible if an attacker can control plaintext. 10.8. Frame Parsing Several protocol elements contain nested length elements, typically in the form of frames with an explicit length containing variable- length integers. This could pose a security risk to an incautious implementer. An implementation MUST ensure that the length of a frame exactly matches the length of the fields it contains. 10.9. Early Data The use of 0-RTT with HTTP/3 creates an exposure to replay attack. The anti-replay mitigations in [HTTP-REPLAY] MUST be applied when using HTTP/3 with 0-RTT. Bishop Expires 18 June 2021 [Page 47] Internet-Draft HTTP/3 December 2020 10.10. Migration Certain HTTP implementations use the client address for logging or access-control purposes. Since a QUIC client''s address might change during a connection (and future versions might support simultaneous use of multiple addresses), such implementations will need to either actively retrieve the client''s current address or addresses when they are relevant or explicitly accept that the original address might change. 10.11. Privacy Considerations Several characteristics of HTTP/3 provide an observer an opportunity to correlate actions of a single client or server over time. These include the value of settings, the timing of reactions to stimulus, and the handling of any features that are controlled by settings. As far as these create observable differences in behavior, they could be used as a basis for fingerprinting a specific client. HTTP/3''s preference for using a single QUIC connection allows correlation of a user''s activity on a site. Reusing connections for different origins allows for correlation of activity across those origins. Several features of QUIC solicit immediate responses and can be used by an endpoint to measure latency to their peer; this might have privacy implications in certain scenarios. 11. IANA Considerations This document registers a new ALPN protocol ID (Section 11.1) and creates new registries that manage the assignment of codepoints in HTTP/3. 11.1. Registration of HTTP/3 Identification String This document creates a new registration for the identification of HTTP/3 in the "Application Layer Protocol Negotiation (ALPN) Protocol IDs" registry established in [RFC7301]. The "h3" string identifies HTTP/3: Protocol: HTTP/3 Identification Sequence: 0x68 0x33 ("h3") Specification: This document Bishop Expires 18 June 2021 [Page 48] Internet-Draft HTTP/3 December 2020 11.2. New Registries New registries created in this document operate under the QUIC registration policy documented in Section 22.1 of [QUIC-TRANSPORT]. These registries all include the common set of fields listed in Section 22.1.1 of [QUIC-TRANSPORT]. These registries [SHALL be/are] collected under a "Hypertext Transfer Protocol version 3 (HTTP/3) Parameters" heading. The initial allocations in these registries created in this document are all assigned permanent status and list a change controller of the IETF and a contact of the HTTP working group (ietf-http-wg@w3.org). 11.2.1. Frame Types This document establishes a registry for HTTP/3 frame type codes. The "HTTP/3 Frame Type" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. While this registry is separate from the "HTTP/2 Frame Type" registry defined in [HTTP2], it is preferable that the assignments parallel each other where the code spaces overlap. If an entry is present in only one registry, every effort SHOULD be made to avoid assigning the corresponding value to an unrelated operation. In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following field: Frame Type: A name or label for the frame type. Specifications of frame types MUST include a description of the frame layout and its semantics, including any parts of the frame that are conditionally present. The entries in Table 2 are registered by this document. Bishop Expires 18 June 2021 [Page 49] Internet-Draft HTTP/3 December 2020 +==============+=======+===============+ | Frame Type | Value | Specification | +==============+=======+===============+ | DATA | 0x0 | Section 7.2.1 | +--------------+-------+---------------+ | HEADERS | 0x1 | Section 7.2.2 | +--------------+-------+---------------+ | Reserved | 0x2 | N/A | +--------------+-------+---------------+ | CANCEL_PUSH | 0x3 | Section 7.2.3 | +--------------+-------+---------------+ | SETTINGS | 0x4 | Section 7.2.4 | +--------------+-------+---------------+ | PUSH_PROMISE | 0x5 | Section 7.2.5 | +--------------+-------+---------------+ | Reserved | 0x6 | N/A | +--------------+-------+---------------+ | GOAWAY | 0x7 | Section 7.2.6 | +--------------+-------+---------------+ | Reserved | 0x8 | N/A | +--------------+-------+---------------+ | Reserved | 0x9 | N/A | +--------------+-------+---------------+ | MAX_PUSH_ID | 0xd | Section 7.2.7 | +--------------+-------+---------------+ Table 2: Initial HTTP/3 Frame Types Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 11.2.2. Settings Parameters This document establishes a registry for HTTP/3 settings. The "HTTP/3 Settings" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. Bishop Expires 18 June 2021 [Page 50] Internet-Draft HTTP/3 December 2020 While this registry is separate from the "HTTP/2 Settings" registry defined in [HTTP2], it is preferable that the assignments parallel each other. If an entry is present in only one registry, every effort SHOULD be made to avoid assigning the corresponding value to an unrelated operation. In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following fields: Setting Name: A symbolic name for the setting. Specifying a setting name is optional. Default: The value of the setting unless otherwise indicated. A default SHOULD be the most restrictive possible value. The entries in Table 3 are registered by this document. +========================+=======+=================+===========+ | Setting Name | Value | Specification | Default | +========================+=======+=================+===========+ | Reserved | 0x2 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x3 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x4 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | Reserved | 0x5 | N/A | N/A | +------------------------+-------+-----------------+-----------+ | MAX_FIELD_SECTION_SIZE | 0x6 | Section 7.2.4.1 | Unlimited | +------------------------+-------+-----------------+-----------+ Table 3: Initial HTTP/3 Settings Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 11.2.3. Error Codes This document establishes a registry for HTTP/3 error codes. The "HTTP/3 Error Code" registry manages a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. Bishop Expires 18 June 2021 [Page 51] Internet-Draft HTTP/3 December 2020 Registrations for error codes are required to include a description of the error code. An expert reviewer is advised to examine new registrations for possible duplication with existing error codes. Use of existing registrations is to be encouraged, but not mandated. Use of values that are registered in the "HTTP/2 Error Code" registry is discouraged. In addition to common fields as described in Section 11.2, this registry includes two additional fields. Permanent registrations in this registry MUST include the following field: Name: A name for the error code. Description: A brief description of the error code semantics. The entries in Table 4 are registered by this document. These error codes were selected from the range that operates on a Specification Required policy to avoid collisions with HTTP/2 error codes. +===========================+========+==============+===============+ | Name | Value | Description | Specification | +===========================+========+==============+===============+ | H3_NO_ERROR | 0x0100 | No error | Section 8.1 | +---------------------------+--------+--------------+---------------+ | H3_GENERAL_PROTOCOL_ERROR | 0x0101 | General | Section 8.1 | | | | protocol | | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_INTERNAL_ERROR | 0x0102 | Internal | Section 8.1 | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_STREAM_CREATION_ERROR | 0x0103 | Stream | Section 8.1 | | | | creation | | | | | error | | +---------------------------+--------+--------------+---------------+ | H3_CLOSED_CRITICAL_STREAM | 0x0104 | Critical | Section 8.1 | | | | stream was | | | | | closed | | +---------------------------+--------+--------------+---------------+ | H3_FRAME_UNEXPECTED | 0x0105 | Frame not | Section 8.1 | | | | permitted | | | | | in the | | | | | current | | | | | state | | +---------------------------+--------+--------------+---------------+ | H3_FRAME_ERROR | 0x0106 | Frame | Section 8.1 | | | | violated | | | | | layout or | | Bishop Expires 18 June 2021 [Page 52] Internet-Draft HTTP/3 December 2020 | | | size rules | | +---------------------------+--------+--------------+---------------+ | H3_EXCESSIVE_LOAD | 0x0107 | Peer | Section 8.1 | | | | generating | | | | | excessive | | | | | load | | +---------------------------+--------+--------------+---------------+ | H3_ID_ERROR | 0x0108 | An | Section 8.1 | | | | identifier | | | | | was used | | | | | incorrectly | | +---------------------------+--------+--------------+---------------+ | H3_SETTINGS_ERROR | 0x0109 | SETTINGS | Section 8.1 | | | | frame | | | | | contained | | | | | invalid | | | | | values | | +---------------------------+--------+--------------+---------------+ | H3_MISSING_SETTINGS | 0x010a | No SETTINGS | Section 8.1 | | | | frame | | | | | received | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_REJECTED | 0x010b | Request not | Section 8.1 | | | | processed | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_CANCELLED | 0x010c | Data no | Section 8.1 | | | | longer | | | | | needed | | +---------------------------+--------+--------------+---------------+ | H3_REQUEST_INCOMPLETE | 0x010d | Stream | Section 8.1 | | | | terminated | | | | | early | | +---------------------------+--------+--------------+---------------+ | H3_MESSAGE_ERROR | 0x010e | Malformed | Section 8.1 | | | | message | | +---------------------------+--------+--------------+---------------+ | H3_CONNECT_ERROR | 0x010f | TCP reset | Section 8.1 | | | | or error on | | | | | CONNECT | | | | | request | | +---------------------------+--------+--------------+---------------+ | H3_VERSION_FALLBACK | 0x0110 | Retry over | Section 8.1 | | | | HTTP/1.1 | | +---------------------------+--------+--------------+---------------+ Table 4: Initial HTTP/3 Error Codes Bishop Expires 18 June 2021 [Page 53] Internet-Draft HTTP/3 December 2020 Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 11.2.4. Stream Types This document establishes a registry for HTTP/3 unidirectional stream types. The "HTTP/3 Stream Type" registry governs a 62-bit space. This registry follows the QUIC registry policy; see Section 11.2. Permanent registrations in this registry are assigned using the Specification Required policy ([RFC8126]), except for values between 0x00 and 0x3f (in hexadecimal; inclusive), which are assigned using Standards Action or IESG Approval as defined in Section 4.9 and 4.10 of [RFC8126]. In addition to common fields as described in Section 11.2, permanent registrations in this registry MUST include the following fields: Stream Type: A name or label for the stream type. Sender: Which endpoint on an HTTP/3 connection may initiate a stream of this type. Values are "Client", "Server", or "Both". Specifications for permanent registrations MUST include a description of the stream type, including the layout and semantics of the stream contents. The entries in the following table are registered by this document. +================+=======+===============+========+ | Stream Type | Value | Specification | Sender | +================+=======+===============+========+ | Control Stream | 0x00 | Section 6.2.1 | Both | +----------------+-------+---------------+--------+ | Push Stream | 0x01 | Section 4.4 | Server | +----------------+-------+---------------+--------+ Table 5 Each code of the format "0x1f * N + 0x21" for non-negative integer values of N (that is, 0x21, 0x40, ..., through 0x3ffffffffffffffe) MUST NOT be assigned by IANA and MUST NOT appear in the listing of assigned values. 12. References 12.1. Normative References Bishop Expires 18 June 2021 [Page 54] Internet-Draft HTTP/3 December 2020 [ALTSVC] Nottingham, M., McManus, P., and J. Reschke, "HTTP Alternative Services", RFC 7838, DOI 10.17487/RFC7838, April 2016, <https://www.rfc-editor.org/info/rfc7838>. [CACHING] Fielding, R., Nottingham, M., and J. Reschke, "HTTP Caching", Work in Progress, Internet-Draft, draft-ietf- httpbis-cache-13, 14 December 2020, <http://www.ietf.org/ internet-drafts/draft-ietf-httpbis-cache-13.txt>. [HTTP-REPLAY] Thomson, M., Nottingham, M., and W. Tarreau, "Using Early Data in HTTP", RFC 8470, DOI 10.17487/RFC8470, September 2018, <https://www.rfc-editor.org/info/rfc8470>. [QPACK] Krasic, C., Bishop, M., and A. Frindell, Ed., "QPACK: Header Compression for HTTP over QUIC", Work in Progress, Internet-Draft, draft-ietf-quic-qpack-20, 15 December 2020, <https://tools.ietf.org/html/draft-ietf-quic-qpack-20>. [QUIC-TRANSPORT] Iyengar, J., Ed. and M. Thomson, Ed., "QUIC: A UDP-Based Multiplexed and Secure Transport", Work in Progress, Internet-Draft, draft-ietf-quic-transport-34, 15 December 2020, <https://tools.ietf.org/html/draft-ietf-quic- transport-34>. [RFC0793] Postel, J., "Transmission Control Protocol", STD 7, RFC 793, DOI 10.17487/RFC0793, September 1981, <https://www.rfc-editor.org/info/rfc793>. [RFC2119] Bradner, S., "Key words for use in RFCs to Indicate Requirement Levels", BCP 14, RFC 2119, DOI 10.17487/RFC2119, March 1997, <https://www.rfc-editor.org/info/rfc2119>. [RFC6066] Eastlake 3rd, D., "Transport Layer Security (TLS) Extensions: Extension Definitions", RFC 6066, DOI 10.17487/RFC6066, January 2011, <https://www.rfc-editor.org/info/rfc6066>. [RFC6125] Saint-Andre, P. and J. Hodges, "Representation and Verification of Domain-Based Application Service Identity within Internet Public Key Infrastructure Using X.509 (PKIX) Certificates in the Context of Transport Layer Security (TLS)", RFC 6125, DOI 10.17487/RFC6125, March 2011, <https://www.rfc-editor.org/info/rfc6125>. Bishop Expires 18 June 2021 [Page 55] Internet-Draft HTTP/3 December 2020 [RFC6265] Barth, A., "HTTP State Management Mechanism", RFC 6265, DOI 10.17487/RFC6265, April 2011, <https://www.rfc-editor.org/info/rfc6265>. [RFC7301] Friedl, S., Popov, A., Langley, A., and E. Stephan, "Transport Layer Security (TLS) Application-Layer Protocol Negotiation Extension", RFC 7301, DOI 10.17487/RFC7301, July 2014, <https://www.rfc-editor.org/info/rfc7301>. [RFC8126] Cotton, M., Leiba, B., and T. Narten, "Guidelines for Writing an IANA Considerations Section in RFCs", BCP 26, RFC 8126, DOI 10.17487/RFC8126, June 2017, <https://www.rfc-editor.org/info/rfc8126>. [RFC8174] Leiba, B., "Ambiguity of Uppercase vs Lowercase in RFC 2119 Key Words", BCP 14, RFC 8174, DOI 10.17487/RFC8174, May 2017, <https://www.rfc-editor.org/info/rfc8174>. [SEMANTICS] Fielding, R., Nottingham, M., and J. Reschke, "HTTP Semantics", Work in Progress, Internet-Draft, draft-ietf- httpbis-semantics-13, 14 December 2020, <http://www.ietf.org/internet-drafts/draft-ietf-httpbis- semantics-13.txt>. [URI] Berners-Lee, T., Fielding, R., and L. Masinter, "Uniform Resource Identifier (URI): Generic Syntax", STD 66, RFC 3986, DOI 10.17487/RFC3986, January 2005, <https://www.rfc-editor.org/info/rfc3986>. 12.2. Informative References [BREACH] Gluck, Y., Harris, N., and A. Prado, "BREACH: Reviving the CRIME Attack", July 2013, <http://breachattack.com/resources/ BREACH%20-%20SSL,%20gone%20in%2030%20seconds.pdf>. [HPACK] Peon, R. and H. Ruellan, "HPACK: Header Compression for HTTP/2", RFC 7541, DOI 10.17487/RFC7541, May 2015, <https://www.rfc-editor.org/info/rfc7541>. [HTTP11] Fielding, R., Nottingham, M., and J. Reschke, "HTTP/1.1", Work in Progress, Internet-Draft, draft-ietf-httpbis- messaging-13, 14 December 2020, <http://www.ietf.org/ internet-drafts/draft-ietf-httpbis-messaging-13.txt>. Bishop Expires 18 June 2021 [Page 56] Internet-Draft HTTP/3 December 2020 [HTTP2] Belshe, M., Peon, R., and M. Thomson, Ed., "Hypertext Transfer Protocol Version 2 (HTTP/2)", RFC 7540, DOI 10.17487/RFC7540, May 2015, <https://www.rfc-editor.org/info/rfc7540>. [RFC6585] Nottingham, M. and R. Fielding, "Additional HTTP Status Codes", RFC 6585, DOI 10.17487/RFC6585, April 2012, <https://www.rfc-editor.org/info/rfc6585>. [RFC8164] Nottingham, M. and M. Thomson, "Opportunistic Security for HTTP/2", RFC 8164, DOI 10.17487/RFC8164, May 2017, <https://www.rfc-editor.org/info/rfc8164>. [TFO] Cheng, Y., Chu, J., Radhakrishnan, S., and A. Jain, "TCP Fast Open", RFC 7413, DOI 10.17487/RFC7413, December 2014, <https://www.rfc-editor.org/info/rfc7413>. [TLS13] Rescorla, E., "The Transport Layer Security (TLS) Protocol Version 1.3", RFC 8446, DOI 10.17487/RFC8446, August 2018, <https://www.rfc-editor.org/info/rfc8446>. Appendix A. Considerations for Transitioning from HTTP/2 HTTP/3 is strongly informed by HTTP/2, and bears many similarities. This section describes the approach taken to design HTTP/3, points out important differences from HTTP/2, and describes how to map HTTP/2 extensions into HTTP/3. HTTP/3 begins from the premise that similarity to HTTP/2 is preferable, but not a hard requirement. HTTP/3 departs from HTTP/2 where QUIC differs from TCP, either to take advantage of QUIC features (like streams) or to accommodate important shortcomings (such as a lack of total ordering). These differences make HTTP/3 similar to HTTP/2 in key aspects, such as the relationship of requests and responses to streams. However, the details of the HTTP/3 design are substantially different from HTTP/2. These departures are noted in this section. A.1. Streams HTTP/3 permits use of a larger number of streams (2^62-1) than HTTP/2. The same considerations about exhaustion of stream identifier space apply, though the space is significantly larger such that it is likely that other limits in QUIC are reached first, such as the limit on the connection flow control window. Bishop Expires 18 June 2021 [Page 57] Internet-Draft HTTP/3 December 2020 In contrast to HTTP/2, stream concurrency in HTTP/3 is managed by QUIC. QUIC considers a stream closed when all data has been received and sent data has been acknowledged by the peer. HTTP/2 considers a stream closed when the frame containing the END_STREAM bit has been committed to the transport. As a result, the stream for an equivalent exchange could remain "active" for a longer period of time. HTTP/3 servers might choose to permit a larger number of concurrent client-initiated bidirectional streams to achieve equivalent concurrency to HTTP/2, depending on the expected usage patterns. Due to the presence of other unidirectional stream types, HTTP/3 does not rely exclusively on the number of concurrent unidirectional streams to control the number of concurrent in-flight pushes. Instead, HTTP/3 clients use the MAX_PUSH_ID frame to control the number of pushes received from an HTTP/3 server. A.2. HTTP Frame Types Many framing concepts from HTTP/2 can be elided on QUIC, because the transport deals with them. Because frames are already on a stream, they can omit the stream number. Because frames do not block multiplexing (QUIC''s multiplexing occurs below this layer), the support for variable-maximum-length packets can be removed. Because stream termination is handled by QUIC, an END_STREAM flag is not required. This permits the removal of the Flags field from the generic frame layout. Frame payloads are largely drawn from [HTTP2]. However, QUIC includes many features (e.g., flow control) that are also present in HTTP/2. In these cases, the HTTP mapping does not re-implement them. As a result, several HTTP/2 frame types are not required in HTTP/3. Where an HTTP/2-defined frame is no longer used, the frame ID has been reserved in order to maximize portability between HTTP/2 and HTTP/3 implementations. However, even equivalent frames between the two mappings are not identical. Many of the differences arise from the fact that HTTP/2 provides an absolute ordering between frames across all streams, while QUIC provides this guarantee on each stream only. As a result, if a frame type makes assumptions that frames from different streams will still be received in the order sent, HTTP/3 will break them. Some examples of feature adaptations are described below, as well as general guidance to extension frame implementors converting an HTTP/2 extension to HTTP/3. Bishop Expires 18 June 2021 [Page 58] Internet-Draft HTTP/3 December 2020 A.2.1. Prioritization Differences HTTP/2 specifies priority assignments in PRIORITY frames and (optionally) in HEADERS frames. HTTP/3 does not provide a means of signaling priority. Note that while there is no explicit signaling for priority, this does not mean that prioritization is not important for achieving good performance. A.2.2. Field Compression Differences HPACK was designed with the assumption of in-order delivery. A sequence of encoded field sections must arrive (and be decoded) at an endpoint in the same order in which they were encoded. This ensures that the dynamic state at the two endpoints remains in sync. Because this total ordering is not provided by QUIC, HTTP/3 uses a modified version of HPACK, called QPACK. QPACK uses a single unidirectional stream to make all modifications to the dynamic table, ensuring a total order of updates. All frames that contain encoded fields merely reference the table state at a given time without modifying it. [QPACK] provides additional details. A.2.3. Flow Control Differences HTTP/2 specifies a stream flow control mechanism. Although all HTTP/2 frames are delivered on streams, only the DATA frame payload is subject to flow control. QUIC provides flow control for stream data and all HTTP/3 frame types defined in this document are sent on streams. Therefore, all frame headers and payload are subject to flow control. A.2.4. Guidance for New Frame Type Definitions Frame type definitions in HTTP/3 often use the QUIC variable-length integer encoding. In particular, Stream IDs use this encoding, which allows for a larger range of possible values than the encoding used in HTTP/2. Some frames in HTTP/3 use an identifier rather than a Stream ID (e.g., Push IDs). Redefinition of the encoding of extension frame types might be necessary if the encoding includes a Stream ID. Because the Flags field is not present in generic HTTP/3 frames, those frames that depend on the presence of flags need to allocate space for flags as part of their frame payload. Bishop Expires 18 June 2021 [Page 59] Internet-Draft HTTP/3 December 2020 Other than these issues, frame type HTTP/2 extensions are typically portable to QUIC simply by replacing Stream 0 in HTTP/2 with a control stream in HTTP/3. HTTP/3 extensions will not assume ordering, but would not be harmed by ordering, and would be portable to HTTP/2 in the same manner. A.2.5. Mapping Between HTTP/2 and HTTP/3 Frame Types DATA (0x0): Padding is not defined in HTTP/3 frames. See Section 7.2.1. HEADERS (0x1): The PRIORITY region of HEADERS is not defined in HTTP/3 frames. Padding is not defined in HTTP/3 frames. See Section 7.2.2. PRIORITY (0x2): As described in Appendix A.2.1, HTTP/3 does not provide a means of signaling priority. RST_STREAM (0x3): RST_STREAM frames do not exist in HTTP/3, since QUIC provides stream lifecycle management. The same code point is used for the CANCEL_PUSH frame (Section 7.2.3). SETTINGS (0x4): SETTINGS frames are sent only at the beginning of the connection. See Section 7.2.4 and Appendix A.3. PUSH_PROMISE (0x5): The PUSH_PROMISE frame does not reference a stream; instead the push stream references the PUSH_PROMISE frame using a Push ID. See Section 7.2.5. PING (0x6): PING frames do not exist in HTTP/3, as QUIC provides equivalent functionality. GOAWAY (0x7): GOAWAY does not contain an error code. In the client to server direction, it carries a Push ID instead of a server initiated stream ID. See Section 7.2.6. WINDOW_UPDATE (0x8): WINDOW_UPDATE frames do not exist in HTTP/3, since QUIC provides flow control. CONTINUATION (0x9): CONTINUATION frames do not exist in HTTP/3; instead, larger HEADERS/PUSH_PROMISE frames than HTTP/2 are permitted. Bishop Expires 18 June 2021 [Page 60] Internet-Draft HTTP/3 December 2020 Frame types defined by extensions to HTTP/2 need to be separately registered for HTTP/3 if still applicable. The IDs of frames defined in [HTTP2] have been reserved for simplicity. Note that the frame type space in HTTP/3 is substantially larger (62 bits versus 8 bits), so many HTTP/3 frame types have no equivalent HTTP/2 code points. See Section 11.2.1. A.3. HTTP/2 SETTINGS Parameters An important difference from HTTP/2 is that settings are sent once, as the first frame of the control stream, and thereafter cannot change. This eliminates many corner cases around synchronization of changes. Some transport-level options that HTTP/2 specifies via the SETTINGS frame are superseded by QUIC transport parameters in HTTP/3. The HTTP-level options that are retained in HTTP/3 have the same value as in HTTP/2. The superseded settings are reserved, and their receipt is an error. See Section 7.2.4.1 for discussion of both the retained and reserved values. Below is a listing of how each HTTP/2 SETTINGS parameter is mapped: SETTINGS_HEADER_TABLE_SIZE: See [QPACK]. SETTINGS_ENABLE_PUSH: This is removed in favor of the MAX_PUSH_ID frame, which provides a more granular control over server push. Specifying a setting with the identifier 0x2 (corresponding to the SETTINGS_ENABLE_PUSH parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_MAX_CONCURRENT_STREAMS: QUIC controls the largest open Stream ID as part of its flow control logic. Specifying a setting with the identifier 0x3 (corresponding to the SETTINGS_MAX_CONCURRENT_STREAMS parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_INITIAL_WINDOW_SIZE: QUIC requires both stream and connection flow control window sizes to be specified in the initial transport handshake. Specifying a setting with the identifier 0x4 (corresponding to the SETTINGS_INITIAL_WINDOW_SIZE parameter) in the HTTP/3 SETTINGS frame is an error. SETTINGS_MAX_FRAME_SIZE: This setting has no equivalent in HTTP/3. Specifying a setting with the identifier 0x5 (corresponding to the SETTINGS_MAX_FRAME_SIZE parameter) in the HTTP/3 SETTINGS frame is an error. Bishop Expires 18 June 2021 [Page 61] Internet-Draft HTTP/3 December 2020 SETTINGS_MAX_HEADER_LIST_SIZE: This setting identifier has been renamed SETTINGS_MAX_FIELD_SECTION_SIZE. In HTTP/3, setting values are variable-length integers (6, 14, 30, or 62 bits long) rather than fixed-length 32-bit fields as in HTTP/2. This will often produce a shorter encoding, but can produce a longer encoding for settings that use the full 32-bit space. Settings ported from HTTP/2 might choose to redefine their value to limit it to 30 bits for more efficient encoding, or to make use of the 62-bit space if more than 30 bits are required. Settings need to be defined separately for HTTP/2 and HTTP/3. The IDs of settings defined in [HTTP2] have been reserved for simplicity. Note that the settings identifier space in HTTP/3 is substantially larger (62 bits versus 16 bits), so many HTTP/3 settings have no equivalent HTTP/2 code point. See Section 11.2.2. As QUIC streams might arrive out of order, endpoints are advised not to wait for the peers'' settings to arrive before responding to other streams. See Section 7.2.4.2. A.4. HTTP/2 Error Codes QUIC has the same concepts of "stream" and "connection" errors that HTTP/2 provides. However, the differences between HTTP/2 and HTTP/3 mean that error codes are not directly portable between versions. The HTTP/2 error codes defined in Section 7 of [HTTP2] logically map to the HTTP/3 error codes as follows: NO_ERROR (0x0): H3_NO_ERROR in Section 8.1. PROTOCOL_ERROR (0x1): This is mapped to H3_GENERAL_PROTOCOL_ERROR except in cases where more specific error codes have been defined. Such cases include H3_FRAME_UNEXPECTED, H3_MESSAGE_ERROR, and H3_CLOSED_CRITICAL_STREAM defined in Section 8.1. INTERNAL_ERROR (0x2): H3_INTERNAL_ERROR in Section 8.1. FLOW_CONTROL_ERROR (0x3): Not applicable, since QUIC handles flow control. SETTINGS_TIMEOUT (0x4): Not applicable, since no acknowledgement of SETTINGS is defined. STREAM_CLOSED (0x5): Not applicable, since QUIC handles stream management. Bishop Expires 18 June 2021 [Page 62] Internet-Draft HTTP/3 December 2020 FRAME_SIZE_ERROR (0x6): H3_FRAME_ERROR error code defined in Section 8.1. REFUSED_STREAM (0x7): H3_REQUEST_REJECTED (in Section 8.1) is used to indicate that a request was not processed. Otherwise, not applicable because QUIC handles stream management. CANCEL (0x8): H3_REQUEST_CANCELLED in Section 8.1. COMPRESSION_ERROR (0x9): Multiple error codes are defined in [QPACK]. CONNECT_ERROR (0xa): H3_CONNECT_ERROR in Section 8.1. ENHANCE_YOUR_CALM (0xb): H3_EXCESSIVE_LOAD in Section 8.1. INADEQUATE_SECURITY (0xc): Not applicable, since QUIC is assumed to provide sufficient security on all connections. HTTP_1_1_REQUIRED (0xd): H3_VERSION_FALLBACK in Section 8.1. Error codes need to be defined for HTTP/2 and HTTP/3 separately. See Section 11.2.3. A.4.1. Mapping Between HTTP/2 and HTTP/3 Errors An intermediary that converts between HTTP/2 and HTTP/3 may encounter error conditions from either upstream. It is useful to communicate the occurrence of error to the downstream but error codes largely reflect connection-local problems that generally do not make sense to propagate. An intermediary that encounters an error from an upstream origin can indicate this by sending an HTTP status code such as 502, which is suitable for a broad class of errors. There are some rare cases where it is beneficial to propagate the error by mapping it to the closest matching error type to the receiver. For example, an intermediary that receives an HTTP/2 stream error of type REFUSED_STREAM from the origin has a clear signal that the request was not processed and that the request is safe to retry. Propagating this error condition to the client as an HTTP/3 stream error of type H3_REQUEST_REJECTED allows the client to take the action it deems most appropriate. In the reverse direction, the intermediary might deem it beneficial to pass on client request cancellations that are indicated by terminating a stream with H3_REQUEST_CANCELLED; see Section 4.1.2. Bishop Expires 18 June 2021 [Page 63] Internet-Draft HTTP/3 December 2020 Conversion between errors is described in the logical mapping. The error codes are defined in non-overlapping spaces in order to protect against accidental conversion that could result in the use of inappropriate or unknown error codes for the target version. An intermediary is permitted to promote stream errors to connection errors but they should be aware of the cost to the HTTP/3 connection for what might be a temporary or intermittent error. Appendix B. Change Log *RFC Editor''s Note:* Please remove this section prior to publication of a final version of this document. B.1. Since draft-ietf-quic-http-32 * Removed draft version guidance; added final version string * Added H3_MESSAGE_ERROR for malformed messages B.2. Since draft-ietf-quic-http-31 Editorial changes only. B.3. Since draft-ietf-quic-http-30 Editorial changes only. B.4. Since draft-ietf-quic-http-29 * Require a connection error if a reserved frame type that corresponds to a frame in HTTP/2 is received (#3991, #3993) * Require a connection error if a reserved setting that corresponds to a setting in HTTP/2 is received (#3954, #3955) B.5. Since draft-ietf-quic-http-28 * CANCEL_PUSH is recommended even when the stream is reset (#3698, #3700) * Use H3_ID_ERROR when GOAWAY contains a larger identifier (#3631, #3634) B.6. Since draft-ietf-quic-http-27 * Updated text to refer to latest HTTP revisions Bishop Expires 18 June 2021 [Page 64] Internet-Draft HTTP/3 December 2020 * Use the HTTP definition of authority for establishing and coalescing connections (#253, #2223, #3558) * Define use of GOAWAY from both endpoints (#2632, #3129) * Require either :authority or Host if the URI scheme has a mandatory authority component (#3408, #3475) B.7. Since draft-ietf-quic-http-26 * No changes B.8. Since draft-ietf-quic-http-25 * Require QUICv1 for HTTP/3 (#3117, #3323) * Remove DUPLICATE_PUSH and allow duplicate PUSH_PROMISE (#3275, #3309) * Clarify the definition of "malformed" (#3352, #3345) B.9. Since draft-ietf-quic-http-24 * Removed H3_EARLY_RESPONSE error code; H3_NO_ERROR is recommended instead (#3130,#3208) * Unknown error codes are equivalent to H3_NO_ERROR (#3276,#3331) * Some error codes are reserved for greasing (#3325,#3360) B.10. Since draft-ietf-quic-http-23 * Removed "quic" Alt-Svc parameter (#3061,#3118) * Clients need not persist unknown settings for use in 0-RTT (#3110,#3113) * Clarify error cases around CANCEL_PUSH (#2819,#3083) B.11. Since draft-ietf-quic-http-22 * Removed priority signaling (#2922,#2924) * Further changes to error codes (#2662,#2551): - Error codes renumbered Bishop Expires 18 June 2021 [Page 65] Internet-Draft HTTP/3 December 2020 - HTTP_MALFORMED_FRAME replaced by HTTP_FRAME_ERROR, HTTP_ID_ERROR, and others * Clarify how unknown frame types interact with required frame sequence (#2867,#2858) * Describe interactions with the transport in terms of defined interface terms (#2857,#2805) * Require the use of the "http-opportunistic" resource (RFC 8164) when scheme is "http" (#2439,#2973) * Settings identifiers cannot be duplicated (#2979) * Changes to SETTINGS frames in 0-RTT (#2972,#2790,#2945): - Servers must send all settings with non-default values in their SETTINGS frame, even when resuming - If a client doesn''t have settings associated with a 0-RTT ticket, it uses the defaults - Servers can''t accept early data if they cannot recover the settings the client will have remembered * Clarify that Upgrade and the 101 status code are prohibited (#2898,#2889) * Clarify that frame types reserved for greasing can occur on any stream, but frame types reserved due to HTTP/2 correspondence are prohibited (#2997,#2692,#2693) * Unknown error codes cannot be treated as errors (#2998,#2816) B.12. Since draft-ietf-quic-http-21 No changes B.13. Since draft-ietf-quic-http-20 * Prohibit closing the control stream (#2509, #2666) * Change default priority to use an orphan node (#2502, #2690) * Exclusive priorities are restored (#2754, #2781) * Restrict use of frames when using CONNECT (#2229, #2702) Bishop Expires 18 June 2021 [Page 66] Internet-Draft HTTP/3 December 2020 * Close and maybe reset streams if a connection error occurs for CONNECT (#2228, #2703) * Encourage provision of sufficient unidirectional streams for QPACK (#2100, #2529, #2762) * Allow extensions to use server-initiated bidirectional streams (#2711, #2773) * Clarify use of maximum header list size setting (#2516, #2774) * Extensive changes to error codes and conditions of their sending - Require connection errors for more error conditions (#2511, #2510) - Updated the error codes for illegal GOAWAY frames (#2714, #2707) - Specified error code for HEADERS on control stream (#2708) - Specified error code for servers receiving PUSH_PROMISE (#2709) - Specified error code for receiving DATA before HEADERS (#2715) - Describe malformed messages and their handling (#2410, #2764) - Remove HTTP_PUSH_ALREADY_IN_CACHE error (#2812, #2813) - Refactor Push ID related errors (#2818, #2820) - Rationalize HTTP/3 stream creation errors (#2821, #2822) B.14. Since draft-ietf-quic-http-19 * SETTINGS_NUM_PLACEHOLDERS is 0x9 (#2443,#2530) * Non-zero bits in the Empty field of the PRIORITY frame MAY be treated as an error (#2501) B.15. Since draft-ietf-quic-http-18 * Resetting streams following a GOAWAY is recommended, but not required (#2256,#2457) * Use variable-length integers throughout (#2437,#2233,#2253,#2275) Bishop Expires 18 June 2021 [Page 67] Internet-Draft HTTP/3 December 2020 - Variable-length frame types, stream types, and settings identifiers - Renumbered stream type assignments - Modified associated reserved values * Frame layout switched from Length-Type-Value to Type-Length-Value (#2395,#2235) * Specified error code for servers receiving DUPLICATE_PUSH (#2497) * Use connection error for invalid PRIORITY (#2507, #2508) B.16. Since draft-ietf-quic-http-17 * HTTP_REQUEST_REJECTED is used to indicate a request can be retried (#2106, #2325) * Changed error code for GOAWAY on the wrong stream (#2231, #2343) B.17. Since draft-ietf-quic-http-16 * Rename "HTTP/QUIC" to "HTTP/3" (#1973) * Changes to PRIORITY frame (#1865, #2075) - Permitted as first frame of request streams - Remove exclusive reprioritization - Changes to Prioritized Element Type bits * Define DUPLICATE_PUSH frame to refer to another PUSH_PROMISE (#2072) * Set defaults for settings, allow request before receiving SETTINGS (#1809, #1846, #2038) * Clarify message processing rules for streams that aren''t closed (#1972, #2003) * Removed reservation of error code 0 and moved HTTP_NO_ERROR to this value (#1922) * Removed prohibition of zero-length DATA frames (#2098) Bishop Expires 18 June 2021 [Page 68] Internet-Draft HTTP/3 December 2020 B.18. Since draft-ietf-quic-http-15 Substantial editorial reorganization; no technical changes. B.19. Since draft-ietf-quic-http-14 * Recommend sensible values for QUIC transport parameters (#1720,#1806) * Define error for missing SETTINGS frame (#1697,#1808) * Setting values are variable-length integers (#1556,#1807) and do not have separate maximum values (#1820) * Expanded discussion of connection closure (#1599,#1717,#1712) * HTTP_VERSION_FALLBACK falls back to HTTP/1.1 (#1677,#1685) B.20. Since draft-ietf-quic-http-13 * Reserved some frame types for grease (#1333, #1446) * Unknown unidirectional stream types are tolerated, not errors; some reserved for grease (#1490, #1525) * Require settings to be remembered for 0-RTT, prohibit reductions (#1541, #1641) * Specify behavior for truncated requests (#1596, #1643) B.21. Since draft-ietf-quic-http-12 * TLS SNI extension isn''t mandatory if an alternative method is used (#1459, #1462, #1466) * Removed flags from HTTP/3 frames (#1388, #1398) * Reserved frame types and settings for use in preserving extensibility (#1333, #1446) * Added general error code (#1391, #1397) * Unidirectional streams carry a type byte and are extensible (#910,#1359) * Priority mechanism now uses explicit placeholders to enable persistent structure in the tree (#441,#1421,#1422) Bishop Expires 18 June 2021 [Page 69] Internet-Draft HTTP/3 December 2020 B.22. Since draft-ietf-quic-http-11 * Moved QPACK table updates and acknowledgments to dedicated streams (#1121, #1122, #1238) B.23. Since draft-ietf-quic-http-10 * Settings need to be remembered when attempting and accepting 0-RTT (#1157, #1207) B.24. Since draft-ietf-quic-http-09 * Selected QCRAM for header compression (#228, #1117) * The server_name TLS extension is now mandatory (#296, #495) * Specified handling of unsupported versions in Alt-Svc (#1093, #1097) B.25. Since draft-ietf-quic-http-08 * Clarified connection coalescing rules (#940, #1024) B.26. Since draft-ietf-quic-http-07 * Changes for integer encodings in QUIC (#595,#905) * Use unidirectional streams as appropriate (#515, #240, #281, #886) * Improvement to the description of GOAWAY (#604, #898) * Improve description of server push usage (#947, #950, #957) B.27. Since draft-ietf-quic-http-06 * Track changes in QUIC error code usage (#485) B.28. Since draft-ietf-quic-http-05 * Made push ID sequential, add MAX_PUSH_ID, remove SETTINGS_ENABLE_PUSH (#709) * Guidance about keep-alive and QUIC PINGs (#729) * Expanded text on GOAWAY and cancellation (#757) B.29. Since draft-ietf-quic-http-04 Bishop Expires 18 June 2021 [Page 70] Internet-Draft HTTP/3 December 2020 * Cite RFC 5234 (#404) * Return to a single stream per request (#245,#557) * Use separate frame type and settings registries from HTTP/2 (#81) * SETTINGS_ENABLE_PUSH instead of SETTINGS_DISABLE_PUSH (#477) * Restored GOAWAY (#696) * Identify server push using Push ID rather than a stream ID (#702,#281) * DATA frames cannot be empty (#700) B.30. Since draft-ietf-quic-http-03 None. B.31. Since draft-ietf-quic-http-02 * Track changes in transport draft B.32. Since draft-ietf-quic-http-01 * SETTINGS changes (#181): - SETTINGS can be sent only once at the start of a connection; no changes thereafter - SETTINGS_ACK removed - Settings can only occur in the SETTINGS frame a single time - Boolean format updated * Alt-Svc parameter changed from "v" to "quic"; format updated (#229) * Closing the connection control stream or any message control stream is a fatal error (#176) * HPACK Sequence counter can wrap (#173) * 0-RTT guidance added * Guide to differences from HTTP/2 and porting HTTP/2 extensions added (#127,#242) Bishop Expires 18 June 2021 [Page 71] Internet-Draft HTTP/3 December 2020 B.33. Since draft-ietf-quic-http-00 * Changed "HTTP/2-over-QUIC" to "HTTP/QUIC" throughout (#11,#29) * Changed from using HTTP/2 framing within Stream 3 to new framing format and two-stream-per-request model (#71,#72,#73) * Adopted SETTINGS format from draft-bishop-httpbis-extended- settings-01 * Reworked SETTINGS_ACK to account for indeterminate inter-stream order (#75) * Described CONNECT pseudo-method (#95) * Updated ALPN token and Alt-Svc guidance (#13,#87) * Application-layer-defined error codes (#19,#74) B.34. Since draft-shade-quic-http2-mapping-00 * Adopted as base for draft-ietf-quic-http * Updated authors/editors list Acknowledgements The original authors of this specification were Robbie Shade and Mike Warres. The IETF QUIC Working Group received an enormous amount of support from many people. Among others, the following people provided substantial contributions to this document: * Bence Beky * Daan De Meyer * Martin Duke * Roy Fielding * Alan Frindell * Alessandro Ghedini * Nick Harper Bishop Expires 18 June 2021 [Page 72] Internet-Draft HTTP/3 December 2020 * Ryan Hamilton * Christian Huitema * Subodh Iyengar * Robin Marx * Patrick McManus * Luca Niccolini * 奥 一穂 (Kazuho Oku) * Lucas Pardue * Roberto Peon * Julian Reschke * Eric Rescorla * Martin Seemann * Ben Schwartz * Ian Swett * Willy Taureau * Martin Thomson * Dmitri Tikhonov * Tatsuhiro Tsujikawa A portion of Mike''s contribution was supported by Microsoft during his employment there. Author''s Address Mike Bishop (editor) Akamai Email: mbishop@evequefou.be Bishop Expires 18 June 2021 [Page 73]');
INSERT INTO "sources" VALUES(4,1,'https://news.ycombinator.com/item?id=31647033','https://news.ycombinator.com/item?id=31647033','RFC 9114 – HTTP/3 | Hacker News','2026-10-22T14:00:03+00:00','text/html; charset=utf-8','f51a946872892bb6707917cd777f4abcb99eec2d2c1e2a5acab314f106cbf22f','[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]');
INSERT INTO "sources" VALUES(5,1,'https://http2.github.io','https://http2.github.io','HTTP/2','2026-10-22T14:00:42+00:00','text/html; charset=utf-8','4cfc221493942ccc110ca9809828380d5544c77ee5f1623c55baf244208eb124','[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]');
INSERT INTO "sources" VALUES(6,1,'https://www.imperva.com/learn/performance/http2','https://www.imperva.com/learn/performance/http2/','What is HTTP/2 | How it Differs from HTTP/1.1 and SPDY | Imperva','2026-10-22T14:00:48+00:00','text/html; charset=UTF-8','83f6d081c251295438b4a39b8f1afb51b7a74828fba260b758cde592bd3ef4a5','[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]');
INSERT INTO "sources" VALUES(7,1,'https://www.cloudflare.com/learning/performance/what-is-http3','https://www.cloudflare.com/learning/performance/what-is-http3/','What is HTTP/3?','2026-10-22T14:01:30+00:00','text/html; charset=utf-8','3950f0e8ce54ef875d1ac27e84b286df4e4e0352e314ede4c0ebf54aee6addbb','[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]');
INSERT INTO "sources" VALUES(8,1,'https://www.fastly.com/learning/what-is-http-3','https://www.fastly.com/learning/what-is-http-3','What Is HTTP/3? Key Features, Benefits - Fastly | Fastly','2026-10-22T14:01:31+00:00','text/html','cdd3b5f1baf0559dc66cc4a0d08ffaf28e2a4f0c932d15c1c08b4ae679da22dc','[Text withheld in the public demo: the rights to redistribute this page are not cleared. The URL, title, retrieval date and content hash are kept.]');
CREATE TABLE subquestions (
    id INTEGER PRIMARY KEY,
    run_id INTEGER NOT NULL REFERENCES runs(id),
    question TEXT NOT NULL,
    evidence_requirements TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL
);
INSERT INTO "subquestions" VALUES(1,1,'What is the publication date of the HTTP/2 specification as an RFC?','["RFC publication date for HTTP/2", "RFC number for HTTP/2"]','evidence_collected');
INSERT INTO "subquestions" VALUES(2,1,'What is the publication date of the HTTP/3 specification as an RFC?','["RFC publication date for HTTP/3", "RFC number for HTTP/3"]','evidence_collected');
INSERT INTO "subquestions" VALUES(3,1,'Which transport layer protocol does HTTP/2 use?','["name of transport protocol used by HTTP/2", "description of how HTTP/2 uses TCP"]','evidence_collected');
INSERT INTO "subquestions" VALUES(4,1,'Which transport layer protocol does HTTP/3 use and how does it differ from HTTP/2''s transport?','["name of transport protocol used by HTTP/3", "description of HTTP/3''s use of QUIC instead of TCP"]','evidence_collected');
INSERT INTO "subquestions" VALUES(5,2,'Has Mistral AI released an official financial statement or annual report for fiscal year 2024 that includes net profit or loss?','["statement on release of financial results for fiscal year 2024", "indication of net profit or net loss in the report"]','collection_incomplete');
INSERT INTO "subquestions" VALUES(6,2,'What is the net profit or net loss reported by Mistral AI for fiscal year 2024, if any?','["numerical value of net profit or loss", "currency and time period (fiscal year 2024)"]','collection_incomplete');
INSERT INTO "subquestions" VALUES(7,2,'Is there an official, publicly accessible document—such as an annual report, press release, or regulatory filing—published by Mistral AI that discloses the financial results for fiscal year 2024?','["title and publication date of the document", "publisher (must be Mistral AI or authorized entity)", "direct link or citation to the source"]','collection_incomplete');
CREATE TABLE verification_result_evidence (
    result_id INTEGER NOT NULL REFERENCES verification_results(id),
    evidence_id INTEGER NOT NULL REFERENCES claim_evidence(id),
    PRIMARY KEY (result_id, evidence_id)
);
INSERT INTO "verification_result_evidence" VALUES(6,1);
INSERT INTO "verification_result_evidence" VALUES(7,2);
INSERT INTO "verification_result_evidence" VALUES(8,3);
INSERT INTO "verification_result_evidence" VALUES(9,4);
INSERT INTO "verification_result_evidence" VALUES(10,5);
INSERT INTO "verification_result_evidence" VALUES(12,6);
CREATE TABLE verification_result_passages (
    result_id INTEGER NOT NULL REFERENCES verification_results(id),
    passage_id TEXT NOT NULL REFERENCES passages(id),
    role TEXT NOT NULL CHECK (role IN ('claim_evidence', 'neighbour_context')),
    PRIMARY KEY (result_id, passage_id)
);
INSERT INTO "verification_result_passages" VALUES(6,'S5-P1','claim_evidence');
INSERT INTO "verification_result_passages" VALUES(7,'S1-P11','claim_evidence');
INSERT INTO "verification_result_passages" VALUES(8,'S2-P4','claim_evidence');
INSERT INTO "verification_result_passages" VALUES(9,'S2-P4','claim_evidence');
INSERT INTO "verification_result_passages" VALUES(10,'S2-P2','claim_evidence');
INSERT INTO "verification_result_passages" VALUES(12,'S1-P0','claim_evidence');
CREATE TABLE verification_results (
    id INTEGER PRIMARY KEY,
    claim_id INTEGER NOT NULL REFERENCES claims(id),
    stage TEXT NOT NULL,
    verdict TEXT NOT NULL,
    reason TEXT NOT NULL,
    model TEXT,
    model_call_id INTEGER REFERENCES model_calls(id),
    details TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    CHECK ((stage = 'integrity' AND verdict IN ('passed', 'failed'))
        OR (stage = 'semantic' AND verdict IN ('supported', 'partially_supported', 'unsupported', 'contradicted', 'error')))
);
INSERT INTO "verification_results" VALUES(1,1,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 1, "passage_ref": "S5-P1", "resolution": "resolved", "match": {"mode": "exact", "start": 43}, "ok": true}]}','2026-10-22T14:46:39+00:00');
INSERT INTO "verification_results" VALUES(2,2,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 2, "passage_ref": "S1-P11", "resolution": "resolved", "match": {"mode": "exact", "start": 528}, "ok": true}]}','2026-10-22T14:46:39+00:00');
INSERT INTO "verification_results" VALUES(3,3,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 3, "passage_ref": "S2-P4", "resolution": "resolved", "match": {"mode": "exact", "start": 228}, "ok": true}]}','2026-10-22T14:46:39+00:00');
INSERT INTO "verification_results" VALUES(4,4,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 4, "passage_ref": "S2-P4", "resolution": "resolved", "match": {"mode": "exact", "start": 414}, "ok": true}]}','2026-10-22T14:46:39+00:00');
INSERT INTO "verification_results" VALUES(5,5,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 5, "passage_ref": "S2-P2", "resolution": "resolved", "match": {"mode": "exact", "start": 295}, "ok": true}]}','2026-10-22T14:46:39+00:00');
INSERT INTO "verification_results" VALUES(6,1,'semantic','partially_supported','S5-P1 confirms that the HTTP/2 specification was published as RFC 9113, establishing the RFC number. However, the claim asks for the publication date, and the evidence provides only the RFC number without specifying when RFC 9113 was published.','anthropic/claude-haiku-4.5',25,'{"model_verdict": "partially_supported", "aspects": {"date": "missing", "quantity": "not_applicable", "entity": "ok", "attribution": "not_applicable", "scope": "ok", "causality": "not_applicable", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": ["the publication date of RFC 9113"], "conflicts": [], "evidence_used": ["S5-P1"], "context_passage_ids": ["S5-P0"], "used_claim_evidence_passages": ["S5-P1"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:46:43+00:00');
INSERT INTO "verification_results" VALUES(7,2,'semantic','supported','S1-P11 directly states: ''The string "h2" identifies the protocol where HTTP/2 uses Transport Layer Security (TLS)''. This exactly matches the claim that HTTP/2 uses TLS when identified by the "h2" string.','anthropic/claude-haiku-4.5',26,'{"model_verdict": "supported", "aspects": {"date": "not_applicable", "quantity": "not_applicable", "entity": "ok", "attribution": "not_applicable", "scope": "ok", "causality": "not_applicable", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": [], "conflicts": [], "evidence_used": ["S1-P11"], "context_passage_ids": ["S1-P10", "S1-P12"], "used_claim_evidence_passages": ["S1-P11"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:46:46+00:00');
INSERT INTO "verification_results" VALUES(8,3,'semantic','supported','S2-P4 directly states that ''HTTP/3 uses QUIC, a transport layer network protocol which uses user space congestion control over the User Datagram Protocol (UDP).'' This fully establishes the claim that HTTP/3 uses QUIC as its transport layer protocol.','anthropic/claude-haiku-4.5',27,'{"model_verdict": "supported", "aspects": {"date": "not_applicable", "quantity": "not_applicable", "entity": "ok", "attribution": "not_applicable", "scope": "ok", "causality": "not_applicable", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": [], "conflicts": [], "evidence_used": ["S2-P4"], "context_passage_ids": ["S2-P3", "S2-P5"], "used_claim_evidence_passages": ["S2-P4"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:46:49+00:00');
INSERT INTO "verification_results" VALUES(9,4,'semantic','supported','S2-P4 establishes that HTTP/3 uses QUIC over UDP while HTTP/2 uses TCP, and that QUIC provides native multiplexing avoiding head-of-line blocking where lost packets only impact affected streams.','anthropic/claude-haiku-4.5',29,'{"model_verdict": "supported", "aspects": {"date": "not_applicable", "quantity": "not_applicable", "entity": "ok", "attribution": "not_applicable", "scope": "ok", "causality": "ok", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": [], "conflicts": [], "evidence_used": ["S2-P4"], "context_passage_ids": ["S2-P3", "S2-P5"], "used_claim_evidence_passages": ["S2-P4"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:46:54+00:00');
INSERT INTO "verification_results" VALUES(10,5,'semantic','supported','S2-P2 directly states: ''On 28 October 2018 in a mailing list discussion, Mark Nottingham, Chair of the IETF HTTP and QUIC Working Groups, proposed renaming HTTP-over-QUIC to HTTP/3.'' This exactly matches the claim''s assertion about the date, the person, and the action taken.','anthropic/claude-haiku-4.5',30,'{"model_verdict": "supported", "aspects": {"date": "ok", "quantity": "not_applicable", "entity": "ok", "attribution": "ok", "scope": "ok", "causality": "not_applicable", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": [], "conflicts": [], "evidence_used": ["S2-P2"], "context_passage_ids": ["S2-P1", "S2-P3"], "used_claim_evidence_passages": ["S2-P2"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:46:56+00:00');
INSERT INTO "verification_results" VALUES(11,6,'integrity','passed','all evidence references resolve and every quote occurs in its passage (integrity only; this does not show support)',NULL,NULL,'{"references": [{"evidence_id": 6, "passage_ref": "S1-P0", "resolution": "resolved", "match": {"mode": "exact", "start": 19}, "ok": true}]}','2026-10-22T14:47:19+00:00');
INSERT INTO "verification_results" VALUES(12,6,'semantic','supported','S1-P0 explicitly states that RFC 9113 is the HTTP/2 specification and was published in June 2022. The cited passage confirms ''RFC 9113'', ''HTTP/2'', and ''Published: June 2022''.','anthropic/claude-haiku-4.5',34,'{"model_verdict": "supported", "aspects": {"date": "ok", "quantity": "ok", "entity": "ok", "attribution": "not_applicable", "scope": "ok", "causality": "not_applicable", "forecast_vs_observation": "ok", "qualifications": "ok"}, "unsupported_details": [], "conflicts": [], "evidence_used": ["S1-P0"], "context_passage_ids": ["S1-P1"], "used_claim_evidence_passages": ["S1-P0"], "used_neighbour_passages": [], "rubric": "attribution-v3"}','2026-10-22T14:47:21+00:00');
CREATE INDEX idx_associations_run ON source_associations(run_id, subquestion_id);
CREATE INDEX idx_model_calls_run ON model_calls(run_id, id);
CREATE INDEX idx_selections_run ON research_selections(run_id, id);
CREATE INDEX idx_sources_run ON sources(run_id);
CREATE INDEX idx_passages_source ON passages(source_id);
CREATE INDEX idx_events_run ON audit_events(run_id, id);
CREATE INDEX idx_attempts_run ON fetch_attempts(run_id, id);
CREATE INDEX idx_claims_run ON claims(run_id, id);
CREATE INDEX idx_claim_evidence_claim ON claim_evidence(claim_id, position);
CREATE INDEX idx_verification_claim ON verification_results(claim_id, stage, id);
CREATE TRIGGER claims_same_run BEFORE INSERT ON claims
BEGIN
    SELECT RAISE(ABORT, 'claim and subquestion must belong to the same run')
    WHERE (SELECT run_id FROM subquestions WHERE id = NEW.subquestion_id) IS NOT NEW.run_id;
    SELECT RAISE(ABORT, 'claim and its parent version must belong to the same run')
    WHERE NEW.parent_claim_id IS NOT NULL
      AND (SELECT run_id FROM claims WHERE id = NEW.parent_claim_id) IS NOT NEW.run_id;
END;
CREATE TRIGGER claim_evidence_same_run BEFORE INSERT ON claim_evidence
WHEN NEW.passage_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'evidence passage must belong to the claim''s run')
    WHERE (SELECT s.run_id FROM passages p JOIN sources s ON s.id = p.source_id WHERE p.id = NEW.passage_id)
          IS NOT (SELECT run_id FROM claims WHERE id = NEW.claim_id);
END;
CREATE TRIGGER result_evidence_same_claim BEFORE INSERT ON verification_result_evidence
BEGIN
    SELECT RAISE(ABORT, 'a verification result may only cite its own claim''s evidence')
    WHERE (SELECT claim_id FROM claim_evidence WHERE id = NEW.evidence_id)
          IS NOT (SELECT claim_id FROM verification_results WHERE id = NEW.result_id);
END;
CREATE TRIGGER result_passages_same_run BEFORE INSERT ON verification_result_passages
BEGIN
    SELECT RAISE(ABORT, 'a verification result may only use passages of its own run')
    WHERE (SELECT s.run_id FROM passages p JOIN sources s ON s.id = p.source_id WHERE p.id = NEW.passage_id)
          IS NOT (SELECT c.run_id FROM verification_results r JOIN claims c ON c.id = r.claim_id WHERE r.id = NEW.result_id);
END;
CREATE TRIGGER result_passages_no_update BEFORE UPDATE ON verification_result_passages
BEGIN SELECT RAISE(ABORT, 'verification results are immutable'); END;
CREATE TRIGGER result_passages_no_delete BEFORE DELETE ON verification_result_passages
BEGIN SELECT RAISE(ABORT, 'verification results are never deleted'); END;
CREATE TRIGGER claims_no_update BEFORE UPDATE ON claims
BEGIN SELECT RAISE(ABORT, 'claims are immutable; create a new version instead'); END;
CREATE TRIGGER claims_no_delete BEFORE DELETE ON claims
BEGIN SELECT RAISE(ABORT, 'claims are never deleted (rejected claims are kept)'); END;
CREATE TRIGGER claim_evidence_no_update BEFORE UPDATE ON claim_evidence
BEGIN SELECT RAISE(ABORT, 'claim evidence is immutable'); END;
CREATE TRIGGER claim_evidence_no_delete BEFORE DELETE ON claim_evidence
BEGIN SELECT RAISE(ABORT, 'claim evidence is never deleted'); END;
CREATE TRIGGER verification_results_no_update BEFORE UPDATE ON verification_results
BEGIN SELECT RAISE(ABORT, 'verification results are immutable'); END;
CREATE TRIGGER verification_results_no_delete BEFORE DELETE ON verification_results
BEGIN SELECT RAISE(ABORT, 'verification results are never deleted'); END;
CREATE INDEX idx_coverage_run ON coverage_assessments(run_id, round);
CREATE INDEX idx_tasks_run ON correction_tasks(run_id, planned_round);
CREATE INDEX idx_reports_run ON reports(run_id, id);
CREATE TRIGGER dispositions_same_run BEFORE INSERT ON claim_dispositions
BEGIN
    SELECT RAISE(ABORT, 'a claim may only be excluded within its own run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id) IS NOT NEW.run_id;
END;
CREATE TRIGGER coverage_support_same_run BEFORE INSERT ON coverage_supporting_claims
BEGIN
    SELECT RAISE(ABORT, 'a coverage assessment may only cite claims of its own run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id)
          IS NOT (SELECT run_id FROM coverage_assessments WHERE id = NEW.assessment_id);
END;
CREATE TRIGGER report_claims_eligible BEFORE INSERT ON report_claims
BEGIN
    SELECT RAISE(ABORT, 'report claim must belong to the report''s run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id) IS NOT (SELECT run_id FROM reports WHERE id = NEW.report_id);
    SELECT RAISE(ABORT, 'report claim text must equal the stored claim text exactly')
    WHERE NEW.claim_text IS NOT (SELECT text FROM claims WHERE id = NEW.claim_id);
    SELECT RAISE(ABORT, 'report claim version must equal the stored version')
    WHERE NEW.claim_version IS NOT (SELECT version FROM claims WHERE id = NEW.claim_id);
    SELECT RAISE(ABORT, 'only naturally drafted claims may enter a report')
    WHERE (SELECT origin FROM claims WHERE id = NEW.claim_id) IS NOT 'drafted';
    SELECT RAISE(ABORT, 'excluded claims may not enter a report')
    WHERE EXISTS (SELECT 1 FROM claim_dispositions WHERE claim_id = NEW.claim_id);
    SELECT RAISE(ABORT, 'superseded claim versions may not enter a report')
    WHERE EXISTS (SELECT 1 FROM claims WHERE parent_claim_id = NEW.claim_id);
    SELECT RAISE(ABORT, 'claim integrity has not passed')
    WHERE (SELECT verdict FROM verification_results WHERE claim_id = NEW.claim_id AND stage = 'integrity'
           ORDER BY id DESC LIMIT 1) IS NOT 'passed';
    SELECT RAISE(ABORT, 'claim is not supported')
    WHERE (SELECT verdict FROM verification_results WHERE claim_id = NEW.claim_id AND stage = 'semantic'
           ORDER BY id DESC LIMIT 1) IS NOT 'supported';
    SELECT RAISE(ABORT, 'semantic result must be the claim''s latest')
    WHERE NEW.semantic_result_id IS NOT (SELECT id FROM verification_results WHERE claim_id = NEW.claim_id
           AND stage = 'semantic' ORDER BY id DESC LIMIT 1);
END;
CREATE TRIGGER report_citations_used BEFORE INSERT ON report_citations
BEGIN
    SELECT RAISE(ABORT, 'a report citation must be a passage the verdict actually relied on')
    WHERE NOT EXISTS (
        SELECT 1 FROM verification_result_passages vp
        WHERE vp.passage_id = NEW.passage_id
          AND vp.result_id = (SELECT semantic_result_id FROM report_claims WHERE id = NEW.report_claim_id));
END;
CREATE TRIGGER report_omissions_same_run BEFORE INSERT ON report_omissions
BEGIN
    SELECT RAISE(ABORT, 'an omitted claim must belong to the report''s run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id) IS NOT (SELECT run_id FROM reports WHERE id = NEW.report_id);
END;
CREATE TRIGGER dispositions_no_update BEFORE UPDATE ON claim_dispositions
BEGIN SELECT RAISE(ABORT, 'exclusions are immutable'); END;
CREATE TRIGGER dispositions_no_delete BEFORE DELETE ON claim_dispositions
BEGIN SELECT RAISE(ABORT, 'exclusions are never deleted'); END;
CREATE TRIGGER coverage_no_update BEFORE UPDATE ON coverage_assessments
BEGIN SELECT RAISE(ABORT, 'coverage assessments are immutable'); END;
CREATE TRIGGER coverage_no_delete BEFORE DELETE ON coverage_assessments
BEGIN SELECT RAISE(ABORT, 'coverage assessments are never deleted'); END;
CREATE TRIGGER coverage_support_no_update BEFORE UPDATE ON coverage_supporting_claims
BEGIN SELECT RAISE(ABORT, 'coverage assessments are immutable'); END;
CREATE TRIGGER coverage_support_no_delete BEFORE DELETE ON coverage_supporting_claims
BEGIN SELECT RAISE(ABORT, 'coverage assessments are never deleted'); END;
CREATE TRIGGER reports_no_update BEFORE UPDATE ON reports
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER reports_no_delete BEFORE DELETE ON reports
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_sections_no_update BEFORE UPDATE ON report_sections
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_sections_no_delete BEFORE DELETE ON report_sections
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_claims_no_update BEFORE UPDATE ON report_claims
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_claims_no_delete BEFORE DELETE ON report_claims
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_citations_no_update BEFORE UPDATE ON report_citations
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_citations_no_delete BEFORE DELETE ON report_citations
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_gaps_no_update BEFORE UPDATE ON report_gaps
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_gaps_no_delete BEFORE DELETE ON report_gaps
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_omissions_no_update BEFORE UPDATE ON report_omissions
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_omissions_no_delete BEFORE DELETE ON report_omissions
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE INDEX idx_obligations_run ON coverage_obligations(run_id, requirement_key);
CREATE TRIGGER claim_relevance_valid BEFORE INSERT ON claim_relevance
BEGIN
    SELECT RAISE(ABORT, 'a relevance judgment may only concern a claim of its own run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id)
          IS NOT (SELECT c.run_id FROM obligation_assessments o JOIN coverage_assessments c ON c.id = o.assessment_id
                  WHERE o.id = NEW.obligation_assessment_id);
    SELECT RAISE(ABORT, 'the requirement of a relevance judgment must be the requirement of its obligation assessment')
    WHERE NEW.requirement_key IS NOT (SELECT o.requirement_key FROM obligation_assessments oa JOIN coverage_obligations o ON o.id = oa.obligation_id
                                      WHERE oa.id = NEW.obligation_assessment_id);
END;
CREATE TRIGGER claim_relevance_no_update BEFORE UPDATE ON claim_relevance
BEGIN SELECT RAISE(ABORT, 'coverage assessments are immutable'); END;
CREATE TRIGGER claim_relevance_no_delete BEFORE DELETE ON claim_relevance
BEGIN SELECT RAISE(ABORT, 'coverage assessments are never deleted'); END;
CREATE TRIGGER report_claim_roles_no_update BEFORE UPDATE ON report_claim_roles
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_claim_roles_no_delete BEFORE DELETE ON report_claim_roles
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER report_relevance_no_update BEFORE UPDATE ON report_relevance
BEGIN SELECT RAISE(ABORT, 'reports are immutable snapshots'); END;
CREATE TRIGGER report_relevance_no_delete BEFORE DELETE ON report_relevance
BEGIN SELECT RAISE(ABORT, 'reports are never deleted'); END;
CREATE TRIGGER obligations_same_run BEFORE INSERT ON coverage_obligations
BEGIN
    SELECT RAISE(ABORT, 'an obligation must belong to a subquestion of its own run')
    WHERE (SELECT run_id FROM subquestions WHERE id = NEW.subquestion_id) IS NOT NEW.run_id;
END;
CREATE TRIGGER obligation_assessments_same_run BEFORE INSERT ON obligation_assessments
BEGIN
    SELECT RAISE(ABORT, 'an obligation assessment must stay within one run')
    WHERE (SELECT run_id FROM coverage_obligations WHERE id = NEW.obligation_id)
          IS NOT (SELECT run_id FROM coverage_assessments WHERE id = NEW.assessment_id);
END;
CREATE TRIGGER obligation_support_same_run BEFORE INSERT ON obligation_supporting_claims
BEGIN
    SELECT RAISE(ABORT, 'an obligation assessment may only cite claims of its own run')
    WHERE (SELECT run_id FROM claims WHERE id = NEW.claim_id)
          IS NOT (SELECT c.run_id FROM obligation_assessments o JOIN coverage_assessments c ON c.id = o.assessment_id
                  WHERE o.id = NEW.obligation_assessment_id);
END;
CREATE TRIGGER obligations_no_update BEFORE UPDATE ON coverage_obligations
BEGIN SELECT RAISE(ABORT, 'coverage obligations are immutable'); END;
CREATE TRIGGER obligations_no_delete BEFORE DELETE ON coverage_obligations
BEGIN SELECT RAISE(ABORT, 'coverage obligations are never deleted'); END;
CREATE TRIGGER obligation_assessments_no_update BEFORE UPDATE ON obligation_assessments
BEGIN SELECT RAISE(ABORT, 'coverage assessments are immutable'); END;
CREATE TRIGGER obligation_assessments_no_delete BEFORE DELETE ON obligation_assessments
BEGIN SELECT RAISE(ABORT, 'coverage assessments are never deleted'); END;
CREATE TRIGGER obligation_support_no_update BEFORE UPDATE ON obligation_supporting_claims
BEGIN SELECT RAISE(ABORT, 'coverage assessments are immutable'); END;
CREATE TRIGGER obligation_support_no_delete BEFORE DELETE ON obligation_supporting_claims
BEGIN SELECT RAISE(ABORT, 'coverage assessments are never deleted'); END;
COMMIT;
